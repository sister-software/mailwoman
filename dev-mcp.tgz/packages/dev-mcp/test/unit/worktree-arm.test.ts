/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   The worktree arm's interface, exercised against a throwaway git repo rather than this one.
 *
 *   Deliberately not a geocode: building an engine costs minutes and needs the data root, so a test that ran one
 *   would be a slow integration test wearing a unit test's clothes. What is asserted here is the implementation that
 *   was actually hard — that a ref arm runs the REF's source and a `worktree` arm runs the uncommitted one,
 *   that a dirty tree says so in the commit it reports, and that neither leaves litter behind.
 */

import { pathExists } from "@mailwoman/core/fs/readers"
import { temporaryDirectory } from "@mailwoman/core/fs/temporary"
import { createSymbolicLink, makeDirectories, writeLocalJSONFile, writeLocalTextFile } from "@mailwoman/core/fs/writers"
import { stringifyJSON } from "@mailwoman/core/json"
import { runFileSync } from "@mailwoman/core/process"
import { runWorktreeArm, WORKING_TREE_REF } from "@mailwoman/dev-mcp/worktree/arm"
import { join } from "path-ts"
import { Globerator } from "spliterator/node/fs"
import { afterAll, describe, expect, it } from "vitest"

const fixtures = new AsyncDisposableStack()

afterAll(() => fixtures.disposeAsync())

/**
 * A minimal git repo whose "pipeline" is one file, plus a `node_modules` the farm can mirror.
 *
 * `mailwoman/geocode` is stubbed as a real package directory so the runner's import
 * resolves without this test needing the monorepo.
 * That is the same resolution path the real arm uses.
 *
 * A stub here proves the farm and the subprocess, and the engine is exercised
 * for real by the tools that call this.
 */
async function fakeRepo(marker: string): Promise<string> {
	const root = String(fixtures.use(await temporaryDirectory("mwdev-wt-test-")).path)

	await makeDirectories(join(root, "packages", "mailwoman"))
	await writeLocalJSONFile({ name: "root", workspaces: ["packages/mailwoman"] }, join(root, "package.json"))

	await writeLocalJSONFile(
		{
			name: "mailwoman",
			// Mirrors the real package after the prefix fold: `geocode-session.ts` became `geocode/session.ts`
			// behind the `./geocode` directory entry, which is the subpath the arm runner imports.
			exports: { "./geocode": { node: "./geocode/index.ts", default: "./geocode/index.ts" } },
		},
		join(root, "packages", "mailwoman", "package.json")
	)

	await writeLocalTextFile(
		`export async function createGeocodeSession() {
			return {
				geocode: async (input) => ({ result: { lat: 1, lon: 2, resolution_tier: ${stringifyJSON(marker)}, components: { locality: input } } }),
				[Symbol.dispose]: () => {},
			}
		}\n`,
		join(root, "packages", "mailwoman", "geocode", "index.ts")
	)

	// The workspace link yarn would have installed.
	// Both arms need it and for different reasons: the worktree arm resolves through it
	// directly, and the ref arm's farm mirrors this directory to build its own.
	// So an empty node_modules here would test neither path.
	await makeDirectories(join(root, "node_modules"))
	await createSymbolicLink(join(root, "packages", "mailwoman"), join(root, "node_modules", "mailwoman"))
	// Untracked and ignored, so the "does not touch the caller's tree" assertion compares
	// a clean status to a clean status rather than to one this helper dirtied.
	await writeLocalTextFile("node_modules\n", join(root, ".gitignore"))

	runFileSync("git", ["init", "-q", "-b", "main"], { cwd: root })
	runFileSync("git", ["config", "user.email", "t@example.com"], { cwd: root })
	runFileSync("git", ["config", "user.name", "T"], { cwd: root })
	runFileSync("git", ["add", "-A"], { cwd: root })
	runFileSync("git", ["commit", "-qm", "initial"], { cwd: root })

	return root
}

const OPTIONS = {}

describe("runWorktreeArm — a ref arm runs THAT ref's source", () => {
	it("answers from the committed source, not the working tree", async () => {
		const root = await fakeRepo("committed")

		// Edit without committing.
		// A ref arm must not see this.
		// That is the whole distinction it sells.
		await writeLocalTextFile(
			`export async function createGeocodeSession() {
				return { geocode: async () => ({ result: { lat: 9, lon: 9, resolution_tier: "uncommitted", components: {} } }), [Symbol.dispose]: () => {} }
			}\n`,
			join(root, "packages", "mailwoman", "geocode", "index.ts")
		)

		const result = await runWorktreeArm({ repoRoot: root, ref: "HEAD", inputs: ["x"], options: OPTIONS })

		expect(result.answers[0]!.tier).toBe("committed")
		expect(result.commit).not.toContain("+dirty")
	})
})

describe("runWorktreeArm — the WORKTREE arm runs the UNCOMMITTED source", () => {
	it("answers from the working tree and marks the commit dirty", async () => {
		const root = await fakeRepo("committed")

		await writeLocalTextFile(
			`export async function createGeocodeSession() {
				return { geocode: async () => ({ result: { lat: 9, lon: 9, resolution_tier: "uncommitted", components: {} } }), [Symbol.dispose]: () => {} }
			}\n`,
			join(root, "packages", "mailwoman", "geocode", "index.ts")
		)

		const result = await runWorktreeArm({
			repoRoot: root,
			ref: WORKING_TREE_REF,
			inputs: ["x"],
			options: OPTIONS,
		})

		expect(result.answers[0]!.tier).toBe("uncommitted")
		// A dirty tree is not its head.
		// Reporting the bare sha would let a result claim a commit it did not run.
		expect(result.commit).toContain("+dirty")
	})

	it("leaves no runner behind in the operator's own checkout", async () => {
		const root = await fakeRepo("committed")

		await runWorktreeArm({ repoRoot: root, ref: WORKING_TREE_REF, inputs: ["x"], options: OPTIONS })

		expect(await pathExists(join(root, ".mwdev-arm-runner.ts"))).toBe(false)
	})

	it("removes the runner even when the child throws", async () => {
		const root = await fakeRepo("committed")

		await writeLocalTextFile(
			`export async function createGeocodeSession() { throw new Error("boom") }\n`,
			join(root, "packages", "mailwoman", "geocode", "index.ts")
		)

		await expect(
			runWorktreeArm({ repoRoot: root, ref: WORKING_TREE_REF, inputs: ["x"], options: OPTIONS })
		).rejects.toThrow(/boom|Command failed/)

		expect(await pathExists(join(root, ".mwdev-arm-runner.ts"))).toBe(false)
	})
})

describe("runWorktreeArm — cleanup", () => {
	it("registers no worktree after a ref arm completes", async () => {
		const root = await fakeRepo("committed")

		await runWorktreeArm({ repoRoot: root, ref: "HEAD", inputs: ["x"], options: OPTIONS })

		const listed = runFileSync("git", ["worktree", "list"], { cwd: root, encoding: "utf8" })

		// The main checkout is always listed. a leaked worktree would be a second line.
		// oxlint-disable-next-line mailwoman/prefer-spliterator -- the test creates at most one extra worktree
		expect(listed.trim().split("\n")).toHaveLength(1)
	})

	it("does not touch the caller's HEAD or working tree", async () => {
		const root = await fakeRepo("committed")
		const before = runFileSync("git", ["status", "--porcelain"], { cwd: root, encoding: "utf8" })
		const head = runFileSync("git", ["rev-parse", "HEAD"], { cwd: root, encoding: "utf8" })

		await runWorktreeArm({ repoRoot: root, ref: "HEAD", inputs: ["x"], options: OPTIONS })

		expect(runFileSync("git", ["status", "--porcelain"], { cwd: root, encoding: "utf8" })).toBe(before)
		expect(runFileSync("git", ["rev-parse", "HEAD"], { cwd: root, encoding: "utf8" })).toBe(head)
		// A stash-based arm would have moved these.
		// A worktree cannot, which is why it is a worktree.
		expect(await Globerator.from("*", { cwd: root, absolute: false, onlyFiles: false }).toArray()).toContain("packages")
	})
})

describe("runWorktreeArm — per-input failures", () => {
	it("reports a throwing input as an errored answer rather than failing the batch", async () => {
		const root = await fakeRepo("committed")

		await writeLocalTextFile(
			`export async function createGeocodeSession() {
				return {
					geocode: async (input) => {
						if (input === "bad") throw new Error("nope")
						return { result: { lat: 1, lon: 2, resolution_tier: "ok", components: {} } }
					},
					[Symbol.dispose]: () => {},
				}
			}\n`,
			join(root, "packages", "mailwoman", "geocode", "index.ts")
		)

		const result = await runWorktreeArm({
			repoRoot: root,
			ref: WORKING_TREE_REF,
			inputs: ["good", "bad"],
			options: OPTIONS,
		})

		expect(result.answers).toHaveLength(2)
		expect(result.answers[0]!.tier).toBe("ok")
		expect(result.answers[1]!.lat).toBeNull()
		expect(result.answers[1]!.error).toContain("nope")
	})
})
