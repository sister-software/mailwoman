/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Unified runtime loader for the street-morphology FST — the #1315 street-context check's signal
 *   source, previously rebuilt from the libpostal dictionaries per process at three duplicate call
 *   sites (runtime pipeline / parity eval / neural harness). The sealed artifact
 *   (`fst-street-morphology.bin`, built by `mailwoman gazetteer build street-morphology`) replaces
 *   those per-process builds. this loader is the one resolution ladder every node call site shares:
 *
 *   1. An explicit `artifactPath` (e.g. the weights-package sibling surfaced by
 *      `NeuralAddressClassifier.streetMorphologyPath`). When given, it is the only artifact probed.
 *   2. Otherwise the staged sealed artifact at `$MAILWOMAN_DATA_ROOT/wof/fst-street-morphology.bin`.
 *   3. Build-from-dictionaries fallback: `buildStreetMorphologyFST` over core's bundled libpostal
 *      `street_types.txt` files — the pre-artifact behavior, kept so a missing artifact degrades to
 *      a per-process build rather than a crash.
 *
 *   A present-but-unreadable artifact reports through `onWarn` and falls through to the build rung.
 *   Browsers can't take the fallback (no fs) — they deserialize the same artifact via
 *   `fst-deserialize-web.ts` (see the docs demo loader).
 */

import { dataRootPath } from "@mailwoman/core/data-root"
import { pathExists, readLocalBuffer } from "@mailwoman/core/fs/readers"
import { resourceDictionaryPath } from "@mailwoman/core/paths"
import type { PathBuilder, PathBuilderLike } from "path-ts"

import type { FSTMatcher } from "#fst/matcher"
import { deserializeFST, readFSTProvenance } from "#fst/serialize"
import type { FSTProvenance } from "#fst/types"
import { buildStreetMorphologyFST } from "#street/morphology/fst/builder"

/**
 * The sealed artifact's canonical filename — identical in the data-root staging dir
 * and as a weights-package sibling.
 */
export const STREET_MORPHOLOGY_ARTIFACT_FILENAME = "fst-street-morphology.bin"

/**
 * The staged artifact's default location: `$MAILWOMAN_DATA_ROOT/wof/fst-street-morphology.bin`.
 */
export function defaultStreetMorphologyArtifactPath(): PathBuilder {
	return dataRootPath("wof", STREET_MORPHOLOGY_ARTIFACT_FILENAME)
}

export interface LoadStreetMorphologyFSTOpts {
	/**
	 * Explicit artifact path (e.g. A weights-package sibling).
	 *
	 * When given it is the only artifact probed — missing or unreadable degrades
	 * straight to the dictionary build, never a throw.
	 */
	artifactPath?: PathBuilderLike
	/**
	 * Dictionaries dir for the build fallback.
	 *
	 * Defaults to core's bundled libpostal dictionaries.
	 */
	dictionariesDir?: PathBuilderLike
	/**
	 * Unreadable-artifact diagnostics.
	 *
	 * Defaults to silent (the caller owns its warn channel).
	 */
	onWarn?: (message: string) => void
}

export interface LoadedStreetMorphologyFST {
	matcher: FSTMatcher
	/**
	 * Which rung produced the matcher: a sealed-artifact deserialize, or the per-process dictionary build.
	 */
	source: "artifact" | "built"
	/**
	 * The artifact path when `source === "artifact"`.
	 */
	path?: PathBuilderLike
	/**
	 * Build provenance — read from the artifact trailer, or carried fresh off the fallback build.
	 */
	provenance?: FSTProvenance
}

/**
 * Load the street-morphology matcher: sealed artifact first, per-process
 * dictionary build as the degrade path.
 */
export async function loadStreetMorphologyFST(
	opts: LoadStreetMorphologyFSTOpts = {}
): Promise<LoadedStreetMorphologyFST> {
	const warn = opts.onWarn ?? (() => {})
	const artifactPath = opts.artifactPath ?? defaultStreetMorphologyArtifactPath()

	if (await pathExists(artifactPath)) {
		try {
			const buf = await readLocalBuffer(artifactPath)
			const matcher = deserializeFST(buf)
			const provenance = readFSTProvenance(buf)

			return { matcher, source: "artifact", path: artifactPath, ...(provenance ? { provenance } : {}) }
		} catch (error) {
			warn(
				`street-morphology artifact at ${artifactPath} unreadable (${(error as Error).message}) — falling back to the dictionary build`
			)
		}
	}

	const built = await buildStreetMorphologyFST({
		dictionariesDir: (opts.dictionariesDir ?? resourceDictionaryPath("libpostal")).toString(),
	})

	return { matcher: built.matcher, source: "built", provenance: built.provenance }
}
