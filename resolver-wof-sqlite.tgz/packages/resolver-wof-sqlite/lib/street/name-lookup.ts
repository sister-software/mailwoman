/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   #727 stage-2 phase 4c — the SQLite backend for {@link StreetLocalityEvidence}.
 *
 *   Reads a street-name index (the FR instance = BAN `street-centroids-fr.db`, a `street_centroid`
 *   table of `street_norm × locality_base × postcode` rows) and answers "does this street surface
 *   exist as a name" for the k-best rerank. Sync-by-interface, `readOnly`, prepared statements,
 *   graceful-degrade on a tableless extract — the same reader discipline as `AddressPointSqliteLookup`.
 *
 *   The fold interface: the surface is folded with {@link foldStreetSurface} (the shared function),
 *   and the DB's `street_norm` column must have been built with that same fold or every hyphenated /
 *   apostrophe'd street silently misses. The current `street-centroids-fr.db` predates the interface
 *   fold (it folded without hyphen/apostrophe normalization); it must be rebuilt with
 *   `foldStreetSurface` + a `street_norm` index before this backend is wired in production. Until
 *   then this class is correct-by-construction against a fixture built with the interface fold, and
 *   the production rebuild is a tracked BAN-sdk follow-up.
 */

import { foldStreetSurface, type StreetEvidenceScope, type StreetLocalityEvidence } from "@mailwoman/resolver"
import { DatabaseClient } from "@mailwoman/sqlite/client"

import type { WOFDatabase } from "#schema"
import { hasColumn, hasTable } from "#sqlite-utils"

export interface SQLiteStreetNameLookupOpts {
	/**
	 * ISO-2 (upper-case) countries this index answers for.
	 *
	 * Default `["FR"]` (the BAN street-centroids instance).
	 */
	countries?: Iterable<string>
	/**
	 * Table name.
	 *
	 * Default `street_centroid`.
	 */
	table?: string
}

/**
 * A {@link StreetLocalityEvidence} backed by a street-name SQLite index.
 *
 * Positive evidence only: any doubt (missing table, read miss) returns `false`,
 * so the rerank fails open to the model's ranking.
 */
export class SQLiteStreetNameLookup implements StreetLocalityEvidence, Disposable {
	readonly countries: ReadonlySet<string>
	readonly #db: DatabaseClient<WOFDatabase>
	readonly #byName: ReturnType<DatabaseClient["prepare"]> | undefined
	readonly #byNameLocality: ReturnType<DatabaseClient["prepare"]> | undefined
	readonly #byNamePostcode: ReturnType<DatabaseClient["prepare"]> | undefined

	constructor(dbPath: string, opts: SQLiteStreetNameLookupOpts = {}) {
		this.countries = new Set([...(opts.countries ?? ["FR"])].map((c) => c.toUpperCase()))
		this.#db = new DatabaseClient<WOFDatabase>(dbPath, { readOnly: true })
		const table = opts.table ?? "street_centroid"

		// Degrade gracefully on an empty/tableless extract.
		// A no-op miss, never a crash (#568 discipline).
		if (hasTable(this.#db, table)) {
			// Prefer the #727 phase-4c `name_key` column
			// (foldStreetSurface, indexed by `idx_sc_name` for a direct seek); fall back to
			// `street_norm` on a pre-rebuild extract (a skip-scan, but correct).
			// The fold used to build `name_key` must match `foldStreetSurface` here (the fold-parity interface).
			const keyCol = hasColumn(this.#db, table, "name_key") ? "name_key" : "street_norm"
			this.#byName = this.#db.prepare(`SELECT 1 FROM ${table} WHERE ${keyCol} = ? LIMIT 1`)

			this.#byNameLocality = this.#db.prepare(
				`SELECT 1 FROM ${table} WHERE ${keyCol} = ? AND locality_base = ? LIMIT 1`
			)

			this.#byNamePostcode = this.#db.prepare(`SELECT 1 FROM ${table} WHERE ${keyCol} = ? AND postcode = ? LIMIT 1`)
		}
	}

	hasStreetName(streetSurface: string, scope?: StreetEvidenceScope): boolean {
		if (!this.#byName) return false
		const norm = foldStreetSurface(streetSurface)

		if (!norm) return false

		// Scoped lookups tighten precision when the hypothesis carries a locality/postcode.
		// A scoped miss falls back to the unscoped probe (index incompleteness in the scope
		// column is not evidence of absence — positive-evidence rule).
		if (
			scope?.locality &&
			this.#byNameLocality &&
			this.#byNameLocality.get(norm, foldStreetSurface(scope.locality)) !== undefined
		) {
			return true
		}

		if (scope?.postcode && this.#byNamePostcode && this.#byNamePostcode.get(norm, scope.postcode) !== undefined) {
			return true
		}

		return this.#byName.get(norm) !== undefined
	}

	[Symbol.dispose](): void {
		this.#db[Symbol.dispose]()
	}
}
