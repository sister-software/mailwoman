/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   #920 — the GeoNames postal fold's two laws, as tests: (1) the name law (stored names match the
 *   sanitized-query token shape — spaced CZ and dashed PL forms measured broken/worse in the
 *   night-31 experiment), (2) medoid centroids (the member point, never an off-settlement mean —
 *   the p50-tax law).
 */

import { temporaryDirectory } from "@mailwoman/core/fs/temporary"
import { writeLocalTextFile } from "@mailwoman/core/fs/writers"
import { GEONAMES_POSTAL_ID_BASE } from "@mailwoman/core/resolver/synthetic-id-ranges"
import { ingestGeonamesPostal, normalizePostcodeName } from "@mailwoman/resolver-wof-sqlite/geonames"
import type { WOFDatabase } from "@mailwoman/resolver-wof-sqlite/schema"
import { DatabaseClient } from "@mailwoman/sqlite/client"
import { join } from "path-ts"
import { describe, expect, it } from "vitest"

describe("normalizePostcodeName (the #920 name law)", () => {
	it("strips the spaced CZ/SK form to the query-token shape", () => {
		expect(normalizePostcodeName("110 00")).toBe("11000")
	})

	it("strips the dashed PL form", () => {
		expect(normalizePostcodeName("11-041")).toBe("11041")
	})

	it("keeps plain alphanumerics whole", () => {
		expect(normalizePostcodeName("8281")).toBe("8281")
		expect(normalizePostcodeName("AD500")).toBe("AD500")
	})
})

async function fixtureDB(): Promise<DatabaseClient<WOFDatabase>> {
	const db = DatabaseClient.temp<WOFDatabase>()

	db.exec(`
		CREATE TABLE spr (
			id INTEGER PRIMARY KEY, parent_id INTEGER NOT NULL DEFAULT -1, name TEXT NOT NULL DEFAULT '',
			placetype TEXT NOT NULL DEFAULT '', country TEXT NOT NULL DEFAULT '',
			latitude REAL NOT NULL DEFAULT 0, longitude REAL NOT NULL DEFAULT 0,
			min_latitude REAL NOT NULL DEFAULT 0, min_longitude REAL NOT NULL DEFAULT 0,
			max_latitude REAL NOT NULL DEFAULT 0, max_longitude REAL NOT NULL DEFAULT 0,
			is_current INTEGER NOT NULL DEFAULT 1, is_deprecated INTEGER NOT NULL DEFAULT 0,
			is_ceased INTEGER NOT NULL DEFAULT 0, is_superseded INTEGER NOT NULL DEFAULT 0,
			is_superseding INTEGER NOT NULL DEFAULT 0, lastmodified INTEGER NOT NULL DEFAULT 0
		);
		CREATE TABLE names (id INTEGER NOT NULL, name TEXT, placetype TEXT, country TEXT, language TEXT, lastmodified INTEGER);
	`)

	return db
}

describe("ingestGeonamesPostal", () => {
	it("folds one medoid row per normalized code, with the display form as an alt name", async () => {
		await using dirDirectory = await temporaryDirectory("gn-postal-")
		const dir = dirDirectory.path

		// Three members of "110 00": two clustered at ~50.08, one outlier pulling the mean north.
		// The medoid must be one of the real points (the cluster member nearest the mean), never the mean itself.
		await writeLocalTextFile(
			[
				"CZ\t110 00\tPraha 1\tPraha\t10\t\t\t\t\t50.08\t14.42\t4",
				"CZ\t110 00\tPraha 1-x\tPraha\t10\t\t\t\t\t50.09\t14.43\t4",
				"CZ\t110 00\tOutlier\tPraha\t10\t\t\t\t\t50.30\t14.60\t4",
				"CZ\t500 02\tHradec\tKralovehradecky\t\t\t\t\t\t50.21\t15.83\t4",
			].join("\n"),
			join(dir, "CZ.txt")
		)

		const db = await fixtureDB()
		const result = await ingestGeonamesPostal(db, ["CZ"], dir)

		expect(result.inserted).toBe(2)
		expect(result.byCountry.CZ).toBe(2)

		const row = db.prepare("SELECT id, name, placetype, latitude, longitude FROM spr WHERE name = '11000'").get() as {
			id: number
			name: string
			placetype: string
			latitude: number
			longitude: number
		}

		expect(row.placetype).toBe("postalcode")
		expect(row.id).toBeGreaterThanOrEqual(GEONAMES_POSTAL_ID_BASE)
		// Medoid = a real member (50.09 is nearest the outlier-pulled mean), not the mean (~50.157).
		expect([50.08, 50.09, 50.3]).toContain(row.latitude)
		expect(row.latitude).toBe(50.09)

		const names = db
			.prepare("SELECT name FROM names WHERE id = ? ORDER BY name")
			.all(row.id)
			.map((r) => (r as { name: string }).name)

		expect(names).toEqual(["110 00", "11000"])
	})

	it("reports a code whose rows all name one point", async () => {
		await using dirDirectory = await temporaryDirectory("gn-postal-degenerate-")
		const dir = dirDirectory.path

		// TH 10230 verbatim: two Bangkok districts published at one coordinate ~90 km from either.
		// The medoid has nothing to choose between, and the result must say so
		// rather than presenting two rows as agreement.
		await writeLocalTextFile(
			[
				"TH\t10230\tLat Phrao\tBangkok\t10\t\t\t\t\t14.3333\t99.9167\t1",
				"TH\t10230\tKhanna Yao\tBangkok\t10\t\t\t\t\t14.3333\t99.9167\t1",
				"TH\t10120\tYan Nawa\tBangkok\t10\t\t\t\t\t13.6969\t100.5407\t4",
			].join("\n"),
			join(dir, "TH.txt")
		)

		const db = await fixtureDB()
		const result = await ingestGeonamesPostal(db, ["TH"], dir)

		expect(result.byCountry.TH).toBe(2)
		// 10120 is a single row — one point by construction, and not what this counter is about.
		expect(result.singlePointByCountry.TH).toBe(1)

		const row = db.prepare("SELECT latitude, longitude FROM spr WHERE name = '10230'").get() as {
			latitude: number
			longitude: number
		}

		expect([row.latitude, row.longitude]).toEqual([14.3333, 99.9167])
	})

	it("reports missing country files instead of throwing", async () => {
		await using dirDirectory = await temporaryDirectory("gn-postal-empty-")
		const dir = dirDirectory.path
		const db = await fixtureDB()
		const result = await ingestGeonamesPostal(db, ["FI"], dir)

		expect(result.inserted).toBe(0)
		expect(result.missing).toEqual(["FI"])
	})
})
