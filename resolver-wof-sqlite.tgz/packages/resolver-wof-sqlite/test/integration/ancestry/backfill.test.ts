/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 */

import { temporaryDirectory, type TemporaryDirectory } from "@mailwoman/core/fs/temporary"
import { makeDirectories, writeLocalJSONFile } from "@mailwoman/core/fs/writers"
import { backfillAncestorsFromHierarchy, discoverAdminDataRoots } from "@mailwoman/resolver-wof-sqlite/ancestry"
import type { WOFDatabase } from "@mailwoman/resolver-wof-sqlite/schema"
import { DatabaseClient } from "@mailwoman/sqlite/client"
import { join } from "path-ts"
import { afterAll, beforeAll, expect, test } from "vitest"

let root: TemporaryDirectory

beforeAll(async () => {
	root = await temporaryDirectory("ancestry-backfill-")
	// Nested lab layout: <root.path>/whosonfirst-data/whosonfirst-data-admin-us/data
	await makeDirectories(root.resolve("whosonfirst-data", "whosonfirst-data-admin-us", "data"))
	// Flat layout: <root.path>/whosonfirst-data-admin-gb/data
	await makeDirectories(root.resolve("whosonfirst-data-admin-gb", "data"))
	// A non-WOF sibling dir that must be ignored
	await makeDirectories(root.resolve("some-other-repo", "data"))
	// A `data` dir buried too deep (depth 3+) that must not be discovered
	await makeDirectories(root.resolve("whosonfirst-data", "nested", "deeper", "data"))
})

afterAll(() => root[Symbol.asyncDispose]())

test("discoverAdminDataRoots: finds nested + flat whosonfirst data roots, skips non-WOF + too-deep", async () => {
	const roots = await discoverAdminDataRoots(root.path)

	expect(roots).toContain(root.resolve("whosonfirst-data", "whosonfirst-data-admin-us", "data"))
	expect(roots).toContain(root.resolve("whosonfirst-data-admin-gb", "data"))
	// non-WOF sibling is not traversed (its name doesn't start with whosonfirst-data)
	expect(roots).not.toContain(root.resolve("some-other-repo", "data"))
	// `nested/deeper/data` sits at depth 3 from root.path — beyond the 2-level cap
	expect(roots).not.toContain(root.resolve("whosonfirst-data", "nested", "deeper", "data"))
})

test("discoverAdminDataRoots: missing root.path yields empty list, never throws", async () => {
	expect(await discoverAdminDataRoots(root.resolve("does-not-exist"))).toEqual([])
})

test("backfillAncestorsFromHierarchy: inserts wof:hierarchy ancestors for only-self places, idempotent", async () => {
	await using db = DatabaseClient.temp<WOFDatabase>()
	db.exec("CREATE TABLE spr (id INTEGER PRIMARY KEY, placetype TEXT)")
	db.exec("CREATE TABLE ancestors (id INTEGER, ancestor_id INTEGER, ancestor_placetype TEXT, lastmodified INTEGER)")

	// A multi-parent locality (parent_id=-4 in real WOF) — only-self ancestry, must be repaired.
	const orphanID = 85_977_539
	db.prepare("INSERT INTO spr (id, placetype) VALUES (?, 'locality')").run(orphanID)
	db.prepare("INSERT INTO ancestors VALUES (?, ?, 'locality', 0)").run(orphanID, orphanID) // self only
	// A country (top-level) with only-self ancestry — must be skipped rather than queried for geojson.
	db.prepare("INSERT INTO spr (id, placetype) VALUES (?, 'country')").run(85_633_793)
	db.prepare("INSERT INTO ancestors VALUES (?, ?, 'country', 0)").run(85_633_793, 85_633_793)

	// Source geojson with a populated wof:hierarchy (region + country), even though parent_id is -4.
	const dataRoot = root.resolve("whosonfirst-data", "whosonfirst-data-admin-us", "data")
	await makeDirectories(join(dataRoot, "859", "775", "39"))

	await writeLocalJSONFile(
		{
			properties: {
				"wof:parent_id": -4,
				"wof:hierarchy": [
					{ locality_id: orphanID, region_id: 85_688_543, country_id: 85_633_793 },
					{ locality_id: orphanID, region_id: 85_688_543, county_id: 102_081_863 },
				],
			},
		},
		join(dataRoot, "859", "775", "39", `${orphanID}.geojson`)
	)

	const result = await backfillAncestorsFromHierarchy(db, [dataRoot])
	// region + country + county = 3 distinct ancestors across branches (self/locality excluded).
	expect(result.placesFixed).toBe(1)
	expect(result.rowsAdded).toBe(3)

	const ancestorIDs = db
		.prepare("SELECT ancestor_id FROM ancestors WHERE id = ? AND ancestor_id != ? ORDER BY ancestor_id")
		.all(orphanID, orphanID)
		.map((r) => (r as { ancestor_id: number }).ancestor_id)

	expect(ancestorIDs).toEqual([85_633_793, 85_688_543, 102_081_863].toSorted((a, b) => a - b))

	// Re-run: idempotent — already-present rows are not duplicated.
	const again = await backfillAncestorsFromHierarchy(db, [dataRoot])
	expect(again.rowsAdded).toBe(0)
	expect(again.placesFixed).toBe(0)
})

test("backfillAncestorsFromHierarchy: repairs a borough that INHERITED its parent's dead end (#1445)", async () => {
	await using db = DatabaseClient.temp<WOFDatabase>()
	db.exec("CREATE TABLE spr (id INTEGER PRIMARY KEY, placetype TEXT)")
	db.exec("CREATE TABLE ancestors (id INTEGER, ancestor_id INTEGER, ancestor_placetype TEXT, lastmodified INTEGER)")

	// New York City: the multi-parent locality, already repaired by an earlier pass.
	// It has a full ancestor set, so it is not a candidate this time.
	const nycID = 85_977_539
	const brooklynID = 421_205_765
	const nyStateID = 85_688_543
	const kingsCountyID = 102_082_361
	const usID = 85_633_793

	db.prepare("INSERT INTO spr (id, placetype) VALUES (?, 'locality')").run(nycID)

	for (const [aid, pt] of [
		[nycID, "locality"],
		[usID, "country"],
		[nyStateID, "region"],
		[kingsCountyID, "county"],
	] as Array<[number, string]>) {
		db.prepare("INSERT INTO ancestors VALUES (?, ?, ?, 0)").run(nycID, aid, pt)
	}

	// Brooklyn: parent_id points at NYC, so the parent_id closure produced exactly self + NYC and stopped.
	// NYC's own parent_id is the -4 sentinel.
	// Two ancestor rows, which the previous "<= 1 ancestor row" candidate test excluded,
	// leaving the borough with no region ancestor.
	db.prepare("INSERT INTO spr (id, placetype) VALUES (?, 'borough')").run(brooklynID)
	db.prepare("INSERT INTO ancestors VALUES (?, ?, 'borough', 0)").run(brooklynID, brooklynID)
	db.prepare("INSERT INTO ancestors VALUES (?, ?, 'locality', 0)").run(brooklynID, nycID)

	const dataRoot = root.resolve("whosonfirst-data", "whosonfirst-data-admin-us", "data")
	await makeDirectories(join(dataRoot, "421", "205", "765"))

	// Brooklyn's real source hierarchy.
	// The whole chain is present even though parent_id is not -4.
	await writeLocalJSONFile(
		{
			properties: {
				"wof:parent_id": nycID,
				"wof:hierarchy": [
					{
						borough_id: brooklynID,
						continent_id: 102_191_575,
						country_id: usID,
						county_id: kingsCountyID,
						locality_id: nycID,
						region_id: nyStateID,
					},
				],
			},
		},
		join(dataRoot, "421", "205", "765", `${brooklynID}.geojson`)
	)

	const result = await backfillAncestorsFromHierarchy(db, [dataRoot])

	// continent + country + county + region = 4 new rows.
	// Self is excluded, and the locality row (NYC) is already present, so neither is re-inserted.
	expect(result.placesFixed).toBe(1)
	expect(result.rowsAdded).toBe(4)

	const byPlacetype = db
		.prepare("SELECT ancestor_placetype AS pt, ancestor_id AS aid FROM ancestors WHERE id = ? ORDER BY pt")
		.all(brooklynID) as Array<{ pt: string; aid: number }>

	// The region ancestor is the whole point: without it the resolver's region-descendant filter
	// cannot reach the borough, and "Brooklyn, NY" resolves to a Jefferson County hamlet instead.
	expect(byPlacetype.find((row) => row.pt === "region")?.aid).toBe(nyStateID)
	expect(byPlacetype.find((row) => row.pt === "county")?.aid).toBe(kingsCountyID)
	expect(byPlacetype.find((row) => row.pt === "country")?.aid).toBe(usID)
	expect(byPlacetype.filter((row) => row.aid === nycID)).toHaveLength(1)

	// NYC itself was never a candidate.
	// It already had a country ancestor.
	expect(db.prepare("SELECT COUNT(*) AS n FROM ancestors WHERE id = ?").get(nycID)).toEqual({ n: 4 })

	const again = await backfillAncestorsFromHierarchy(db, [dataRoot])
	expect(again.rowsAdded).toBe(0)
})

test("backfillAncestorsFromHierarchy: survives more candidates than SQLite's bound-variable cap", async () => {
	await using db = DatabaseClient.temp<WOFDatabase>()
	db.exec("CREATE TABLE spr (id INTEGER PRIMARY KEY, placetype TEXT)")
	db.exec("CREATE TABLE ancestors (id INTEGER, ancestor_id INTEGER, ancestor_placetype TEXT, lastmodified INTEGER)")
	// Production always carries ancestors_by_id (unified-schema.ts) and the freeze
	// runs its index phase before this backfill.
	// Without it the correlated not exists is quadratic over 33k rows.
	db.exec("CREATE INDEX ancestors_by_id ON ancestors(id)")

	// node:sqlite caps a statement at 32,766 bound variables.
	// The 2026-08-04 wide-coverage admin build carried 67,521 country-less candidates.
	// 33,000 self-only places reproduce the overflow.
	const insertSpr = db.prepare("INSERT INTO spr (id, placetype) VALUES (?, 'locality')")
	const insertAnc = db.prepare("INSERT INTO ancestors VALUES (?, ?, 'locality', 0)")
	db.exec("BEGIN")

	for (let id = 1; id <= 33_000; id++) {
		insertSpr.run(id)
		insertAnc.run(id, id)
	}

	db.exec("COMMIT")

	// Empty roots: every geojson probe misses without touching the filesystem 33,000 times.
	const result = await backfillAncestorsFromHierarchy(db, [])

	// No geojson exists for any of them.
	// Every candidate is skipped, none fixed.
	// The assertion that matters is that the pass completes at all instead of
	// throwing "too many SQL variables".
	expect(result.placesFixed).toBe(0)
	expect(result.rowsAdded).toBe(0)
	expect(result.noGeojson).toBe(33_000)
})

test("backfillAncestorsFromHierarchy: leaves a place whose SOURCE hierarchy stops short alone", async () => {
	await using db = DatabaseClient.temp<WOFDatabase>()
	db.exec("CREATE TABLE spr (id INTEGER PRIMARY KEY, placetype TEXT)")
	db.exec("CREATE TABLE ancestors (id INTEGER, ancestor_id INTEGER, ancestor_placetype TEXT, lastmodified INTEGER)")

	// Fatumafuti, American Samoa: WOF itself gives it {country_id, locality_id} and no region.
	// The artifact matching that is correct rather than truncated — and because it has a
	// country ancestor it is not a candidate at all, so no geojson probe happens for it.
	const id = 101_734_391
	db.prepare("INSERT INTO spr (id, placetype) VALUES (?, 'locality')").run(id)
	db.prepare("INSERT INTO ancestors VALUES (?, ?, 'locality', 0)").run(id, id)
	db.prepare("INSERT INTO ancestors VALUES (?, ?, 'country', 0)").run(id, 85_633_793)

	const dataRoot = root.resolve("whosonfirst-data", "whosonfirst-data-admin-us", "data")
	const result = await backfillAncestorsFromHierarchy(db, [dataRoot])

	expect(result.placesFixed).toBe(0)
	expect(result.rowsAdded).toBe(0)
	expect(result.noGeojson).toBe(0)
})
