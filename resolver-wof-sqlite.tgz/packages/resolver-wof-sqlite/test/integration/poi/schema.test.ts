/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 */

import { createLayerCoverageTable, createLayerManifestTable } from "@mailwoman/core/layers"
import {
	createPOISearchFTS,
	createPOIStagingTables,
	createPOITable,
	POI_FTS_TABLE,
	type POIDatabase,
} from "@mailwoman/resolver-wof-sqlite/poi"
import { normalizeLocalityForKey } from "@mailwoman/resolver-wof-sqlite/street"
import { DatabaseClient } from "@mailwoman/sqlite/client"
import { sql } from "kysely"
import { describe, expect, it } from "vitest"

function openMemory(): { raw: DatabaseClient<POIDatabase>; kdb: DatabaseClient<POIDatabase> } {
	const raw = DatabaseClient.temp<POIDatabase>()

	return { raw, kdb: raw }
}

describe("poi schema", () => {
	it("creates the clustered WITHOUT ROWID poi table with h3_cell leading the PK", async () => {
		const { kdb } = openMemory()
		await createPOITable(kdb)
		const { rows } = await sql<{ sql: string }>`select sql from sqlite_master where name = 'poi'`.execute(kdb)
		const ddl = rows[0]?.sql.toLowerCase() ?? ""
		expect(ddl).toContain("without rowid")
		const pkClause = ddl.slice(ddl.indexOf("primary key ("))

		expect(pkClause).toMatch(
			/primary key \(\s*"?h3_cell"?\s*,\s*"?category_id"?\s*,\s*"?neg_rank"?\s*,\s*"?rowid_key"?\s*\)/
		)
	})

	it("stages + interface tables coexist and accept typed rows", async () => {
		const { kdb } = openMemory()
		await createPOIStagingTables(kdb)
		await createLayerManifestTable(kdb)
		await createLayerCoverageTable(kdb)

		await kdb
			.insertInto("poi_stage")
			.values({
				h3_cell: 1001,
				category_id: 3,
				neg_rank: 0.03,
				rowid_key: 1,
				brand_wikidata: "Q38076",
				name: "McDonald's",
				name_key: normalizeLocalityForKey("McDonald's"),
				latitude: 39.78,
				longitude: -89.65,
				country: "US",
				confidence: 0.93,
				gers_id: null,
			})
			.execute()

		const row = await kdb.selectFrom("poi_stage").selectAll().executeTakeFirstOrThrow()
		expect(row.name).toBe("McDonald's")
		expect(row.h3_cell).toBe(1001)
		expect(row.confidence).toBe(0.93)
	})

	it("creates the FTS5 name index (raw DDL — Kysely cannot express virtual tables)", async () => {
		const { raw, kdb } = openMemory()
		await createPOITable(kdb)
		createPOISearchFTS(raw)
		const found = raw.prepare("select name from sqlite_master where name = ?").get(POI_FTS_TABLE)
		expect(found).toBeDefined()
	})
})
