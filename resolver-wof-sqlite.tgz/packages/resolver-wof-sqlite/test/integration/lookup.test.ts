/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Tests for `WOFSQLitePlaceLookup` against an in-memory fixture DB. The fixture mimics the shape of
 *   a real WOF SQLite distribution but with ~10 hand-picked places — enough to exercise the FTS,
 *   placetype + country + parent filters, and ranking heuristics. No checked-in binary.
 *
 *   Integration tests against a real WOF distribution will land in a follow-up PR once the WOF
 *   download is authorized (night-shift agent hit an auto-mode block on the data.geocode.earth
 *   fetch).
 */

import { temporaryDirectory } from "@mailwoman/core/fs/temporary"
import { changeMode } from "@mailwoman/core/fs/writers"
import { WOFSQLitePlaceLookup } from "@mailwoman/resolver-wof-sqlite/lookup"
import type { WOFDatabase } from "@mailwoman/resolver-wof-sqlite/schema"
import { DatabaseClient } from "@mailwoman/sqlite/client"
import { join } from "path-ts"
import { afterEach, beforeEach, describe, expect, test } from "vitest"

interface FixturePlace {
	id: number
	parent_id: number | null
	name: string
	placetype: string
	country: string | null
	lat: number
	lon: number
	/**
	 * Alternate names (one per locale) — joined into FTS as a single token-bag.
	 */
	alt_names?: string[]
	/**
	 * Ancestor chain (not including self).
	 *
	 * Used to seed the `ancestors` table.
	 */
	ancestor_ids?: number[]
}

/**
 * A small but representative fixture covering the cases the tests assert against.
 */
const FIXTURE: FixturePlace[] = [
	// Countries
	{ id: 85_633_147, parent_id: null, name: "United States", placetype: "country", country: "US", lat: 39.5, lon: -98 },
	{ id: 85_633_723, parent_id: null, name: "France", placetype: "country", country: "FR", lat: 46.5, lon: 2.5 },
	{
		id: 85_633_159,
		parent_id: null,
		name: "United Kingdom",
		placetype: "country",
		country: "GB",
		lat: 54.5,
		lon: -2.5,
	},
	{ id: 85_632_997, parent_id: null, name: "Canada", placetype: "country", country: "CA", lat: 56, lon: -96 },

	// US regions
	{
		id: 85_688_489,
		parent_id: 85_633_147,
		name: "Texas",
		placetype: "region",
		country: "US",
		lat: 31,
		lon: -100,
		ancestor_ids: [85_633_147],
	},
	{
		id: 85_688_541,
		parent_id: 85_633_147,
		name: "Illinois",
		placetype: "region",
		country: "US",
		lat: 40,
		lon: -89,
		ancestor_ids: [85_633_147],
	},
	{
		id: 85_688_543,
		parent_id: 85_633_147,
		name: "Massachusetts",
		placetype: "region",
		country: "US",
		lat: 42,
		lon: -71.5,
		ancestor_ids: [85_633_147],
	},

	// CA regions
	{
		id: 85_682_077,
		parent_id: 85_632_997,
		name: "Ontario",
		placetype: "region",
		country: "CA",
		lat: 50,
		lon: -85,
		ancestor_ids: [85_632_997],
	},

	// Localities
	{
		id: 101_751_119,
		parent_id: 85_683_033, // FR region (not in fixture. irrelevant for the assertions)
		name: "Paris",
		placetype: "locality",
		country: "FR",
		lat: 48.85,
		lon: 2.34,
		// The canonical name also lives in `names` in a real WOF distribution —
		// required for the exact-match tier (#exactMatchIDs queries `names`, not `spr`).
		// Same shape as Brooklyn below.
		alt_names: ["Paris", "Pari", "París", "パリ", "巴黎"],
		ancestor_ids: [85_633_723],
	},
	{
		id: 101_715_829,
		parent_id: 85_688_489,
		name: "Paris",
		placetype: "locality",
		country: "US",
		lat: 33.66,
		lon: -95.55,
		ancestor_ids: [85_688_489, 85_633_147],
	},
	{
		id: 101_727_113,
		parent_id: 85_688_541,
		name: "Springfield",
		placetype: "locality",
		country: "US",
		lat: 39.78,
		lon: -89.65,
		ancestor_ids: [85_688_541, 85_633_147],
	},
	{
		id: 101_729_437,
		parent_id: 85_688_543,
		name: "Springfield",
		placetype: "locality",
		country: "US",
		lat: 42.1,
		lon: -72.59,
		ancestor_ids: [85_688_543, 85_633_147],
	},
	{
		id: 101_750_367,
		parent_id: 85_633_159,
		name: "London",
		placetype: "locality",
		country: "GB",
		lat: 51.51,
		lon: -0.13,
		ancestor_ids: [85_633_159],
	},
	{
		id: 101_748_449,
		parent_id: 85_682_077,
		name: "London",
		placetype: "borough", // intentionally not locality — to test the placetype filter
		country: "CA",
		lat: 42.98,
		lon: -81.25,
		ancestor_ids: [85_682_077, 85_632_997],
	},
	{
		id: 101_751_069,
		parent_id: 85_633_723,
		name: "Paris-l'Hôpital",
		placetype: "locality",
		country: "FR",
		lat: 46.92,
		lon: 4.69,
		ancestor_ids: [85_633_723],
	},

	// The Brooklyn pair: WOF files Brooklyn-the-borough (NYC, pop 2.5M) as placetype `borough`, not `locality`. A locality query must still reach it via the shared placetype expansion (core/resolver PLACETYPE_FILTER_GROUPS). Otherwise the only locality-typed match is the fuzzy "Brooklyn Park" and the resolver mislocates to Minnesota.
	{
		id: 421_205_765,
		parent_id: 85_633_147,
		name: "Brooklyn",
		placetype: "borough",
		country: "US",
		lat: 40.64,
		lon: -73.95,
		// The canonical name also lives in `names` in a real WOF distribution —
		// required for the exact-match tier (#exactMatchIDs queries `names`, not `spr`).
		alt_names: ["Brooklyn"],
		ancestor_ids: [85_633_147],
	},
	{
		id: 85_969_229,
		parent_id: 85_633_147,
		name: "Brooklyn Park",
		placetype: "locality",
		country: "US",
		lat: 45.11,
		lon: -93.35,
		ancestor_ids: [85_633_147],
	},

	// Alias-bag boundary fixture (#523): two aliases whose concatenation straddles the phrase "York New". The exact tier must never promote this place for that straddling query, while each alias on its own ("New City") still warrants the exact tier.
	{
		id: 999_000_001,
		parent_id: 85_633_147,
		name: "Twin Hamlet",
		placetype: "locality",
		country: "US",
		lat: 40.2,
		lon: -76.8,
		alt_names: ["Old York", "New City"],
		ancestor_ids: [85_633_147],
	},
]

function buildFixtureDB(path = ":memory:"): DatabaseClient<WOFDatabase> {
	const db = new DatabaseClient<WOFDatabase>(path)

	// Schema mirrors the real WOF SQLite distribution at data.geocode.earth
	// (subset of columns we actually read. Full schema is documented in `schema.ts`).
	// WOF lifecycle: both `is_current = -1` (modern) and `is_current = 1` (legacy)
	// mean current; `0` means not current.
	// See #91.
	db.exec(`
		CREATE TABLE spr (
			id INTEGER PRIMARY KEY,
			parent_id INTEGER,
			name TEXT,
			placetype TEXT,
			country TEXT,
			latitude REAL,
			longitude REAL,
			min_latitude REAL,
			max_latitude REAL,
			min_longitude REAL,
			max_longitude REAL,
			is_current INTEGER,
			is_deprecated INTEGER
		);
		CREATE TABLE names (
			rowid INTEGER PRIMARY KEY AUTOINCREMENT,
			id INTEGER NOT NULL,
			language TEXT,
			name TEXT NOT NULL
		);
		CREATE TABLE ancestors (
			rowid INTEGER PRIMARY KEY AUTOINCREMENT,
			id INTEGER NOT NULL,
			ancestor_id INTEGER NOT NULL,
			ancestor_placetype TEXT
		);
	`)

	// Fixture places store centroid lat/lon.
	// For bbox tests we use a small ~10 km square around each centroid so R*Tree
	// intersection queries have something realistic to bite on.
	const insertSpr = db.prepare(
		`INSERT INTO spr (
			id, parent_id, name, placetype, country,
			latitude, longitude,
			min_latitude, max_latitude, min_longitude, max_longitude,
			is_current, is_deprecated
		)
		 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, -1, 0)`
	)

	const insertName = db.prepare(`INSERT INTO names (id, language, name) VALUES (?, ?, ?)`)
	const insertAncestor = db.prepare(`INSERT INTO ancestors (id, ancestor_id, ancestor_placetype) VALUES (?, ?, ?)`)

	for (const p of FIXTURE) {
		// ~0.05° padding around the centroid in each direction (≈ 5 km in latitude, varies with longitude) —
		// tight enough that bbox intersection tests behave like point tests
		// but real enough that the R*Tree gets exercised.
		insertSpr.run(
			p.id,
			p.parent_id,
			p.name,
			p.placetype,
			p.country,
			p.lat,
			p.lon,
			p.lat - 0.05,
			p.lat + 0.05,
			p.lon - 0.05,
			p.lon + 0.05
		)

		for (const alt of p.alt_names ?? []) {
			insertName.run(p.id, "und", alt)
		}

		for (const aid of p.ancestor_ids ?? []) {
			insertAncestor.run(p.id, aid, "ancestor")
		}
	}

	return db
}

let lookup: WOFSQLitePlaceLookup

beforeEach(() => {
	const db = buildFixtureDB()
	lookup = new WOFSQLitePlaceLookup({ database: db, buildFTS: true })
})

afterEach(() => {
	lookup[Symbol.dispose]()
})

describe("WOFSQLitePlaceLookup against an inline WOF fixture", () => {
	test('"Paris" with no country/parent filter returns both Paris,FR and Paris,US as localities', async () => {
		// Without a popularity signal (real WOF has wof:population. v0.1 doesn't model it) the
		// resolver has no reason to prefer one Paris over the other — both are valid candidates.
		// Callers disambiguate via country / parentID / alt-name match.
		const candidates = await lookup.findPlace({ text: "Paris" })
		const names = candidates.map((c) => `${c.name},${c.country}`)
		expect(names).toContain("Paris,FR")
		expect(names).toContain("Paris,US")
		expect(candidates.every((c) => c.placetype === "locality")).toBe(true)
	})

	test('"Paris" with country: "US" returns Paris,TX first', async () => {
		const candidates = await lookup.findPlace({ text: "Paris", country: "US" })
		expect(candidates.length).toBeGreaterThan(0)
		expect(candidates[0]).toMatchObject({ name: "Paris", country: "US", placetype: "locality" })
	})

	test('"London" with placetype: "locality" INCLUDES the Ontario borough (locality placetype expansion)', async () => {
		// `locality` expands to locality + borough + localadmin (core/resolver PLACETYPE_FILTER_GROUPS):
		// WOF files many city-like places (Brooklyn, the London boroughs) under
		// `borough`/`localadmin`, and a locality span must be able to reach them.
		const candidates = await lookup.findPlace({ text: "London", placetype: "locality" })
		const byCountry = candidates.map((c) => `${c.country}:${c.placetype}`)
		expect(byCountry).toContain("GB:locality")
		expect(byCountry).toContain("CA:borough")
	})

	test('an explicit placetype: "borough" filter stays narrow (no reverse expansion)', async () => {
		const candidates = await lookup.findPlace({ text: "London", placetype: "borough" })
		expect(candidates).toHaveLength(1)
		expect(candidates[0]).toMatchObject({ name: "London", country: "CA", placetype: "borough" })
	})

	test('"Brooklyn" locality query reaches the exact-named borough over the fuzzy "Brooklyn Park" locality', async () => {
		// The live-demo bug (2026-06-11): with the borough excluded, the only locality-typed
		// match was the partial "Brooklyn Park" → resolved to Minnesota.
		// The expansion makes the exact-named borough reachable, and exact-match tiering puts it on top.
		const candidates = await lookup.findPlace({ text: "Brooklyn", placetype: "locality" })
		expect(candidates.length).toBeGreaterThan(0)
		expect(candidates[0]).toMatchObject({ id: 421_205_765, name: "Brooklyn", placetype: "borough" })
		expect(candidates[0]?.exactMatch).toBe(true)
	})

	test('"Springfield" with parentID: Illinois returns Springfield,IL first', async () => {
		const illinoisID = 85_688_541
		const candidates = await lookup.findPlace({ text: "Springfield", parentID: illinoisID })
		expect(candidates.length).toBeGreaterThan(0)
		expect(candidates[0]).toMatchObject({ name: "Springfield", country: "US", parent_id: illinoisID })
	})

	test('alternate-name match: "パリ" returns Paris,FR via the names join', async () => {
		const candidates = await lookup.findPlace({ text: "パリ" })
		expect(candidates.length).toBeGreaterThan(0)
		expect(candidates[0]).toMatchObject({ name: "Paris", country: "FR" })
	})

	test("length penalty: short name beats long name for short query", async () => {
		// Compare the alias-free pair (Paris,US vs Paris-l'Hôpital,FR — both have empty alt_names bags)
		// so this guards the name-column length penalty in isolation.
		// Paris,FR is no longer a clean subject: its four aliases now carry four ALIAS_SEPARATOR tokens
		// (#523), and that alias-doc length inflation drags its raw BM25 below the alias-free l'Hôpital row.
		// The known shared-length-stats problem (#189), not the name-length penalty under test.
		const candidates = await lookup.findPlace({ text: "Paris" })
		const parisUs = candidates.find((c) => c.name === "Paris" && c.country === "US")
		const parisLHopital = candidates.find((c) => c.name === "Paris-l'Hôpital")
		expect(parisUs).toBeDefined()
		expect(parisLHopital).toBeDefined()
		expect(parisUs!.score).toBeGreaterThan(parisLHopital!.score)
	})

	test("exact-name tier keeps an alias-rich place above a partial match despite its longer alias doc (#523)", async () => {
		// The user-visible guarantee for the pair the length-penalty test used to compare: Paris,FR's
		// separator-inflated alias doc may cost it raw BM25, but "Paris" is an exact name match
		// and the exact tier orders it above the partial-matching Paris-l'Hôpital regardless.
		const candidates = await lookup.findPlace({ text: "Paris", country: "FR" })
		const names = candidates.map((c) => c.name)
		expect(names.indexOf("Paris")).toBeGreaterThanOrEqual(0)
		expect(names.indexOf("Paris-l'Hôpital")).toBeGreaterThan(names.indexOf("Paris"))
	})

	test("limit defaults to 10, respected when specified", async () => {
		const cap2 = await lookup.findPlace({ text: "Paris", limit: 2 })
		expect(cap2.length).toBeLessThanOrEqual(2)
	})

	test("empty/whitespace-only text returns an empty array (not an FTS syntax error)", async () => {
		expect(await lookup.findPlace({ text: "" })).toEqual([])
		expect(await lookup.findPlace({ text: "   " })).toEqual([])
		expect(await lookup.findPlace({ text: "!!!" })).toEqual([])
	})

	test("query with special characters is sanitized — `St. (Petersburg)` does not throw", async () => {
		// No such place in the fixture.
		// We only assert no SQL syntax error.
		await expect(lookup.findPlace({ text: "St. (Petersburg)" })).resolves.toEqual([])
	})

	test("exact-match tier survives a names-less (slim) DB via the place_search alias bag", async () => {
		// Slim DBs built with `dropNames` have no `names` table.
		// The aliases survive only inside the FTS `alt_names` token bag. #exactMatchIDs
		// must fall back to it so "Brooklyn" still tiers the exact-named borough above
		// the fuzzy "Brooklyn Park" against a hot/slim DB.
		const db = buildFixtureDB()
		const withFTS = new WOFSQLitePlaceLookup({ database: db, buildFTS: true })
		withFTS[Symbol.dispose]() // releases nothing we need — the FTS table now exists on `db`, which we own
		db.exec(`DROP TABLE names`)
		const lookup2 = new WOFSQLitePlaceLookup({ database: db })

		try {
			const candidates = await lookup2.findPlace({ text: "Brooklyn", placetype: "locality" })
			expect(candidates[0]).toMatchObject({ id: 421_205_765, name: "Brooklyn", placetype: "borough" })
			expect(candidates[0]?.exactMatch).toBe(true)
		} finally {
			lookup2[Symbol.dispose]()
			await db.destroy()
		}
	})

	test("alias-bag boundary: a query straddling two aliases is never exact on a names-less DB (#523)", async () => {
		// "York New" straddles the bag "Old York <sep> New City": its tokens and-match
		// the row, but the exact tier must not promote it.
		// Pre-#523 the bag was space-joined and the padded containment check
		// (' old york new city ' ⊇ ' york new ') false-promoted exactly this shape.
		const db = buildFixtureDB()
		const withFTS = new WOFSQLitePlaceLookup({ database: db, buildFTS: true })
		withFTS[Symbol.dispose]()
		db.exec(`DROP TABLE names`)
		const lookup2 = new WOFSQLitePlaceLookup({ database: db })

		try {
			const straddle = await lookup2.findPlace({ text: "York New", placetype: "locality" })
			expect(straddle.some((c) => c.exactMatch === true)).toBe(false)
			// A single alias still warrants the exact tier from the bag alone.
			const alias = await lookup2.findPlace({ text: "New City", placetype: "locality" })
			expect(alias[0]).toMatchObject({ id: 999_000_001, exactMatch: true })
		} finally {
			lookup2[Symbol.dispose]()
			await db.destroy()
		}
	})

	test("Disposable: Symbol.dispose closes the lookup", async () => {
		await using db = buildFixtureDB()

		{
			using disposable = new WOFSQLitePlaceLookup({ database: db, buildFTS: true })
			const cands = await disposable.findPlace({ text: "Paris" })
			expect(cands.length).toBeGreaterThan(0)
		}
		// After the using block: querying via the original db handle should still work because we don't own it.
		const after = db.prepare(`SELECT COUNT(*) AS n FROM spr`).get() as { n: number }
		expect(after.n).toBe(FIXTURE.length)
	})
})

describe("WOFSQLitePlaceLookup ctor", () => {
	test("requires exactly one of database / databasePath", () => {
		expect(() => new WOFSQLitePlaceLookup({})).toThrow(/one of/)

		expect(
			() => new WOFSQLitePlaceLookup({ database: DatabaseClient.temp<WOFDatabase>(), databasePath: "/tmp/x.db" })
		).toThrow(/not both/)
	})

	test("errors loudly when FTS table is missing and buildFTS is false", () => {
		using db = DatabaseClient.temp<WOFDatabase>()
		db.exec(`CREATE TABLE places (id INTEGER PRIMARY KEY, parent_id INTEGER, name TEXT, placetype TEXT, country TEXT);`)
		expect(() => new WOFSQLitePlaceLookup({ database: db, buildFTS: false })).toThrow(/place_search/)
	})

	test("SMOKE: a sealed 0444 on-disk extract opens and still answers FTS queries end-to-end", async () => {
		// smoke test rather than the regression guard: SQLite silently downgrades a write-mode open
		// to read-only on an owned 0444 file, so this passes under the old `readOnly: false` too.
		// It does not distinguish old from new code.
		// It proves a genuinely sealed file resolves end-to-end.
		// The real invariant (the open mode chosen per `buildFTS` — read-only on every
		// query path, read-write only for the FTS build) is enforced by the DatabaseSync
		// construction spy in `lookup-readonly-open.test.ts`.
		await using dirDirectory = await temporaryDirectory("mw-wof-ro-")
		const dir = dirDirectory.path
		const dbPath = join(dir, "admin-fixture.db")

		// Build the fixture on disk with its FTS index, then seal the file 0444 to mimic a shipped extract.
		{
			await using disk = buildFixtureDB(dbPath)
			const builder = new WOFSQLitePlaceLookup({ database: disk, buildFTS: true })
			builder[Symbol.dispose]()
		}
		await changeMode(dbPath, 0o444)

		let ro: WOFSQLitePlaceLookup | undefined

		try {
			// The real code path: databasePath → `new DatabaseClient<WOFDatabase>(path, { readOnly: !opts.buildFTS })`.
			// With buildFTS omitted this opens the 0444 file read-only.
			// A write-mode open would throw here.
			ro = new WOFSQLitePlaceLookup({ databasePath: dbPath })
			const candidates = await ro.findPlace({ text: "Paris", country: "US" })
			expect(candidates.length).toBeGreaterThan(0)
			expect(candidates[0]).toMatchObject({ name: "Paris", country: "US", placetype: "locality" })
		} finally {
			ro?.[Symbol.dispose]()
			// Restore write permission so the temp dir can be cleaned up.
			await changeMode(dbPath, 0o644)
		}
	})
})
