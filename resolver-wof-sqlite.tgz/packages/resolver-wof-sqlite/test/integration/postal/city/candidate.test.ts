/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   #741 postcode-keyed postal-city side-index on the candidate backend. Builds a fixture
 *   candidate.db (via `buildCandidateTable`) with Nashville (high pop) + a far Antioch, CA
 *   distractor, attaches a `postal_city_candidate` row (`antioch`, 37013 → Nashville), and pins the
 *   probe's behaviour: an exact `(name_key, postcode)` hit resolves the postal city to its
 *   geographic locality. a bare query (no postcode), a postcode miss, a non-locality request, and a
 *   candidate.db without the side-index are all untouched (byte-stable).
 */

import { temporaryDirectory, type TemporaryDirectory } from "@mailwoman/core/fs/temporary"
import { buildCandidateTable } from "@mailwoman/resolver-wof-sqlite/build-candidate"
import { WOFCandidateTableLookup } from "@mailwoman/resolver-wof-sqlite/candidate-lookup"
import {
	createPostalCityCandidateTable,
	POSTAL_CITY_CANDIDATE_TABLE,
	type PostalCityCandidateDatabase,
} from "@mailwoman/resolver-wof-sqlite/postal"
import { normalizeLocalityForKey } from "@mailwoman/resolver-wof-sqlite/street"
import { DatabaseClient } from "@mailwoman/sqlite/client"
import { afterEach, beforeEach, describe, expect, test } from "vitest"

let scratch: TemporaryDirectory
let candidatePath: string

function buildFixtureAdmin(path: string): void {
	using db = new DatabaseClient<PostalCityCandidateDatabase>(path)

	db.exec(`
		CREATE TABLE spr (
			id INTEGER PRIMARY KEY, name TEXT, placetype TEXT, country TEXT,
			latitude REAL, longitude REAL,
			min_latitude REAL, min_longitude REAL, max_latitude REAL, max_longitude REAL,
			is_current INTEGER, is_deprecated INTEGER
		);
		CREATE TABLE place_population (id INTEGER PRIMARY KEY, population INTEGER NOT NULL DEFAULT 0);
		CREATE TABLE place_search (wof_id INTEGER PRIMARY KEY, alt_names TEXT);
		CREATE TABLE place_abbr (id INTEGER PRIMARY KEY, abbr TEXT);
		CREATE TABLE ancestors (id INTEGER, ancestor_id INTEGER, ancestor_placetype TEXT);

		-- Nashville (the geographic locality 37013 sits in) and a far Antioch, CA distractor.
		INSERT INTO spr VALUES (1, 'Nashville', 'locality', 'US', 36.17, -86.78, 36.0, -87.0, 36.4, -86.5, -1, 0);
		INSERT INTO spr VALUES (2, 'Antioch', 'locality', 'US', 38.0, -121.8, 37.9, -121.9, 38.1, -121.7, -1, 0);
		INSERT INTO place_population VALUES (1, 700000);
		INSERT INTO place_population VALUES (2, 117000);
	`)
}

/**
 * Attach the #741 side-index with one edge: the postal city "Antioch" at 37013 → Nashville (id 1).
 */
async function attachPostalCityIndex(path: string): Promise<void> {
	using kdb = new DatabaseClient<PostalCityCandidateDatabase>(path)

	await createPostalCityCandidateTable(kdb)

	await kdb
		.insertInto(POSTAL_CITY_CANDIDATE_TABLE)
		.values({
			name_key: normalizeLocalityForKey("Antioch"),
			postcode: "37013",
			spr_id: 1,
			name: "Nashville",
			latitude: 36.17,
			longitude: -86.78,
		})
		.execute() // closes the underlying `raw` handle
}

beforeEach(async () => {
	scratch = await temporaryDirectory("mailwoman-pcc-")
	const input = scratch.resolve("admin.db")
	candidatePath = scratch.resolve("candidate.db")
	buildFixtureAdmin(input)
	await buildCandidateTable({ input, output: candidatePath, postcodes: [] })
})

afterEach(async () => {
	scratch[Symbol.asyncDispose]()
})

describe("WOFCandidateTableLookup postal-city side-index (#741)", () => {
	test("WITHOUT the side-index, a postal-city query resolves to the far distractor (the gap)", async () => {
		using lk = new WOFCandidateTableLookup({ databasePath: candidatePath })

		const hits = await lk.findPlace({ text: "Antioch", placetype: "locality", postcode: "37013", country: "US" })
		expect(hits[0]!.name).toBe("Antioch") // the CA distractor — no side-index to redirect
		expect(hits[0]!.lat).toBeCloseTo(38, 1)
	})

	test("WITH the side-index, an exact (name_key, postcode) hit resolves to the geographic locality", async () => {
		await attachPostalCityIndex(candidatePath)
		using lk = new WOFCandidateTableLookup({ databasePath: candidatePath })

		const hits = await lk.findPlace({ text: "Antioch", placetype: "locality", postcode: "37013", country: "US" })
		expect(hits).toHaveLength(1)
		expect(hits[0]!.name).toBe("Nashville")
		expect(hits[0]!.lat).toBeCloseTo(36.17, 1)
		expect(hits[0]!.exactMatch).toBe(true)
	})

	test("a BARE query (no postcode) is untouched — bare 'Antioch' still resolves to the CA distractor", async () => {
		await attachPostalCityIndex(candidatePath)
		using lk = new WOFCandidateTableLookup({ databasePath: candidatePath })

		const hits = await lk.findPlace({ text: "Antioch", placetype: "locality", country: "US" })
		expect(hits[0]!.name).toBe("Antioch")
		expect(hits[0]!.lat).toBeCloseTo(38, 1)
	})

	test("a postcode NOT in the side-index falls through to the normal probe", async () => {
		await attachPostalCityIndex(candidatePath)
		using lk = new WOFCandidateTableLookup({ databasePath: candidatePath })

		const hits = await lk.findPlace({ text: "Antioch", placetype: "locality", postcode: "99999", country: "US" })
		expect(hits[0]!.name).toBe("Antioch")
	})

	test("a NON-locality request (region) does not consult the locality side-index", async () => {
		await attachPostalCityIndex(candidatePath)
		using lk = new WOFCandidateTableLookup({ databasePath: candidatePath })

		const hits = await lk.findPlace({ text: "Antioch", placetype: "region", postcode: "37013", country: "US" })
		expect(hits.every((h) => h.name !== "Nashville")).toBe(true)
	})

	test("a candidate.db WITHOUT the side-index is byte-stable (no probe, no crash)", async () => {
		// candidatePath has no postal_city_candidate table here (attach not called).
		using lk = new WOFCandidateTableLookup({ databasePath: candidatePath })

		const hits = await lk.findPlace({ text: "Antioch", placetype: "locality", postcode: "37013", country: "US" })
		expect(hits[0]!.name).toBe("Antioch")
	})
})
