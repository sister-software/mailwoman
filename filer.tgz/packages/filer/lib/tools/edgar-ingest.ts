/**
 * @copyright Sister Software.
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   `mailwoman filer edgar-ingest`'s library half — the edgar chain against a live SEC client, with the
 *   full registrant index. No argv, no `process.exit`: the command owns argument parsing, rendering, and
 *   exit codes. Every field on the result is a number the command can render without importing another
 *   module.
 */

import { readLocalTextFile } from "@mailwoman/core/fs/readers"
import { writeLocalTextFile, makeDirectories } from "@mailwoman/core/fs/writers"
import { stringifyJSON } from "@mailwoman/core/json"

import { parseCIKLookupData, type CompanyTickerEntry } from "#sdk/edgar/filings/index"
import { collectEdgarSubsidiaryRows, type EdgarIngestReport } from "#sdk/edgar/ingest"
import { createSECClient } from "#sdk/sec-client"

export type { EdgarIngestReport, EdgarSkipReason } from "#sdk/edgar/ingest"

export interface FilerEdgarIngestOptions {
	/**
	 * Company names to resolve — one per line in a file, or passed as an array.
	 *
	 * Every name is tried.
	 * A blank line is skipped rather than producing an outcome.
	 */
	queries: string[]
	/**
	 * Output directory for the subsidiary rows as jsonl.
	 */
	outDir: string
	/**
	 * Optional CIK lookup-data file path (`cik-lookup-data.txt`, one `name:CIK:` per line).
	 */
	cikLookupPath?: string
	/**
	 * CIKs pinned as corroborated regardless of SIC.
	 */
	pinnedCIKs?: string[]
	/**
	 * Called once per registrant as it completes.
	 */
	onOutcome?: (outcome: { query: string; ok: boolean; subsidiaries: number; detail: string }) => void
}

export interface FilerEdgarIngestResult {
	report: EdgarIngestReport
	jsonlPath: string
	lookupEntries: number
}

/**
 * Run the edgar ingest chain against a live SEC client and write the subsidiary rows to `outDir` as jsonl.
 *
 * The ticker index is read from `cikLookupPath` when given.
 * It is parsed to `CompanyTickerEntry[]` once and reused across every query.
 */
export async function filerEdgarIngest(options: FilerEdgarIngestOptions): Promise<FilerEdgarIngestResult> {
	const client = createSECClient()

	const tickers: CompanyTickerEntry[] = options.cikLookupPath
		? parseCIKLookupData(await readLocalTextFile(options.cikLookupPath))
		: []

	const pinnedSet = options.pinnedCIKs?.length ? new Set(options.pinnedCIKs) : undefined

	const { rows, report } = await collectEdgarSubsidiaryRows(client, options.queries, tickers, {
		pinnedCIKs: pinnedSet,
		onOutcome: options.onOutcome
			? (outcome) =>
					options.onOutcome?.({
						query: outcome.query,
						ok: !outcome.skipReason,
						subsidiaries: outcome.subsidiaries,
						detail:
							outcome.skipReason ??
							`${outcome.subsidiaries} subsidiaries, ${outcome.unparseable} unparseable, SIC ${outcome.sic ?? "?"}`,
					})
			: undefined,
	})

	const { join } = await import("path-ts")

	await makeDirectories(options.outDir)

	const jsonlPath = join(options.outDir, "edgar-subsidiaries.jsonl")
	const lines = rows.map((row) => stringifyJSON(row))

	await writeLocalTextFile(lines, jsonlPath)

	return { report, jsonlPath, lookupEntries: tickers.length }
}
