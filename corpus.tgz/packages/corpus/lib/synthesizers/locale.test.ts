/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Tests for the German synthesizer (night-shift 2026-06-02, DE-1). Validates the {raw, components}
 *   interface and the BIO output via the real `alignRow`: the model must see German order — street →
 *   house_number (house after street) and postcode → locality (postcode before city) — the
 *   convention the US/FR-trained model never learned.
 */

import { type LocaleBaseTuple, synthesizeGermanRow, synthesizeLocaleRow } from "@mailwoman/corpus/synthesizers/locale"
import type { CanonicalRow } from "@mailwoman/corpus/types"
import { alignRow } from "@mailwoman/corpus/utils"
import { describe, expect, it } from "vitest"

const BERLIN: LocaleBaseTuple = {
	house_number: "27",
	street: "Straußstraße",
	locality: "Berlin",
	region: "Berlin",
	postcode: "12623",
}

// `() => 0.5` keeps both house number (0.5 < 0.8) and postcode (0.5 < 0.85).
const keepAll = () => 0.5

describe("synthesizeGermanRow", () => {
	it("renders idiomatic German order (street, then house#; postcode before city)", () => {
		const row = synthesizeGermanRow(BERLIN, { random: keepAll })!
		expect(row).not.toBeNull()
		expect(row.raw).toContain("Straußstraße 27") // house number after street
		expect(row.raw).toContain("12623 Berlin") // postcode before city
		expect(row.raw.indexOf("Straußstraße")).toBeLessThan(row.raw.indexOf(" 27"))
		expect(row.raw.indexOf("12623")).toBeLessThan(row.raw.indexOf("Berlin"))
	})

	it("drops region (the DE template absorbs the Bundesland into the city line)", () => {
		const row = synthesizeGermanRow(BERLIN, { random: keepAll })!
		expect(row.components.region).toBeUndefined()
	})

	it("aligns to German-order BIO: house_number after street, locality after postcode", () => {
		const row = synthesizeGermanRow(BERLIN, { random: keepAll })!
		const canonical = { ...row, country: "DE", source: "synth-german", source_id: "synth-german:test" } as CanonicalRow
		const aligned = alignRow(canonical)
		expect(aligned.kind).toBe("labeled")

		if (aligned.kind !== "labeled") throw new Error("expected a labeled row")
		const labels = aligned.row.labels
		const firstOf = (tag: string) => labels.findIndex((l) => l.includes(tag))
		expect(firstOf("street")).toBeGreaterThanOrEqual(0)
		expect(firstOf("house_number")).toBeGreaterThan(firstOf("street"))
		expect(firstOf("locality")).toBeGreaterThan(firstOf("postcode"))
	})
})

describe("the comma-free separator (#1946)", () => {
	const KOELN: LocaleBaseTuple = {
		house_number: "12",
		street: "Neusser Str.",
		dependent_locality: "Nippes",
		locality: "Köln",
		region: "Nordrhein-Westfalen",
		postcode: "50733",
	}

	it("renders the native order with no commas, every component still verbatim", () => {
		const row = synthesizeGermanRow(KOELN, { random: keepAll, separator: " " })!

		expect(row.raw).toBe("Neusser Str. 12 Nippes 50733 Köln")
		expect(row.components.dependent_locality).toBe("Nippes")
	})

	it("is the template's comma form with the default separator", () => {
		expect(synthesizeGermanRow(KOELN, { random: keepAll })!.raw).toBe("Neusser Str. 12, Nippes, 50733 Köln")
	})

	it("aligns the comma-free row to BIO with the district as dependent_locality between street and postcode", () => {
		const row = synthesizeGermanRow(KOELN, { random: keepAll, separator: " " })!

		const canonical = {
			...row,
			country: "DE",
			source: "synth-german",
			source_id: "synth-german:nippes",
		} as CanonicalRow

		const aligned = alignRow(canonical)

		if (aligned.kind !== "labeled") throw new Error("expected a labeled row")
		const labels = aligned.row.labels
		const firstOf = (tag: string) => labels.findIndex((l) => l.includes(tag))

		expect(firstOf("dependent_locality")).toBeGreaterThan(firstOf("house_number"))
		expect(firstOf("postcode")).toBeGreaterThan(firstOf("dependent_locality"))
		expect(labels.filter((l) => l.startsWith("B-street"))).toHaveLength(1)
	})

	it("leaves the international layout on its own separator", () => {
		const row = synthesizeLocaleRow(BERLIN, "DE", { random: keepAll, order: "international", separator: " " })!

		expect(row.raw).toBe("27 Straußstraße, Berlin, Berlin 12623")
	})
})

describe("synthesizeLocaleRow (generic)", () => {
	it("ES renders Spanish order (house after street, postcode before city) and tags the locale", () => {
		const madrid: LocaleBaseTuple = { house_number: "12", street: "Calle Mayor", locality: "Madrid", postcode: "28013" }
		const row = synthesizeLocaleRow(madrid, "ES", { random: keepAll })!
		expect(row).not.toBeNull()
		expect(row.locale).toBe("es-ES")
		// ES renders "Calle Mayor, 12, 28013 Madrid" — house after street
		// (a comma between them, unlike German), postcode before city.
		// The order is what the recipe teaches.
		expect(row.raw.indexOf("Calle Mayor")).toBeLessThan(row.raw.indexOf("12"))
		expect(row.raw).toContain("28013 Madrid")
	})

	it("synthesizeGermanRow is the DE wrapper", () => {
		const row = synthesizeGermanRow(BERLIN, { random: keepAll })!
		expect(row.locale).toBe("de-DE")
		expect(synthesizeLocaleRow(BERLIN, "DE", { random: keepAll })!.raw).toBe(row.raw)
	})
})

const DRESDEN: LocaleBaseTuple = {
	house_number: "14",
	street: "Goetheallee",
	locality: "Dresden",
	region: "Sachsen",
	postcode: "01309",
}

describe("synthesizeLocaleRow order option (order-robustness)", () => {
	it("international order renders house-FIRST, postcode-AFTER-city, region IN THE TAIL", () => {
		// keepAll = 0.5 keeps house# + postcode. International uses the US template + the region tail → "27 Straußstraße, Berlin, Berlin 12623" (the layout the eval feeds. v0.9.3 / #327).
		const row = synthesizeLocaleRow(BERLIN, "DE", { random: keepAll, order: "international" })!
		expect(row).not.toBeNull()
		expect(row.raw.indexOf("27")).toBeLessThan(row.raw.indexOf("Straußstraße")) // house before street
		expect(row.raw.indexOf("12623")).toBeGreaterThan(row.raw.indexOf("Berlin")) // postcode after city
		expect(row.components.region).toBe("Berlin") // region carried for international (dropped for native)
	})

	it("region tail renders with a DISTINCT region (City, Region Postcode)", () => {
		const row = synthesizeLocaleRow(DRESDEN, "DE", { random: keepAll, order: "international" })!
		expect(row.raw).toBe("14 Goetheallee, Dresden, Sachsen 01309")
		expect(row.components.region).toBe("Sachsen")
	})

	it("keeps the address's own locale tag — only the surface layout changes", () => {
		const row = synthesizeLocaleRow(BERLIN, "DE", { random: keepAll, order: "international" })!
		expect(row.locale).toBe("de-DE") // the render template is US, but it's still a German address
	})

	it("aligns to international-order BIO: house# before street, region after locality, postcode last", () => {
		const row = synthesizeLocaleRow(DRESDEN, "DE", { random: keepAll, order: "international" })!
		const canonical = { ...row, country: "DE", source: "synth-german", source_id: "synth-german:intl" } as CanonicalRow
		const aligned = alignRow(canonical)
		expect(aligned.kind).toBe("labeled")

		if (aligned.kind !== "labeled") throw new Error("expected a labeled row")
		const labels = aligned.row.labels
		const firstOf = (tag: string) => labels.findIndex((l) => l.includes(tag))
		expect(firstOf("house_number")).toBeLessThan(firstOf("street")) // inverse of the native test
		expect(firstOf("region")).toBeGreaterThan(firstOf("locality")) // region in the tail, after the city
		expect(firstOf("postcode")).toBeGreaterThan(firstOf("region")) // postcode last
	})

	it("native order is unchanged and consumes no extra RNG draw (default stays default)", () => {
		// Same seeded sequence must yield the identical native render whether or not `order` is passed.
		const seq = () => {
			let i = 0
			const vals = [0.1, 0.2, 0.3, 0.4]

			return () => vals[i++ % vals.length]!
		}

		const withoutOpt = synthesizeLocaleRow(BERLIN, "DE", { random: seq() })!
		const withNative = synthesizeLocaleRow(BERLIN, "DE", { random: seq(), order: "native" })!
		expect(withNative.raw).toBe(withoutOpt.raw)
	})
})

describe("NZ dependent_locality (suburb below city)", () => {
	// NZ envelopes carry both a suburb and a city: "31 Rawene Road, Birkenhead, Auckland".
	// The OA district column holds the city (Auckland), city the suburb (Birkenhead) —
	// see `readTuples` districtAsLocality.
	const AUCKLAND: LocaleBaseTuple = {
		house_number: "31",
		street: "Rawene Road",
		dependent_locality: "Birkenhead",
		locality: "Auckland",
	}

	it("renders the suburb BEFORE the city, both present, and tags en-NZ", () => {
		const row = synthesizeLocaleRow(AUCKLAND, "NZ", { random: keepAll })!
		expect(row).not.toBeNull()
		expect(row.locale).toBe("en-NZ")
		expect(row.raw).toContain("Birkenhead, Auckland") // suburb, then city
		expect(row.raw.indexOf("Birkenhead")).toBeLessThan(row.raw.indexOf("Auckland"))
		expect(row.components.dependent_locality).toBe("Birkenhead")
		expect(row.components.locality).toBe("Auckland")
	})

	it("aligns to BIO with dependent_locality between street and locality", () => {
		const row = synthesizeLocaleRow(AUCKLAND, "NZ", { random: keepAll })!
		const canonical = { ...row, country: "NZ", source: "synth-nz", source_id: "synth-nz:test" } as CanonicalRow
		const aligned = alignRow(canonical)
		expect(aligned.kind).toBe("labeled")

		if (aligned.kind !== "labeled") throw new Error("expected a labeled row")
		const labels = aligned.row.labels
		// Exact tag match after stripping the B-/I- prefix — "dependent_locality" contains
		// "locality" as a substring, so a naive `.includes` would conflate the two.
		const firstOf = (tag: string) => labels.findIndex((l) => l.replace(/^[BI]-/, "") === tag)
		expect(firstOf("dependent_locality")).toBeGreaterThan(firstOf("street"))
		expect(firstOf("locality")).toBeGreaterThan(firstOf("dependent_locality"))
	})

	it("omits dependent_locality when absent (the ~18% of NZ rows with no district)", () => {
		const noSuburb: LocaleBaseTuple = { house_number: "26A", street: "Henley Road", locality: "Kaukapakapa" }
		const row = synthesizeLocaleRow(noSuburb, "NZ", { random: keepAll })!
		expect(row).not.toBeNull()
		expect(row.components.dependent_locality).toBeUndefined()
		expect(row.components.locality).toBe("Kaukapakapa")
		expect(row.raw).toContain("Kaukapakapa")
	})
})

describe("NL postcode normalization", () => {
	const NL: LocaleBaseTuple = {
		house_number: "105",
		street: "De Ruijterkade",
		locality: "Amsterdam",
		postcode: "1011AB",
	}

	it("canonicalizes the NL postcode to the spaced form so native order aligns (was rejected)", () => {
		const row = synthesizeLocaleRow(NL, "NL", { random: keepAll, order: "native" })!
		expect(row).not.toBeNull() // previously NULL — the template's "1011 AB" didn't match unspaced "1011AB"
		expect(row.components.postcode).toBe("1011 AB")
		expect(row.raw).toContain("1011 AB")
	})

	it("leaves other countries' postcodes untouched", () => {
		const de = synthesizeLocaleRow(BERLIN, "DE", { random: keepAll })!
		expect(de.components.postcode).toBe("12623")
	})

	it("postcodeShape: as-source keeps OA's glued NL form (the eval's observed shape, #241)", () => {
		const row = synthesizeLocaleRow(NL, "NL", { random: keepAll, postcodeShape: "as-source" })!
		expect(row).not.toBeNull()
		expect(row.components.postcode).toBe("1011AB")
		expect(row.raw).toContain("1011AB Amsterdam")
	})

	it("postcodeShape: conventional (and the default) space the two-letter suffix", () => {
		const explicit = synthesizeLocaleRow(NL, "NL", { random: keepAll, postcodeShape: "conventional" })!
		expect(explicit.components.postcode).toBe("1011 AB")
		expect(explicit.raw).toBe(synthesizeLocaleRow(NL, "NL", { random: keepAll })!.raw)
	})
})

describe("nativeHouseJoin (#241 — ES street→house join diversity)", () => {
	const MADRID: LocaleBaseTuple = {
		house_number: "12",
		street: "Calle Mayor",
		locality: "Madrid",
		postcode: "28013",
	}

	it("space collapses the ES template's comma join to the OA/eval space join", () => {
		const template = synthesizeLocaleRow(MADRID, "ES", { random: keepAll })!
		const spaced = synthesizeLocaleRow(MADRID, "ES", { random: keepAll, nativeHouseJoin: "space" })!
		expect(template.raw).toBe("Calle Mayor, 12, 28013 Madrid")
		expect(spaced.raw).toBe("Calle Mayor 12, 28013 Madrid")
		expect(spaced.components).toEqual(template.components) // same components — only the surface join moves
	})

	it("is a no-op for templates that already space-join (DE)", () => {
		const spaced = synthesizeLocaleRow(BERLIN, "DE", { random: keepAll, nativeHouseJoin: "space" })!
		expect(spaced.raw).toBe(synthesizeLocaleRow(BERLIN, "DE", { random: keepAll })!.raw)
	})

	it("is ignored for international order (already house-first, space-joined)", () => {
		const intl = synthesizeLocaleRow(MADRID, "ES", { random: keepAll, order: "international" })!

		const intlSpace = synthesizeLocaleRow(MADRID, "ES", {
			random: keepAll,
			order: "international",
			nativeHouseJoin: "space",
		})!

		expect(intlSpace.raw).toBe(intl.raw)
	})

	it("still aligns to BIO after the join collapse", () => {
		const row = synthesizeLocaleRow(MADRID, "ES", { random: keepAll, nativeHouseJoin: "space" })!
		const canonical = { ...row, country: "ES", source: "synth-es", source_id: "synth-es:test" } as CanonicalRow
		const aligned = alignRow(canonical)
		expect(aligned.kind).toBe("labeled")
	})

	it("consumes no extra RNG draw (defaults unchanged for a given sequence)", () => {
		const seq = () => {
			let i = 0
			const vals = [0.1, 0.2, 0.3, 0.4]

			return () => vals[i++ % vals.length]!
		}

		const withoutOpts = synthesizeLocaleRow(MADRID, "ES", { random: seq() })!

		const withDefaults = synthesizeLocaleRow(MADRID, "ES", {
			random: seq(),
			nativeHouseJoin: "template",
			postcodeShape: "conventional",
		})!

		expect(withDefaults.raw).toBe(withoutOpts.raw)
	})
})
