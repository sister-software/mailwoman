/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Golden eval-set validator (Phase 1 task #9 in the plan).
 *
 *   The golden set is hand-labeled ground truth for the neural classifier. Each entry must carry
 *   components whose surface forms actually occur in `raw` — otherwise the entry will silently rot
 *   the eval signal. This module:
 *
 *   - Defines `GoldenEntry` (schema check).
 *   - Loads `.jsonl` files (one entry per line).
 *   - Validates every entry: schema shape, ComponentTag membership, reachability of each component in
 *       `raw` via `componentsPresentIn`.
 *   - Returns a structured report of per-entry errors so the CLI / CI surface can act on it.
 *
 *   The 1000-entry target (500 US + 500 FR) is a human task. This module catches the regressions that
 *   creep in over time as new entries land.
 */

import { componentsPresentIn } from "@mailwoman/codex/address-format"
import { COMPONENT_TAGS, type ComponentTag } from "@mailwoman/codex/component"
import { parseJSONStrict, stringifyJSON } from "@mailwoman/core/json"
import { join } from "path-ts"
import { TextSpliterator } from "spliterator"
import { Globerator } from "spliterator/node/fs"

const TAG_SET = new Set<string>(COMPONENT_TAGS as readonly string[])

/**
 * A golden-set candidate row, as `golden-expand` writes and `golden-promote` reads.
 *
 * `source` names the producer (`expand-golden:<provider>`); the seed/provenance fields
 * trace the candidate back to the corpus row and LLM call that produced it.
 * A committed golden entry is the {@link GoldenEntry} narrowing.
 */
export interface GoldenCandidateEntry {
	raw: string
	components: Partial<Record<ComponentTag, string>>
	country: string
	source: string
	notes?: string
	seed_source_id?: string
	seed_source_adapter?: string
	dropped_components?: string[]
	provenance?: { provider: string; model: string }
}

/**
 * One entry in a golden `.jsonl` file.
 */
export interface GoldenEntry extends GoldenCandidateEntry {
	source: "golden"
}

/**
 * Per-entry validation failure.
 */
export interface GoldenIssue {
	file: string
	line: number
	reason: string
}

/**
 * Aggregate report from `validateGoldenDir`.
 */
export interface GoldenReport {
	entries: number
	files: number
	issues: GoldenIssue[]
}

/**
 * Parse a single jsonl line into a `GoldenEntry`.
 *
 * @throws on schema violations.
 */
export function parseGoldenLine(line: string): GoldenEntry {
	// The throw is the result: `validateGoldenFile` catches it and records the message
	// against the line number, so a tolerant parse would report a corrupt row as valid.
	const obj = parseJSONStrict<Partial<GoldenEntry> & Record<string, unknown>>(line)

	if (typeof obj.raw !== "string" || !obj.raw.length) {
		throw new Error("missing/empty raw")
	}

	if (typeof obj.country !== "string" || !/^[A-Z]{2}$/u.test(obj.country)) {
		throw new Error(`country must be ISO 3166-1 alpha-2 (got ${stringifyJSON(obj.country)})`)
	}

	if (obj.source !== "golden") {
		throw new Error(`source must be "golden" (got ${stringifyJSON(obj.source)})`)
	}

	const components = (obj.components ?? {}) as Record<string, unknown>

	for (const [k, v] of Object.entries(components)) {
		if (!TAG_SET.has(k)) throw new Error(`unknown ComponentTag: ${k}`)

		if (typeof v !== "string" || !v.length) {
			throw new Error(`components.${k} must be a non-empty string`)
		}
	}

	return {
		raw: obj.raw,
		components: components as GoldenEntry["components"],
		country: obj.country,
		source: "golden",
		notes: typeof obj.notes === "string" ? obj.notes : undefined,
	}
}

/**
 * Check that every component in `entry` appears in `entry.raw`.
 *
 * A golden entry's `raw` is hand-written ground truth rather than a render, so the question
 * here really is containment: does this labeled span occur in the string a person typed.
 * That is the weaker of the two reconciliations, and the right one for a string no layout produced.
 */
export function unreachableComponents(entry: GoldenEntry): ComponentTag[] {
	const present = componentsPresentIn(entry.components, entry.raw)
	const missing: ComponentTag[] = []

	for (const tag of Object.keys(entry.components) as ComponentTag[]) {
		if (!(tag in present)) {
			missing.push(tag)
		}
	}

	return missing
}

/**
 * Validate one `.jsonl` file end-to-end, returning a list of issues.
 *
 * Parses line by line over `TextSpliterator` rather than `JSONSpliterator`: every issue this returns
 * carries the line number it was found on, and a malformed line has to be reported rather than thrown.
 * `JSONSpliterator` parses each row for you and throws on the first bad one — correct for
 * consumers that want the rows, wrong for the validator whose whole job is locating the bad ones.
 */
export async function validateGoldenFile(path: string): Promise<GoldenIssue[]> {
	const issues: GoldenIssue[] = []
	// Counted over every row including blanks, so the number matches what an editor shows.
	let lineNumber = 0

	for await (const raw of TextSpliterator.fromAsync(path, { skipEmpty: false })) {
		lineNumber++
		const line = raw.trim()

		if (!line) continue
		const i = lineNumber - 1

		try {
			const entry = parseGoldenLine(line)
			const unreachable = unreachableComponents(entry)

			if (unreachable.length) {
				issues.push({
					file: path,
					line: i + 1,
					reason: `components not reachable in raw: ${unreachable.join(", ")}`,
				})
			}
		} catch (error) {
			issues.push({ file: path, line: i + 1, reason: (error as Error).message })
		}
	}

	return issues
}

/**
 * Validate every `.jsonl` in a golden directory.
 */
export async function validateGoldenDir(dir: string): Promise<GoldenReport> {
	const files = await Globerator.files("jsonl", { cwd: dir, absolute: false, recursive: false }).toSorted()
	const issues: GoldenIssue[] = []
	let entries = 0

	for (const name of files) {
		const fullPath = join(dir, name)
		const fileIssues = await validateGoldenFile(fullPath)
		issues.push(...fileIssues)

		for await (const line of TextSpliterator.fromAsync(fullPath)) {
			if (line.trim()) {
				entries++
			}
		}
	}

	return { entries, files: files.length, issues }
}
