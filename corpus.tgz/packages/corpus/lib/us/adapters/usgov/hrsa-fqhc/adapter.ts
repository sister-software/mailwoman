/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   `usgov-hrsa-fqhc`: HRSA "Health Center Service Delivery Site Locations" CSV consumer.
 *
 *   Federally Qualified Health Centers (FQHCs) are HRSA-funded community health programs that
 *   self-report site addresses to the HRSA Data Warehouse. The published CSV (`data.hrsa.gov`)
 *   carries the site name, the postal-formatted street address, and the locality/region/postcode
 *   quad. The source warrants its place on adversarial-value-per-row (#22): every facility name is a
 *   human-typed venue string and the addresses pass through enough hands to accumulate the
 *   abbreviation drift + suite designator chaos that pure gazetteer data does not.
 *
 *   The adapter consumes a CSV file the operator pre-downloads. The HRSA data is published as a
 *   single national CSV (~10K rows), small enough that the operator can re-fetch on every corpus
 *   rebuild without an intermediate SQLite step. Column names below match the HRSA Data Warehouse's
 *   "Health Center Service Delivery Site" public dataset. Operators substituting the
 *   closely-related "Site Address" or "Health Center" public extracts may need to remap columns.
 *   the readme documents the expected set.
 *
 *   Output: one row per CSV record, with `venue` component carrying the site name and the address
 *   quad on `(house_number, street, locality, region, postcode)`. Component order is critical:
 *   `venue` is inserted first so alignment claims its surface span before `locality` searches for
 *   its own (the kryptonite case "Buffalo Health Clinic, …, Buffalo, NY" relies on `venue`
 *   consuming the first "Buffalo" so locality lands on the second).
 *
 *   License: stamped `"Public Domain"` per the HRSA Data Warehouse's federal government distribution
 *   terms.
 */

import { formatAddressRow } from "@mailwoman/codex/address-format"
import { CSVSpliterator } from "spliterator"

import { splitStreetLine, stableSourceID } from "#adapters/utils"
import { AddressRole, type AdapterOptions, type CanonicalRow, type CorpusAdapter } from "#types"
import { lookupStateAbbreviation } from "#us/fips-state"

/**
 * Registry id for this adapter.
 *
 * Stamped into every row it emits, so a corpus record can be traced back to the dataset it came from.
 */
export const USGOV_HRSA_FQHC_ADAPTER_ID = "usgov-hrsa-fqhc"
/**
 * License carried by this source (Public Domain), attached to each row so downstream
 * consumers inherit the terms rather than having to look them up.
 */
export const USGOV_HRSA_FQHC_DEFAULT_LICENSE = "Public Domain"

/**
 * Subset of HRSA "Health Center Service Delivery Site Locations" CSV columns consulted by the adapter.
 *
 * Column names match the canonical HRSA Data Warehouse export header.
 * Operators substituting a closely-related extract should rename columns to match.
 * The readme has the mapping cheatsheet.
 */
interface HRSASiteRow {
	"Site Name": string
	"Site Address": string
	"Site City": string
	"Site State Abbreviation": string
	"Site Postal Code": string
	/**
	 * Optional.
	 *
	 * Falls back to `stableSourceID` derived from components when missing.
	 */
	"Site ID"?: string
}

/**
 * Split a "123 Main St Suite 4" surface form into `(house_number, street)`.
 *
 * The regex tolerates one trailing letter on the number (`"123A Main St"`)
 * and a hyphenated form (`"40-12 Bell Blvd"`); anything else falls back to street-only.
 *
 * Suite / Apt / Unit designators stay on `street`.
 * Mailwoman's `unit` component exists but the address-formatter does not have a clean
 * slot for it, and HRSA addresses do not separate the suite into its own column.
 *
 * Leaving the surface form intact in `street` keeps the adversarial training signal
 * (the model learns that a trailing "Suite 4" is part of the road line in this distribution).
 */

export function createUSGovHRSAFQHCAdapter(): CorpusAdapter {
	return {
		id: USGOV_HRSA_FQHC_ADAPTER_ID,
		defaultLicense: USGOV_HRSA_FQHC_DEFAULT_LICENSE,
		addressRole: AddressRole.Facility,
		description:
			"HRSA Federally Qualified Health Center site locations (public-domain). Adversarial source: venue + address co-occurrence, hand-entered.",

		async *rows(opts: AdapterOptions): AsyncIterable<CanonicalRow> {
			if (opts.country && opts.country !== "US") {
				throw new Error(`usgov-hrsa-fqhc adapter: only US supported, got country=${opts.country}`)
			}

			const rows = CSVSpliterator.fromAsync(opts.inputPath, {
				normalizeKeys: false,
			})

			let emitted = 0

			for await (const record of rows as AsyncIterable<HRSASiteRow>) {
				if (opts.signal?.aborted) break

				if (opts.limit !== undefined && emitted >= opts.limit) break

				const venue = (record["Site Name"] ?? "").trim()
				const split = splitStreetLine(record["Site Address"] ?? "")
				const city = (record["Site City"] ?? "").trim()
				const stateAbbr = (record["Site State Abbreviation"] ?? "").trim()
				const postcode = (record["Site Postal Code"] ?? "").trim()

				if (!venue || !split || !city || !postcode) continue
				const state = lookupStateAbbreviation(stateAbbr)

				if (!state) continue

				// Insertion order matters here.
				// `venue` first so alignment claims its span (which may contain a token like "Buffalo")
				// before `locality` runs its search — the kryptonite case `Buffalo Health Clinic, Buffalo NY`
				// otherwise mis-labels the venue's "Buffalo" as locality.
				const components: CanonicalRow["components"] = {
					venue,
					...(split.house_number ? { house_number: split.house_number } : {}),
					street: split.street,
					locality: city,
					region: state.abbreviation,
					postcode,
				}

				const rendered = formatAddressRow(components, "US", { singleLine: true })

				if (!rendered) continue

				const { raw, components: aligned } = rendered

				const siteID = (record["Site ID"] ?? "").trim()

				const sourceID = siteID
					? `${USGOV_HRSA_FQHC_ADAPTER_ID}-${siteID}`
					: stableSourceID(USGOV_HRSA_FQHC_ADAPTER_ID, aligned)

				yield {
					raw,
					components: aligned,
					country: "US",
					locale: "en-US",
					source: USGOV_HRSA_FQHC_ADAPTER_ID,
					source_id: sourceID,
					corpus_version: "",
					license: USGOV_HRSA_FQHC_DEFAULT_LICENSE,
				}

				emitted++
			}
		},
	}
}

/**
 * The configured adapter instance registered with the corpus builder.
 */
export const usgovHrsaFqhcAdapter = createUSGovHRSAFQHCAdapter()
