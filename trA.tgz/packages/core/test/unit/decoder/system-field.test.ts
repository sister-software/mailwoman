/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Interface tests for `AddressTree.system` + the `containmentFor` indirection — the forward-compat
 *   anti-lock-in boundary (DeepSeek resolver consult, 2026-05-30). These lock in two guarantees:
 *
 *   1. The discriminator round-trips: `buildAddressTree(..., { system })` stamps `tree.system`, and
 *        omitting it leaves `system` absent (the default Western path).
 *   2. It is currently behavior-neutral: every system resolves to the same containment map, so the same
 *        tokens produce a structurally identical tree regardless of `system`. (When a distinct
 *        system map lands in Phase 6, that last guarantee is the one that intentionally changes —
 *        and this test is where the change must be made deliberately rather than by accident.)
 */

import { buildAddressTree } from "@mailwoman/core/decoder/build-tree"
import { containmentFor, PARENT_OF, WESTERN_PARENT_OF } from "@mailwoman/core/decoder/containment"
import type { DecoderToken } from "@mailwoman/core/decoder/types"
import { validateTree } from "@mailwoman/core/decoder/validate-tree"
import { describe, expect, test } from "vitest"

import { tok, WHITE_HOUSE_RAW } from "./fixtures.ts"

function tokens(): DecoderToken[] {
	return [
		tok("1600", 0, 4, "B-house_number"),
		tok("Pennsylvania", 5, 17, "B-street"),
		tok("Avenue", 18, 24, "I-street"),
		tok("NW", 25, 27, "I-street"),
		tok("Washington", 29, 39, "B-locality"),
		tok("DC", 41, 43, "B-region"),
		tok("20500", 44, 49, "B-postcode"),
	]
}

interface ShapedNode {
	tag: string
	value: string
	children: readonly ShapedNode[]
}

/**
 * Stable structural fingerprint: each node as `tag(value)` with nested children.
 */
function shape(nodes: readonly ShapedNode[]): string {
	return nodes.map((n) => `${n.tag}[${shape(n.children)}]`).join(",")
}

describe("AddressTree.system + containmentFor", () => {
	test("system is absent by default", () => {
		const tree = buildAddressTree(WHITE_HOUSE_RAW, tokens())
		expect(tree.system).toBeUndefined()
	})

	test("buildAddressTree stamps the requested system onto the tree", () => {
		expect(buildAddressTree(WHITE_HOUSE_RAW, tokens(), { system: "western" }).system).toBe("western")
		expect(buildAddressTree(WHITE_HOUSE_RAW, tokens(), { system: "japanese" }).system).toBe("japanese")
	})

	test("system is behavior-neutral today — identical structure regardless of system", () => {
		const base = shape(buildAddressTree(WHITE_HOUSE_RAW, tokens()).roots)
		const western = shape(buildAddressTree(WHITE_HOUSE_RAW, tokens(), { system: "western" }).roots)
		const japanese = shape(buildAddressTree(WHITE_HOUSE_RAW, tokens(), { system: "japanese" }).roots)
		expect(western).toBe(base)
		expect(japanese).toBe(base)
	})

	test("containmentFor returns the Western map for every system today", () => {
		expect(containmentFor(undefined)).toBe(WESTERN_PARENT_OF)
		expect(containmentFor("western")).toBe(WESTERN_PARENT_OF)
		expect(containmentFor("japanese")).toBe(WESTERN_PARENT_OF)
	})

	test("PARENT_OF alias still points at the Western map (back-compat for existing imports)", () => {
		expect(PARENT_OF).toBe(WESTERN_PARENT_OF)
	})

	test("validateTree honors the tree's system (a valid Western tree stays valid when tagged)", () => {
		const tree = buildAddressTree(WHITE_HOUSE_RAW, tokens(), { system: "western" })
		expect(validateTree(tree).valid).toBe(true)
	})
})
