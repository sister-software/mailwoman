/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 */

import { buildAddressTree } from "@mailwoman/core/decoder/build-tree"
import type { AddressNode, DecoderToken } from "@mailwoman/core/decoder/types"
import { describe, expect, test } from "vitest"

import { findByTag, tok, WHITE_HOUSE_RAW, whiteHouseTokens } from "./fixtures.ts"

describe("buildAddressTree", () => {
	test("emits one span per B-/I- group, dropping O", () => {
		const tree = buildAddressTree(WHITE_HOUSE_RAW, whiteHouseTokens())
		// 5 spans: house_number, street, locality, region, postcode
		const allTags: string[] = []

		const collect = (n: AddressNode): void => {
			allTags.push(n.tag)

			for (const c of n.children) {
				collect(c)
			}
		}

		for (const r of tree.roots) {
			collect(r)
		}

		expect(allTags.toSorted()).toEqual(["house_number", "locality", "postcode", "region", "street"])
	})

	test("groups B-street + I-street + I-street into one street span taken from raw", () => {
		const tree = buildAddressTree(WHITE_HOUSE_RAW, whiteHouseTokens())
		const street = findByTag(tree.roots, "street")!
		expect(street.value).toBe("Pennsylvania Avenue NW")
		expect(street.start).toBe(5)
		expect(street.end).toBe(27)
	})

	test("nests house_number under street", () => {
		const tree = buildAddressTree(WHITE_HOUSE_RAW, whiteHouseTokens())
		const street = findByTag(tree.roots, "street")!
		expect(street.children.map((c) => c.tag)).toContain("house_number")
	})

	test("nests street + postcode under locality (containment, not source order)", () => {
		const tree = buildAddressTree(WHITE_HOUSE_RAW, whiteHouseTokens())
		const locality = findByTag(tree.roots, "locality")!
		const childTags = locality.children.map((c) => c.tag)
		expect(childTags).toContain("street")
		expect(childTags).toContain("postcode")
	})

	test("nests locality under region; region is the only root", () => {
		const tree = buildAddressTree(WHITE_HOUSE_RAW, whiteHouseTokens())
		expect(tree.roots).toHaveLength(1)
		expect(tree.roots[0]!.tag).toBe("region")
		expect(tree.roots[0]!.children.map((c) => c.tag)).toEqual(["locality"])
	})

	test("source order preserved in sibling sort (street before postcode under locality)", () => {
		const tree = buildAddressTree(WHITE_HOUSE_RAW, whiteHouseTokens())
		const locality = findByTag(tree.roots, "locality")!
		expect(locality.children.map((c) => c.tag)).toEqual(["street", "postcode"])
	})

	test("hanging I- with no prior B- starts a new span (lenient recovery)", () => {
		const raw = "Paris"
		const tokens: DecoderToken[] = [tok("Paris", 0, 5, "I-locality")]
		const tree = buildAddressTree(raw, tokens)
		expect(tree.roots[0]?.tag).toBe("locality")
		expect(tree.roots[0]?.value).toBe("Paris")
	})

	test("confidence is the mean of token confidences across the span", () => {
		const raw = "Pennsylvania Avenue"
		const tokens: DecoderToken[] = [tok("Pennsylvania", 0, 12, "B-street", 0.8), tok("Avenue", 13, 19, "I-street", 0.6)]
		const tree = buildAddressTree(raw, tokens)
		expect(tree.roots[0]!.confidence).toBeCloseTo(0.7, 5)
	})

	test("postcode-before-locality still attaches to locality (nearest-parent rule)", () => {
		// "75004 Paris"
		const raw = "75004 Paris"
		const tokens: DecoderToken[] = [tok("75004", 0, 5, "B-postcode"), tok("Paris", 6, 11, "B-locality")]
		const tree = buildAddressTree(raw, tokens)
		const locality = findByTag(tree.roots, "locality")!
		expect(locality.children.map((c) => c.tag)).toEqual(["postcode"])
	})
})

// Boundary-trim regression coverage.
// Samples sourced from v0.4.0's post-hoc regression
// diagnostic (.playpen/control/drafts/v0_4_0-regression-diagnostic.md).
// The shipped v0.4.0 model occasionally emits BIO spans with leading/trailing punctuation.
// the decoder now trims the span boundary past non-word characters. start/end tighten in sync
// so consumers slicing raw[start:end] get the same string as node.value.
describe("buildAddressTree — boundary trim", () => {
	test("strips leading comma+space from postcode span", () => {
		// Simulates ", 7647" pred for the gold "76470" — the slip from the diagnostic.
		const raw = ", 22220"
		const tokens: DecoderToken[] = [tok(", 22220", 0, 7, "B-postcode")]
		const tree = buildAddressTree(raw, tokens)
		const postcode = findByTag(tree.roots, "postcode")!
		expect(postcode.value).toBe("22220")
		expect(postcode.start).toBe(2)
		expect(postcode.end).toBe(7)
		expect(raw.slice(postcode.start, postcode.end)).toBe(postcode.value)
	})

	test("strips trailing punctuation from postcode span", () => {
		const raw = "Paris 75004,"
		const tokens: DecoderToken[] = [tok("Paris", 0, 5, "B-locality"), tok("75004,", 6, 12, "B-postcode")]
		const tree = buildAddressTree(raw, tokens)
		const postcode = findByTag(tree.roots, "postcode")!
		expect(postcode.value).toBe("75004")
		expect(postcode.end).toBe(11)
	})

	test("drops a span that trims to empty (all-punctuation)", () => {
		const raw = "350 5th Ave"

		const tokens: DecoderToken[] = [
			tok("350", 0, 3, "B-house_number"),
			tok(" ", 3, 4, "B-postcode"), // pathological model emission
			tok("5th", 4, 7, "B-street"),
			tok("Ave", 8, 11, "I-street"),
		]

		const tree = buildAddressTree(raw, tokens)
		expect(tree.roots.some((r) => r.tag === "postcode")).toBe(false)
	})

	test("preserves Unicode letters (accents, non-Latin) in span values", () => {
		const raw = "Montréal, QC"

		const tokens: DecoderToken[] = [
			tok("Montréal", 0, 8, "B-locality"),
			tok(",", 8, 9, "O"),
			tok("QC", 10, 12, "B-region"),
		]

		const tree = buildAddressTree(raw, tokens)
		const locality = findByTag(tree.roots, "locality")!
		expect(locality.value).toBe("Montréal")
	})

	test("does not trim word-internal punctuation (hyphens, apostrophes)", () => {
		const raw = "Sainte-Livrade-sur-Lot"
		const tokens: DecoderToken[] = [tok("Sainte-Livrade-sur-Lot", 0, 22, "B-locality")]
		const tree = buildAddressTree(raw, tokens)
		expect(tree.roots[0]!.value).toBe("Sainte-Livrade-sur-Lot")
	})

	test("preserves trailing abbreviation period (#1519 trailing-dot fix)", () => {
		// "Neusser Str." — model correctly labels the dot as I-street.
		// The period is an abbreviation marker rather than a punctuation slip.
		const raw = "Neusser Str. 12"

		const tokens: DecoderToken[] = [
			tok("Neusser", 0, 7, "B-street"),
			tok("Str.", 8, 12, "I-street"),
			tok("12", 13, 15, "B-house_number"),
		]

		const tree = buildAddressTree(raw, tokens)

		const street = findByTag(tree.roots, "street")!
		expect(street.value).toBe("Neusser Str.")
		expect(raw.slice(street.start, street.end)).toBe("Neusser Str.")
	})

	test("strips trailing comma but preserves abbreviation period", () => {
		// "Neusser Str.," — the comma is punctuation slip, the dot is abbreviation.
		const raw = "Neusser Str., 12"

		const tokens: DecoderToken[] = [
			tok("Neusser", 0, 7, "B-street"),
			tok("Str.,", 8, 13, "I-street"),
			tok("12", 14, 16, "B-house_number"),
		]

		const tree = buildAddressTree(raw, tokens)
		const street = findByTag(tree.roots, "street")!
		expect(street.value).toBe("Neusser Str.")
		expect(raw.slice(street.start, street.end)).toBe("Neusser Str.")
	})

	test("preserves abbreviation period on single-token street span", () => {
		// "Av." as a standalone abbreviation — span is the whole token.
		const raw = "Av. Paulista, 100"

		const tokens: DecoderToken[] = [
			tok("Av.", 0, 3, "B-street"),
			tok("Paulista,", 4, 13, "I-street"),
			tok("100", 14, 17, "B-house_number"),
		]

		const tree = buildAddressTree(raw, tokens)

		const street = findByTag(tree.roots, "street")!
		expect(street.value).toBe("Av. Paulista")
	})
})

// Paired-punctuation span-edge trimming (paired-punctuation audit, .superpowers/sdd/task-9-audit-report.md).
// `trimBoundary` is generic — it strips any leading/trailing non-word character,
// one at a time, with no notion of "pairing" at all.
// That's what makes it inherently safe for unbalanced paired punctuation too:
// it never looks for a matching partner, so a lone leading quote with no closer, or a lone
// trailing paren with no opener, trims exactly the same way a single stray comma does.
// These cases characterize that the existing mechanism (built for the v0.4.0 comma-slip class)
// generalizes to quotes/brackets/braces/guillemets without any dedicated code.
describe("buildAddressTree — paired-punctuation span-edge trimming", () => {
	test('strips a wrapping straight-quote pair from a venue-shaped span ("The Grange")', () => {
		const raw = '"The Grange", Fishburn'

		const tokens: DecoderToken[] = [
			tok('"The', 0, 4, "B-venue"),
			tok('Grange",', 5, 13, "I-venue"),
			tok("Fishburn", 14, 22, "B-locality"),
		]

		const tree = buildAddressTree(raw, tokens)
		const venue = findByTag(tree.roots, "venue")!
		expect(venue.value).toBe("The Grange")
		expect(raw.slice(venue.start, venue.end)).toBe("The Grange")
	})

	test("strips a wrapping parenthetical from an aside-shaped span (rear entrance)", () => {
		const raw = "12 High St (rear entrance), Leeds"
		const tokens: DecoderToken[] = [tok("(rear", 11, 16, "B-unit"), tok("entrance),", 17, 27, "I-unit")]
		const tree = buildAddressTree(raw, tokens)
		const unit = findByTag(tree.roots, "unit")!
		expect(unit.value).toBe("rear entrance")
	})

	test("strips a wrapping bracket pair from a designator-shaped span [Block B]", () => {
		const raw = "Unit 4 [Block B]"
		const tokens: DecoderToken[] = [tok("[Block", 7, 13, "B-unit"), tok("B]", 14, 16, "I-unit")]
		const tree = buildAddressTree(raw, tokens)
		const unit = findByTag(tree.roots, "unit")!
		expect(unit.value).toBe("Block B")
	})

	test("strips a wrapping brace pair {Block C}", () => {
		const raw = "{Block C}, Leeds"
		const tokens: DecoderToken[] = [tok("{Block", 0, 6, "B-unit"), tok("C},", 7, 10, "I-unit")]
		const tree = buildAddressTree(raw, tokens)
		const unit = findByTag(tree.roots, "unit")!
		expect(unit.value).toBe("Block C")
	})

	test("strips wrapping guillemets «The Grange»", () => {
		const raw = "«The Grange», Fishburn"

		const tokens: DecoderToken[] = [
			tok("«The", 0, 4, "B-venue"),
			tok("Grange»,", 5, 13, "I-venue"),
			tok("Fishburn", 14, 22, "B-locality"),
		]

		const tree = buildAddressTree(raw, tokens)
		const venue = findByTag(tree.roots, "venue")!
		expect(venue.value).toBe("The Grange")
	})

	test("strips curly quotes “The Grange” the same way as straight quotes", () => {
		const raw = "“The Grange”, Fishburn"
		const tokens: DecoderToken[] = [tok("“The", 0, 4, "B-venue"), tok("Grange”,", 5, 13, "I-venue")]
		const tree = buildAddressTree(raw, tokens)
		const venue = findByTag(tree.roots, "venue")!
		expect(venue.value).toBe("The Grange")
	})

	test("UNBALANCED leading quote (no closer anywhere) still trims cleanly, no crash", () => {
		const raw = '"The Grange, Fishburn'

		const tokens: DecoderToken[] = [
			tok('"The', 0, 4, "B-venue"),
			tok("Grange,", 5, 12, "I-venue"),
			tok("Fishburn", 13, 21, "B-locality"),
		]

		expect(() => buildAddressTree(raw, tokens)).not.toThrow()
		const venue = findByTag(buildAddressTree(raw, tokens).roots, "venue")!
		expect(venue.value).toBe("The Grange")
	})

	test("UNBALANCED trailing paren (no opener anywhere) still trims cleanly, no crash", () => {
		const raw = "12 High St rear entrance), Leeds"
		const tokens: DecoderToken[] = [tok("rear", 11, 15, "B-unit"), tok("entrance),", 16, 26, "I-unit")]
		expect(() => buildAddressTree(raw, tokens)).not.toThrow()
		const unit = findByTag(buildAddressTree(raw, tokens).roots, "unit")!
		expect(unit.value).toBe("rear entrance")
	})

	test("an all-punctuation paired-quote-only span (empty content) is dropped, not crashed on", () => {
		const raw = '"", Fishburn'
		const tokens: DecoderToken[] = [tok('"",', 0, 3, "B-venue"), tok("Fishburn", 4, 12, "B-locality")]
		expect(() => buildAddressTree(raw, tokens)).not.toThrow()
		const tree = buildAddressTree(raw, tokens)
		expect(tree.roots.some((r) => r.tag === "venue")).toBe(false)
	})
})

// Spurious-boundary repair.
// The neural model fragments some multi-word locality values into two B-locality spans
// ("Saint Paul" → B-locality "Saint" + B-locality "Paul") — a real, decode- agnostic
// emission bug (argmax == viterbi. see scripts/diag-saintalbans.ts).
// A `B-X` token that is whitespace-adjacent to an open `X` span is folded in.
// a comma/separator keeps spans distinct.
describe("buildAddressTree — adjacent same-tag merge (fragmentation repair)", () => {
	function localitySpans(nodes: AddressNode[]): AddressNode[] {
		const out: AddressNode[] = []

		const walk = (n: AddressNode): void => {
			if (n.tag === "locality") {
				out.push(n)
			}

			for (const c of n.children) {
				walk(c)
			}
		}

		for (const n of nodes) {
			walk(n)
		}

		return out
	}

	test("folds whitespace-adjacent B-locality B-locality into one span", () => {
		// "Saint Paul, MN" — model emits B-locality on both "Saint" and "Paul".
		const raw = "Saint Paul, MN"

		const tokens: DecoderToken[] = [
			tok("Saint", 0, 5, "B-locality"),
			tok("Paul", 6, 10, "B-locality"),
			tok(",", 10, 11, "O"),
			tok("MN", 12, 14, "B-region"),
		]

		const locs = localitySpans(buildAddressTree(raw, tokens).roots)
		expect(locs).toHaveLength(1)
		expect(locs[0]!.value).toBe("Saint Paul")
		expect(locs[0]!.start).toBe(0)
		expect(locs[0]!.end).toBe(10)
	})

	test("folds across a zero-width whitespace-only O artifact (real SentencePiece stream)", () => {
		// Exact stream observed from the model (scripts/diag-saintalbans.ts): SentencePiece emits a
		// standalone zero-width "▁" marker between the words, labeled O. It must not break the span.
		const raw = "Saint Paul, MN"

		const tokens: DecoderToken[] = [
			tok("▁Saint", 0, 5, "B-locality"),
			tok("▁", 6, 6, "O"),
			tok("Paul", 6, 10, "B-locality"),
			tok(",", 10, 11, "O"),
			tok("▁", 12, 12, "O"),
			tok("MN", 12, 14, "B-region"),
		]

		const locs = localitySpans(buildAddressTree(raw, tokens).roots)
		expect(locs).toHaveLength(1)
		expect(locs[0]!.value).toBe("Saint Paul")
	})

	test("merges within a full address too (St + Albans → one locality)", () => {
		// "22 Brigham Rd, Saint Albans, VT 05478"
		const raw = "22 Brigham Rd, Saint Albans, VT 05478"

		const tokens: DecoderToken[] = [
			tok("22", 0, 2, "B-house_number"),
			tok("Brigham", 3, 10, "B-street"),
			tok("Rd", 11, 13, "I-street"),
			tok(",", 13, 14, "O"),
			tok("Saint", 15, 20, "B-locality"),
			tok("Albans", 21, 27, "B-locality"),
			tok(",", 27, 28, "O"),
			tok("VT", 29, 31, "B-region"),
			tok("05478", 32, 37, "B-postcode"),
		]

		const locs = localitySpans(buildAddressTree(raw, tokens).roots)
		expect(locs).toHaveLength(1)
		expect(locs[0]!.value).toBe("Saint Albans")
	})

	test("GUARD: comma between same-tag spans keeps them distinct (no merge)", () => {
		// Two separate localities, comma in the gap (no intervening O token).
		const raw = "Dallas, Austin"
		const tokens: DecoderToken[] = [tok("Dallas", 0, 6, "B-locality"), tok("Austin", 8, 14, "B-locality")]
		const locs = localitySpans(buildAddressTree(raw, tokens).roots)
		expect(locs).toHaveLength(2)
		expect(locs.map((l) => l.value).toSorted()).toEqual(["Austin", "Dallas"])
	})

	test("GUARD: intervening O token keeps same-tag spans distinct", () => {
		const raw = "Dallas , Austin"

		const tokens: DecoderToken[] = [
			tok("Dallas", 0, 6, "B-locality"),
			tok(",", 7, 8, "O"),
			tok("Austin", 9, 15, "B-locality"),
		]

		const locs = localitySpans(buildAddressTree(raw, tokens).roots)
		expect(locs).toHaveLength(2)
	})

	test("merged span confidence is the mean across all folded tokens", () => {
		const raw = "Saint Paul"
		const tokens: DecoderToken[] = [tok("Saint", 0, 5, "B-locality", 0.9), tok("Paul", 6, 10, "B-locality", 0.5)]
		const locs = localitySpans(buildAddressTree(raw, tokens).roots)
		expect(locs).toHaveLength(1)
		expect(locs[0]!.confidence).toBeCloseTo(0.7, 5)
	})
})

// Diagnostic for the en-GB locale arc (docs/superpowers/specs/2026-07-22-en-gb-locale-arc-design.md, Phase 3):
// the spec assumed the word-consistency heal lumps "suburb, city" into one locality span.
// These characterize `emitSpans` directly to settle whether the decode pipeline itself
// preserves the dependent_locality/locality distinction across a comma.
describe("buildAddressTree — dependent_locality/locality comma separation (spec Phase-3 diagnostic)", () => {
	function tagsOf(nodes: AddressNode[]): string[] {
		const out: string[] = []

		const walk = (n: AddressNode): void => {
			out.push(n.tag)

			for (const c of n.children) {
				walk(c)
			}
		}

		for (const n of nodes) {
			walk(n)
		}

		return out
	}

	test("distinct tags across a comma stay two spans (Plimmerton, Porirua)", () => {
		// "Plimmerton, Porirua" — dependent_locality then (after the comma) locality.
		const raw = "Plimmerton, Porirua"

		const tokens: DecoderToken[] = [
			tok("Plimmerton", 0, 10, "B-dependent_locality"),
			tok(",", 10, 11, "O"),
			tok("Porirua", 12, 19, "B-locality"),
		]

		const tree = buildAddressTree(raw, tokens)
		const tags = tagsOf(tree.roots).toSorted()
		expect(tags).toEqual(["dependent_locality", "locality"])

		const depLocality = findByTag(tree.roots, "dependent_locality")!
		const locality = findByTag(tree.roots, "locality")!
		expect(depLocality.value).toBe("Plimmerton")
		expect(locality.value).toBe("Porirua")
	})

	test("GUARD: same-tag spans across a comma stay two spans (Springfield, Chicago)", () => {
		// Documents the comma guard already asserted in emitSpans: same-tag same-address spans
		// separated by a comma never merge, so a locality/locality "suburb, city" pair the
		// model emits as two distinct B-locality spans is not lumped by the decoder.
		const raw = "Springfield, Chicago"

		const tokens: DecoderToken[] = [
			tok("Springfield", 0, 11, "B-locality"),
			tok(",", 11, 12, "O"),
			tok("Chicago", 13, 20, "B-locality"),
		]

		const tree = buildAddressTree(raw, tokens)
		const localities: AddressNode[] = []

		const walk = (n: AddressNode): void => {
			if (n.tag === "locality") {
				localities.push(n)
			}

			for (const c of n.children) {
				walk(c)
			}
		}

		for (const r of tree.roots) {
			walk(r)
		}

		expect(localities).toHaveLength(2)
		expect(localities.map((l) => l.value).toSorted()).toEqual(["Chicago", "Springfield"])
	})
})
