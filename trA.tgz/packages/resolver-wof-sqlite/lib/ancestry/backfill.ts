/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Repair the truncated ancestry that {@link populateAncestors} (the parent_id closure in
 *   unified-schema.ts) leaves wherever the closure dead-ends before reaching the top.
 *
 *   Root cause (#440 / #832): a place that straddles multiple parents — New York City spans five
 *   counties (its boroughs), London 30+ — carries `wof:parent_id = -4`, so the parent_id closure
 *   dead-ends and the place gets no region/county/country ancestry. The resolver's region-descendant
 *   filter then can't reach it: given "New York, NY", NYC (with no NY-state ancestor) is excluded and
 *   a correctly-parented namesake ("New York Mills", pop 3,190) wins over NYC's 8.8M. The same defect
 *   orphans London, Singapore, and ~2,850 other localities — the most demo-visible queries.
 *
 *   **The dead end is inherited by children (#1445).** Repairing the `-4` place itself does not repair
 *   anything below it: the closure walks Brooklyn → New York and stops, because New York's own
 *   `parent_id` is `-4`. Brooklyn-the-borough (pop 2.5M) therefore carried exactly two ancestor rows —
 *   itself and New York — with no county, region or country, and the only US locality-tier place named
 *   "Brooklyn" that survived a New-York-State descendant filter was Pillar Point, a Jefferson County
 *   hamlet 411 km away carrying "Brooklyn" as an alternate name. All five NYC boroughs, every London
 *   borough and Hyderabad's zones were in the same state.
 *
 *   So the candidate test is not "has only a self ancestor" — that misses every child of a repaired
 *   place, which by construction has two. It is **"has no `country`-tier ancestor"**. Country is the
 *   universal terminal for every non-{@link TOP_PLACETYPES} placetype, so its absence is exactly the
 *   signal that the chain dead-ended somewhere, at whatever depth. On a wide-coverage build this
 *   selects ~24k places against 2.55M rows.
 *
 *   A place whose `wof:hierarchy` genuinely stops short is not a candidate and needs no repair: the
 *   source is the authority on what a place should have. American Samoa's localities, for instance,
 *   have `{country_id, locality_id}` and no region in WOF itself — the artifact matching that is
 *   correct rather than truncated.
 *
 *   The authoritative hierarchy is in the source geojson: `wof:hierarchy` is an array of branches,
 *   each a `<placetype>_id` → id map (region_id, county_id, country_id, …), fully populated even when
 *   parent_id is -4. This reads it for every candidate and inserts the missing ancestor rows (one per
 *   distinct ancestor across branches).
 *
 *   Must run after populateAncestors and before the build freezes (vacuum into), so the rows land in
 *   the shipped artifact — `scripts/build-unified-wof.ts` Phase 3 calls it inline. The standalone
 *   `scripts/backfill-ancestors-from-hierarchy.ts` is a thin CLI over the same function for ad-hoc
 *   repair of an already-built DB. Idempotent by the per-pair existence check rather than by the candidate
 *   test: each (id, ancestor_id) is inserted at most once, so a second run over the same DB adds
 *   nothing.
 */

import { readWOFFeature } from "@mailwoman/core/resources/whosonfirst"
import type { DatabaseClient } from "@mailwoman/sqlite/client"
import { join, resolvePath, type PathBuilderLike } from "path-ts"
import { Globerator } from "spliterator/node/fs"

import type { WOFDatabase } from "#schema"

/**
 * Genuinely top-level placetypes — they never have (or need) an ancestor, so skip them.
 */
const TOP_PLACETYPES = new Set(["country", "continent", "empire", "ocean", "marinearea", "planet"])

export interface AncestryBackfillResult {
	/**
	 * Places that gained at least one ancestor row.
	 */
	placesFixed: number
	/**
	 * Total ancestor rows inserted.
	 */
	rowsAdded: number
	/**
	 * Candidates whose source geojson could not be found
	 * (non-WOF backfilled places, or repos not present locally) — skipped rather than an error.
	 */
	noGeojson: number
}

/**
 * Discover the `data` directories under a WOF repos root that hold attached geojson,
 * e.g. `<root>/whosonfirst-data/whosonfirst-data-admin-us/data`.
 *
 * Resolves an id to its geojson via these roots.
 * Accepts both the nested lab layout (a `whosonfirst-data` group dir holding the admin repos)
 * and a flat layout (admin repos directly under the root); searches at most two directory levels deep.
 */
export async function discoverAdminDataRoots(reposRoot: PathBuilderLike): Promise<string[]> {
	const roots: string[] = []

	const visit = async (dir: string, depth: number): Promise<void> => {
		if (depth > 2) return

		let names: string[]

		try {
			names = (await Globerator.from("*", { cwd: dir, withFileTypes: true, onlyFiles: false }).toArray())
				.filter((entry) => entry.isDirectory())
				.map((entry) => entry.name)
		} catch {
			return
		}

		for (const name of names) {
			const child = join(dir, name)

			if (name === "data") {
				roots.push(child)
			} else if (name.startsWith("whosonfirst-data")) {
				await visit(child, depth + 1)
			}
		}
	}

	await visit(resolvePath(reposRoot), 0)

	return roots
}

// `<placetype>_id` key → ancestor placetype.
// WOF hierarchy keys are e.g. region_id, county_id.
// Self is filtered downstream by the `aid === id` check, so we do not special-case locality
// here: for a locality candidate `locality_id` is self (dropped by aid===id), but for a
// neighbourhood candidate `locality_id` is its parent locality — a real ancestor we must keep.
function placetypeFromKey(key: string): string | null {
	if (!key.endsWith("_id")) return null

	return key.slice(0, -3)
}

/**
 * Insert missing ancestor rows for every place whose ancestry chain dead-ended
 * before reaching a country, by reading `wof:hierarchy` from its source geojson
 * under `geojsonRoots` (see {@link discoverAdminDataRoots}).
 *
 * Runs inside a single transaction. caller owns connection lifecycle (open, WAL checkpoint, close).
 *
 * `opts.maxID` bounds the candidate scan to ids below it — pass the synthetic-id base
 * (`OVERTURE_ID_BASE`, 8e12) so the backfill considers only real WOF places.
 * Overture/GeoNames rows carry synthetic ids and have no `wof:hierarchy` geojson,
 * so probing them is pure waste: on a wide-coverage DB the country-less set is
 * millions of Overture/GeoNames leaf localities, and the per-candidate geojson probe
 * across every repo root turns a seconds-long WOF-only pass into a ~40-minute one
 * (their ancestry comes from the parent_id closure rather than this backfill).
 *
 * Correctness-preserving — the skipped rows would have `noGeojson`-skipped anyway.
 * Omit `maxID` (default) for the legacy WOF-only DBs.
 */
export async function backfillAncestorsFromHierarchy(
	db: DatabaseClient<WOFDatabase>,
	geojsonRoots: readonly string[],
	opts: { maxID?: number } = {}
): Promise<AncestryBackfillResult> {
	const maxID = opts.maxID ?? Number.MAX_SAFE_INTEGER

	// "No country-tier ancestor" is the dead-end signal at any depth — see the module docstring.
	// The earlier "<= 1 ancestor row" test only caught the dead end's origin, never the children
	// that inherit it (a child of a repaired -4 place has two rows: itself and that parent) (#1445).
	// The id bound is stated first so SQLite prunes by the PK index before the not exists runs at all.
	const candidateBase = db
		.selectFrom("spr")
		.where("id", "<", maxID)
		.where((eb) =>
			eb.not(
				eb.exists(
					eb
						.selectFrom("ancestors as a")
						.select("a.id")
						.whereRef("a.id", "=", "spr.id")
						.where("a.ancestor_placetype", "=", "country")
				)
			)
		)

	const candidates = await candidateBase.select(["id", "placetype"]).execute()

	// Every candidate's existing ancestors in one query rather than an indexed read each.
	// The widened candidate test made that per-candidate read the dominant cost of the pass,
	// and the set is bounded: a candidate reaching this point has a handful of rows at most.
	// The candidate set rides in as the same predicate re-issued as a subquery, never a
	// materialized `IN (?, ?, …)` list — node:sqlite caps a statement at 32,766 bound variables
	// and the wide-coverage build has 67,521 candidates (measured 2026-08-04).
	const alreadyPresent = new Map<number, Set<number>>()

	for (const row of await db
		.selectFrom("ancestors")
		.select(["id", "ancestor_id"])
		.where("id", "in", candidateBase.select("spr.id"))
		.execute()) {
		let set = alreadyPresent.get(row.id)

		if (!set) {
			set = new Set()
			alreadyPresent.set(row.id, set)
		}

		set.add(Number(row.ancestor_id))
	}

	const insert = db.prepare(
		"INSERT INTO ancestors (id, ancestor_id, ancestor_placetype, lastmodified) VALUES (?, ?, ?, 0)"
	)

	let placesFixed = 0
	let rowsAdded = 0
	let noGeojson = 0
	db.exec("BEGIN")

	for (const { id, placetype } of candidates) {
		if (placetype && TOP_PLACETYPES.has(placetype)) continue
		const gj = await readWOFFeature(id, geojsonRoots)
		const hierarchy = gj?.properties?.["wof:hierarchy"]

		if (!hierarchy || !hierarchy.length) {
			if (!gj) {
				noGeojson++
			}

			continue
		}

		// Collect distinct (ancestor_id, placetype) across all hierarchy branches, excluding self.
		const seen = new Map<number, string>()

		for (const branch of hierarchy) {
			for (const [key, val] of Object.entries(branch)) {
				const pt = placetypeFromKey(key)

				if (!pt) continue
				const aid = Number(val)

				if (!Number.isFinite(aid) || aid <= 0 || aid === id) continue

				if (!seen.has(aid)) {
					seen.set(aid, pt)
				}
			}
		}

		let present = alreadyPresent.get(id)

		if (!present) {
			present = new Set()
			alreadyPresent.set(id, present)
		}

		let added = 0

		for (const [aid, pt] of seen) {
			if (present.has(aid)) continue

			insert.run(id, aid, pt)
			present.add(aid)

			added++
		}

		if (added > 0) {
			placesFixed++
			rowsAdded += added
		}
	}

	db.exec("COMMIT")

	return { placesFixed, rowsAdded, noGeojson }
}
