/**
 * Train Stage 1 with auto-resume on GPU hang. gfx1103 (Radeon 780M) firmware has observed
 * HW Exception ("GPU Hang") under sustained load roughly every 1-2h.
 *
 * This wrapper restarts the training process when it exits non-zero,
 * resuming from the latest step-* checkpoint.
 *
 * Run from the `corpus-python/` directory so the relative `$config` path resolves against cwd:
 *
 * HSA_OVERRIDE_GFX_VERSION=11.0.0 node scripts/train_with_resume.ts [extra args passed to python -m mailwoman_train
 * train]
 *
 * Stops when:
 *
 * - Python exits 0 (training reached max_steps)
 * - Signal trap caught (sigint/sigterm)
 * - Max-attempts reached (default 50, override via $MAX_ATTEMPTS)
 */

import { tempRootPath } from "@mailwoman/core/data-root"
import { liveEnv } from "@mailwoman/core/env"
import { open } from "@mailwoman/core/fs/readers"
import { passThroughCLIArguments } from "@mailwoman/core/scripting/utils"
import { z } from "zod"
import { $, sleep } from "zx"

const $public = liveEnv(
	z.object({
		MAX_ATTEMPTS: z.string().optional(),
		LOG: z.string().optional(),
		CONFIG: z.string().optional(),
	})
)

const MAX_ATTEMPTS = Number($public.MAX_ATTEMPTS ?? 50)
const LOG = $public.LOG ?? tempRootPath("stage1-train.log")
const CONFIG = $public.CONFIG ?? "src/mailwoman_train/configs/stage1-coarse.yaml"
/**
 * Verbatim passthrough to `python -m mailwoman_train train` — parseArgs cannot collect
 * undeclared flags, and reconstructing them from tokens would be lossy.
 */
const ADDITIONAL_COMMAND_LINE_ARGS = passThroughCLIArguments()

// Open the log once in append mode. every attempt appends to the same file (bash did `>>"$LOG" 2>&1` per invocation).
const logFd = await open(LOG, "a")

// zx prints the command to stderr by default. the bash wrapper kept python output in $LOG only, so stay quiet.
$.verbose = false

// Match the bash trap: on sigint/sigterm, log a line and exit 130.
function onSignal(): void {
	console.log("[wrapper] received signal, exiting")

	process.exit(130)
}

process.on("SIGINT", onSignal)
process.on("SIGTERM", onSignal)

/**
 * Spawn the python trainer, routing its stdout+stderr to $LOG (matching bash `>>"$LOG" 2>&1`)
 * and returning the exit code without throwing on non-zero.
 *
 * @param resume - Whether to pass `--resume auto` (the resume loop) or start fresh.
 */
async function runTraining(resume: boolean): Promise<number> {
	const shell = $({ stdio: ["ignore", logFd.fd, logFd.fd], nothrow: true })

	const output = resume
		? await shell`python -u -m mailwoman_train train --config ${CONFIG} --resume auto ${ADDITIONAL_COMMAND_LINE_ARGS}`
		: await shell`python -u -m mailwoman_train train --config ${CONFIG} ${ADDITIONAL_COMMAND_LINE_ARGS}`

	return output.exitCode ?? 1
}

let attempt = 0

// First attempt — fresh start unless --resume is already in the passed args.
if (!ADDITIONAL_COMMAND_LINE_ARGS.includes("--resume")) {
	console.log("[wrapper] attempt 1: fresh start")

	const exit = await runTraining(false)
	attempt = 1

	if (exit === 0) {
		console.log("[wrapper] training completed successfully on attempt 1")

		process.exit(0)
	}

	console.log(`[wrapper] attempt 1 exited with ${exit} — resuming`)
}

while (attempt < MAX_ATTEMPTS) {
	attempt += 1

	console.log(`[wrapper] attempt ${attempt}: resume=auto`)

	const exit = await runTraining(true)

	if (exit === 0) {
		console.log(`[wrapper] training completed successfully on attempt ${attempt}`)

		process.exit(0)
	}

	console.log(`[wrapper] attempt ${attempt} exited with ${exit}; sleeping 15s then resuming`)

	await sleep("15s")
}

console.log(`[wrapper] MAX_ATTEMPTS=${MAX_ATTEMPTS} reached, giving up`)

process.exit(1)
