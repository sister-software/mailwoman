/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Shared plumbing for the docs structural checks (docs-architecture cleanup, Phase 4): walk
 *   `docs/articles`, parse each page's frontmatter block, and derive the Docusaurus doc id. Used by
 *   `check-docs-structure.ts` (the CI check) and `list-stale-docs.ts` (the quarterly freshness
 *   sweep).
 *
 *   The frontmatter parser is deliberately minimal — top-level `key: scalar` lines only, quotes
 *   stripped. Nested values (`tags:` arrays, block scalars) record the key as declared but carry no
 *   value. That covers every field the checks read (`role`, `status`, `title`, `id`, `review-by`,
 *   …) without pulling a YAML dependency into what must stay a no-install fast path in CI.
 */

// Node builtins on purpose.
// `check-docs-structure.ts` reaches this file, and the Docs workflow runs it before `yarn install`.
// Same reason the frontmatter parser above stays hand-rolled: nothing here may need an install.
/* oxlint-disable typescript/no-restricted-imports -- runs before `yarn install`; see above */
import { readdir, readFile } from "node:fs/promises"
import * as path from "node:path"
import { fileURLToPath } from "node:url"
/* oxlint-enable typescript/no-restricted-imports */

const SCRIPT_DIR = path.dirname(fileURLToPath(import.meta.url))

/**
 * The docs package root, taken as the part of this module's path before its
 * `scripts/` segment rather than by counting `..` upward.
 *
 * A count encodes how deep under `scripts/` this file happens to sit, so moving it down
 * one level resolves to a directory that does not exist — the failure this replaces,
 * where the content root read as `docs/scripts/docs/articles`.
 * Truncating at the segment holds at any depth.
 */
const DOCS_ROOT = SCRIPT_DIR.slice(0, SCRIPT_DIR.lastIndexOf(`${path.sep}scripts${path.sep}`))

/**
 * Absolute path to the docs-plugin content root (`docs/articles`).
 */
export const ARTICLES_DIR = path.join(DOCS_ROOT, "articles")

/**
 * One `.md`/`.mdx` page under `docs/articles`.
 */
export interface DocPage {
	/**
	 * Path relative to `docs/articles`, posix separators — e.g. `concepts/bio-labels.mdx`.
	 */
	relativePath: string
	/**
	 * Absolute filesystem path.
	 */
	absolutePath: string
	/**
	 * The Docusaurus doc id: the directory part of the file path plus the frontmatter `id:`
	 * override (which replaces only the final segment) or the extension-less basename —
	 * e.g. `recipes/timezones.md` with `id: timezone-lookup` → `recipes/timezone-lookup`.
	 */
	id: string
	/**
	 * Top-level scalar frontmatter fields, quotes stripped.
	 */
	frontmatter: Map<string, string>
	/**
	 * Every top-level frontmatter key, including keys whose values are nested/non-scalar.
	 */
	declaredKeys: Set<string>
}

const FRONTMATTER_KEY_PATTERN = /^([A-Za-z][A-Za-z0-9_-]*):(.*)$/

/**
 * Strip one layer of matched surrounding quotes from a scalar value.
 */
function unquote(value: string): string {
	if (value.length >= 2 && (value[0] === '"' || value[0] === "'") && value.endsWith(value[0]!)) {
		return value.slice(1, -1)
	}

	return value
}

/**
 * Parse the leading `---`-fenced frontmatter block of a markdown source.
 *
 * Returns top-level scalar fields plus the set of all declared top-level keys.
 */
export function parseFrontmatter(source: string): { fields: Map<string, string>; declaredKeys: Set<string> } {
	const fields = new Map<string, string>()
	const declaredKeys = new Set<string>()

	let opened = false

	// This module runs in the PRE-install "Docs structure checks" CI check (docs-build.yml), whose
	// interface is node built-ins only — no install has happened when it executes. A spliterator
	// import here is ERR_MODULE_NOT_FOUND on every CI run (2026-08-04). Frontmatter blocks are a
	// handful of short lines. the whole-buffer split costs nothing at this scale.
	// oxlint-disable-next-line mailwoman/prefer-spliterator -- pre-install, built-ins-only CI over a handful of frontmatter lines
	for (const line of source.split("\n")) {
		if (!opened) {
			// A file without the opening fence has no frontmatter at all.
			if (line.trim() !== "---") break

			opened = true

			continue
		}

		if (line.trim() === "---") break

		const match = FRONTMATTER_KEY_PATTERN.exec(line)

		if (!match) continue // Nested/continuation line (indented, `- ` item, …) — not a top-level key.

		const [, key, rawValue] = match
		declaredKeys.add(key!)

		const value = unquote(rawValue!.trim())

		if (value) {
			fields.set(key!, value)
		}
	}

	return { fields, declaredKeys }
}

/**
 * Walk `docs/articles` and parse every `.md`/`.mdx` page.
 */
export async function collectDocPages(): Promise<DocPage[]> {
	const entries = await readdir(ARTICLES_DIR, { recursive: true })
	const pages: DocPage[] = []

	for (const entry of entries.toSorted()) {
		const relativePath = entry.split(path.sep).join("/")

		if (!relativePath.endsWith(".md") && !relativePath.endsWith(".mdx")) continue

		const absolutePath = path.join(ARTICLES_DIR, entry)
		const { fields, declaredKeys } = parseFrontmatter(await readFile(absolutePath, "utf8"))

		const directory = path.posix.dirname(relativePath)
		const basename = path.posix.basename(relativePath).replace(/\.mdx?$/, "")
		const idTail = fields.get("id") ?? basename
		const id = directory === "." ? idTail : `${directory}/${idTail}`

		pages.push({ relativePath, absolutePath, id, frontmatter: fields, declaredKeys })
	}

	return pages
}

/**
 * Mirrors the docs plugin's `exclude` globs in `docs/docusaurus.config.ts` (search for `exclude:` under `path:
 * "articles"`) — pages the build never publishes, so they can't collide or orphan on the live site. Keep the two in
 * sync when the config's exclusions change.
 */
export function isExcludedFromBuild(page: DocPage): boolean {
	if (page.relativePath.startsWith("reviews/")) return true

	if (page.relativePath.startsWith("evals/")) {
		const basename = path.posix.basename(page.relativePath)

		return basename.includes("postmortem") || basename.includes("night-shift-session-report")
	}

	return false
}

/**
 * The evals and retrospectives trees are a delegated workstream (see the coordination
 * boundary in `docs/superpowers/plans/2026-07-14-documentation-architecture-cleanup.md`);
 * their role/status adoption ships with its own check.
 *
 * Only the duplicate-title check reads them — a title collision is site-wide by nature.
 */
export function isDelegatedWorkstream(page: DocPage): boolean {
	return page.relativePath.startsWith("evals/") || page.relativePath.startsWith("retrospectives/")
}
