/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 */

import { EarthRedirect } from "#components/EarthRedirect/EarthRedirect"

export default function TraceRedirect() {
	return <EarthRedirect path="/trace" />
}
