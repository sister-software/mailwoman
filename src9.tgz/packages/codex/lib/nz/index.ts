/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   The New Zealand address system (NZ Post / ISO 3166-2:NZ. ADV358 Address Standards):
 *   delivery-service types (PO Box, Private Bag, CMB, Response Bag, Counter Delivery, Poste
 *   Restante) and the 4-digit postcode. NZ addresses carry no state/region line.
 */

export * from "#nz/delivery-service"
export * from "#nz/postcode"
