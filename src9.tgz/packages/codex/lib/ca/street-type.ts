/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Canadian street types and directionals — bilingual, because Canada Post recognizes both English
 *   and French forms on the same national network.
 *
 *   The informative contrast with `us/street-suffix.ts`, `de/street-type.ts`, and `fr/voie.ts`:
 *
 *   - US — a trailing word with a USPS-standardized abbreviation (`Main Street` → `ST`).
 *   - German — a fused trailing suffix (`Hauptstraße`).
 *   - French — a leading standalone word (`Rue de la Paix`).
 *   - Canadian — both at once. An English street puts the type last (`Maple Avenue`, `Sunset
 *       Crescent`); a French street puts it first (`Rue Sainte-Catherine`, `Boulevard
 *       René-Lévesque`). So {@link isCanadianStreetWord} matches a whole token against either
 *       vocabulary and stays position-agnostic — it cannot assume a side the way the
 *       single-language files do.
 *
 *   The directionals carry the same bilingual twist, and one trap inside it: French `Ouest`
 *   abbreviates to `O`, not `W`. A naive English-only matcher reading `Rue Sherbrooke O` would miss
 *   the quadrant entirely. {@link CA_DIRECTIONALS} spells out the French abbreviations so `O` =
 *   Ouest = West is recognized.
 */

import { foldToken } from "#normalize"

/**
 * English Canadian street-type words (Canada Post's recognized set, lowercase).
 *
 * Appear as the trailing token of an English street name (`Maple Avenue`, `Sunset Crescent`).
 */
export const CA_STREET_TYPES_EN: ReadonlySet<string> = new Set([
	"street",
	"avenue",
	"boulevard",
	"drive",
	"road",
	"crescent",
	"court",
	"place",
	"lane",
	"way",
	"trail",
	"terrace",
	"close",
	"circle",
	"square",
	"heights",
	"grove",
	"gardens",
	"hill",
	"park",
	"row",
	"walk",
	"green",
	"bay",
	"cove",
	"check",
	"point",
	"ridge",
	"view",
])

/**
 * French Canadian street-type words (Canada Post's recognized set, lowercase, accent-containing).
 *
 * Appear as the leading token of a French street name (`Rue Sainte-Catherine`, `Chemin du Roy`).
 * Folded for matching in {@link isCanadianStreetWord}, so `Côte`/`cote` and `Allée`/`allee` key alike.
 */
export const CA_STREET_TYPES_FR: ReadonlySet<string> = new Set([
	"rue",
	"avenue",
	"boulevard",
	"chemin",
	"côte",
	"place",
	"impasse",
	"allée",
	"croissant",
	"montée",
	"rang",
	"ruelle",
	"voie",
	"passage",
	"carré",
	"terrasse",
	"promenade",
	"sentier",
])

/**
 * {@link foldToken}, letters only, so `Côte`/`cote`, `Allée`/`allee`, `Crescent`/`crescent` key alike.
 */
function foldLetters(s: string): string {
	return foldToken(s).replaceAll(/[^a-z]/g, "")
}

/**
 * The English + French street-type vocabularies, both folded, for one position-agnostic lookup.
 */
const STREET_WORD_SET: ReadonlySet<string> = (() => {
	const out = new Set<string>()

	for (const w of CA_STREET_TYPES_EN) {
		out.add(foldLetters(w))
	}

	for (const w of CA_STREET_TYPES_FR) {
		out.add(foldLetters(w))
	}

	return out
})()

/**
 * True when a token is a Canadian street-type word in either language
 * (case- and accent-insensitive) — `Street`, `Crescent`, `Rue`, `Chemin`, `Côte`.
 *
 * Position-agnostic, because an English type trails the name and a French type leads it.
 * The matcher cannot lean on a side.
 */
export function isCanadianStreetWord(token: unknown): boolean {
	if (typeof token !== "string") return false
	const t = foldLetters(token)

	return t.length > 0 && STREET_WORD_SET.has(t)
}

/**
 * Bilingual directional words → canonical compass letter.
 *
 * Covers the bare letters (`N S E W`), the full English words (`North`/`South`/`East`/`West`),
 * and the full French words (`Nord`/`Sud`/`Est`/`Ouest`).
 * The bilingual twist is `O`: French `Ouest` abbreviates to `O`, not `W`,
 * so an English-only matcher silently drops the quadrant on a French address line.
 *
 * Keys are folded (lowercase, accent-free); values are the English compass letter.
 */
export const CA_DIRECTIONALS: Record<string, "N" | "S" | "E" | "W"> = {
	n: "N",
	north: "N",
	nord: "N",
	s: "S",
	south: "S",
	sud: "S",
	e: "E",
	east: "E",
	est: "E",
	w: "W",
	west: "W",
	ouest: "W",
	o: "W", // French Ouest abbreviates to O rather than W — the bilingual trap.
}

/**
 * True when a token is a Canadian directional in either language
 * (case- and accent-insensitive) — `N`, `NW`, `Nord`, `Ouest`, `O`.
 *
 * Compound English quadrants (`NW`, `SE`) are accepted by decomposing into their single-letter halves.
 * The lone French `O` resolves to West.
 */
export function isCanadianDirectional(token: unknown): boolean {
	if (typeof token !== "string") return false
	const t = foldLetters(token)

	if (!t.length) return false

	if (t in CA_DIRECTIONALS) return true

	// Compound English quadrants like NW / SE / NE / SW: each half must be a single-letter directional.
	if (t.length === 2) {
		const isLetter = (h: string): boolean => h === "n" || h === "s" || h === "e" || h === "w"

		return isLetter(t[0]!) && isLetter(t[1]!)
	}

	return false
}
