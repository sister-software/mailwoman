/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   `@mailwoman/api-kit` — plumbing for Mailwoman's http surfaces: the node serve wrapper, OpenAPI
 *   emit helpers, generic timing metrics, and the native error envelope. Plumbing only, by rule:
 *   domain schemas live next to their routes in the package that owns the wire interface (see the
 *   2026-07-12 design spec's anti-meta guardrails).
 */

export * from "#error"
export * from "#geo"
export * from "#metrics"
export * from "#openapi"
export * from "#request"
export * from "#serve"
export * from "#engine-stamp"
