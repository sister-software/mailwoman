/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Read the published file geodatabase as a stream of WGS84 features, through ogr2ogr — one scenario layer
 *   at a time.
 *
 *   OGR is build tooling, never A serve dependency (scope invariant 6). It converts the authority's geometry
 *   into the structure the runtime probes, and nothing downstream of this module knows gdal exists.
 *
 *   the source is not IN WGS84 and saying SO is the check. Every ncerm layer is published in OSGB36 /
 *   British National Grid — metres, easting/northing, epsg:27700 — so a builder that read the coordinates as
 *   degrees would place every polygon off the west coast of Africa. The projection is asserted against each
 *   layer's declared authority code before a single feature is read, and the reprojected stream is asserted
 *   against the collection's own declared bounding box, which is the check that catches a coordinate-order
 *   mistake the projection check cannot see.
 *
 *   the datum shift needs A grid, and its absence is silent. OSGB36 to WGS84 is accurate to a metre only
 *   through the OSTN15 grid. without it proj substitutes a ballpark offset and produces coordinates that are
 *   metres wrong and indistinguishable from correct ones. On the sibling flood product that showed up only as
 *   eight disagreements out of 59 against the authority's own service.
 *   {@linkcode assertDatumTransformationAvailable} refuses the build rather than letting the whole layer
 *   shift.
 *
 *   `OGR_GEOM_AREA` rides along AS the independent area witness. gdal computes it on the source geometry in
 *   the source's own metres, before reprojection and before this package has touched a ring — so comparing it
 *   against an area computed from the encoded rings is a two-path check on ring nesting and hole handling,
 *   which are otherwise silent when wrong.
 *
 *   the distance column is named PER layer and is aliased here. `nfi2055_0` on NFI/2055/0CC, `smp2105_95` on
 *   SMP/2105/95CC — twelve names for one quantity. The `select` aliases whichever one this scenario declares
 *   to `distance_m`, so nothing downstream carries twelve branches, and a scenario whose column has been
 *   renamed fails as a SQL error naming the column rather than as a stream of null distances.
 */

import { stringifyJSON } from "@mailwoman/core/json"
import { limitedFeatureCount } from "@mailwoman/core/layers"
import { assertRingsInsideExtent, requireArealPolygons, type MultiPolygonRings } from "@mailwoman/spatial"
import { readOGRLayerIdentity } from "@mailwoman/spatial/tools/ogr"
import { ogr2ogrGeoJSONSeq } from "@mailwoman/spatial/tools/ogr-stream"

import {
	NCERM_DECLARED_BBOX,
	NCERM_SCENARIOS_BY_KEY,
	NCERM_SOURCE_EPSG,
	scenarioCarriesPolicy,
	type CoastalScenario,
} from "#vocabulary"

/**
 * The ring types and the proj guard, both re-exported from `@mailwoman/spatial`:
 * neither is coastal-specific, and a second copy of the `projinfo` parse would be
 * a second place for the ballpark check to stop refusing.
 */

/**
 * One erosion-zone feature, reprojected to WGS84.
 */
export interface CoastalSourceFeature {
	/**
	 * `<scenario key>:<objectid>`.
	 */
	areaID: string
	scenario: CoastalScenario
	frontageID: number
	distanceM: number
	smpNo: number | null
	smpName: string | null
	smpPolicyUnit: string | null
	mtPolicy: string | null
	mtPolicyInterpretation: string | null
	ltPolicy: string | null
	ltPolicyInterpretation: string | null
	defenceType: string | null
	publishedYear: number | null
	maxOverlap: number | null
	/**
	 * Gdal's own area of the source geometry, in square metres of the source projection.
	 */
	sourceAreaM2: number
	polygons: MultiPolygonRings
}

/**
 * One ground-instability feature, reprojected to WGS84.
 *
 * A different hazard with a different schema.
 */
export interface CoastalInstabilityFeature {
	areaID: string
	kind: string
	location: string | null
	localAuthority: string | null
	smpNo: number | null
	smpName: string | null
	smpPolicyUnits: string | null
	rearScarpProbability: string | null
	sourceAreaM2: number
	polygons: MultiPolygonRings
}

/**
 * What the ingest was pointed at.
 */
export interface CoastalIngestOptions {
	/**
	 * Path to the unzipped `.gdb` directory.
	 */
	geodatabasePath: string
	/**
	 * Stop after this many features per layer.
	 *
	 * The fixtures and smoke rungs use it.
	 * A full build does not set it.
	 */
	limit?: number
	/**
	 * The epsg code the source must declare.
	 *
	 * A source declaring anything else is a product change rather than a variation to absorb.
	 */
	expectEPSG?: number
	/**
	 * The extent every reprojected vertex must land inside.
	 *
	 * Defaults to the erosion collections' own declaration, which contains the two
	 * ground-instability collections' tighter boxes.
	 */
	declaredBBox?: readonly [number, number, number, number]
	/**
	 * Read only the authority's feature ids in `[objectIDFrom, objectIDTo]`, inclusive.
	 *
	 * This is what makes a bounded build possible: h3's wasm heap cannot be reset from JavaScript,
	 * so the classification runs one child process per range of the authority's own ids.
	 * Ranges rather than an offset because `objectid` is the source's stable key.
	 *
	 * A range names the same features on every run, which an offset into a result set does not.
	 *
	 * Each layer numbers its own `objectid` from 1, so a range is per layer.
	 */
	objectIDFrom?: number
	objectIDTo?: number
}

/**
 * What one layer declares about itself — including the attribute fields IT actually has,
 * because the fourteen published layers do not share one schema.
 */
export interface CoastalLayerIdentity {
	epsg: number
	featureCount: number
	layer: string
	/**
	 * The layer's own attribute field names.
	 *
	 * A `select` naming a column this set does not hold is refused by ogr2ogr outright,
	 * so the query is built from the set rather than from a schema read off a sibling layer.
	 */
	fields: ReadonlySet<string>
}

/**
 * Coordinate decimals ogr2ogr writes into the stream.
 *
 * Nine is ~0.1 mm at this latitude — far past the source's own precision, and chosen
 * so the reprojection contributes nothing measurable to the area cross-check.
 */
const COORDINATE_PRECISION = 9

/**
 * How far outside the declared extent a vertex may fall before the ingest refuses.
 *
 * A declared extent is itself a rounded published value, so an exact test would be brittle.
 * This margin is small enough that an unprojected or axis-swapped read —
 * which lands degrees or whole hemispheres away — still fails.
 */
const BBOX_MARGIN_DEGREES = 0.01

/**
 * What one layer declares about itself: its authority code and its feature count,
 * read before any feature is.
 *
 * @throws {Error} When the layer is missing, or its declared epsg is not `expectEPSG`.
 */
export async function readCoastalSourceIdentity(
	layer: string,
	options: CoastalIngestOptions
): Promise<CoastalLayerIdentity> {
	const identity = await readOGRLayerIdentity({
		path: options.geodatabasePath,
		layer,
		expectEPSG: options.expectEPSG ?? NCERM_SOURCE_EPSG,
		context: "coastal ingest",
		areaOfUse: "United Kingdom",
		requireFields: true,
		messages: {
			emptyFields:
				"an empty field list would make every optional column read as absent, which is a projection failure wearing a schema's clothes",
		},
	})

	return { epsg: identity.epsg, featureCount: identity.featureCount, layer: identity.layer, fields: identity.fields }
}

/**
 * The id-range predicate shared by both `select` builders.
 */
function idBounds(options: CoastalIngestOptions): string {
	const bounds: string[] = []

	if (options.objectIDFrom !== undefined) {
		bounds.push(`OBJECTID >= ${options.objectIDFrom}`)
	}

	if (options.objectIDTo !== undefined) {
		bounds.push(`OBJECTID <= ${options.objectIDTo}`)
	}

	return bounds.length ? ` WHERE ${bounds.join(" AND ")}` : ""
}

/**
 * The attribute columns an erosion-zone layer is read for where it has them,
 * and as literal `NULL` where it does not.
 *
 * The fourteen layers do not share one schema, and the exception is A single column on A single layer.
 * `NCERM_SMP_2105_0CC` carries no `smp_name`; the other eleven scenario layers
 * and both ground-instability layers do.
 *
 * A builder that read the schema from one layer — the survey read `NCERM_SMP_2105_95CC` —
 * and generalized it fails on the twelfth layer with `error 1: Unrecognized field name smp_name`,
 * 66,000 features into a run.
 * Loud, and only because ogr2ogr refuses an unknown column: a source that answered NULL
 * instead would have shipped.
 *
 * The four policy columns are the same shape for a different reason: the six NFI layers
 * omit them because under a no-intervention scenario there is no policy to record,
 * which is a documented property of the product rather than an irregularity in it.
 *
 * The distance column is not in this set.
 * Its absence is a product change and throws.
 */
const OPTIONAL_SCENARIO_FIELDS: ReadonlyArray<string> = [
	"smp_no",
	"smp_name",
	"smp_pu",
	"mt_smp",
	"mt_smp_int",
	"lt_smp",
	"lt_smp_int",
	"def_type",
	"published",
	"maxoverlap",
]

/**
 * The erosion-zone `select` for one scenario, built against the layer's own field list.
 */
function scenarioSelectSQL(
	scenario: CoastalScenario,
	identity: CoastalLayerIdentity,
	options: CoastalIngestOptions
): string {
	// The policy asymmetry is regular across the product — the six NFI layers omit all four
	// columns and the six SMP layers carry all four — so a layer that disagrees with its own
	// scenario is a source-schema change rather than the `smp_name` kind of irregularity,
	// and it is worth hearing about rather than absorbing into a NULL.
	const carriesPolicy = identity.fields.has("mt_smp")

	if (carriesPolicy !== scenarioCarriesPolicy(scenario)) {
		throw new Error(
			`coastal ingest: ${scenario.layer} ${carriesPolicy ? "carries" : "carries no"} shoreline-management policy columns, ` +
				`and its ${scenario.management} scenario ${scenarioCarriesPolicy(scenario) ? "should carry them" : "should not"} — ` +
				"the product's policy asymmetry follows the management scenario, so a layer that disagrees with it changed"
		)
	}

	if (!identity.fields.has(scenario.distanceColumn)) {
		throw new Error(
			`coastal ingest: ${scenario.layer} carries no ${scenario.distanceColumn} column — the distance IS the reading, so its absence is a product change rather than a variation to absorb`
		)
	}

	if (!identity.fields.has("frontageid")) {
		throw new Error(`coastal ingest: ${scenario.layer} carries no frontageid column`)
	}

	const attributes = OPTIONAL_SCENARIO_FIELDS.map((field) =>
		identity.fields.has(field) ? field : `NULL AS ${field}`
	).join(", ")

	return (
		`SELECT OBJECTID AS object_id, frontageid, ${scenario.distanceColumn} AS distance_m, ${attributes}, ` +
		`OGR_GEOM_AREA AS source_area_m2 FROM ${scenario.layer}` +
		idBounds(options)
	)
}

/**
 * The attribute columns a ground-instability layer is read for, on the same terms as the scenario set above.
 */
const OPTIONAL_INSTABILITY_FIELDS: ReadonlyArray<string> = [
	"location",
	"local_auth",
	"smp_no",
	"smp_name",
	"smp_pu1",
	"smp_pu2",
	"smp_pu3",
	"smp_pu4",
	"smp_pu5",
	"rearscarpr",
]

/**
 * The ground-instability `select`, built against the layer's own field list.
 */
function instabilitySelectSQL(layer: string, identity: CoastalLayerIdentity, options: CoastalIngestOptions): string {
	const attributes = OPTIONAL_INSTABILITY_FIELDS.map((field) =>
		identity.fields.has(field) ? field : `NULL AS ${field}`
	).join(", ")

	return (
		`SELECT OBJECTID AS object_id, ${attributes}, OGR_GEOM_AREA AS source_area_m2 FROM ${layer}` + idBounds(options)
	)
}

interface RawFeature {
	properties: Record<string, number | string | null>
	geometry: { type: string; coordinates: unknown } | null
}

/**
 * Stream one layer through ogr2ogr as GeoJSON, checking every vertex against the declared extent.
 *
 * A swapped coordinate order survives a projection check — both axes are still
 * numbers in a plausible range — and shows up here immediately, before 89,371
 * polygons are written to the wrong side of the planet.
 *
 * @throws {Error} When ogr2ogr fails, when a feature carries no geometry, or
 *   when a reprojected vertex falls outside the declared extent.
 */
async function* streamLayer(
	sql: string,
	options: CoastalIngestOptions,
	label: string
): AsyncGenerator<{ raw: RawFeature; polygons: MultiPolygonRings }> {
	const [minLon, minLat, maxLon, maxLat] = options.declaredBBox ?? NCERM_DECLARED_BBOX

	const args = [
		"-f",
		"GeoJSONSeq",
		"/vsistdout/",
		"-t_srs",
		"EPSG:4326",
		"-lco",
		`COORDINATE_PRECISION=${COORDINATE_PRECISION}`,
		...(options.limit === undefined ? [] : ["-limit", String(options.limit)]),
		"-sql",
		sql,
		options.geodatabasePath,
	]

	for await (const raw of ogr2ogrGeoJSONSeq<RawFeature>(args, `coastal ingest (${label})`)) {
		const id = String(raw.properties.object_id)

		if (!raw.geometry) {
			throw new Error(`coastal ingest: ${label} feature ${id} carries no geometry`)
		}

		const polygons = requireArealPolygons(raw.geometry, `${label} feature ${id}`, "coastal ingest")

		assertRingsInsideExtent(
			polygons,
			`${label} feature ${id}`,
			{ minLon, minLat, maxLon, maxLat },
			BBOX_MARGIN_DEGREES,
			"coastal ingest"
		)

		yield { raw, polygons }
	}
}

/**
 * A published value, as a string or null.
 *
 * `" "` is a real value in this product and is never folded to null.
 */
function verbatimText(value: number | string | null | undefined): string | null {
	return value === null || value === undefined ? null : String(value)
}

function numberOf(value: number | string | null | undefined): number | null {
	return value === null || value === undefined ? null : Number(value)
}

/**
 * Stream one scenario's erosion zones.
 */
export async function* readCoastalScenarioFeatures(
	scenario: CoastalScenario,
	options: CoastalIngestOptions,
	identity?: CoastalLayerIdentity
): AsyncGenerator<CoastalSourceFeature> {
	// The layer's own field list decides the `select`, because the fourteen layers do
	// not share one schema — see `OPTIONAL_SCENARIO_FIELDS`.
	// Read here when the caller has not already read it, which costs one `ogrinfo -so`
	// per layer against a build that streams thousands of features from it.
	const layerIdentity = identity ?? (await readCoastalSourceIdentity(scenario.layer, options))
	const sql = scenarioSelectSQL(scenario, layerIdentity, options)

	for await (const { raw, polygons } of streamLayer(sql, options, scenario.layer)) {
		const properties = raw.properties

		yield {
			areaID: `${scenario.key}:${String(properties.object_id)}`,
			scenario,
			frontageID: Number(properties.frontageid),
			// A missing distance is refused rather than defaulted: measured, neither of the two layers sampled
			// carries a null, and a zero written in place of one reads as "no erosion projected here".
			distanceM: assertFiniteDistance(properties.distance_m, scenario, String(properties.object_id)),
			smpNo: numberOf(properties.smp_no),
			smpName: verbatimText(properties.smp_name),
			smpPolicyUnit: verbatimText(properties.smp_pu),
			mtPolicy: verbatimText(properties.mt_smp),
			mtPolicyInterpretation: verbatimText(properties.mt_smp_int),
			ltPolicy: verbatimText(properties.lt_smp),
			ltPolicyInterpretation: verbatimText(properties.lt_smp_int),
			defenceType: verbatimText(properties.def_type),
			publishedYear: numberOf(properties.published),
			maxOverlap: numberOf(properties.maxoverlap),
			sourceAreaM2: Number(properties.source_area_m2 ?? 0),
			polygons,
		}
	}
}

/**
 * Refuse a null or non-finite erosion distance.
 *
 * @throws {TypeError} When the scenario's distance column holds no number for this feature.
 */
function assertFiniteDistance(
	value: number | string | null | undefined,
	scenario: CoastalScenario,
	id: string
): number {
	const distance = Number(value)

	if (value === null || value === undefined || !Number.isFinite(distance)) {
		throw new TypeError(
			`coastal ingest: ${scenario.layer} feature ${id} carries no ${scenario.distanceColumn} value — a missing distance defaulted to zero reads as "no erosion projected here"`
		)
	}

	return distance
}

/**
 * Stream one ground-instability layer.
 */
export async function* readCoastalInstabilityFeatures(
	layer: string,
	kind: string,
	options: CoastalIngestOptions
): AsyncGenerator<CoastalInstabilityFeature> {
	const identity = await readCoastalSourceIdentity(layer, options)

	for await (const { raw, polygons } of streamLayer(instabilitySelectSQL(layer, identity, options), options, layer)) {
		const properties = raw.properties

		const units = [properties.smp_pu1, properties.smp_pu2, properties.smp_pu3, properties.smp_pu4, properties.smp_pu5]
			.map((unit) => verbatimText(unit)?.trim() ?? "")
			.filter((unit) => unit.length)

		yield {
			areaID: `${kind}:${String(properties.object_id)}`,
			kind,
			location: verbatimText(properties.location),
			localAuthority: verbatimText(properties.local_auth),
			smpNo: numberOf(properties.smp_no),
			smpName: verbatimText(properties.smp_name),
			smpPolicyUnits: units.length ? units.join(", ") : null,
			rearScarpProbability: verbatimText(properties.rearscarpr),
			sourceAreaM2: Number(properties.source_area_m2 ?? 0),
			polygons,
		}
	}
}

/**
 * Where a build's features come from, and what the source declares about itself.
 *
 * The builder takes one of these rather than a path, which is what makes the fixture rung possible:
 * hand-built geometry with no network and no gdal still exercises the whole database half —
 * the domain checks, the cell classification, the coverage rows, the manifest and the seal.
 * A fixture rung that could only run through ogr2ogr would test the conversion on the
 * machines that have it and nothing at all on the ones that do not.
 */
export interface CoastalFeatureSource {
	/**
	 * What the source says it holds, across every layer this source covers.
	 *
	 * The build compares its own streamed total against this, so a short read throws
	 * instead of building a shorter coastline.
	 */
	declaredFeatureCount: number
	epsg: number
	/**
	 * A description of where these features came from, for the receipt.
	 */
	origin: string
	/**
	 * The scenarios this source yields, in the order it yields them.
	 */
	scenarios: ReadonlyArray<CoastalScenario>
	erosionFeatures: () => AsyncIterable<CoastalSourceFeature>
	instabilityFeatures: () => AsyncIterable<CoastalInstabilityFeature>
}

export interface GeodatabaseSourceOptions extends CoastalIngestOptions {
	/**
	 * Which scenarios to read.
	 *
	 * Defaults to all twelve.
	 */
	scenarioKeys?: ReadonlyArray<string>
	/**
	 * Skip the two ground-instability layers.
	 *
	 * The chunked build reads them in their own pass.
	 */
	skipInstability?: boolean
	declaredFeatureCount?: number
}

/**
 * The published geodatabase as a feature source — identity read up front per layer,
 * features streamed on demand.
 */
export async function createGeodatabaseFeatureSource(options: GeodatabaseSourceOptions): Promise<CoastalFeatureSource> {
	const scenarios = (options.scenarioKeys ?? [...NCERM_SCENARIOS_BY_KEY.keys()]).map((key) => {
		const scenario = NCERM_SCENARIOS_BY_KEY.get(key)

		if (!scenario) {
			throw new Error(
				`coastal ingest: ${stringifyJSON(key)} is not one of the twelve published scenarios (${[...NCERM_SCENARIOS_BY_KEY.keys()].join(", ")})`
			)
		}

		return scenario
	})

	const instability = options.skipInstability
		? []
		: [
				{ layer: "NCERM_Ground_Instability_Zone", kind: "zone" },
				{ layer: "NCERM_Ground_Instability_Recession", kind: "recession" },
			]

	let declared = 0
	let epsg = NCERM_SOURCE_EPSG

	// Every layer's identity is read up front and kept, because the fourteen layers do not
	// share one schema and the `select` for each is built from its own field list.
	// Re-reading it per stream would work and would cost a second `ogrinfo` per layer.
	// Keeping it makes the identity the source declared and the identity the
	// query was built from the same object.
	const identities = new Map<string, CoastalLayerIdentity>()

	for (const layer of [...scenarios.map((scenario) => scenario.layer), ...instability.map((entry) => entry.layer)]) {
		const identity = await readCoastalSourceIdentity(layer, options)

		identities.set(layer, identity)

		declared += limitedFeatureCount(identity.featureCount, options.limit)
		epsg = identity.epsg
	}

	return {
		// A range's own count is supplied by the caller, because `ogrinfo` reports a layer's total and nothing narrower.
		declaredFeatureCount: options.declaredFeatureCount ?? declared,
		epsg,
		origin: options.geodatabasePath,
		scenarios,
		async *erosionFeatures() {
			for (const scenario of scenarios) {
				yield* readCoastalScenarioFeatures(scenario, options, identities.get(scenario.layer))
			}
		},
		async *instabilityFeatures() {
			for (const entry of instability) {
				yield* readCoastalInstabilityFeatures(entry.layer, entry.kind, options)
			}
		},
	}
}
