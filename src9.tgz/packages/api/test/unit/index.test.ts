/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 */

import { createMailwomanAPI, type MailwomanAPIEngine, type ParsedAddressResult } from "@mailwoman/api"
import { metricsSnapshot, resetMetricsForTest } from "@mailwoman/api-kit"
import { type GeocodeOutcomeLike, MAX_ADDRESS_LENGTH } from "@mailwoman/api/schema"
import { stringifyJSON } from "@mailwoman/core/json"
import { buildEngineStamp, type EngineStamp } from "@mailwoman/core/license"
import { beforeEach, expect, test } from "vitest"

beforeEach(() => {
	resetMetricsForTest()
})

/**
 * The `detail` text every "engine method absent" 503 carries —
 * see `routes.ts`'s `GEOCODER_UNAVAILABLE_DETAIL`.
 */
const GEOCODER_UNAVAILABLE_DETAIL =
	"install @mailwoman/neural + @mailwoman/resolver-wof-sqlite and provide gazetteer data (MAILWOMAN_WOF_DB / MAILWOMAN_CANDIDATE_DB)"

function fixtureParseOutcome(address: string, debug?: boolean): ParsedAddressResult {
	return {
		input: address,
		components: [
			{ tag: "house_number", value: "1600" },
			{ tag: "street", value: "Pennsylvania Ave NW" },
		],
		tree: { raw: address, roots: [] },
		debug: debug ? "diagnostic report" : undefined,
	}
}

interface GeocodeResultWithAddress extends Pick<GeocodeOutcomeLike, "lat" | "lon" | "resolution_tier"> {
	address: string
}

function fixtureGeocodeOutcome(address: string): GeocodeResultWithAddress {
	return { address, lat: 38.8977, lon: -77.0365, resolution_tier: "address_point" }
}

/**
 * A fully-wired fixture engine — every method present, exercising every 200 happy path.
 */
const fullEngine: MailwomanAPIEngine<GeocodeResultWithAddress> = {
	parse: async (address, opts) => fixtureParseOutcome(address, opts.debug),
	geocode: async (address) => fixtureGeocodeOutcome(address),
	batch: async (addresses) => ({
		results: addresses.map((a) => (a === "bad" ? { input: a, error: "boom" } : fixtureGeocodeOutcome(a))),
	}),
	resolveTree: async (tree) => ({ tree }),
	reload: async () => ({ reloaded: true, versions: { wof: "v1" } }),
	health: async () => ({ model: { name: "test-model", version: "0.0.0" } }),
}

// MARK: /v1/parse

test("POST /v1/parse: happy path returns the components + decoded tree", async () => {
	const app = createMailwomanAPI(fullEngine)

	const res = await app.request("/v1/parse", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({ address: "1600 Pennsylvania Ave NW" }),
	})

	expect(res.status).toBe(200)
	const body = (await res.json()) as ParsedAddressResult
	expect(body.input).toBe("1600 Pennsylvania Ave NW")
	expect(body.components).toHaveLength(2)
	expect(body.tree.roots).toEqual([])
	expect(body.debug).toBeUndefined()
})

test("POST /v1/parse: debug:true reaches the engine and rides back in the response", async () => {
	const app = createMailwomanAPI(fullEngine)

	const res = await app.request("/v1/parse", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({ address: "1600 Pennsylvania Ave NW", debug: true }),
	})

	const body = (await res.json()) as ParsedAddressResult
	expect(body.debug).toBe("diagnostic report")
})

test("GET /v1/parse?address=&debug=: happy path, first-value query reads", async () => {
	const app = createMailwomanAPI(fullEngine)

	const res = await app.request("/v1/parse?address=1600+Pennsylvania+Ave+NW&debug=true")
	expect(res.status).toBe(200)
	const body = (await res.json()) as ParsedAddressResult
	expect(body.input).toBe("1600 Pennsylvania Ave NW")
	expect(body.debug).toBe("diagnostic report")
})

test('POST /v1/parse: missing address body key -> 400 { error: "address is required" }', async () => {
	const app = createMailwomanAPI(fullEngine)

	const res = await app.request("/v1/parse", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({}),
	})

	expect(res.status).toBe(400)
	expect(await res.json()).toEqual({ error: "address is required" })
})

test('POST /v1/parse: empty-string address -> 400 { error: "address is required" }', async () => {
	const app = createMailwomanAPI(fullEngine)

	const res = await app.request("/v1/parse", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({ address: "   " }),
	})

	expect(res.status).toBe(400)
	expect(await res.json()).toEqual({ error: "address is required" })
})

test('GET /v1/parse: absent address -> 400 { error: "address is required" }', async () => {
	const app = createMailwomanAPI(fullEngine)

	const res = await app.request("/v1/parse")
	expect(res.status).toBe(400)
	expect(await res.json()).toEqual({ error: "address is required" })
})

test("POST /v1/parse: engine.parse absent -> 501", async () => {
	const app = createMailwomanAPI({})

	const res = await app.request("/v1/parse", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({ address: "1600 Pennsylvania Ave NW" }),
	})

	expect(res.status).toBe(501)
	expect(await res.json()).toEqual({ error: "parse not implemented" })
})

test("GET /v1/parse: engine.parse absent -> 501", async () => {
	const app = createMailwomanAPI({})

	const res = await app.request("/v1/parse?address=x")
	expect(res.status).toBe(501)
	expect(await res.json()).toEqual({ error: "parse not implemented" })
})

// MARK: /v1/geocode

test("POST /v1/geocode: happy path passes the GeocodeOutcome through verbatim", async () => {
	const app = createMailwomanAPI(fullEngine)

	const res = await app.request("/v1/geocode", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({ address: "1600 Pennsylvania Ave NW" }),
	})

	expect(res.status).toBe(200)
	expect(await res.json()).toEqual(fixtureGeocodeOutcome("1600 Pennsylvania Ave NW"))
})

test('POST /v1/geocode: missing address -> 400 { error: "address is required" }', async () => {
	const app = createMailwomanAPI(fullEngine)

	const res = await app.request("/v1/geocode", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({}),
	})

	expect(res.status).toBe(400)
	expect(await res.json()).toEqual({ error: "address is required" })
})

test("POST /v1/geocode: engine.geocode absent -> 503 (deps missing in production)", async () => {
	const app = createMailwomanAPI({})

	const res = await app.request("/v1/geocode", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({ address: "x" }),
	})

	expect(res.status).toBe(503)
	expect(await res.json()).toEqual({ error: "geocoder not available", detail: GEOCODER_UNAVAILABLE_DETAIL })
})

test("POST /v1/geocode: a thrown engine error is recorded as an error tier, then rethrown into the 500 net", async () => {
	const app = createMailwomanAPI({
		geocode: async () => {
			throw new Error("resolver exploded")
		},
	})

	const res = await app.request("/v1/geocode", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({ address: "x" }),
	})

	expect(res.status).toBe(500)
	expect(await res.json()).toEqual({ error: "internal error", detail: "resolver exploded" })

	const metricsRes = await app.request("/metrics")
	const snapshot = (await metricsRes.json()) as { timings: { errors: number } }
	expect(snapshot.timings.errors).toBe(1)
})

// MARK: /v1/batch

test("POST /v1/batch: happy path returns one row per address, in order, per-row error isolation", async () => {
	const app = createMailwomanAPI(fullEngine)

	const res = await app.request("/v1/batch", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({ addresses: ["1600 Pennsylvania Ave NW", "bad"] }),
	})

	expect(res.status).toBe(200)
	const body = (await res.json()) as { results: unknown[] }
	expect(body.results).toEqual([fixtureGeocodeOutcome("1600 Pennsylvania Ave NW"), { input: "bad", error: "boom" }])
})

test("POST /v1/batch: empty addresses array -> 200 { results: [] }, even with no engine", async () => {
	const app = createMailwomanAPI({})

	const res = await app.request("/v1/batch", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({ addresses: [] }),
	})

	expect(res.status).toBe(200)
	expect(await res.json()).toEqual({ results: [] })
})

test('POST /v1/batch: wrong body shape -> 400 { error: "body must be { addresses: string[] } " }', async () => {
	const app = createMailwomanAPI(fullEngine)

	const res = await app.request("/v1/batch", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({ addresses: ["ok", 42] }),
	})

	expect(res.status).toBe(400)
	expect(await res.json()).toEqual({ error: "body must be { addresses: string[] }" })
})

test("POST /v1/batch: over batchMax -> 413", async () => {
	const app = createMailwomanAPI(fullEngine, { batchMax: 2 })

	const res = await app.request("/v1/batch", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({ addresses: ["a", "b", "c"] }),
	})

	expect(res.status).toBe(413)
	expect(await res.json()).toEqual({ error: "batch too large: 3 > 2" })
})

test("POST /v1/batch: engine.batch absent -> 503", async () => {
	const app = createMailwomanAPI({})

	const res = await app.request("/v1/batch", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({ addresses: ["a"] }),
	})

	expect(res.status).toBe(503)
	expect(await res.json()).toEqual({ error: "geocoder not available", detail: GEOCODER_UNAVAILABLE_DETAIL })
})

test("/v1/batch records whole-call latency under the batch tier", async () => {
	resetMetricsForTest()
	const app = createMailwomanAPI({ batch: async () => ({ results: [] }) })

	await app.request("/v1/batch", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({ addresses: ["x"] }),
	})

	const snapshot = metricsSnapshot()
	expect(snapshot.timings.tiers["batch"]).toBe(1)
})

// MARK: /v1/resolve

test("POST /v1/resolve: happy path returns { tree } passed through the engine", async () => {
	const app = createMailwomanAPI(fullEngine)
	const tree = { raw: "Berlin", roots: [] }

	const res = await app.request("/v1/resolve", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({ tree }),
	})

	expect(res.status).toBe(200)
	expect(await res.json()).toEqual({ tree })
})

test('POST /v1/resolve: wrong body shape -> 400 { error: "body must be { tree: AddressTree, opts? } " }', async () => {
	const app = createMailwomanAPI(fullEngine)

	const res = await app.request("/v1/resolve", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({}),
	})

	expect(res.status).toBe(400)
	expect(await res.json()).toEqual({ error: "body must be { tree: AddressTree, opts? }" })
})

test("POST /v1/resolve: engine.resolveTree absent -> 503", async () => {
	const app = createMailwomanAPI({})

	const res = await app.request("/v1/resolve", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({ tree: { raw: "x", roots: [] } }),
	})

	expect(res.status).toBe(503)
	expect(await res.json()).toEqual({ error: "resolver not available", detail: GEOCODER_UNAVAILABLE_DETAIL })
})

// MARK: /v1/reload

test("POST /v1/reload: happy path passes { reloaded, versions } through", async () => {
	const app = createMailwomanAPI(fullEngine)

	const res = await app.request("/v1/reload", { method: "POST" })
	expect(res.status).toBe(200)
	expect(await res.json()).toEqual({ reloaded: true, versions: { wof: "v1" } })
})

test("POST /v1/reload: engine.reload absent -> 503", async () => {
	const app = createMailwomanAPI({})

	const res = await app.request("/v1/reload", { method: "POST" })
	expect(res.status).toBe(503)
	expect(await res.json()).toEqual({ error: "geocoder not available", detail: GEOCODER_UNAVAILABLE_DETAIL })
})

// MARK: /v1/format — always available

test("POST /v1/format: round-trips components into a formatted string + a non-empty canonicalKey", async () => {
	const app = createMailwomanAPI({})

	const res = await app.request("/v1/format", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({
			components: { house_number: "1600", road: "Pennsylvania Ave NW", city: "Washington" },
			country: "US",
		}),
	})

	expect(res.status).toBe(200)
	const body = (await res.json()) as { formatted: string; canonicalKey: string }
	// The formatter template owns the exact rendering — only pin the required substring.
	expect(body.formatted).toContain("1600")
	expect(body.canonicalKey.length).toBeGreaterThan(0)
})

test("POST /v1/format: a multi-span component value collapses to its first span", async () => {
	const app = createMailwomanAPI({})

	const res = await app.request("/v1/format", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({
			components: { house_number: ["1600", "1601"], road: "Pennsylvania Ave NW" },
			country: "US",
		}),
	})

	expect(res.status).toBe(200)
	const body = (await res.json()) as { formatted: string }
	expect(body.formatted).toContain("1600")
	expect(body.formatted).not.toContain("1601")
})

test("POST /v1/format: a missing required field -> 400 in the api-kit envelope, NOT the raw zod shape", async () => {
	const app = createMailwomanAPI({})

	const res = await app.request("/v1/format", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({ country: "US" }), // components missing
	})

	expect(res.status).toBe(400)
	const body = (await res.json()) as Record<string, unknown>
	expect(body["error"]).toBe("invalid request body")
	expect(typeof body["detail"]).toBe("string")
	// The api-kit envelope is exactly {error, detail?} — assert the raw zod validator shape leaked nowhere.
	expect(body["success"]).toBeUndefined()
	expect(body["issues"]).toBeUndefined()
	expect(Object.keys(body).toSorted()).toEqual(["detail", "error"])
})

// MARK: /health

test("GET /health: with an engine, spreads engine.health() alongside status + uptime_s", async () => {
	const app = createMailwomanAPI(fullEngine)

	const res = await app.request("/health")
	expect(res.status).toBe(200)
	const body = (await res.json()) as Record<string, unknown>
	expect(body["status"]).toBe("ok")
	expect(typeof body["uptime_s"]).toBe("number")
	expect(body["model"]).toEqual({ name: "test-model", version: "0.0.0" })
})

test("GET /health: without an engine, still answers 200 with status + uptime_s (health answers even when broken)", async () => {
	const app = createMailwomanAPI({})

	const res = await app.request("/health")
	expect(res.status).toBe(200)
	const body = (await res.json()) as Record<string, unknown>
	expect(body["status"]).toBe("ok")
	expect(typeof body["uptime_s"]).toBe("number")
})

// MARK: /metrics

test("GET /metrics: reflects a recorded /v1/geocode call", async () => {
	const app = createMailwomanAPI(fullEngine)
	const before = (await (await app.request("/metrics")).json()) as { timings: { total: number } }
	expect(before.timings.total).toBe(0)

	await app.request("/v1/geocode", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({ address: "1600 Pennsylvania Ave NW" }),
	})

	const after = (await (await app.request("/metrics")).json()) as {
		timings: { total: number; tiers: Record<string, number> }
	}

	expect(after.timings.total).toBe(1)
	expect(after.timings.tiers["address_point"]).toBe(1)
})

// MARK: /openapi.json

test("GET /openapi.json: documents all 8 native paths, and is not self-referenced", async () => {
	const app = createMailwomanAPI(fullEngine)

	const res = await app.request("/openapi.json")
	expect(res.status).toBe(200)
	const doc = (await res.json()) as { openapi: string; paths: Record<string, unknown> }
	expect(doc.openapi).toBe("3.1.0")

	expect(Object.keys(doc.paths).toSorted()).toEqual(
		[
			"/health",
			"/metrics",
			"/v1/batch",
			"/v1/format",
			"/v1/geocode",
			"/v1/parse",
			"/v1/reload",
			"/v1/resolve",
		].toSorted()
	)

	expect(doc.paths["/openapi.json"]).toBeUndefined()
})

test("GET /openapi.json: full-info document config lands (license, contact, servers, security, tags)", async () => {
	const app = createMailwomanAPI(fullEngine)

	const res = await app.request("/openapi.json")

	const doc = (await res.json()) as {
		info: { license?: { name: string }; contact?: { name?: string; url?: string } }
		servers?: Array<{ url: string }>
		security?: unknown[]
		tags?: Array<{ name: string }>
	}

	expect(doc.info.license?.name).toBe("AGPL-3.0-only OR LicenseRef-Commercial")
	expect(doc.info.contact?.url).toBe("https://mailwoman.ai")
	expect(doc.servers?.[0]?.url).toBe("http://{host}:{port}")
	expect(doc.security).toEqual([])
	expect(doc.tags?.map((t) => t.name)).toContain("meta")
})

// MARK: cors + body limit + the 500 safety net

test("CORS: permissive Access-Control-Allow-Origin on responses (browser clients), GET/POST/OPTIONS", async () => {
	const app = createMailwomanAPI(fullEngine)

	const res = await app.request("/health")
	expect(res.headers.get("access-control-allow-origin")).toBe("*")
})

test("CORS: preflight OPTIONS answers 204 with GET/POST/OPTIONS in Allow-Methods", async () => {
	const app = createMailwomanAPI(fullEngine)

	const res = await app.request("/v1/geocode", {
		method: "OPTIONS",
		headers: { origin: "https://example.com", "access-control-request-method": "POST" },
	})

	expect(res.status).toBe(204)
	const allowed = res.headers.get("access-control-allow-methods") ?? ""
	expect(allowed).toContain("GET")
	expect(allowed).toContain("POST")
	expect(allowed).toContain("OPTIONS")
})

test("CORS: { cors: false } disables the headers (for a proxy that owns CORS)", async () => {
	const app = createMailwomanAPI(fullEngine, { cors: false })

	const res = await app.request("/health")
	expect(res.headers.get("access-control-allow-origin")).toBeNull()
})

test("bodyLimitBytes: an oversized /v1/* POST answers 413, not a buffered crash", async () => {
	const app = createMailwomanAPI(fullEngine, { bodyLimitBytes: 16 })

	const res = await app.request("/v1/geocode", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({ address: "well over sixteen bytes" }),
	})

	expect(res.status).toBe(413)
	expect(await res.json()).toEqual({ error: "request body too large" })
})

test("an engine fault answers the native 500 envelope with a helpful detail, never a crash", async () => {
	const app = createMailwomanAPI({
		parse: async () => {
			throw new Error("model exploded")
		},
	})

	const res = await app.request("/v1/parse?address=x")
	expect(res.status).toBe(500)
	expect(await res.json()).toEqual({ error: "internal error", detail: "model exploded" })
})

test("malformed JSON answers a 400 envelope, not a 500", async () => {
	const app = createMailwomanAPI({})

	const res = await app.request("/v1/format", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: "{truncated",
	})

	expect(res.status).toBe(400)
	expect(await res.json()).toEqual({ error: "invalid request body", detail: "malformed JSON" })
})

test(`POST /v1/parse: an address past ${MAX_ADDRESS_LENGTH} chars -> 400`, async () => {
	const app = createMailwomanAPI(fullEngine)

	const res = await app.request("/v1/parse", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({ address: "a".repeat(MAX_ADDRESS_LENGTH + 1) }),
	})

	expect(res.status).toBe(400)
})

test(`POST /v1/parse: an address exactly at ${MAX_ADDRESS_LENGTH} chars is accepted`, async () => {
	const app = createMailwomanAPI(fullEngine)

	const res = await app.request("/v1/parse", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({ address: "a".repeat(MAX_ADDRESS_LENGTH) }),
	})

	expect(res.status).toBe(200)
})

test("POST /v1/batch: the length bound applies PER ROW, not just to the request", async () => {
	// The row cap bounds how many addresses arrive. without a per-element bound one
	// request is still `batchMax` unbounded bodies.
	const app = createMailwomanAPI(fullEngine)

	const res = await app.request("/v1/batch", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({ addresses: ["350 5th Ave", "a".repeat(MAX_ADDRESS_LENGTH + 1)] }),
	})

	expect(res.status).toBe(400)
})

// MARK: engine stamp

const stamp = buildEngineStamp({ version: "9.2.0", expression: "AGPL-3.0-only OR LicenseRef-Commercial" })

test("engine option: every /v1 body carries `engine` and every response carries the two headers", async () => {
	const app = createMailwomanAPI(fullEngine, { engine: stamp })

	const post = (path: string, body: unknown) =>
		app.request(path, { method: "POST", headers: { "content-type": "application/json" }, body: stringifyJSON(body) })

	for (const res of [
		await post("/v1/parse", { address: "1600 Pennsylvania Ave NW" }),
		await post("/v1/geocode", { address: "1600 Pennsylvania Ave NW" }),
		await post("/v1/resolve", { tree: { raw: "x", roots: [] } }),
		await post("/v1/format", { components: { house_number: "1600", road: "Pennsylvania Ave NW" }, country: "US" }),
	]) {
		expect(res.status).toBe(200)
		expect(res.headers.get("server")).toBe("mailwoman/9.2.0 (AGPL-3.0-only)")
		expect(res.headers.get("link")).toBe('<https://mailwoman.ai/license>; rel="license"')
		expect(((await res.json()) as { engine: EngineStamp }).engine).toEqual(stamp)
	}

	const health = await app.request("/health")

	expect(health.headers.get("link")).toBe('<https://mailwoman.ai/license>; rel="license"')
	expect((await health.json()) as object).not.toHaveProperty("engine")
})

test("engine option: /v1/batch stamps the envelope once, not the rows", async () => {
	const app = createMailwomanAPI(fullEngine, { engine: stamp })

	const res = await app.request("/v1/batch", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({ addresses: ["a", "b"] }),
	})

	const body = (await res.json()) as { engine: EngineStamp; results: object[] }

	expect(body.engine).toEqual(stamp)
	expect(body.results).toHaveLength(2)

	for (const row of body.results) {
		expect(row).not.toHaveProperty("engine")
	}
})

test("no engine option: no `engine` field and no headers", async () => {
	const app = createMailwomanAPI(fullEngine)

	const res = await app.request("/v1/parse", {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: stringifyJSON({ address: "1600 Pennsylvania Ave NW" }),
	})

	expect(res.headers.get("server")).toBeNull()
	expect(res.headers.get("link")).toBeNull()
	expect((await res.json()) as object).not.toHaveProperty("engine")
})
