/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   The native Mailwoman Hono app: cors + a request-body-size guard + the strict-validation error
 *   envelope + the `/v1` routes + the emitted OpenAPI document. Engine-agnostic — the `mailwoman`
 *   CLI wires the real parse/geocode/resolve stack (phase 4b); tests inject fixtures.
 */

import { OpenAPIHono } from "@hono/zod-openapi"
import {
	attachOpenAPIDocs,
	engineHeaders,
	errorResponse,
	type OpenAPIDocInfo,
	readServedDocumentInfo,
} from "@mailwoman/api-kit"
import type { EngineStamp } from "@mailwoman/core/license"
import { bodyLimit } from "hono/body-limit"
import { cors } from "hono/cors"

import type { MailwomanAPIEngine } from "#engine"
import { DEFAULT_BATCH_MAX, registerMailwomanAPIRoutes } from "#routes"
import type { GeocodeOutcomeLike } from "#schema"

/**
 * 2 MiB — carried from the express server's `express.json({ limit: "2mb" })` (`mailwoman/server/index.ts`).
 */
const DEFAULT_BODY_LIMIT_BYTES = 2 * 1024 * 1024

/**
 * Options for {@link createMailwomanAPI}.
 */
export interface MailwomanAPIOptions {
	/**
	 * Emit permissive cors headers (`Access-Control-Allow-Origin: *`) on every response
	 * and answer preflight `options` with `204`.
	 *
	 * Default `true` — browser-embedded clients (the demo, a map widget) need it:
	 * a cross-origin XHR (including the `post` preflight) is blocked without it (#1017).
	 * Set `false` when a reverse proxy already owns the cors headers.
	 */
	cors?: boolean

	/**
	 * Max request body size in bytes, enforced ahead of every `/v1/*` handler.
	 *
	 * Default 2 MiB.
	 */
	bodyLimitBytes?: number

	/**
	 * Max `addresses` rows accepted by `post /v1/batch`.
	 *
	 * Default 500 (see `routes.ts`'s `DEFAULT_BATCH_MAX`).
	 */
	batchMax?: number

	/**
	 * The engine stamp to carry on every response: `engine` in each `/v1` body
	 * and the `Server` + `Link: rel="license"` headers everywhere.
	 *
	 * Absent when an embedding application builds the app without the `mailwoman`
	 * package. the `mailwoman serve` command always passes one.
	 */
	engine?: EngineStamp
}

/**
 * Short, single-line summary of a zod validation failure for the envelope's `detail`
 * field — not the full `ZodError`, which is multi-line and carries internal
 * path/code detail not meant for a wire response.
 */
function summarizeValidationError(error: { issues: Array<{ path: PropertyKey[]; message: string }> }): string {
	return error.issues.map((issue) => `${issue.path.join(".") || "(root)"}: ${issue.message}`).join("; ")
}

/**
 * The document info stamped into the emitted OpenAPI document.
 *
 * Exported (not inlined) so the `mailwoman openapi` command can call `emitOpenAPIDocuments`
 * with the same info the mounted `/openapi.json` route (below, via {@link attachOpenAPIDocs})
 * uses — one source of truth, no risk of the two drifting.
 */
export const MAILWOMAN_API_DOC_INFO: OpenAPIDocInfo = {
	...(await readServedDocumentInfo(import.meta.url, "@mailwoman/api")),
	license: { name: "AGPL-3.0-only OR LicenseRef-Commercial", identifier: "AGPL-3.0-only" },
	contact: { name: "Sister Software", url: "https://mailwoman.ai" },
	servers: [
		{
			url: "http://{host}:{port}",
			variables: { host: { default: "127.0.0.1" }, port: { default: "3000" } },
		},
	],
	security: [],
	tags: [
		{ name: "parsing", description: "Free-text address parsing." },
		{ name: "geocoding", description: "Address-to-coordinate resolution." },
		{ name: "resolving", description: "Gazetteer resolution over an already-decoded address tree." },
		{ name: "formatting", description: "Component-dict rendering — the inverse of parsing." },
		{ name: "meta", description: "Health, metrics, and deploy-time operations." },
	],
}

/**
 * Build the native Mailwoman app around an injected {@link MailwomanAPIEngine}.
 */
export function createMailwomanAPI<T extends Partial<GeocodeOutcomeLike> = GeocodeOutcomeLike>(
	engine: MailwomanAPIEngine<T>,
	options: MailwomanAPIOptions = {}
): OpenAPIHono {
	const app = new OpenAPIHono({
		// This surface is ours (no vendor interface to preserve): every declared body/query
		// schema is validator-enforced, and a failure maps through the shared api-kit
		// envelope — never the raw zod `{success, error}` shape.
		// Individual routes (routes.ts) override this per-call to answer their own
		// friendly business message (e.g. "address is required"); this is the fallback
		// for the rest (currently just `/v1/format`).
		defaultHook: (result, c) => {
			if (!result.success) {
				return errorResponse(c, 400, "invalid request body", summarizeValidationError(result.error))
			}

			return undefined
		},
	})

	// Browser-embedded clients need cors or their cross-origin XHR
	// (including the mutating `/v1/*` preflight) is blocked before it completes (#1017).
	// GET+post, unlike the read-only drop-ins (photon, nominatim).
	if (options.cors !== false) {
		app.use(cors({ origin: "*", allowMethods: ["GET", "POST", "OPTIONS"], allowHeaders: ["*"], maxAge: 86_400 }))
	}

	if (options.engine) {
		app.use(engineHeaders(options.engine))
	}

	// Safety net: an engine fault answers the native envelope, never a crash.
	// `detail` carries the raw message — this surface is ours to design,
	// so (unlike the vendor-constrained drop-in envelopes) we can be helpful.
	app.onError((error, c) => {
		// A malformed request body is a client-side syntax error rather than a server fault —
		// Hono's zod-openapi validator throws before a route's own hook ever sees the body,
		// so it lands here instead of the per-route 400s in routes.ts.
		// Answer 400 rather than the 500 net (which stays reserved for engine faults).
		if (error instanceof Error && error.message.includes("Malformed JSON")) {
			return errorResponse(c, 400, "invalid request body", "malformed JSON")
		}

		return errorResponse(c, 500, "internal error", error instanceof Error ? error.message : String(error))
	})

	// Ahead of the handlers (which buffer the body into memory) so an oversized post is rejected
	// before that buffering happens rather than after — mirrors the libpostal precedent.
	app.use(
		"/v1/*",
		bodyLimit({
			maxSize: options.bodyLimitBytes ?? DEFAULT_BODY_LIMIT_BYTES,
			onError: (c) => errorResponse(c, 413, "request body too large"),
		})
	)

	registerMailwomanAPIRoutes(app, engine, {
		batchMax: options.batchMax ?? DEFAULT_BATCH_MAX,
		engine: options.engine,
	})

	attachOpenAPIDocs(app, MAILWOMAN_API_DOC_INFO)

	return app
}
