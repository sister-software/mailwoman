/**
 * @copyright Sister Software.
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Tests for {@link plausibilityCheck} (decisions 4, 6, 8). The four §7-2b acceptance criteria get their
 *   own `describe("§7-2b criteria")` block at the bottom of this file. every suite above it exercises the
 *   composition logic itself — claim resolution, the tech→category mapping, filing/physical evidence
 *   assembly, the abstain precedent, and the `coverage_confidence` combination — so each criterion can assert
 *   its own specific claim against a module already known to compose correctly in isolation.
 *
 *   Fixture idiom: a real `bdc.db` built via `buildBDCDatabase`'s `rows:` injection point (same idiom as
 *   `filing-landscape.test.ts`), and a poi-layer pair built the same way `nearest-infrastructure.test.ts`
 *   established (`poi-schema.ts` table builders directly — `bdc` cannot depend on the `mailwoman`
 *   workspace). Unlike that test's deliberately-decoupled `schemadb` fixture, several tests here need a
 *   realistic poi `layer_manifest` (a real recorded `spineKeys.h3.resolution`) to exercise
 *   `assertLayerSpineResolution`, so `openpoischemadb` below writes one explicitly with resolution 9
 *   (matching `POI_H3_RESOLUTION`) by default, overridable per test for the mismatch case.
 *
 *   Springfield, IL is the shared center (same coordinates `nearest-infrastructure.test.ts` uses) for
 *   every fixture below, so a single set of derived cells serves both the bdc.db and poi fixtures.
 */

import type { BDCDatabase } from "@mailwoman/bdc/schema"
import { buildBDCDatabase } from "@mailwoman/bdc/sdk/build-bdc"
import { res9ShortCellToRes6Parent } from "@mailwoman/bdc/sdk/filing-landscape"
import type { BDCAvailabilityRow } from "@mailwoman/bdc/sdk/parsing"
import {
	PLAUSIBILITY_TECH_PHYSICAL_CATEGORIES,
	physicalCategoriesForTechnology,
	plausibilityCheck,
	type GeocodeLike,
	type PlausibilityAbstainReason,
	type PlausibilityBundle,
	type PlausibilityCoverageAxisState,
	type PlausibilityDeps,
	type PlausibilityEvidence,
} from "@mailwoman/bdc/sdk/plausibility"
import { BroadbandTechnologyCode } from "@mailwoman/bdc/sdk/technologies"
import { temporaryDirectory, type TemporaryDirectory } from "@mailwoman/core/fs/temporary"
import {
	createLayerCoverageTable,
	createLayerManifestTable,
	writeLayerCoverage,
	writeLayerManifest,
	type layerschemadatabase,
} from "@mailwoman/core/layers"
import {
	POILookup,
	createPOIBrandIndex,
	createPOINameKeyIndex,
	createPOISearchFTS,
	createPOIStagingTables,
	createPOITable,
	type POIDatabase,
} from "@mailwoman/resolver-wof-sqlite/poi"
import { normalizeLocalityForKey } from "@mailwoman/resolver-wof-sqlite/street"
import { shortCellToInt, type H3Cell, type PointLiteral } from "@mailwoman/spatial"
import { DatabaseClient } from "@mailwoman/sqlite/client"
import { cellToChildren, cellToLatLng, cellToParent, latLngToCell } from "h3-js"
import { describe, expect, it } from "vitest"

const ASOF_DATE = "2026-07-30"

const SPRINGFIELD = { latitude: 39.7817, longitude: -89.6501 }

const SPRINGFIELD_POINT: PointLiteral = {
	type: "Point",
	coordinates: [SPRINGFIELD.longitude, SPRINGFIELD.latitude],
}

const SPRINGFIELD_RES9_FULL = latLngToCell(SPRINGFIELD.latitude, SPRINGFIELD.longitude, 9) as H3Cell
const SPRINGFIELD_RES9_SHORT = shortCellToInt(SPRINGFIELD_RES9_FULL)
const SPRINGFIELD_RES6_PARENT_FULL = cellToParent(SPRINGFIELD_RES9_FULL, 6) as H3Cell
const SPRINGFIELD_RES6_PARENT_SHORT = res9ShortCellToRes6Parent(SPRINGFIELD_RES9_SHORT)

// A sibling res-9 cell sharing springfield's res-6 parent but carrying no bdc_availability rows of its own.
// The "covered res-6 parent, zero filings in this exact cell" positive-absence case
// (filing-landscape.ts's own docstring: the h3Cells query path is the only way to exercise this,
// since geoid-mode's "no rows ⇒ no candidate cell" shortcut can never produce it).
// Derived from h3-js, never hardcoded.
const SPRINGFIELD_SIBLING_RES9_FULL = cellToChildren(SPRINGFIELD_RES6_PARENT_FULL, 9).find(
	(cell) => cell !== SPRINGFIELD_RES9_FULL
) as H3Cell

const [SIBLING_LAT, SIBLING_LON] = cellToLatLng(SPRINGFIELD_SIBLING_RES9_FULL)
const SIBLING_POINT: PointLiteral = { type: "Point", coordinates: [SIBLING_LON, SIBLING_LAT] }

const GEOID_SPRINGFIELD = "170010001001001"
const PROVIDER_FIBER = 130_001
const PROVIDER_DSL = 130_002

const SPRINGFIELD_CENTROID = { lat: SPRINGFIELD.latitude, lon: SPRINGFIELD.longitude }

function blockCentroids(geoid: string): { lat: number; lon: number } | undefined {
	return geoid === GEOID_SPRINGFIELD ? SPRINGFIELD_CENTROID : undefined
}

/**
 * One matching-tech/matching-or-better-speed row (corroborates the fiber@1000 claim) and one
 * lesser-tech row (DSL — never corroborates a fiber claim, regardless of speed) at the same geoid.
 */
function fixtureRows(): BDCAvailabilityRow[] {
	return [
		{
			geoid: GEOID_SPRINGFIELD,
			provider_id: PROVIDER_FIBER,
			technology_code: BroadbandTechnologyCode.OpticalCarrierFiber,
			location_id: "SPR-FIBER",
			max_advertised_download_speed: 1000,
			max_advertised_upload_speed: 1000,
			low_latency: 1,
			business_residential_code: "R",
		},
		{
			geoid: GEOID_SPRINGFIELD,
			provider_id: PROVIDER_DSL,
			technology_code: BroadbandTechnologyCode.AsymmetricXDSL,
			location_id: "SPR-DSL",
			max_advertised_download_speed: 1000,
			max_advertised_upload_speed: 1000,
			low_latency: 0,
			business_residential_code: "R",
		},
	]
}

/**
 * A built `bdc.db`, its open reader, and the scratch directory holding it —
 * all released when the binding leaves scope.
 */
type BDCFixture = TemporaryDirectory & { db: DatabaseClient<BDCDatabase> }

async function buildBDCFixture(): Promise<BDCFixture> {
	await using fixture = await temporaryDirectory("bdc-plausibility-bdc-")
	const out = fixture.resolve("bdc.db")

	await buildBDCDatabase({
		rows: fixtureRows(),
		out,
		asOfDate: ASOF_DATE,
		buildSHA: "deadbeef",
		blockCentroids,
	})

	return fixture.moveWith({ db: fixture.use(new DatabaseClient<BDCDatabase>(out, { readOnly: true })) })
}

interface POIFixtureRow {
	name: string
	category: string
	latitude: number
	longitude: number
	confidence?: number
}

const TELECOM_EXCHANGE_NEAR: POIFixtureRow = {
	name: "Central Office 12",
	category: "telecom_exchange",
	latitude: 39.782,
	longitude: -89.6501,
	confidence: 0.92,
}

const CATEGORY_IDS: Record<string, number> = { telecom_exchange: 1, tower_comms: 2, data_center: 3, cafe: 4 }

function cellFor(latitude: number, longitude: number): number {
	return shortCellToInt(latLngToCell(latitude, longitude, 9) as H3Cell)
}

/**
 * A built `poi.db` and the scratch directory holding it, both removed when the binding leaves scope.
 */
type POIFixture = TemporaryDirectory & { path: string }

async function buildPOILookupFixture(rows: readonly POIFixtureRow[]): Promise<POIFixture> {
	await using scratch = await temporaryDirectory("bdc-plausibility-poi-")
	const path = scratch.resolve("poi.db")

	await using kdb = new DatabaseClient<POIDatabase>(path)

	await createPOITable(kdb)
	await createPOIStagingTables(kdb)
	createPOISearchFTS(kdb)

	for (const [category, id] of Object.entries(CATEGORY_IDS)) {
		await kdb.insertInto("poi_category_codes").values({ id, category }).execute()
	}

	let rowidKey = 1

	for (const row of rows) {
		const confidence = row.confidence ?? 0.9

		await kdb
			.insertInto("poi")
			.values({
				h3_cell: cellFor(row.latitude, row.longitude),
				category_id: CATEGORY_IDS[row.category] ?? 0,
				neg_rank: 1 - confidence,
				rowid_key: rowidKey++,
				name: row.name,
				name_key: normalizeLocalityForKey(row.name),
				brand_wikidata: null,
				latitude: row.latitude,
				longitude: row.longitude,
				country: "US",
				confidence,
				gers_id: null,
			})
			.execute()
	}

	await createPOINameKeyIndex(kdb)
	await createPOIBrandIndex(kdb)

	return scratch.moveWith({ path })
}

/**
 * A `layerschemadatabase`-only fixture standing in for poi.db's own manifest/coverage —
 * not poi.db's actual file (mirrors `nearest-infrastructure.test.ts`'s decoupled `openemptyschemadb`),
 * but with a realistic recorded `spineKeys.h3.resolution` (9, matching `POI_H3_RESOLUTION`)
 * by default so `assertLayerSpineResolution` passes in the happy-path tests.
 *
 * `resolutionOverride` lets the mismatch test set something else.
 */
async function openpoischemadb(resolutionOverride = 9): Promise<DatabaseClient<layerschemadatabase>> {
	const kdb = DatabaseClient.temp<layerschemadatabase>()

	await createLayerManifestTable(kdb)
	await createLayerCoverageTable(kdb)

	await writeLayerManifest(kdb, {
		name: "test-poi-layer",
		version: "0.0.0-test",
		schemaVersion: 1,
		tier: "build-local",
		license: "ODbL-1.0",
		source: "test-fixture",
		sourceVintage: ASOF_DATE,
		buildCmd: "test",
		buildSHA: "deadbeef",
		freshnessPolicy: "sealed",
		spineKeys: { h3: { column: "h3_cell", resolution: resolutionOverride } },
		createdAt: `${ASOF_DATE}T00:00:00Z`,
	})

	return kdb
}

/**
 * Both layers open together, poi coverage written for exactly Springfield's own
 * res-6 parent (the query point's cell).
 *
 * Hoisted to module scope — shared by the "full composition" suite below and the `§7-2b criteria`
 * block (criterion 2's co-presence claim reuses this exact fixture rather than re-deriving it).
 */
async function openBoth(): Promise<AsyncDisposableStack & { deps: PlausibilityDeps }> {
	const stack = new AsyncDisposableStack()
	const bdc = stack.use(await buildBDCFixture())
	const poi = stack.use(await buildPOILookupFixture([TELECOM_EXCHANGE_NEAR]))
	const poischemadb = stack.use(await openpoischemadb())
	const poiLookup = stack.use(new POILookup({ databasePath: poi.path }))

	// Coverage for exactly Springfield's own res-6 parent — the query point's cell.
	await writeLayerCoverage(poischemadb, [{ h3Cell: SPRINGFIELD_RES6_PARENT_SHORT, completeness: 1, observedRows: 1 }])

	return Object.assign(stack, {
		deps: { bdcDB: bdc.db, poi: { lookup: poiLookup, schemadb: poischemadb } },
	})
}

describe("physicalCategoriesForTechnology / PLAUSIBILITY_TECH_PHYSICAL_CATEGORIES", () => {
	it("maps fiber to the three infra categories", () => {
		expect(physicalCategoriesForTechnology(BroadbandTechnologyCode.OpticalCarrierFiber)).toEqual([
			"telecom_exchange",
			"telecom_cabinet",
			"data_center",
		])
	})

	it.each([
		["Unlicensed", BroadbandTechnologyCode.UnlicensedTerrestrialFixedWireless],
		["Licensed", BroadbandTechnologyCode.LicensedTerrestrialFixedWireless],
		["LicensedByRule", BroadbandTechnologyCode.LicensedByRuleTerrestrialFixedWireless],
	])("maps the %s fixed-wireless code to tower_comms", (_label, code) => {
		expect(physicalCategoriesForTechnology(code)).toEqual(["tower_comms"])
	})

	it("maps every other tech code to [] — no physical falsifier claimed", () => {
		expect(physicalCategoriesForTechnology(BroadbandTechnologyCode.AsymmetricXDSL)).toEqual([])
		expect(physicalCategoriesForTechnology(BroadbandTechnologyCode.CableModemDOCSIS3)).toEqual([])
		expect(physicalCategoriesForTechnology(BroadbandTechnologyCode.GeostationarySatellite)).toEqual([])
		expect(physicalCategoriesForTechnology(BroadbandTechnologyCode.ElectricPowerLine)).toEqual([])
		expect(physicalCategoriesForTechnology(999)).toEqual([])
	})

	it("the exported table has exactly the four mapped codes", () => {
		expect(
			Object.keys(PLAUSIBILITY_TECH_PHYSICAL_CATEGORIES)
				.map(Number)
				.toSorted((a, b) => a - b)
		).toEqual([50, 70, 71, 72])
	})
})

describe("plausibilityCheck — claim resolution", () => {
	it("throws when the claim has none of geoid/point/address", async () => {
		await expect(
			plausibilityCheck({ technologyCode: BroadbandTechnologyCode.OpticalCarrierFiber, claimedDownloadMbps: 100 }, {})
		).rejects.toThrow(/geoid.*point.*address/i)
	})

	it("throws when claim.address is given without deps.geocode", async () => {
		await expect(
			plausibilityCheck(
				{
					address: "123 Main St, Springfield, IL",
					technologyCode: BroadbandTechnologyCode.OpticalCarrierFiber,
					claimedDownloadMbps: 100,
				},
				{}
			)
		).rejects.toThrow(/deps\.geocode/)
	})

	it("throws when geocode resolves no coordinate for the address", async () => {
		const geocode = async (): Promise<GeocodeLike> => ({ lat: null, lon: null })

		await expect(
			plausibilityCheck(
				{
					address: "nowhere",
					technologyCode: BroadbandTechnologyCode.OpticalCarrierFiber,
					claimedDownloadMbps: 100,
				},
				{ geocode }
			)
		).rejects.toThrow(/could not resolve a coordinate/)
	})

	it("block_resolution is 'geoid' for a geoid claim and 'h3_cell_approximation' for a point claim", async () => {
		const byGeoid = await plausibilityCheck(
			{ geoid: GEOID_SPRINGFIELD, technologyCode: BroadbandTechnologyCode.AsymmetricXDSL, claimedDownloadMbps: 10 },
			{}
		)

		expect(byGeoid.block_resolution).toBe("geoid")

		const byPoint = await plausibilityCheck(
			{
				point: SPRINGFIELD_POINT,
				technologyCode: BroadbandTechnologyCode.AsymmetricXDSL,
				claimedDownloadMbps: 10,
			},
			{}
		)

		expect(byPoint.block_resolution).toBe("h3_cell_approximation")
	})

	it("geocodes an address claim and resolves it through the point path", async () => {
		const geocode = async (address: string): Promise<GeocodeLike> => {
			expect(address).toBe("123 Main St, Springfield, IL")

			return { lat: SPRINGFIELD.latitude, lon: SPRINGFIELD.longitude }
		}

		const bundle = await plausibilityCheck(
			{
				address: "123 Main St, Springfield, IL",
				technologyCode: BroadbandTechnologyCode.AsymmetricXDSL,
				claimedDownloadMbps: 10,
			},
			{ geocode }
		)

		expect(bundle.block_resolution).toBe("h3_cell_approximation")
	})
})

describe("plausibilityCheck — bdc layer absent/insufficient (decision 6)", () => {
	it("abstains requires_bdc_layer and leaves vintage null when deps.bdcDB is absent", async () => {
		const bundle = await plausibilityCheck(
			{
				point: SPRINGFIELD_POINT,
				technologyCode: BroadbandTechnologyCode.OpticalCarrierFiber,
				claimedDownloadMbps: 100,
			},
			{}
		)

		expect(bundle.vintage).toBeNull()
		expect(bundle.evidence_found).toContainEqual({ type: "abstain", reason: "requires_bdc_layer", layer: "bdc" })
		expect(bundle.evidence_found.some((e) => e.type === "filing")).toBe(false)
		// The filing axis names why it's not covered — the layer was never wired —
		// distinct from a wired-but-unsurveyed cell (see the next test).
		expect(bundle.coverage_detail.filing).toBe("layer_missing")
	})

	it("abstains insufficient_survey_data (not requires_bdc_layer) when bdc.db is open but this exact cell was never surveyed, and vintage IS populated", async () => {
		await using bdc = await buildBDCFixture()

		// Far from Springfield — genuinely never surveyed by this fixture.
		const remote: PointLiteral = { type: "Point", coordinates: [-87.6298, 41.8781] }

		const bundle = await plausibilityCheck(
			{ point: remote, technologyCode: BroadbandTechnologyCode.OpticalCarrierFiber, claimedDownloadMbps: 100 },
			{ bdcDB: bdc.db }
		)

		expect(bundle.vintage).toBe(ASOF_DATE)

		expect(bundle.evidence_found).toContainEqual({
			type: "abstain",
			reason: "insufficient_survey_data",
			layer: "bdc",
		})

		expect(bundle.evidence_found.some((e) => e.type === "filing")).toBe(false)
		// Distinct from the layer-missing case above.
		// The layer is wired, only this cell lacks coverage.
		expect(bundle.coverage_detail.filing).toBe("cell_unsurveyed")
	})
})

describe("plausibilityCheck — filing evidence + corroboration", () => {
	it("emits one filing entry per provider row, corroborates true for a matching tech/speed and false for a different tech", async () => {
		await using bdc = await buildBDCFixture()

		const bundle = await plausibilityCheck(
			{
				geoid: GEOID_SPRINGFIELD,
				technologyCode: BroadbandTechnologyCode.OpticalCarrierFiber,
				claimedDownloadMbps: 1000,
			},
			{ bdcDB: bdc.db }
		)

		const filingEntries = bundle.evidence_found.filter((e) => e.type === "filing")
		expect(filingEntries).toHaveLength(2)

		const fiberEntry = filingEntries.find((e) => e.filing.provider_id === PROVIDER_FIBER)!
		expect(fiberEntry.corroborates).toBe(true)
		expect(fiberEntry.vintage).toBe(ASOF_DATE)

		const dslEntry = filingEntries.find((e) => e.filing.provider_id === PROVIDER_DSL)!
		expect(dslEntry.corroborates).toBe(false)

		// Never disproof: a non-corroborating filing is still a `filing` entry, never anything else.
		expect(filingEntries.every((e) => e.type === "filing")).toBe(true)
	})

	it("corroborates false for a same-tech but LESSER speed filing", async () => {
		await using scratch = await temporaryDirectory("bdc-plausibility-lesser-")
		const out = scratch.resolve("bdc.db")

		await buildBDCDatabase({
			rows: [
				{
					geoid: GEOID_SPRINGFIELD,
					provider_id: PROVIDER_FIBER,
					technology_code: BroadbandTechnologyCode.OpticalCarrierFiber,
					location_id: "SPR-FIBER-SLOW",
					max_advertised_download_speed: 50,
					max_advertised_upload_speed: 50,
					low_latency: 1,
					business_residential_code: "R",
				},
			],
			out,
			asOfDate: ASOF_DATE,
			buildSHA: "deadbeef",
			blockCentroids,
		})

		const inlineDB = scratch.use(new DatabaseClient<BDCDatabase>(out, { readOnly: true }))

		const bundle = await plausibilityCheck(
			{
				geoid: GEOID_SPRINGFIELD,
				technologyCode: BroadbandTechnologyCode.OpticalCarrierFiber,
				claimedDownloadMbps: 1000,
			},
			{ bdcDB: inlineDB }
		)

		const filingEntries = bundle.evidence_found.filter((e) => e.type === "filing")
		expect(filingEntries).toHaveLength(1)
		expect(filingEntries[0]!.corroborates).toBe(false)
	})

	it("positive absence: a covered res-6 parent with zero filings in the queried res-9 cell emits no filing evidence, and still counts as covered", async () => {
		await using bdc = await buildBDCFixture()

		// Sanity: the sibling cell really does share Springfield's res-6 parent, and really is a different res-9 cell.
		expect(SPRINGFIELD_SIBLING_RES9_FULL).not.toBe(SPRINGFIELD_RES9_FULL)
		expect(res9ShortCellToRes6Parent(shortCellToInt(SPRINGFIELD_SIBLING_RES9_FULL))).toBe(SPRINGFIELD_RES6_PARENT_SHORT)

		const bundle = await plausibilityCheck(
			{ point: SIBLING_POINT, technologyCode: BroadbandTechnologyCode.AsymmetricXDSL, claimedDownloadMbps: 10 },
			{ bdcDB: bdc.db }
		)

		expect(bundle.evidence_found.some((e) => e.type === "filing")).toBe(false)
		expect(bundle.evidence_found.some((e) => e.type === "abstain")).toBe(false)
		// DSL has no physical falsifier, so with no poi dep the confidence is filing-axis-only: covered ->
		// "low" (this module's conservative not_applicable extension — see plausibility.ts's module docstring).
		expect(bundle.coverage_confidence).toBe("low")
		// The bundle names why this is "low": physical is not_applicable
		// (DSL has no physical falsifier at all), not a poi survey gap.
		expect(bundle.coverage_detail).toEqual({ filing: "covered", physical: "not_applicable" })
	})
})

describe("plausibilityCheck — physical evidence + poi layer absence (decision 6)", () => {
	it("abstains requires_build_local_layer when the tech implies a physical category but deps.poi is absent", async () => {
		const bundle = await plausibilityCheck(
			{
				point: SPRINGFIELD_POINT,
				technologyCode: BroadbandTechnologyCode.OpticalCarrierFiber,
				claimedDownloadMbps: 100,
			},
			{}
		)

		expect(bundle.evidence_found).toContainEqual({
			type: "abstain",
			reason: "requires_build_local_layer",
			layer: "poi",
		})

		// Physical is layer_missing here — fiber does have a falsifier
		// (see the next test's not_applicable contrast for a tech that has none at all).
		expect(bundle.coverage_detail.physical).toBe("layer_missing")
	})

	it("never abstains on poi for a tech with no physical falsifier, even when deps.poi is absent", async () => {
		const bundle = await plausibilityCheck(
			{ point: SPRINGFIELD_POINT, technologyCode: BroadbandTechnologyCode.AsymmetricXDSL, claimedDownloadMbps: 10 },
			{}
		)

		expect(bundle.evidence_found.some((e) => e.type === "abstain" && e.reason === "requires_build_local_layer")).toBe(
			false
		)

		expect(bundle.evidence_found.some((e) => e.type === "physical_plant")).toBe(false)
		// not_applicable rather than layer_missing.
		// DSL has no physical falsifier regardless of poi's presence.
		expect(bundle.coverage_detail.physical).toBe("not_applicable")
	})

	it("a geoid-only claim (no point/address) skips physical evidence entirely — no abstain, no entry — even with deps.poi present", async () => {
		await using poi = await buildPOILookupFixture([TELECOM_EXCHANGE_NEAR])
		using poischemadb = await openpoischemadb()
		using poiLookup = new POILookup({ databasePath: poi.path })

		const bundle = await plausibilityCheck(
			{
				geoid: GEOID_SPRINGFIELD,
				technologyCode: BroadbandTechnologyCode.OpticalCarrierFiber,
				claimedDownloadMbps: 100,
			},
			{ poi: { lookup: poiLookup, schemadb: poischemadb } }
		)

		expect(bundle.evidence_found.some((e) => e.type === "physical_plant")).toBe(false)

		expect(bundle.evidence_found.some((e) => e.type === "abstain" && e.reason === "requires_build_local_layer")).toBe(
			false
		)

		// no_coordinate — a real capability gap distinct from layer_missing, since deps.poi is wired here.
		expect(bundle.coverage_detail.physical).toBe("no_coordinate")
	})
})

describe("plausibilityCheck — full composition (both layers present)", () => {
	it("co-presence: matching filing + nearby plant, both covered -> high confidence, both evidence kinds present", async () => {
		await using both = await openBoth()
		const { deps } = both

		const bundle = await plausibilityCheck(
			{
				point: SPRINGFIELD_POINT,
				technologyCode: BroadbandTechnologyCode.OpticalCarrierFiber,
				claimedDownloadMbps: 1000,
			},
			deps
		)

		expect(bundle.coverage_confidence).toBe("high")
		expect(bundle.coverage_detail).toEqual({ filing: "covered", physical: "covered" })
		expect(bundle.evidence_found.some((e) => e.type === "filing" && e.corroborates)).toBe(true)
		expect(bundle.evidence_found.some((e) => e.type === "physical_plant")).toBe(true)
		expect(bundle.evidence_found.some((e) => e.type === "abstain")).toBe(false)
	})

	it("both axes unknown (remote, unsurveyed-by-either point) -> insufficient_survey_data", async () => {
		await using both = await openBoth()
		const { deps } = both

		// A remote point: bdc.db never surveyed it, and openBoth()'s poi coverage table only covers
		// Springfield's own res-6 parent, so both axes genuinely come back unknown here — the both-unknown
		// branch, distinct from the actual mixed branch (one covered, one not) exercised below.
		const remote: PointLiteral = { type: "Point", coordinates: [-87.6298, 41.8781] }

		const bundle = await plausibilityCheck(
			{ point: remote, technologyCode: BroadbandTechnologyCode.OpticalCarrierFiber, claimedDownloadMbps: 1000 },
			deps
		)

		expect(bundle.coverage_confidence).toBe("insufficient_survey_data")
		expect(bundle.coverage_detail).toEqual({ filing: "cell_unsurveyed", physical: "cell_unsurveyed" })
		expect(bundle.evidence_found).toContainEqual({ type: "abstain", reason: "insufficient_survey_data", layer: "bdc" })
	})

	// `combineCoverage`'s genuine mixed branch — one axis covered, the other not.
	// It takes deliberate construction: any single point remote enough for bdc.db to
	// have missed it is also outside the poi coverage table, so both axes land on
	// unknown together and the both-unknown branch runs instead.
	// The two tests below drive the mixed branch in both directions by separating the two axes on purpose.
	it("MIXED: filing covered, physical layer entirely missing (no poi dep) -> low", async () => {
		await using bdc = await buildBDCFixture()

		const bundle = await plausibilityCheck(
			{
				geoid: GEOID_SPRINGFIELD,
				technologyCode: BroadbandTechnologyCode.OpticalCarrierFiber,
				claimedDownloadMbps: 1000,
			},
			{ bdcDB: bdc.db } // no poi — physical axis is layer_missing rather than not_applicable (fiber does have a falsifier)
		)

		expect(bundle.coverage_confidence).toBe("low")
		expect(bundle.coverage_detail).toEqual({ filing: "covered", physical: "layer_missing" })
		expect(bundle.evidence_found.some((e) => e.type === "filing")).toBe(true)

		expect(bundle.evidence_found).toContainEqual({
			type: "abstain",
			reason: "requires_build_local_layer",
			layer: "poi",
		})
	})

	it("MIXED: physical covered, filing layer unsurveyed (bdc.db never surveyed this point) -> low", async () => {
		await using bdc = await buildBDCFixture()
		await using poi = await buildPOILookupFixture([])
		using poischemadb = await openpoischemadb()
		using poiLookup = new POILookup({ databasePath: poi.path })

		// Deliberately covering the remote point's own res-6 parent (not Springfield's) — decoupled
		// from any real poi row, same idiom `nearest-infrastructure.test.ts`'s `openemptyschemadb`
		// establishes — so the physical axis reads covered at a cell bdc.db never surveyed,
		// genuinely separating the two axes instead of both landing on unknown together.
		const remote: PointLiteral = { type: "Point", coordinates: [-87.6298, 41.8781] }
		const remoteCell = cellFor(41.8781, -87.6298)

		await writeLayerCoverage(poischemadb, [
			{ h3Cell: res9ShortCellToRes6Parent(remoteCell), completeness: 1, observedRows: 0 },
		])

		const bundle = await plausibilityCheck(
			{ point: remote, technologyCode: BroadbandTechnologyCode.OpticalCarrierFiber, claimedDownloadMbps: 1000 },
			{ bdcDB: bdc.db, poi: { lookup: poiLookup, schemadb: poischemadb } }
		)

		expect(bundle.coverage_confidence).toBe("low")
		expect(bundle.coverage_detail).toEqual({ filing: "cell_unsurveyed", physical: "covered" })
		expect(bundle.evidence_found).toContainEqual({ type: "abstain", reason: "insufficient_survey_data", layer: "bdc" })
		expect(bundle.evidence_found.some((e) => e.type === "physical_plant")).toBe(false)
	})
})

describe("plausibilityCheck — per-layer coverage-spine resolution assertion", () => {
	it("throws when poi.db's recorded resolution disagrees with BDC_H3_RESOLUTION, with both layers wired", async () => {
		await using bdc = await buildBDCFixture()
		await using poi = await buildPOILookupFixture([TELECOM_EXCHANGE_NEAR])
		// Deliberately mismatched: bdc.db records resolution 9 (BDC_H3_RESOLUTION); this poi schemadb records 6.
		using poischemadb = await openpoischemadb(6)
		using poiLookup = new POILookup({ databasePath: poi.path })

		await expect(
			plausibilityCheck(
				{
					point: SPRINGFIELD_POINT,
					technologyCode: BroadbandTechnologyCode.OpticalCarrierFiber,
					claimedDownloadMbps: 1000,
				},
				{ bdcDB: bdc.db, poi: { lookup: poiLookup, schemadb: poischemadb } }
			)
		).rejects.toThrow(/poi\.db's recorded h3 spine resolution \(6\) does not match BDC_H3_RESOLUTION \(9\)/)
	})

	it("throws when poi.db's recorded resolution disagrees with BDC_H3_RESOLUTION, with poi wired ALONE (no bdcDB)", async () => {
		await using poi = await buildPOILookupFixture([TELECOM_EXCHANGE_NEAR])
		// Same mismatch as above, but with bdcDB never wired at all.
		// The case an assertion checking both layers being present would skip entirely.
		// `pointCell` (below) is still derived from BDC_H3_RESOLUTION regardless,
		// so poi's own resolution must be checked here too.
		using poischemadb = await openpoischemadb(6)
		using poiLookup = new POILookup({ databasePath: poi.path })

		await expect(
			plausibilityCheck(
				{
					point: SPRINGFIELD_POINT,
					technologyCode: BroadbandTechnologyCode.OpticalCarrierFiber,
					claimedDownloadMbps: 1000,
				},
				{ poi: { lookup: poiLookup, schemadb: poischemadb } }
			)
		).rejects.toThrow(/poi\.db's recorded h3 spine resolution \(6\) does not match BDC_H3_RESOLUTION \(9\)/)
	})

	it("does not throw when only bdcDB is wired and its own recorded resolution matches BDC_H3_RESOLUTION", async () => {
		await using bdc = await buildBDCFixture()

		await expect(
			plausibilityCheck(
				{
					point: SPRINGFIELD_POINT,
					technologyCode: BroadbandTechnologyCode.OpticalCarrierFiber,
					claimedDownloadMbps: 1000,
				},
				{ bdcDB: bdc.db }
			)
		).resolves.not.toThrow()
	})

	it("does not throw when only poi is wired and its own recorded resolution matches BDC_H3_RESOLUTION", async () => {
		await using poi = await buildPOILookupFixture([TELECOM_EXCHANGE_NEAR])
		using poischemadb = await openpoischemadb() // default resolution 9, matches BDC_H3_RESOLUTION
		using poiLookup = new POILookup({ databasePath: poi.path })

		await expect(
			plausibilityCheck(
				{
					point: SPRINGFIELD_POINT,
					technologyCode: BroadbandTechnologyCode.OpticalCarrierFiber,
					claimedDownloadMbps: 1000,
				},
				{ poi: { lookup: poiLookup, schemadb: poischemadb } }
			)
		).resolves.not.toThrow()
	})
})

/**
 * The §7-2b acceptance criteria — one describe per criterion, mapped 1:1 to the four bullets
 * in `docs/superpowers/plans/2026-07-30-bdc-2b-plan.md`'s "The §7-2b checks" section.
 *
 * Several criteria' behavioral claims are already proven by the suites above.
 * `plausibility.ts`'s own module docstring says as much
 * ("this module is designed for them but doesn't assert them itself").
 *
 * Where that's true, the test below asserts the criterion's specific claim against a
 * real bundle (reusing the established fixtures, including the hoisted `openBoth()`)
 * and cross-references the fuller proof by comment, rather than re-deriving the whole scenario.
 */
describe("§7-2b criteria", () => {
	describe("Criterion 1 — positive-evidence-only invariant (required)", () => {
		it("well-covered area, no filing, no nearby plant -> zero evidence entries, and confidence that reflects the REAL coverage (never insufficient_survey_data)", async () => {
			await using bdc = await buildBDCFixture()
			await using poi = await buildPOILookupFixture([]) // no plant anywhere
			using poischemadb = await openpoischemadb()
			using poiLookup = new POILookup({ databasePath: poi.path })

			// SIBLING_POINT: same res-6 parent as Springfield (real bdc.db coverage), zero
			// bdc_availability rows of its own — filing-landscape.ts's meaning-of-zero positive case
			// (see the "positive absence" test in the "filing evidence + corroboration" suite above).
			// Cover that same res-6 parent on the poi side too, so the physical axis is
			// genuinely surveyed as well rather than merely absent.
			// The well-covered half of this criterion’s contrast (the sparse-cell half is the next test).
			await writeLayerCoverage(poischemadb, [
				{ h3Cell: SPRINGFIELD_RES6_PARENT_SHORT, completeness: 1, observedRows: 0 },
			])

			const bundle = await plausibilityCheck(
				{
					point: SIBLING_POINT,
					technologyCode: BroadbandTechnologyCode.OpticalCarrierFiber,
					claimedDownloadMbps: 100,
				},
				{ bdcDB: bdc.db, poi: { lookup: poiLookup, schemadb: poischemadb } }
			)

			// The core claim: absence never manufactures a negative entry.
			// It just isn't there.
			expect(bundle.evidence_found).toEqual([])
			expect(bundle.coverage_detail).toEqual({ filing: "covered", physical: "covered" })
			// Both axes are genuinely covered -> "high", not "insufficient_survey_data" —
			// mislabeling a real, surveyed "nothing here" as a generic unknown would erase the
			// meaning-of-zero distinction the next test proves in the opposite direction.
			expect(bundle.coverage_confidence).toBe("high")
		})

		it("contrast: absence in a SPARSE, never-surveyed cell yields insufficient_survey_data — never the informative-absence form proved above (fuller proof: 'both axes unknown' test in the 'full composition' suite above)", async () => {
			await using both = await openBoth()
			const { deps } = both

			// Remote from Springfield: neither bdc.db's fixture rows nor openBoth()'s poi coverage
			// table (scoped to Springfield's own res-6 parent) has ever surveyed this point.
			const remote: PointLiteral = { type: "Point", coordinates: [-87.6298, 41.8781] }

			const bundle = await plausibilityCheck(
				{ point: remote, technologyCode: BroadbandTechnologyCode.OpticalCarrierFiber, claimedDownloadMbps: 1000 },
				deps
			)

			expect(bundle.coverage_detail).toEqual({ filing: "cell_unsurveyed", physical: "cell_unsurveyed" })
			expect(bundle.coverage_confidence).toBe("insufficient_survey_data")

			// A criterion anchor must never assert less than the ordinary test it cites as fuller proof,
			// so the abstain assertion from the "both axes unknown" test is mirrored here too.
			expect(bundle.evidence_found).toContainEqual({
				type: "abstain",
				reason: "insufficient_survey_data",
				layer: "bdc",
			})
		})

		/**
		 * Structural half of the criterion: an exhaustive, `satisfies Record<T, true>` pin
		 * (the established idiom — see `mailwoman/test/api-schema-drift.test.ts`) over
		 * every closed string-literal union on the bundle's public surface.
		 *
		 * TypeScript enforces both directions on each object below: a union member missing
		 * from the list fails to compile ("missing property"), and a listed key that isn't a
		 * real union member fails to compile ("excess property" — these are object literals
		 * assigned directly via `satisfies`, so excess-property checking applies).
		 * A future change that adds a verdict-shaped member (e.g. `"implausible"`)
		 * to any of these unions therefore either fails to compile here — silently
		 * missing from the pinned list, forcing a reviewer to touch this file — or,
		 * once added to the list, fails the runtime blocklist check below.
		 *
		 * That's the "mutation-style" assertion criterion 1 asks for: the pins are what
		 * keep the property true rather than a reviewer's memory.
		 *
		 * Only `tsc` checks the `satisfies` clauses (`yarn typecheck:tests`,
		 * which auto-discovers `bdc/tsconfig.test.json`).
		 * `yarn vitest run` alone (esbuild, types stripped) runs only the `it()` below,
		 * which still confirms none of the current values reads as a negative verdict.
		 *
		 * The five union pins close every closed union, but none of them has a claim over
		 * the bundle's own KEY SET — a wholly new field appended to `PlausibilityBundle`
		 * (e.g. A hypothetical `verdict: "plausible" | "implausible"`) would compile
		 * and ship green, since no union pin even looks at it.
		 * `PLAUSIBILITY_BUNDLE_KEYS` below closes that gap the same way:
		 * `satisfies Record<keyof PlausibilityBundle, true>` fails to compile if a key is added to
		 * (or removed from) the interface without a matching update here.
		 */
		const PLAUSIBILITY_BUNDLE_KEYS = {
			claim: true,
			evidence_found: true,
			coverage_confidence: true,
			coverage_detail: true,
			block_resolution: true,
			vintage: true,
		} satisfies Record<keyof PlausibilityBundle, true>

		const EVIDENCE_TYPE_TAGS = {
			filing: true,
			physical_plant: true,
			abstain: true,
		} satisfies Record<PlausibilityEvidence["type"], true>

		const ABSTAIN_REASONS = {
			requires_build_local_layer: true,
			requires_bdc_layer: true,
			insufficient_survey_data: true,
		} satisfies Record<PlausibilityAbstainReason, true>

		const COVERAGE_CONFIDENCE_VALUES = {
			high: true,
			low: true,
			insufficient_survey_data: true,
		} satisfies Record<PlausibilityBundle["coverage_confidence"], true>

		const COVERAGE_AXIS_STATES = {
			covered: true,
			layer_missing: true,
			cell_unsurveyed: true,
			no_coordinate: true,
			not_applicable: true,
		} satisfies Record<PlausibilityCoverageAxisState, true>

		const BLOCK_RESOLUTION_VALUES = {
			geoid: true,
			h3_cell_approximation: true,
		} satisfies Record<PlausibilityBundle["block_resolution"], true>

		/**
		 * Any value shaped like a negative verdict — the thing this scorer's whole design forbids emitting.
		 */
		const VERDICT_LIKE_PATTERN =
			/implaus|disprov|contradic|invalid|false|deny|reject|negat|unsupport|unverif|not_?found|no_service|unavailable/i

		it("no value in the bundle's public type surface (evidence types, abstain reasons, confidence, coverage-axis states, block_resolution) is verdict-shaped", () => {
			const allValues = [
				...Object.keys(EVIDENCE_TYPE_TAGS),
				...Object.keys(ABSTAIN_REASONS),
				...Object.keys(COVERAGE_CONFIDENCE_VALUES),
				...Object.keys(COVERAGE_AXIS_STATES),
				...Object.keys(BLOCK_RESOLUTION_VALUES),
			]

			// Exhaustive means non-empty — a refactor that hollowed out one of the objects
			// above (e.g. Via a bad merge) must not silently pass a loop over nothing.
			expect(allValues).toHaveLength(16)

			for (const value of allValues) {
				expect(value).not.toMatch(VERDICT_LIKE_PATTERN)
			}
		})

		it("PLAUSIBILITY_BUNDLE_KEYS (the key-set pin) is non-empty — a hollowed-out pin object would make the compile-time guard above vacuous", () => {
			// The pin's real teeth are the `satisfies` clause itself, which is compile-time only —
			// to check it by hand, temporarily add a field to `PlausibilityBundle`,
			// rebuild `bdc/out`, confirm `tsc` fails here, then revert.
			// This runtime assertion is only the same non-empty backstop the union pins'
			// own `toHaveLength(16)` above provides.
			// It can't observe a missing key the way `tsc` does.
			expect(Object.keys(PLAUSIBILITY_BUNDLE_KEYS)).toHaveLength(6)
		})
	})

	describe("Criterion 2 — co-presence (fuller proof: 'full composition' suite above)", () => {
		it("matching filing + nearby plant, both covered -> corroborating filing evidence + a physical hit + coverage_confidence: high, coverage_detail fully covered, and no abstain", async () => {
			await using both = await openBoth()
			const { deps } = both

			const bundle = await plausibilityCheck(
				{
					point: SPRINGFIELD_POINT,
					technologyCode: BroadbandTechnologyCode.OpticalCarrierFiber,
					claimedDownloadMbps: 1000,
				},
				deps
			)

			expect(bundle.coverage_confidence).toBe("high")
			// A criterion anchor must never assert less than the ordinary test it cites as fuller proof, so
			// the coverage_detail and no-abstain assertions from the co-presence test are mirrored here too.
			expect(bundle.coverage_detail).toEqual({ filing: "covered", physical: "covered" })
			expect(bundle.evidence_found.some((e) => e.type === "filing" && e.corroborates)).toBe(true)
			expect(bundle.evidence_found.some((e) => e.type === "physical_plant")).toBe(true)
			expect(bundle.evidence_found.some((e) => e.type === "abstain")).toBe(false)
		})
	})

	describe("Criterion 3 — layer absent: abstain, no fabricated evidence (fuller proof: 'bdc layer absent/insufficient' and 'physical evidence + poi layer absence' suites above)", () => {
		it("poi layer absent -> abstain requires_build_local_layer, and no physical_plant (the only distance-related evidence shape) is fabricated", async () => {
			const bundle = await plausibilityCheck(
				{
					point: SPRINGFIELD_POINT,
					technologyCode: BroadbandTechnologyCode.OpticalCarrierFiber,
					claimedDownloadMbps: 100,
				},
				{}
			)

			expect(bundle.evidence_found).toContainEqual({
				type: "abstain",
				reason: "requires_build_local_layer",
				layer: "poi",
			})

			expect(bundle.evidence_found.some((e) => e.type === "physical_plant")).toBe(false)
		})

		it("bdc layer absent -> abstain requires_bdc_layer, vintage: null, and no filing evidence is fabricated", async () => {
			const bundle = await plausibilityCheck(
				{
					point: SPRINGFIELD_POINT,
					technologyCode: BroadbandTechnologyCode.OpticalCarrierFiber,
					claimedDownloadMbps: 100,
				},
				{}
			)

			expect(bundle.vintage).toBeNull()
			expect(bundle.evidence_found).toContainEqual({ type: "abstain", reason: "requires_bdc_layer", layer: "bdc" })
			expect(bundle.evidence_found.some((e) => e.type === "filing")).toBe(false)
		})
	})

	describe("Criterion 4 — block-grain flag (fuller proof: 'claim resolution' suite above)", () => {
		it("address- and point-resolved claims carry block_resolution: h3_cell_approximation; a geoid-given claim carries geoid", async () => {
			const byPoint = await plausibilityCheck(
				{ point: SPRINGFIELD_POINT, technologyCode: BroadbandTechnologyCode.AsymmetricXDSL, claimedDownloadMbps: 10 },
				{}
			)

			expect(byPoint.block_resolution).toBe("h3_cell_approximation")

			const geocode = async (): Promise<GeocodeLike> => ({ lat: SPRINGFIELD.latitude, lon: SPRINGFIELD.longitude })

			const byAddress = await plausibilityCheck(
				{
					address: "123 Main St, Springfield, IL",
					technologyCode: BroadbandTechnologyCode.AsymmetricXDSL,
					claimedDownloadMbps: 10,
				},
				{ geocode }
			)

			expect(byAddress.block_resolution).toBe("h3_cell_approximation")

			const byGeoid = await plausibilityCheck(
				{ geoid: GEOID_SPRINGFIELD, technologyCode: BroadbandTechnologyCode.AsymmetricXDSL, claimedDownloadMbps: 10 },
				{}
			)

			expect(byGeoid.block_resolution).toBe("geoid")
		})
	})
})
