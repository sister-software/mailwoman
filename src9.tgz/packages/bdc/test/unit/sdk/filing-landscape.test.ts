/**
 * @copyright Sister Software.
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   The four pre-registered 2a acceptance criteria for `filingLandscape` — this whole phase
 *   is judged by these. Each criterion builds (or reuses) a fixture `bdc.db` via `buildBDCDatabase`'s
 *   `rows:` test injection point, feeding one location per (geoid, provider, technology) triple so the census in
 *   criterion 3 is hand-verifiable without any BSL/location_id collapsing to reason about.
 *
 *   Fixture: 3 known blocks (SF, NY, and a third block — "divergent" — chosen because its directly
 *   -indexed res-6 cell disagrees with its res-9 cell's H3 hierarchy parent, see below) × 2
 *   providers each at SF/NY, distinct techs/speeds landing in 3 different speed buckets, plus one geoid
 *   that is never fed to the builder at all (criterion 2's "absent from the fixture" block). Criteria 1–4 below
 *   query only `[GEOID_SF, GEOID_NY]` (or subsets), so divergent doesn't perturb their hand-counts
 *   — it's exercised only by the coverage-cell unification tests that need it.
 *
 *   Three properties the four criteria do not pin on their own, each with its own describe block below:
 *
 *   - **Builder and reader must derive a block's res-6 coverage cell the same way.** H3's cell hierarchy
 *     is not geometrically exact: `latLngToCell(centroid, 6)` and `cellToParent(latLngToCell(centroid,
 *     9), 6)` disagree for ~6% of real points. Derive the two sides independently and a genuinely
 *     surveyed block reads back as `unknown_block_count` while its own rows still populate `filings` — a
 *     self-contradiction. `build-bdc.ts` derives both `h3_cell` and the coverage cell from the same full
 *     res-9 index. see that file's docstring. The "builder/reader coverage-cell unification" describe
 *     block below proves the agreement holds even for the divergent block, chosen specifically because
 *     the two derivations do disagree there (asserted inline first, so the test cannot pass vacuously).
 *   - **criterion 2 must exercise `readLayerCoverage`, not the zero-rows shortcut.** A geoid absent from the
 *     fixture derives no candidate cell at all, so it is classified unknown before the coverage check is
 *     ever reached — a criterion 2 built only on that block stays green with the coverage branch deleted
 *     outright. "criterion 2 (extended)" below adds a geoid that has rows but whose `layer_coverage` row is
 *     deliberately deleted post-build (a genuine coverage-check exercise), plus an `h3Cells`-form query
 *     against a cell that was never surveyed at all — that branch is the only path for an `h3Cells`
 *     query, which has no "zero rows" shortcut available to it.
 *   - **The SQL `case` and the JS `speedBucketForDownloadSpeed` mirror must not drift.** "speed bucket
 *     boundaries" below is a table test over the exact boundary values plus a dedicated SQL-vs-JS
 *     agreement test. the "100-1000" bucket is otherwise never exercised by the criteria.
 */

import { BDC_H3_RESOLUTION, type BDCDatabase } from "@mailwoman/bdc/schema"
import { buildBDCDatabase } from "@mailwoman/bdc/sdk/build-bdc"
import {
	BDC_SPEED_BUCKET_100_1000,
	BDC_SPEED_BUCKET_25_100,
	BDC_SPEED_BUCKET_GIGABIT,
	BDC_SPEED_BUCKET_UNDER_25,
	filingLandscape,
	res9ShortCellToRes6Parent,
	speedBucketForDownloadSpeed,
} from "@mailwoman/bdc/sdk/filing-landscape"
import type { BDCAvailabilityRow } from "@mailwoman/bdc/sdk/parsing"
import { pathExists } from "@mailwoman/core/fs/readers"
import { temporaryDirectory, type TemporaryDirectory } from "@mailwoman/core/fs/temporary"
import { changeMode } from "@mailwoman/core/fs/writers"
import { readLayerCoverage, readLayerManifest } from "@mailwoman/core/layers"
import { shortCellToInt, type H3Cell } from "@mailwoman/spatial"
import { DatabaseClient } from "@mailwoman/sqlite/client"
import { openBuiltClient } from "@mailwoman/sqlite/sealed"
import { latLngToCell } from "h3-js"
import { afterAll, beforeAll, describe, expect, it } from "vitest"

const fixtures = new AsyncDisposableStack()

afterAll(() => fixtures.disposeAsync())

const ASOF_DATE = "2026-07-15"

const GEOID_SF = "060750001001001"
const GEOID_NY = "360610001001001"
// A rural-Virginia point found by brute-force search over a conus bounding box specifically
// because its directly-indexed res-6 cell (`latLngToCell(_, 6)`) disagrees with
// its res-9 cell's H3 hierarchy parent (`cellToParent(latLngToCell(_, 9), 6)`) —
// the exact divergence class builder/reader unification guards.
const GEOID_DIVERGENT = "510090101001001"
// Deliberately never passed to `buildBDCDatabase` at all — criterion 2's "absent from the fixture" block.
const GEOID_UNKNOWN = "999999999999999"

const CENTROID_SF = { lat: 37.7749, lon: -122.4194 }
const CENTROID_NY = { lat: 40.7128, lon: -74.006 }
const CENTROID_DIVERGENT = { lat: 37.119, lon: -79.6658 }
// Never registered in `blockCentroids` — purely a coordinate the test
// uses to prove that area's res-6 cell carries no coverage row at all
// (an independent check on the fixture's honesty rather than something `filingLandscape`
// ever looks up for an unrouted geoid — it has no cell to look up in the first place).
const CENTROID_NEVER_SURVEYED = { lat: 41.8781, lon: -87.6298 }

const CENTROIDS: Record<string, { lat: number; lon: number }> = {
	[GEOID_SF]: CENTROID_SF,
	[GEOID_NY]: CENTROID_NY,
	[GEOID_DIVERGENT]: CENTROID_DIVERGENT,
}

function blockCentroids(geoid: string): { lat: number; lon: number } | undefined {
	return CENTROIDS[geoid]
}

const PROVIDER_A = 130_077
const PROVIDER_B = 130_080

/**
 * 5 rows, one location each (`includeLocationIDs` stays default-off. one row per (geoid,
 * provider, technology) triple keeps the block-grain collapse a no-op, so `result.rows`
 * and the hand-computed census in criterion 3 agree without any surprise collapsing):
 *
 * - SF: provider A / tech 50 / 1000 Mbps (gigabit), provider B / tech 40 / 80 Mbps (25-100)
 * - NY: provider A / tech 50 / 1000 Mbps (gigabit — same bucket/tech/provider as SF, block_count sums to 2), provider B /
 *   tech 10 / 10 Mbps (under-25)
 * - Divergent: provider A / tech 30 / 500 Mbps (100-1000) — not queried by Criteria 1–4, only by the fix-round-1 tests.
 */
function fixtureRows(): BDCAvailabilityRow[] {
	return [
		{
			geoid: GEOID_SF,
			provider_id: PROVIDER_A,
			technology_code: 50,
			location_id: "SF-A",
			max_advertised_download_speed: 1000,
			max_advertised_upload_speed: 1000,
			low_latency: 1,
			business_residential_code: "R",
		},
		{
			geoid: GEOID_SF,
			provider_id: PROVIDER_B,
			technology_code: 40,
			location_id: "SF-B",
			max_advertised_download_speed: 80,
			max_advertised_upload_speed: 20,
			low_latency: 0,
			business_residential_code: "R",
		},
		{
			geoid: GEOID_NY,
			provider_id: PROVIDER_A,
			technology_code: 50,
			location_id: "NY-A",
			max_advertised_download_speed: 1000,
			max_advertised_upload_speed: 1000,
			low_latency: 1,
			business_residential_code: "R",
		},
		{
			geoid: GEOID_NY,
			provider_id: PROVIDER_B,
			technology_code: 10,
			location_id: "NY-B",
			max_advertised_download_speed: 10,
			max_advertised_upload_speed: 5,
			low_latency: 0,
			business_residential_code: "R",
		},
		{
			geoid: GEOID_DIVERGENT,
			provider_id: PROVIDER_A,
			technology_code: 30,
			location_id: "DIVERGENT-A",
			max_advertised_download_speed: 500,
			max_advertised_upload_speed: 500,
			low_latency: 1,
			business_residential_code: "R",
		},
	]
}

let scratch: TemporaryDirectory
let out: string

beforeAll(async () => {
	scratch = await temporaryDirectory("bdc-filing-landscape-")
	out = scratch.resolve("bdc.db")

	await buildBDCDatabase({
		rows: fixtureRows(),
		out,
		asOfDate: ASOF_DATE,
		buildSHA: "deadbeef",
		blockCentroids,
	})
})

afterAll(() => scratch[Symbol.asyncDispose]())

function openFixture(): DatabaseClient<BDCDatabase> {
	return new DatabaseClient<BDCDatabase>(out, { readOnly: true })
}

describe("filingLandscape — Check 1: interface conformance", () => {
	it("reads a manifest whose spine is res-9 h3, and stores h3_cell byte-compatible with shortCellToInt(latLngToCell(...))", async () => {
		using db = openFixture()
		const schemadb = db

		const manifest = await readLayerManifest(schemadb)
		expect(manifest.spineKeys.h3?.resolution).toBe(9)
		expect(BDC_H3_RESOLUTION).toBe(9)

		const row = await db
			.selectFrom("bdc_availability")
			.select("h3_cell")
			.where("geoid", "=", GEOID_SF)
			.executeTakeFirstOrThrow()

		const expectedCell = shortCellToInt(latLngToCell(CENTROID_SF.lat, CENTROID_SF.lon, 9) as H3Cell)
		expect(row.h3_cell).toBe(expectedCell)

		// The reader itself must also come back clean against this same fixture.
		const result = await filingLandscape(db, { geoids: [GEOID_SF] })
		expect(result.vintage).toBe(ASOF_DATE)
	})
})

describe("filingLandscape — Check 2: meaning-of-zero", () => {
	it("reports a geoid absent from the fixture in unknown_block_count, never as a zero-filing claim", async () => {
		using db = openFixture()
		const schemadb = db

		// Independent honesty check on the fixture: an area never fed to the builder carries no coverage
		// row at all — proves the "absence" below is real rather than an artifact of the query.
		const neverSurveyedRes6 = shortCellToInt(
			latLngToCell(CENTROID_NEVER_SURVEYED.lat, CENTROID_NEVER_SURVEYED.lon, 6) as H3Cell
		)

		expect(await readLayerCoverage(schemadb, neverSurveyedRes6)).toBeUndefined()

		const knownOnly = await filingLandscape(db, { geoids: [GEOID_SF, GEOID_NY] })
		const withUnknown = await filingLandscape(db, { geoids: [GEOID_SF, GEOID_NY, GEOID_UNKNOWN] })

		expect(withUnknown.unknown_block_count).toBe(1)
		// surveyed_block_count is unchanged by the unknown geoid's presence in the query.
		// It's never folded in as a (zero-filing) survey result.
		expect(withUnknown.surveyed_block_count).toBe(knownOnly.surveyed_block_count)
		expect(withUnknown.surveyed_block_count).toBe(2)

		// The unknown geoid must not silently appear as a zero-count entry anywhere in filings either.
		// It simply contributes nothing (filings for the two known blocks are identical either way).
		expect(withUnknown.filings).toEqual(knownOnly.filings)
	})
})

describe("filingLandscape — Check 2 (extended): coverage-check is required, not a rows-shortcut proxy", () => {
	// criterion 2 above never reaches `readLayerCoverage`.
	// GEOID_UNKNOWN has zero rows, so it's classified unknown by the "no candidate cell" shortcut
	// alone, and the coverage-check branch can be deleted outright without turning it red.
	// These two tests target that branch directly: (a) a geoid with rows whose coverage
	// row is deliberately deleted, and (b) an `h3Cells` query — which has no rows-based
	// shortcut available at all — against a cell that was never surveyed.
	it("(a) a geoid with real rows but a deleted coverage row is unknown, and its rows do not leak into filings", async () => {
		await using coverageScratch = await temporaryDirectory("bdc-filing-landscape-coverage-corrupt-")
		const corruptOut = coverageScratch.resolve("bdc.db")

		await buildBDCDatabase({
			rows: fixtureRows(),
			out: corruptOut,
			asOfDate: ASOF_DATE,
			buildSHA: "deadbeef",
			blockCentroids,
		})

		await changeMode(corruptOut, 0o644)

		await using writable = await openBuiltClient<BDCDatabase>(corruptOut, { write: true })

		const sfRow = await writable
			.selectFrom("bdc_availability")
			.select("h3_cell")
			.where("geoid", "=", GEOID_SF)
			.executeTakeFirstOrThrow()

		const sfCoverageCell = res9ShortCellToRes6Parent(sfRow.h3_cell)

		const schemadb = writable
		// Sanity: the builder did write this coverage row, at the cell the reader derives —
		// deleting it below is a deliberate corruption rather than a pre-existing gap.
		expect(await readLayerCoverage(schemadb, sfCoverageCell)).toBeDefined()

		await schemadb.deleteFrom("layer_coverage").where("h3_cell", "=", sfCoverageCell).execute()
		expect(await readLayerCoverage(schemadb, sfCoverageCell)).toBeUndefined()

		const result = await filingLandscape(writable, { geoids: [GEOID_SF, GEOID_NY] })

		expect(result.unknown_block_count).toBe(1)
		expect(result.surveyed_block_count).toBe(1)

		// SF's rows must not leak into filings now that SF is unknown: the SF-only
		// (PROVIDER_B/tech40/25-100) entry must be absent entirely, and the gigabit entry
		// PROVIDER_A/tech50 shares with NY must drop from block_count 2 to 1 (NY only) —
		// never silently kept at 2 as if SF still counted as surveyed.
		expect(result.filings).toEqual([
			{ provider_id: PROVIDER_A, technology_code: 50, speed_bucket: BDC_SPEED_BUCKET_GIGABIT, block_count: 1 },
			{ provider_id: PROVIDER_B, technology_code: 10, speed_bucket: BDC_SPEED_BUCKET_UNDER_25, block_count: 1 },
		])
	})

	it("(b) an h3Cells query against a never-surveyed cell is unknown, never a zero-filing claim", async () => {
		using db = openFixture()

		// h3Cells mode has no "zero rows" shortcut.
		// The cell is supplied directly, so this is the only code path that can classify it,
		// proving the coverage-check branch itself (not a rows-existence proxy) is what runs.
		const neverSurveyedRes9Cell = shortCellToInt(
			latLngToCell(CENTROID_NEVER_SURVEYED.lat, CENTROID_NEVER_SURVEYED.lon, 9) as H3Cell
		)

		const result = await filingLandscape(db, { h3Cells: [neverSurveyedRes9Cell] })

		expect(result.unknown_block_count).toBe(1)
		expect(result.surveyed_block_count).toBe(0)
		expect(result.filings).toEqual([])
	})
})

describe("filingLandscape — builder/reader coverage-cell unification", () => {
	it("agrees with the builder's coverage cell even at a point where the two derivations used to disagree", async () => {
		using db = openFixture()
		const schemadb = db

		const row = await db
			.selectFrom("bdc_availability")
			.select("h3_cell")
			.where("geoid", "=", GEOID_DIVERGENT)
			.executeTakeFirstOrThrow()

		// Prove this is a genuinely divergent point before trusting the rest of the test:
		// the independent derivation — `latLngToCell(centroid, 6)`, taken without reference to the stored
		// res-9 cell — disagrees with the reader's hierarchy-parent derivation for this exact point.
		// If this assertion ever stops holding (e.g. An h3-js upgrade changes cell boundaries),
		// the point needs re-selecting via a fresh brute-force search.
		const oldBuggyDerivation = shortCellToInt(latLngToCell(CENTROID_DIVERGENT.lat, CENTROID_DIVERGENT.lon, 6) as H3Cell)
		const unifiedDerivation = res9ShortCellToRes6Parent(row.h3_cell)
		expect(unifiedDerivation).not.toBe(oldBuggyDerivation)

		// The builder (fixed) must have written coverage under the unified derivation rather than the old buggy one.
		expect(await readLayerCoverage(schemadb, unifiedDerivation)).toBeDefined()
		expect(await readLayerCoverage(schemadb, oldBuggyDerivation)).toBeUndefined()

		// End-to-end: this block must read back as surveyed, with its own filing intact.
		// The exact self-contradiction (unknown_block_count claiming "never surveyed" while filings shows
		// a real entry for it) the review reproduced against the pre-fix code is what this proves absent.
		const result = await filingLandscape(db, { geoids: [GEOID_DIVERGENT] })
		expect(result.surveyed_block_count).toBe(1)
		expect(result.unknown_block_count).toBe(0)

		expect(result.filings).toEqual([
			{ provider_id: PROVIDER_A, technology_code: 30, speed_bucket: BDC_SPEED_BUCKET_100_1000, block_count: 1 },
		])
	})
})

describe("filingLandscape — Check 3: hand-verified census", () => {
	it("returns the exact ProviderFilingSummary[] for 2 providers over 2 blocks", async () => {
		using db = openFixture()

		const result = await filingLandscape(db, { geoids: [GEOID_SF, GEOID_NY] })

		expect(result.surveyed_block_count).toBe(2)
		expect(result.unknown_block_count).toBe(0)

		// Hand-computed: PROVIDER_A/tech 50/gigabit appears at both blocks (block_count 2);
		// each PROVIDER_B row is distinct per block (25-100 at SF only, under-25 at NY only).
		expect(result.filings).toEqual([
			{ provider_id: PROVIDER_A, technology_code: 50, speed_bucket: BDC_SPEED_BUCKET_GIGABIT, block_count: 2 },
			{ provider_id: PROVIDER_B, technology_code: 10, speed_bucket: BDC_SPEED_BUCKET_UNDER_25, block_count: 1 },
			{ provider_id: PROVIDER_B, technology_code: 40, speed_bucket: BDC_SPEED_BUCKET_25_100, block_count: 1 },
		])
	})

	it("queries equivalently by h3Cells, over the block's own stored cell", async () => {
		using db = openFixture()

		const sfCell = shortCellToInt(latLngToCell(CENTROID_SF.lat, CENTROID_SF.lon, 9) as H3Cell)
		const nyCell = shortCellToInt(latLngToCell(CENTROID_NY.lat, CENTROID_NY.lon, 9) as H3Cell)

		const byGeoid = await filingLandscape(db, { geoids: [GEOID_SF, GEOID_NY] })
		const byCell = await filingLandscape(db, { h3Cells: [sfCell, nyCell] })

		expect(byCell).toEqual(byGeoid)
	})

	it("rejects a query with neither or both of geoids/h3Cells", async () => {
		using db = openFixture()

		await expect(filingLandscape(db, {})).rejects.toThrow(/exactly one/)
		await expect(filingLandscape(db, { geoids: [GEOID_SF], h3Cells: [1] })).rejects.toThrow(/exactly one/)
	})

	it("rejects an empty geoids/h3Cells array rather than silently answering a vacuous all-zero landscape", async () => {
		// `[]` is truthy in JS, so it passes the "exactly one of geoids/h3Cells" XOR check undetected.
		// Without an explicit length guard this would otherwise return
		// `{ surveyed_block_count: 0, unknown_block_count: 0, filings: [] }`, indistinguishable from a
		// real (if uninteresting) result instead of the malformed-query error an empty query actually is.
		// Reachable from the MCP tool layer (`mcp/tools.ts`), which is why both layers carry this guard.
		using db = openFixture()

		await expect(filingLandscape(db, { geoids: [] })).rejects.toThrow(/empty/)
		await expect(filingLandscape(db, { h3Cells: [] })).rejects.toThrow(/empty/)
	})
})

describe("filingLandscape — Check 4: vintage-or-throw", () => {
	it("throws when the manifest row is missing, rather than answering unstamped", async () => {
		await using corruptScratch = await temporaryDirectory("bdc-filing-landscape-corrupt-")
		const corruptOut = corruptScratch.resolve("bdc.db")

		await buildBDCDatabase({
			rows: fixtureRows(),
			out: corruptOut,
			asOfDate: ASOF_DATE,
			buildSHA: "deadbeef",
			blockCentroids,
		})

		// `buildBDCDatabase` seals (chmod 0444).
		// Unseal so the manifest row can be deleted, per `openBuiltClient`'s `write: true`
		// mode (throws `SealedArtifactError` while still sealed).
		await changeMode(corruptOut, 0o644)
		expect(await pathExists(corruptOut)).toBe(true)

		await using writable = await openBuiltClient<BDCDatabase>(corruptOut, { write: true })
		await writable.deleteFrom("layer_manifest").execute()

		await expect(filingLandscape(writable, { geoids: [GEOID_SF] })).rejects.toThrow(/manifest/)
	})
})

describe("speed bucket boundaries", () => {
	it.each([
		[0, BDC_SPEED_BUCKET_UNDER_25],
		[24, BDC_SPEED_BUCKET_UNDER_25],
		[25, BDC_SPEED_BUCKET_25_100],
		[99, BDC_SPEED_BUCKET_25_100],
		[100, BDC_SPEED_BUCKET_100_1000],
		[999, BDC_SPEED_BUCKET_100_1000],
		[1000, BDC_SPEED_BUCKET_GIGABIT],
	])("speedBucketForDownloadSpeed(%i) === %s", (speed, expectedBucket) => {
		expect(speedBucketForDownloadSpeed(speed)).toBe(expectedBucket)
	})

	describe("SQL CASE agrees with the JS mirror at every boundary", () => {
		// One geoid per boundary value, all at the same centroid
		// (the geoid string rather than location, is what `filingLandscape` groups on) —
		// same provider/tech throughout, so the only thing that can split the resulting
		// groups is the SQL case's bucketing of `max_advertised_download_speed`.
		const BOUNDARY_PROVIDER = 999_001
		const BOUNDARY_TECH = 99
		const BOUNDARY_SPEEDS = [0, 24, 25, 99, 100, 999, 1000] as const
		const boundaryGeoid = (speed: number) => `boundary-${speed}`

		let boundaryOut: string

		beforeAll(async () => {
			boundaryOut = fixtures.use(await temporaryDirectory("bdc-filing-landscape-buckets-")).resolve("bdc.db")

			const rows: BDCAvailabilityRow[] = BOUNDARY_SPEEDS.map((speed) => ({
				geoid: boundaryGeoid(speed),
				provider_id: BOUNDARY_PROVIDER,
				technology_code: BOUNDARY_TECH,
				location_id: `boundary-loc-${speed}`,
				max_advertised_download_speed: speed,
				max_advertised_upload_speed: speed,
				low_latency: 1,
				business_residential_code: "R",
			}))

			await buildBDCDatabase({
				rows,
				out: boundaryOut,
				asOfDate: ASOF_DATE,
				buildSHA: "deadbeef",
				blockCentroids: () => CENTROID_SF,
			})
		})

		it("groups the 7 boundary speeds into exactly the 4 buckets the JS mirror predicts", async () => {
			using db = new DatabaseClient<BDCDatabase>(boundaryOut, { readOnly: true })

			const result = await filingLandscape(db, { geoids: BOUNDARY_SPEEDS.map(boundaryGeoid) })

			expect(result.surveyed_block_count).toBe(BOUNDARY_SPEEDS.length)
			expect(result.unknown_block_count).toBe(0)

			// Hand-grouped via the JS mirror itself: {0,24} -> under-25 (2), {25,99} -> 25-100 (2),
			// {100,999} -> 100-1000 (2), {1000} -> gigabit (1) — checking the SQL case's
			// exclusive `<` comparisons land exactly where speedBucketForDownloadSpeed
			// says they should, for every boundary value at once.
			const expectedGroups = new Map<string, number>()

			for (const speed of BOUNDARY_SPEEDS) {
				const bucket = speedBucketForDownloadSpeed(speed)
				expectedGroups.set(bucket, (expectedGroups.get(bucket) ?? 0) + 1)
			}

			expect(result.filings).toHaveLength(expectedGroups.size)

			for (const filing of result.filings) {
				expect(filing.provider_id).toBe(BOUNDARY_PROVIDER)
				expect(filing.technology_code).toBe(BOUNDARY_TECH)
				expect(filing.block_count).toBe(expectedGroups.get(filing.speed_bucket))
			}

			expect(new Set(result.filings.map((f) => f.speed_bucket))).toEqual(new Set(expectedGroups.keys()))
		})
	})
})
