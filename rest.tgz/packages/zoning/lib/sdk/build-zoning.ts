/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Build `zoning-ireland.db` — the sealed two-tier polygon layer, from the Department's bulk export.
 *
 *   the coverage is `source_present` and the tier is `build-local`, and the two are independent refusals.
 *   The coverage basis is about what the source can support: the Department publishes its coverage detail only
 *   inside a map viewer, so an absent zoning polygon is one of at least four different things and
 *   {@linkcode assertNoNegativeClaim} refuses anything stronger before a row is written. The tier is about
 *   what the licence supports: three published statements disagree about the grant, so
 *   {@linkcode assertTierMatchesLicense} refuses a `shipped` build. Resolving either one does not resolve the
 *   other.
 *
 *   the area check is the hole check and the one thing here that is exact. The service encodes hole
 *   roles by ring orientation, and reading them wrong is silent — a hole read as an exterior produces a
 *   well-formed polygon that answers "inside" for every location the plan carved out. Measured over the whole
 *   national export: the rings read with their holes total 5,444.5 km² and the Department's own `Shape__Area`
 *   sums to 5,444.5 km²; the same rings read without their holes total 5,666.6 km². The publisher's figure has
 *   to come from the live service, because the bulk export drops the column — which is what makes this a
 *   two-path check rather than the archive agreeing with itself.
 *
 *   there is no build-time touch table. A zoning cell row names one polygon, so it is final the moment that
 *   polygon is classified. The rows go straight in, and memory stays flat in row count with nothing to resolve
 *   afterwards.
 *
 *   the ingest is bounded anyway. h3's wasm heap cannot be reset from JavaScript and does not survive an
 *   unbounded number of polyfill calls. a sibling product died twice on that, after roughly 510,000 and
 *   798,000 features. This product holds 85,330, so the whole country fits inside the 100,000-id default with
 *   room to spare — and the bound still ships, because a build that stays inside a ceiling by luck is not the
 *   same fact as one that cannot cross it.
 *
 *   the jurisdiction, plan and vocabulary rows are written BY the parent, once, from the merged chunk
 *   reports. They are the only tables whose rows are partials across chunks — an authority and a plan appear
 *   in every chunk that touches them — and merging them in the parent is what keeps the chunk append-only.
 */

import { readFileSize } from "@mailwoman/core/fs/readers"
import { stringifyJSON } from "@mailwoman/core/json"
import {
	areaAgreementFrom,
	assertNoNegativeClaim as assertCoverageNoNegativeClaim,
	createLayerCoverageTable,
	createLayerManifestTable,
	LayerTier,
	polygonLayerManifest,
	sourcePresentCoverageCells,
	writeLayerCoverage,
	writeLayerManifest,
	type AreaAgreementReading,
	type CoverageCell,
} from "@mailwoman/core/layers"
import { resolveModulePath } from "@mailwoman/core/module/resolvers"
import { ingestChunkArguments, mergeCountsInto, runChunkProcess } from "@mailwoman/core/utils"
import { CoverageBasis } from "@mailwoman/evidence"
import { M2_PER_KM2 } from "@mailwoman/spatial"
import type { DatabaseClient } from "@mailwoman/sqlite/client"
import { buildSealedArtifact } from "@mailwoman/sqlite/sealed-build"

import { createZoningTables, type ZoningDatabase } from "#schema"
import type { CrosswalkPair, ObservedTerm, ZoningChunkResult } from "#sdk/ingest/chunk"
import { ingestZoningChunk } from "#sdk/ingest/chunk"
import type { ZoningFeatureSource } from "#sdk/ingest/index"
import {
	assertTierMatchesLicense,
	GZT_ATTRIBUTION,
	GZT_COVERAGE_LIMIT,
	GZT_CROSSWALK_SCHEME,
	GZT_DECLARED_CODES,
	GZT_DECLARED_CODE_SET,
	GZT_ITEM_ID,
	GZT_LAYER_NAME,
	GZT_LICENSE,
	GZT_PLAN_LEVELS,
} from "#vocabulary"

/**
 * Schema version of the domain tables.
 *
 * Bumped when a column changes meaning, never for an added column a reader can ignore.
 */
export const ZONING_SCHEMA_VERSION = 1

/**
 * The plan-level vocabulary scheme.
 */
export const PLAN_LEVEL_SCHEME = "IE-PLAN-LEVEL"

/**
 * Feature ids per chunk process.
 *
 * Sized against the measured ceiling on a sibling product rather than guessed: single-process runs
 * over that layer died after roughly 510,000 and 798,000 features as h3's wasm heap fragmented.
 * This product holds 85,330 features, so this default puts the whole country
 * in one process — and it is the ceiling that makes the build reproducible
 * rather than the fact that this product happens to sit below it.
 *
 * A smaller chunk costs A full pass each.
 * The source is one 247 MB GeoJSON document rather than an indexed store, so ogr2ogr
 * scans all of it per range: measured at 13.2 s per pass on this lab.
 */
export const DEFAULT_CHUNK_SIZE = 100_000

/**
 * Where a build gets its features, and — for a real one — how it bounds each process's share of them.
 */
export type BuildZoningInput =
	| {
			/**
			 * A feature source consumed IN this process.
			 *
			 * Correct for a fixture and for anything small.
			 * It is what the batched form falls back to per chunk, so the two share one implementation.
			 */
			source: ZoningFeatureSource
	  }
	| {
			/**
			 * The bulk export, ingested in bounded chunks — one child process per range
			 * of the authority's own feature ids.
			 */
			batched: {
				exportPath: string
				/**
				 * Feature ids per chunk.
				 *
				 * See {@link DEFAULT_CHUNK_SIZE}.
				 */
				chunkSize?: number
				/**
				 * The feature count the whole build should yield.
				 */
				declaredFeatureCount: number
			}
	  }

export type BuildZoningOptions = BuildZoningInput & {
	/**
	 * Where the sealed artifact lands.
	 *
	 * The build writes beside it and swaps.
	 */
	out: string
	/**
	 * The product vintage — `layer_manifest.version` and `source_vintage`.
	 */
	sourceVintage: string
	buildCmd: string
	buildSHA: string
	/**
	 * ISO-8601, supplied by the caller.
	 *
	 * Never generated here: the interface says so, and a library-generated timestamp
	 * makes two builds of the same inputs differ.
	 */
	createdAt: string
	/**
	 * The resolution the cell index is built at — chosen from the candidates-per-cell
	 * and zero-cell measurement.
	 */
	indexResolution: number
	/**
	 * The resolution `layer_coverage` rows are keyed at.
	 *
	 * Must be coarser than the index resolution.
	 */
	coverageResolution: number
	/**
	 * The publisher's own area figure for the whole product, in square metres.
	 * Its `Shape__Area` sum, read from the live service.
	 *
	 * Supplied, the build asserts the rings it encoded agree with it.
	 */
	expectedSourceAreaM2?: number
	/**
	 * The feature count the live service reports.
	 *
	 * Supplied, the build asserts its own streamed total against it.
	 */
	expectedFeatureCount?: number
	/**
	 * The tier to stamp.
	 *
	 * `build-local` unless the licence contradiction is resolved — see {@link assertTierMatchesLicense}.
	 */
	tier?: LayerTier
	onProgress?: (message: string) => void
}

export interface BuildZoningResult {
	out: string
	features: number
	jurisdictions: number
	plans: number
	indexResolution: number
	coverageResolution: number
	wholeCellRows: number
	partialCellRows: number
	/**
	 * `partialCellRows / (wholeCellRows + partialCellRows)` over the stored rows.
	 *
	 * The whole side is compacted per feature, so this is not the same number the
	 * resolution was chosen on and is reported separately.
	 */
	storedPartialShare: number
	/**
	 * Features whose bounding box forced a resolution coarser than `indexResolution`,
	 * and the resolutions the stored cell rows are actually at.
	 *
	 * Both are reported rather than smoothed over: a reader that assumed one resolution
	 * would probe at the wrong one and read every coarsened feature as an absence.
	 */
	coarsenedFeatures: number
	storedResolutions: number[]
	coverageCells: number
	/**
	 * The basis every coverage row carries.
	 *
	 * `source_present`, always, while `zoning_mapped_extent` is empty.
	 */
	coverageBasis: CoverageBasis
	tier: LayerTier
	license: string
	/**
	 * The ring-role census: how many rings, how many the orientation read as exteriors and holes,
	 * and how many holes were placed on their parent's boundary rather than inside it.
	 */
	rings: {
		total: number
		exteriors: number
		holes: number
		nestedHoles: number
		adjacentHoles: number
		/**
		 * Features whose exterior was chosen by magnitude because no ring read as one by orientation.
		 *
		 * Measured at one of 85,330.
		 * A three-vertex sliver enclosing 3.0 × 10⁻⁷ m², where a ring's winding is
		 * floating-point noise rather than something the publisher stated.
		 * Reported rather than implied to be zero.
		 */
		exteriorByMagnitude: number
	}
	/**
	 * The area totals in square kilometres — what the publisher says, what the
	 * encoded rings say read with their holes, and what they would say read without —
	 * with the witness stated, plus this product's own signed ring sum.
	 *
	 * The publisher's figure is never defaulted to this build's own reading:
	 * a receipt printing "publisher 205.4 km², 0.000% apart" when nobody asked the
	 * publisher is a check reporting itself as passed.
	 */
	area: AreaAgreementReading & { signedKM2: number }
	/**
	 * The vocabulary census, per scheme: how many codes the artifact holds
	 * and how many of them the publisher never declared.
	 */
	vocabulary: Array<{ scheme: string; codes: number; undeclared: number; undeclaredCodes: string[] }>
	/**
	 * (authority, local code) pairs, and how many of them take more than one generic type.
	 * The measurement that keeps `zoning_crosswalk_edge` empty.
	 */
	crosswalk: {
		pairs: number
		nonFunctionalPairs: number
		/**
		 * The worst offenders, most generic types first, for the receipt.
		 */
		worst: Array<{ authorityCode: string; localCode: string; crosswalkCodes: string[] }>
	}
	sizeBytes: number
}

/**
 * The relative gap between the two area readings that fails the build.
 *
 * The comparison is a spherical ring area against the publisher's planar figure in Irish Transverse
 * Mercator, so the two never agree exactly: ITM's scale factor runs 0.99982 at its central meridian
 * and above 1 towards the edges of the island, which contributes a few tenths of a percent to
 * an area, and the spherical approximation contributes a similar amount against the ellipsoid.
 * Measured on the largest feature in the country: 2,223.1 km² spherical against
 * the Department's 2,232.1 km², 0.40% apart.
 *
 * One percent leaves that comfortably inside the tolerance while sitting well below
 * the 4.1% a hole-blind read produces over the same set.
 */
const AREA_TOLERANCE = 0.01

/**
 * How many non-functional crosswalk pairs the receipt names.
 */
const WORST_PAIRS_REPORTED = 8

/**
 * Build the layer.
 *
 * @throws {Error} On a feature that reaches no cell, a feature count that disagrees with
 *   the source's own declaration, an area total that disagrees with the publisher's,
 *   a coverage row that would license a negative claim, a crosswalk edge table written while
 *   the mapping is not a function, or a `shipped` tier asked for under an unresolved licence.
 */
export async function buildZoningDatabase(options: BuildZoningOptions): Promise<BuildZoningResult> {
	const tier = options.tier ?? LayerTier.BuildLocal

	assertTierMatchesLicense(tier, GZT_LICENSE)

	if (options.coverageResolution >= options.indexResolution) {
		throw new Error(
			`zoning build: the coverage resolution (${options.coverageResolution}) must be coarser than the index resolution (${options.indexResolution}) — a row's coverage cell is the PARENT of its index cell`
		)
	}

	const batched = "batched" in options ? options.batched : undefined
	const source = "batched" in options ? undefined : options.source
	const declaredFeatureCount = batched ? batched.declaredFeatureCount : source!.declaredFeatureCount

	options.onProgress?.(
		batched
			? `source: ${batched.exportPath} · ${declaredFeatureCount.toLocaleString()} features`
			: `source: EPSG:${source!.epsg} · ${declaredFeatureCount.toLocaleString()} features · ${source!.origin}`
	)

	const built = await buildSealedArtifact<ZoningDatabase, StreamResult, Omit<BuildZoningResult, "sizeBytes">>({
		out: options.out,
		createTables: async (kdb) => {
			await createZoningTables(kdb)
			await createLayerManifestTable(kdb)
			await createLayerCoverageTable(kdb)
		},
		ingest: async (kdb) => {
			if (!source) return undefined

			return aggregateChunks([
				await ingestZoningChunk(kdb, {
					source,
					indexResolution: options.indexResolution,
					coverageResolution: options.coverageResolution,
					...(options.onProgress ? { onProgress: options.onProgress } : {}),
				}),
			])
		},
		...(batched ? { batched: (tmpPath: string) => runBatchedIngest(tmpPath, options, batched) } : {}),
		finish: async (kdb, ingested) => buildZoningResult(kdb, options, tier, declaredFeatureCount, ingested),
	})

	return { ...built, sizeBytes: await readFileSize(options.out) }
}

/**
 * The post-ingest half of the build, under the second handle: the assertions over what
 * was streamed, then every artifact table beyond the truth tables.
 */
async function buildZoningResult(
	kdb: DatabaseClient<ZoningDatabase>,
	options: BuildZoningOptions,
	tier: LayerTier,
	declaredFeatureCount: number,
	ingested: StreamResult
): Promise<Omit<BuildZoningResult, "sizeBytes">> {
	if (ingested.features !== declaredFeatureCount) {
		throw new Error(
			`zoning build: streamed ${ingested.features} features, the source declares ${declaredFeatureCount} — a short read builds a smaller country and reports success`
		)
	}

	if (options.expectedFeatureCount !== undefined && ingested.features !== options.expectedFeatureCount) {
		throw new Error(
			`zoning build: streamed ${ingested.features} features and the live service reports ${options.expectedFeatureCount} — the archive is a different vintage from the one the service is publishing`
		)
	}

	const area = assertAreaAgreement(ingested, options.expectedSourceAreaM2)

	// the crosswalk is not A table, and the build checks IT rather than assuming IT.
	// Writing no edges while the mapping happens not to be a function would be an accident.
	// Refusing to write them while it is not is a statement.
	const nonFunctional = nonFunctionalPairs(ingested.crosswalkPairs)

	assertCrosswalkIsNotATable(ingested.crosswalkPairs, 0)

	options.onProgress?.(
		`${ingested.features.toLocaleString()} zoning polygons written · ${ingested.rings.total.toLocaleString()} rings ` +
			`(${ingested.rings.exteriors.toLocaleString()} exterior, ${ingested.rings.holes.toLocaleString()} hole)`
	)

	writeJurisdictionRows(kdb, ingested.jurisdictions)
	writePlanRows(kdb, ingested.plans)

	const vocabulary = writeVocabularyRows(kdb, ingested.vocabulary)

	const coverage = sourcePresentCoverageCells(ingested.observedByCoverageCell)

	assertNoNegativeClaim(coverage)

	await writeLayerCoverage(kdb, coverage)

	await writeLayerManifest(
		kdb,
		polygonLayerManifest(options, {
			name: GZT_LAYER_NAME,
			schemaVersion: ZONING_SCHEMA_VERSION,
			license: GZT_LICENSE,
			attribution: GZT_ATTRIBUTION,
			source: `arcgis.com item ${GZT_ITEM_ID}`,
			cellColumn: "zoning_cell.h3_cell",
			tier,
		})
	)

	const storedResolutions = (
		kdb.prepare("SELECT DISTINCT resolution FROM zoning_cell ORDER BY resolution").all() as Array<{
			resolution: number
		}>
	).map((row) => row.resolution)

	// no secondary indexes, and that is A decision rather than an omission.
	// Both probes this artifact serves are already primary-key probes: the cell table's
	// `(h3_cell, area_id)` key answers `where h3_cell = ?` as a range scan of a handful
	// of rows, and the geometry table is probed by `area_id`, its own key.
	// An index over a `without rowid` table carries the primary key in every entry,
	// so it would roughly double the cell tier to serve a scan that is already short.
	const totalCellRows = ingested.wholeCellRows + ingested.partialCellRows

	return {
		out: options.out,
		features: ingested.features,
		jurisdictions: ingested.jurisdictions.length,
		plans: ingested.plans.length,
		indexResolution: options.indexResolution,
		coverageResolution: options.coverageResolution,
		wholeCellRows: ingested.wholeCellRows,
		partialCellRows: ingested.partialCellRows,
		storedPartialShare: totalCellRows ? ingested.partialCellRows / totalCellRows : 0,
		coarsenedFeatures: ingested.coarsened,
		storedResolutions,
		coverageCells: coverage.length,
		coverageBasis: CoverageBasis.SourcePresent,
		tier,
		license: GZT_LICENSE,
		rings: ingested.rings,
		area,
		vocabulary,
		crosswalk: {
			pairs: ingested.crosswalkPairs.length,
			nonFunctionalPairs: nonFunctional.length,
			worst: nonFunctional
				.toSorted((left, right) => right[2].length - left[2].length)
				.slice(0, WORST_PAIRS_REPORTED)
				.map(([authorityCode, localCode, crosswalkCodes]) => ({ authorityCode, localCode, crosswalkCodes })),
		},
	}
}

/**
 * What the whole ingest produced, however many processes it took.
 */
interface StreamResult {
	features: number
	coarsened: number
	wholeCellRows: number
	partialCellRows: number
	observedByCoverageCell: Map<number, number>
	area: { signedM2: number; nestedM2: number; allExteriorM2: number }
	rings: {
		total: number
		exteriors: number
		holes: number
		nestedHoles: number
		adjacentHoles: number
		/**
		 * Features whose exterior was chosen by magnitude because no ring read as one by orientation.
		 *
		 * Measured at one of 85,330.
		 * A three-vertex sliver enclosing 3.0 × 10⁻⁷ m², where a ring's winding is
		 * floating-point noise rather than something the publisher stated.
		 * Reported rather than implied to be zero.
		 */
		exteriorByMagnitude: number
	}
	jurisdictions: Array<[string, string]>
	plans: ZoningChunkResult["plans"]
	vocabulary: ObservedTerm[]
	crosswalkPairs: CrosswalkPair[]
}

/**
 * Add up what the chunks reported.
 *
 * Exported for its own test: the coverage-cell arithmetic and the crosswalk-pair
 * merge are the parts of the batched path a fixture build cannot reach,
 * and getting either wrong produces a well-formed artifact.
 * One that under-reports how many polygons a cell holds, or one that reports a
 * mapping as a function because no single chunk saw it break.
 */
export function aggregateChunks(chunks: ReadonlyArray<ZoningChunkResult>): StreamResult {
	const observedByCoverageCell = new Map<number, number>()
	const jurisdictions = new Map<string, string>()
	const plans = new Map<string, ZoningChunkResult["plans"][number]>()
	const vocabulary = new Map<string, ObservedTerm>()
	const crosswalkPairs = new Map<string, Set<string>>()
	const pairNames = new Map<string, [string, string]>()

	let features = 0
	let coarsened = 0
	let wholeCellRows = 0
	let partialCellRows = 0
	let signedArea = 0
	let nestedArea = 0
	let allExteriorArea = 0
	let ringsTotal = 0
	let exteriors = 0
	let holes = 0
	let nestedHoles = 0
	let adjacentHoles = 0
	let exteriorByMagnitude = 0

	for (const chunk of chunks) {
		features += chunk.features
		coarsened += chunk.coarsened
		wholeCellRows += chunk.wholeCellRows
		partialCellRows += chunk.partialCellRows
		signedArea += chunk.area.signedM2
		nestedArea += chunk.area.nestedM2
		allExteriorArea += chunk.area.allExteriorM2
		ringsTotal += chunk.rings.total
		exteriors += chunk.rings.exteriors
		holes += chunk.rings.holes
		nestedHoles += chunk.rings.nestedHoles
		adjacentHoles += chunk.rings.adjacentHoles
		exteriorByMagnitude += chunk.rings.exteriorByMagnitude

		// A coverage cell straddles chunk boundaries, so the counts ADD rather than replace.
		// Taking the last chunk's value would report a cell as holding only the last chunk's polygons.
		mergeCountsInto(observedByCoverageCell, chunk.observedByCoverageCell)

		for (const [code, name] of chunk.jurisdictions) {
			jurisdictions.set(code, name)
		}

		for (const plan of chunk.plans) {
			if (!plans.has(plan.planID)) {
				plans.set(plan.planID, plan)
			}
		}

		for (const [scheme, code, label, rows] of chunk.vocabulary) {
			const key = `${scheme}\u0000${code}`
			const existing = vocabulary.get(key)

			vocabulary.set(key, existing ? [scheme, code, existing[2], existing[3] + rows] : [scheme, code, label, rows])
		}

		// the pairs merge AS A union, and that is the whole point of doing it here.
		// A mapping that is not a function can look like one inside any single chunk:
		// Cork's `Special Policy Area` takes 14 generic types across the county, and a chunk
		// holding a prefix of its feature ids may well have seen only one of them.
		for (const [authorityCode, localCode, codes] of chunk.crosswalkPairs) {
			const key = `${authorityCode}\u0000${localCode}`
			const existing = crosswalkPairs.get(key)

			pairNames.set(key, [authorityCode, localCode])

			if (existing) {
				for (const code of codes) {
					existing.add(code)
				}
			} else {
				crosswalkPairs.set(key, new Set(codes))
			}
		}
	}

	return {
		features,
		coarsened,
		wholeCellRows,
		partialCellRows,
		observedByCoverageCell,
		area: { signedM2: signedArea, nestedM2: nestedArea, allExteriorM2: allExteriorArea },
		rings: { total: ringsTotal, exteriors, holes, nestedHoles, adjacentHoles, exteriorByMagnitude },
		jurisdictions: [...jurisdictions],
		plans: [...plans.values()],
		vocabulary: [...vocabulary.values()],
		crosswalkPairs: [...crosswalkPairs].map(([key, codes]) => {
			const [authorityCode, localCode] = pairNames.get(key)!

			return [authorityCode, localCode, [...codes].toSorted()] satisfies CrosswalkPair
		}),
	}
}

/**
 * The (authority, local code) pairs that take more than one generic type.
 */
export function nonFunctionalPairs(pairs: ReadonlyArray<CrosswalkPair>): CrosswalkPair[] {
	return pairs.filter((pair) => pair[2].length > 1)
}

/**
 * Refuse a crosswalk edge table while the publisher's mapping is not a function
 * of the (authority, code) pair.
 *
 * An edge table asserts that a code determines a type.
 * Measured nationally, 52 of 795 pairs take more than one — Cork County Council's
 * `Special Policy Area` takes 14 — so an edge table built from this data would have to pick one
 * type per pair and would be this package's invention rather than the Department's mapping.
 *
 * The mapping lives per polygon, on `zoning_area`, where the Department put it.
 *
 * @throws {Error} When edges would be written while any pair is non-functional.
 */
export function assertCrosswalkIsNotATable(pairs: ReadonlyArray<CrosswalkPair>, edgeCount: number): void {
	if (!edgeCount) return

	const broken = nonFunctionalPairs(pairs)

	if (!broken.length) return

	const worst = broken.toSorted((left, right) => right[2].length - left[2].length)[0]!

	throw new Error(
		`zoning build: ${edgeCount} crosswalk edge(s) would be written while ${broken.length} of ${pairs.length} ` +
			`(authority, local code) pairs take more than one generic type — ${worst[0]} ${stringifyJSON(worst[1])} takes ` +
			`${worst[2].length} (${worst[2].join(", ")}). An edge table asserts that a code determines a type, and this ` +
			"publisher assigns the type per polygon, so the table would be this build's invention rather than the authority's mapping"
	)
}

/**
 * Refuse an artifact whose rings do not add up to the area the publisher itself reports.
 *
 * The message carries the hole-blind total beside the nested one, because the gap between them
 * is the diagnosis: a hole read as an exterior ring answers "inside" for every point in it.
 */
function assertAreaAgreement(
	streamed: StreamResult,
	expectedSourceAreaM2: number | undefined
): BuildZoningResult["area"] {
	const signedKM2 = streamed.area.signedM2 / M2_PER_KM2

	// the publisher'S figure is absent rather than defaulted — the reading's own type says so.
	// Filling it with this build's own reading would make the receipt print "0.000% apart"
	// for a check that never ran, which is the one shape a reader cannot tell from a pass.
	const reading = areaAgreementFrom(
		{ nestedM2: streamed.area.nestedM2, allExteriorM2: streamed.area.allExteriorM2 },
		expectedSourceAreaM2
	)

	const area: BuildZoningResult["area"] = { ...reading, signedKM2 }

	if (reading.witness === "absent" || reading.relativeGap <= AREA_TOLERANCE) return area

	throw new Error(
		`zoning build: the encoded rings total ${reading.nestedKM2.toFixed(1)} km² against the publisher's ${reading.sourceKM2.toFixed(1)} km² ` +
			`(${(reading.relativeGap * 100).toFixed(2)}% apart, tolerance ${(AREA_TOLERANCE * 100).toFixed(0)}%). Read without their holes the same rings total ` +
			`${reading.allExteriorKM2.toFixed(1)} km², so compare the two: a hole-blind read answers "inside" for every point in a hole`
	)
}

/**
 * Run the ingest as a sequence of bounded child processes, over ranges of the authority's own feature ids.
 *
 * The parent holds no handle while the chunks run — its caller closed one
 * before this and opens another after.
 * Each child opens the same file and appends.
 *
 * Chunks run one at a time, so there is exactly one writer at every instant and no locking to reason about.
 *
 * @throws {Error} When a chunk exits non-zero, or prints no result line —
 *   a chunk that died mid-range has written a partial set of rows, and continuing
 *   would seal an artifact missing features nobody could name.
 */
async function runBatchedIngest(
	tmpPath: string,
	options: BuildZoningOptions,
	batched: Extract<BuildZoningInput, { batched: unknown }>["batched"]
): Promise<StreamResult> {
	const chunkSize = batched.chunkSize ?? DEFAULT_CHUNK_SIZE
	const script = resolveModulePath("@mailwoman/zoning/scripts/ingest-chunk")
	const chunks: ZoningChunkResult[] = []

	// The upper bound is deliberately open.
	// The source reports a count rather than a maximum id, and a range that stopped at
	// the count would drop every feature past a gap in the numbering.
	let from = 1

	for (;;) {
		const to = from + chunkSize - 1

		options.onProgress?.(`chunk OBJECTID ${from}–${to}`)

		const result = await runChunkProcess<ZoningChunkResult>({
			script,
			context: "zoning build",
			args: ingestChunkArguments({
				database: tmpPath,
				args: ["--export", batched.exportPath, "--object-id-from", String(from), "--object-id-to", String(to)],
				indexResolution: options.indexResolution,
				coverageResolution: options.coverageResolution,
			}),
		})

		chunks.push(result)

		if (!result.features) break

		from = to + 1
	}

	return aggregateChunks(chunks)
}

/**
 * Refuse a coverage row that would license a negative claim.
 *
 * This is the check the meaning-OF-zero rule turns on, and it is a condition rather than a convention.
 * The Department publishes its coverage detail only inside a map viewer,
 * so no row of this layer may support an exclusion.
 *
 * A `designated` or `surveyed` basis here would let an absent zoning polygon be read
 * as a statement that no restriction applies, over most of the map.
 *
 * The reader checks the same thing at open time, so an artifact built by some
 * other path cannot get past it either.
 */
export function assertNoNegativeClaim(cells: ReadonlyArray<CoverageCell>): void {
	assertCoverageNoNegativeClaim("zoning build", cells, GZT_COVERAGE_LIMIT)
}

/**
 * Insert the authorities.
 */
function writeJurisdictionRows(
	database: DatabaseClient<ZoningDatabase>,
	jurisdictions: ReadonlyArray<[string, string]>
): void {
	const insert = database.prepare(
		"INSERT INTO zoning_jurisdiction (jurisdiction_id, name, source_code, country) VALUES (?, ?, ?, ?)"
	)

	for (const [code, name] of jurisdictions.toSorted((left, right) => (left[0] < right[0] ? -1 : 1))) {
		// The id is the publisher's own code.
		// `Fl` for Fingal against `CL`, `CO`, `DU` for the rest — carried in both columns
		// rather than repaired in one, because a repaired code is this package's spelling
		// in a column that claims to be the publisher's.
		insert.run(code, name, code, "IE")
	}
}

/**
 * Insert the plans.
 */
function writePlanRows(database: DatabaseClient<ZoningDatabase>, plans: ZoningChunkResult["plans"]): void {
	const insert = database.prepare(
		"INSERT INTO zoning_plan (plan_id, jurisdiction_id, plan_name, plan_level, valid_from, valid_to, current_plan) " +
			"VALUES (?, ?, ?, ?, ?, ?, ?)"
	)

	for (const plan of plans.toSorted((left, right) => (left.planID < right.planID ? -1 : 1))) {
		insert.run(plan.planID, plan.authorityCode, plan.name, plan.level, plan.from, plan.to, plan.currentPlan)
	}
}

/**
 * Insert the vocabulary: every code the publisher declares, plus every code the data uses,
 * with the difference recorded rather than folded away.
 *
 * A declared code the data never uses is kept at `observed_rows = 0`, because the domain
 * is the publisher's statement of what a value may be rather than a census of what it is.
 * Ireland's `SDZ` plan level is exactly that.
 *
 * A used code the publisher never declared is kept at `declared = 0`, because inventing a declaration
 * would make a source-schema change indistinguishable from the publisher's own vocabulary.
 */
function writeVocabularyRows(
	database: DatabaseClient<ZoningDatabase>,
	observed: ReadonlyArray<ObservedTerm>
): BuildZoningResult["vocabulary"] {
	const insert = database.prepare(
		"INSERT INTO zoning_vocabulary (scheme, code, label, definition, definition_url, declared, observed_rows) " +
			"VALUES (?, ?, ?, ?, ?, ?, ?)"
	)

	const rows = new Map<
		string,
		{ scheme: string; code: string; label: string; declared: number; observedRows: number }
	>()

	const declare = (scheme: string, code: string, label: string): void => {
		rows.set(`${scheme}\u0000${code}`, { scheme, code, label, declared: 1, observedRows: 0 })
	}

	for (const term of GZT_DECLARED_CODES) {
		declare(GZT_CROSSWALK_SCHEME, term.code, term.label)
	}

	for (const term of GZT_PLAN_LEVELS) {
		declare(PLAN_LEVEL_SCHEME, term.code, term.label)
	}

	for (const [scheme, code, label, observedRows] of observed) {
		const key = `${scheme}\u0000${code}`
		const existing = rows.get(key)

		if (existing) {
			existing.observedRows += observedRows

			continue
		}

		rows.set(key, {
			scheme,
			code,
			label,
			// declared is A property OF the publisher'S domain rather than OF the scheme.
			// A local authority's own codes are observed rather than declared —
			// the Department publishes no domain for them — and an undeclared generic
			// type is the event this column exists to make visible.
			declared: scheme === GZT_CROSSWALK_SCHEME && GZT_DECLARED_CODE_SET.has(code) ? 1 : 0,
			observedRows,
		})
	}

	const bySchema = new Map<string, { codes: number; undeclared: number; undeclaredCodes: string[] }>()

	for (const row of [...rows.values()].toSorted((left, right) =>
		left.scheme === right.scheme ? (left.code < right.code ? -1 : 1) : left.scheme < right.scheme ? -1 : 1
	)) {
		// NULL rather than a plausible URL.
		// Every one of the 85,330 rows links its generic type's definition to `viewer.myplan.ie`,
		// which has no DNS record, and three candidate replacements on the live host answer http 404.
		// So the definitions behind the code-to-label pairs were not retrievable
		// and this column says so by being empty.
		insert.run(row.scheme, row.code, row.label, null, null, row.declared, row.observedRows)

		const census = bySchema.get(row.scheme) ?? { codes: 0, undeclared: 0, undeclaredCodes: [] }

		census.codes++

		// A local scheme is undeclared BY construction and reporting it as such would bury the one that matters.
		// The census counts an undeclared code only where the publisher does publish a domain to be outside of.
		if (!row.declared && row.scheme === GZT_CROSSWALK_SCHEME) {
			census.undeclared++
			census.undeclaredCodes.push(row.code)
		}

		bySchema.set(row.scheme, census)
	}

	return [...bySchema].map(([scheme, census]) => ({ scheme, ...census }))
}
