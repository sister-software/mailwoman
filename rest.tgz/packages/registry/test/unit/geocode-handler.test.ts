/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 */

import { makeGeocodeHandler } from "@mailwoman/registry/geocode-handler"
import type { GeocodeAddress } from "@mailwoman/registry/ingest"
import type { SourceRecord } from "@mailwoman/registry/types"
import { describe, expect, it } from "vitest"

const rec = (raw: Record<string, string>): SourceRecord => ({ id: "x", raw }) as SourceRecord

describe("makeGeocodeHandler", () => {
	it("recomputes the address from raw+mapping and attaches the geocode", async () => {
		const geocodeForIngest: GeocodeAddress = async (raw) => ({
			components: {},
			canonicalKey: "",
			formatted: raw.toUpperCase(),
		})

		const handle = makeGeocodeHandler(geocodeForIngest, { address: ["addr", "city", "state"] })

		const out = await handle(rec({ addr: "1 Main St", city: "Austin", state: "TX" }))

		expect(out.address?.formatted).toBe("1 MAIN ST, AUSTIN, TX")
	})

	it("leaves a record with no mapped address untouched (no geocode call)", async () => {
		let calls = 0

		const geocodeForIngest: GeocodeAddress = async () => {
			calls++

			return null
		}

		const handle = makeGeocodeHandler(geocodeForIngest, { address: ["addr"] })

		const out = await handle(rec({ addr: "" }))

		expect(out.address).toBeUndefined()
		expect(calls).toBe(0)
	})

	it("maps a null geocode result to undefined", async () => {
		const geocodeForIngest: GeocodeAddress = async () => null
		const handle = makeGeocodeHandler(geocodeForIngest, { address: ["addr"] })

		expect((await handle(rec({ addr: "nowhere" }))).address).toBeUndefined()
	})
})
