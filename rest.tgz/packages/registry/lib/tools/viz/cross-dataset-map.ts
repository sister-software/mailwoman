/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Render linked entities from a GeoJSON file in MapLibre, colored by source combination.
 *   `crossAgencyOnly` removes links whose sources belong to one agency.
 */

import { dataRootPath, tempRootPath } from "@mailwoman/core/data-root"
import { readLocalJSONFile } from "@mailwoman/core/fs/readers"
import { writeLocalFile } from "@mailwoman/core/fs/writers"
import type { GeoFeature, GeoFeatureCollection, PointLiteral } from "@mailwoman/spatial"

import { type MapFeatureData, toMapHTML } from "#index"

/**
 * Distinct agencies a combination needs before it is plotted as a cross-agency cluster.
 */
const MIN_DISTINCT_AGENCIES = 3

/**
 * Options for {@linkcode crossDatasetMap}.
 */
export interface CrossDatasetMapOptions {
	/**
	 * The `cross-dataset-links` GeoJSON.
	 *
	 * Default `$MAILWOMAN_DATA_ROOT/record-matcher/2026-06-16-cross-dataset-links.geojson`.
	 */
	in?: string
	/**
	 * Output html path.
	 *
	 * Default `/tmp/cross-dataset-map.html`.
	 */
	outHTML?: string
	/**
	 * Keep only entities whose sources span >1 agency (the two FCC datasets count as one).
	 */
	crossAgencyOnly?: boolean
}

const SOURCE_LABELS: Record<string, string> = {
	nppes: "NPPES",
	"fcc-rhc": "FCC RHC",
	"fcc-rhc-commitments": "FCC commitments",
	"txhhsc-nursing": "TX HHSC",
}

const label = (s: string) => SOURCE_LABELS[s] ?? s

/**
 * Which agency each source belongs to.
 *
 * The two FCC datasets (RHC posted-services + commitments) are one agency.
 * So an NPPES↔FCC or FCC↔TX link is cross-agency, but an RHC↔commitments link is not.
 *
 * `--cross-agency-only` keeps just the entities whose sources span >1 agency: the harder,
 * more striking "no shared key across agencies" subset (most of the raw links are FCC-internal).
 */
const SOURCE_AGENCY: Record<string, string> = {
	nppes: "CMS",
	"fcc-rhc": "FCC",
	"fcc-rhc-commitments": "FCC",
	"txhhsc-nursing": "TX HHSC",
}

const agencyOf = (s: string) => SOURCE_AGENCY[s] ?? s

const sourcesOf = (f: GeoFeature<PointLiteral, MapFeatureData>): string[] =>
	Array.isArray(f.properties?.sources) ? f.properties.sources : []

/**
 * Render the cross-dataset-links GeoJSON to a bucket-colored MapLibre html page.
 */
export async function crossDatasetMap(
	options: CrossDatasetMapOptions = {},
	report?: (line: string) => void
): Promise<{ outHTML: string; kept: number; total: number; triple: number }> {
	const IN = options.in || dataRootPath("record-matcher", "2026-06-16-cross-dataset-links.geojson")
	const OUT = options.outHTML || tempRootPath("cross-dataset-map.html")
	const CROSS_AGENCY_ONLY = options.crossAgencyOnly ?? false

	const parsed = await readLocalJSONFile<GeoFeatureCollection<PointLiteral, MapFeatureData>>(IN)

	const total = parsed.features.length

	const geojson = CROSS_AGENCY_ONLY
		? { ...parsed, features: parsed.features.filter((f) => new Set(sourcesOf(f).map(agencyOf)).size > 1) }
		: parsed

	// Synthesize a `bucket` per entity = its sorted source-combination, so toMapHTML colors by the link
	// type (two-source vs the rarer all-three-source spans) rather than the binary cross/single status.
	let triple = 0
	const comboCounts = new Map<string, number>()

	for (const f of geojson.features) {
		const combo = [...new Set(sourcesOf(f))].toSorted()
		const bucket = combo.map(label).join(" + ") || "unlinked"

		if (f.properties) {
			f.properties.bucket = bucket
		}

		if (new Set(combo.map(agencyOf)).size >= MIN_DISTINCT_AGENCIES) {
			triple++
		}

		comboCounts.set(bucket, (comboCounts.get(bucket) ?? 0) + 1)
	}

	const kept = geojson.features.length
	const scope = CROSS_AGENCY_ONLY ? "across agencies" : "across sources"

	const html = toMapHTML(geojson, {
		title: `Cross-dataset entity links — ${kept} resolved ${scope} (no shared key)`,
		flavor: "light",
		colorBy: "bucket",
	})

	await writeLocalFile(html, OUT)
	report?.(`[written] ${OUT}  (${kept}${CROSS_AGENCY_ONLY ? ` of ${total} cross-AGENCY` : ""} entities)`)
	report?.(`  source combinations:`)

	for (const [combo, n] of [...comboCounts.entries()].toSorted((a, b) => b[1] - a[1])) {
		report?.(`    ${n.toString().padStart(4)}  ${combo}`)
	}

	report?.(`  spanning all three agencies: ${triple}`)

	return { outHTML: OUT, kept, total, triple }
}
