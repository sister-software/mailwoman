/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   #625 ceiling measurement — "how good is good enough" for dedup, derived from the data instead of
 *   asserted as a round number (DeepSeek consult, issue #625). The residual dedup error is
 *   over-merge: distinct co-located providers (different NPIs at one clinic/billing address) fused
 *   because a shared address outvotes a disagreeing name. The irreducible part of that — the
 *   **Bayes error** — is the set of co-located distinct-NPI pairs whose names are also ~identical:
 *   no name/org feature can separate them, so any address-aware matcher over-merges them. That
 *   floor caps precision.
 *
 *   This measures it directly and label-free, using NPI as the distinctness truth (different NPI =
 *   different provider). Geocode-free on purpose: the question is the data's separability rather than the
 *   geocoder — so we can run at large N (tens of thousands of TX providers) in seconds. We key
 *   "same address" with the matcher's own `addressFrequencyKey`, and "same name" with a normalized
 *   token Jaccard over the legal business name.
 *
 *   Reports, over co-located distinct-NPI pairs (the over-merge population):
 *
 *   - Co-location prevalence (addresses hosting ≥2 distinct NPIs. providers at shared addresses)
 *   - The org-name-similarity distribution of those pairs
 *   - The collision rate: fraction with org-sim ≥ τ (irreducible over-merge) — the precision floor
 *   - Whether a shared phone would help (it doesn't: institutional switchboards) — among collisions,
 *       how often the two distinct NPIs also share a phone (so phone over-links, can't separate)
 *       …and derives a precision/F1 ceiling under stated assumptions, with the caveats called out.
 *
 *   Run: `mailwoman registry dedup-ceiling [--cap 50000] [--state TX] [--sources <dir>] [--tau 0.7]
 *   [--out-md <md>]`
 */

import { dataRootPath } from "@mailwoman/core/data-root"
import { writeLocalFile } from "@mailwoman/core/fs/writers"
import { formatPercent } from "@mailwoman/core/stats"
import { jaccard } from "@mailwoman/match"

import { colocatedDistinctPairs, scanColocatedProviders, stateOption, type ColocatedProvider } from "#tools/shared"

/**
 * Similarity at or above which a pair is a near-miss worth inspecting rather than unrelated.
 */
const WEAK_SIMILARITY_MIN = 0.3

/**
 * Options for {@linkcode dedupCeiling}.
 */
export interface DedupCeilingOptions {
	/**
	 * Record-matcher sources directory.
	 *
	 * Default `$MAILWOMAN_DATA_ROOT/record-matcher/sources`.
	 */
	sources?: string
	/**
	 * Providers sampled from the registry.
	 *
	 * Default 50000.
	 */
	cap?: number
	/**
	 * State filter.
	 *
	 * Default TX.
	 */
	state?: string
	/**
	 * Org-name Jaccard collision threshold.
	 *
	 * Default 0.7.
	 */
	tau?: number
	/**
	 * Also write the markdown report here.
	 */
	outMd?: string
}

/**
 * #625 ceiling measurement — see the module doc. Emits the markdown report to stdout.
 */
export async function dedupCeiling(
	options: DedupCeilingOptions = {},
	report?: (line: string) => void
): Promise<{ markdown: string; pairs: number; collide: number }> {
	const SOURCES = options.sources || dataRootPath("record-matcher", "sources")
	const CAP = options.cap ?? 50_000
	const STATE = stateOption(options)
	const TAU = options.tau ?? 0.7
	const OUT_MD = options.outMd || ""
	const REGISTRY = `${SOURCES}/nppes_npi-registry_20260607.tsv`

	// Stream Texas organization providers, retaining one primary practice-address record per NPI.
	report?.(`[A] streaming ${STATE} org providers (cap ${CAP})…`)
	const { byAddr, kept, scanned } = await scanColocatedProviders({ registryPath: REGISTRY, state: STATE, cap: CAP })
	report?.(`    scanned ${scanned} rows → ${kept} ${STATE} org providers at ${byAddr.size} distinct addresses`)

	// Measure organization similarity and collision rate for co-located distinct-NPI pairs.
	let sharedAddresses = 0
	let providersAtSharedAddr = 0
	let pairs = 0
	let collide = 0 // org-sim ≥ τ — name-indistinguishable co-located distinct NPIs
	let mid = 0 // τ > sim ≥ 0.3 — partially separable
	let separable = 0 // sim < 0.3 — clearly different names
	let collideSharePhone = 0 // of collisions, also share a phone (phone can't separate either)
	// Of the collisions, split NPI-over-segmentation (one org, many NPIs — merge is correct)
	// from genuinely-distinct co-located providers (the true irreducible over-merge):
	let collideSameAuth = 0 // share an authorized official ⇒ one org, multiple NPIs ⇒ correct to merge
	let collideDistinct = 0 // different official and different specialty ⇒ genuinely different providers
	const PAIR_BUDGET = 5_000_000

	// guard against a pathological mega-address (PO-box farms)

	let lastGroup: readonly ColocatedProvider[] | null = null

	for (const { a, b, group } of colocatedDistinctPairs(byAddr)) {
		if (group !== lastGroup) {
			lastGroup = group

			sharedAddresses++
			providersAtSharedAddr += group.length
		}

		if (pairs >= PAIR_BUDGET) continue

		pairs++
		const sim = jaccard(a.tokens, b.tokens)

		if (sim >= TAU) {
			collide++

			if (a.phone && a.phone === b.phone) {
				collideSharePhone++
			}

			const sameAuth = a.auth !== "" && a.auth === b.auth
			const sameTax = a.taxonomy !== "" && a.taxonomy === b.taxonomy

			if (sameAuth) {
				collideSameAuth++
			} else if (!sameTax) {
				collideDistinct++
			}
		} else if (sim >= WEAK_SIMILARITY_MIN) {
			mid++
		} else {
			separable++
		}
	}

	// Derive the precision ceiling from co-located distinct-NPI records.
	// Pairs, either merge (wrong) or hold them apart using name/org.
	// It can separate the `separable` (and most `mid`) pairs but not the `collide` ones.
	// So the irreducible false-merge rate among co-located distinct pairs is collide/pairs.
	// An oracle's precision on the co-located decision is bounded by how many
	// merges it makes that are correct.
	// We report the collision rate directly and a precision-ceiling band
	// (optimistic: only `collide` over-merge. Conservative: `collide` + half of `mid`).
	// Recall is not the binding constraint here (NPPES same-NPI records almost always share
	// either address or org), so the F1 ceiling tracks the precision ceiling. ---
	const pct = formatPercent

	const lines: string[] = [
		`# #625 — dedup ceiling: the irreducible over-merge of co-located providers`,
		"",
		`_Generated by \`registry/tools/dedup-ceiling.ts\`. ${STATE}, ${kept} type-2 (org) providers ` +
			`(cap ${CAP}), geocode-free: "same address" = the matcher's \`addressFrequencyKey\`; "same name" = ` +
			`normalized token Jaccard over the legal business name (corporate suffixes + articles stripped, domain ` +
			`words kept). NPI is the distinctness truth (different NPI = different provider). τ = ${TAU}._`,
		"",
		`## Co-location prevalence`,
		"",
		`- **${sharedAddresses}** addresses host ≥2 distinct NPIs (${pct(sharedAddresses, byAddr.size)} of ${byAddr.size} addresses).`,
		`- **${providersAtSharedAddr}** providers sit at a shared address (${pct(providersAtSharedAddr, kept)} of ${kept}).`,
		`- **${pairs}** co-located distinct-NPI pairs (the over-merge population)${pairs >= PAIR_BUDGET ? ` — capped at the ${PAIR_BUDGET} pair budget` : ""}.`,
		"",
		`## Name separability of co-located distinct providers`,
		"",
		`| org-name Jaccard | pairs | share | meaning |`,
		`|---|---:|---:|---|`,
		`| ≥ ${TAU} (collision) | ${collide} | ${pct(collide, pairs)} | ~identical names → **irreducible over-merge** |`,
		`| ${0.3}–${TAU} | ${mid} | ${pct(mid, pairs)} | partial — separable with a good model |`,
		`| < 0.3 | ${separable} | ${pct(separable, pairs)} | clearly different names → separable |`,
		"",
		`Of the ${collide} collision pairs, **${collideSharePhone}** (${pct(collideSharePhone, collide)}) also share a phone — ` +
			`so phone (a shared institutional switchboard) does NOT separate them either; if anything it over-links. This is ` +
			`why the benchmark found phone an unreliable secondary identifier.`,
		"",
		`## Splitting the collisions: NPI over-segmentation vs genuinely distinct providers`,
		"",
		`A collision (same address, ~same name, often same phone) with DIFFERENT NPIs is usually one organization holding ` +
			`multiple NPIs (subparts / departments) — where merging is **correct** and NPI-as-truth is **over-segmenting**, ` +
			`not a model error. NPPES's own fields separate the two cases:`,
		"",
		`| collision pair is… | pairs | share of collisions | merging it is… |`,
		`|---|---:|---:|---|`,
		`| same authorized official | ${collideSameAuth} | ${pct(collideSameAuth, collide)} | **correct** — one org, many NPIs (NPI over-segments) |`,
		`| different official AND different specialty | ${collideDistinct} | ${pct(collideDistinct, collide)} | a **genuine** distinct co-located provider — true over-merge |`,
		`| (remainder: different official, same specialty) | ${collide - collideSameAuth - collideDistinct} | ${pct(collide - collideSameAuth - collideDistinct, collide)} | ambiguous — needs adjudication |`,
		"",
		`## The ceiling`,
		"",
		`The raw collision rate is **${pct(collide, pairs)}** of co-located distinct-NPI pairs — but only **${pct(collideDistinct, pairs)}** ` +
			`of co-located pairs are *genuinely* distinct providers indistinguishable by name (different official + specialty). ` +
			`Most collisions are **NPI over-segmentation** (${pct(collideSameAuth, collide)} share an authorized official), where ` +
			`a merge is correct and NPI-truth penalizes it wrongly.`,
		"",
		`**This is the answer to "how good is good enough," and it has two parts:**`,
		`1. Measured against **NPI-as-truth**, F1 is capped well below 0.85 — ~${pct(collide, pairs)} of co-located pairs are ` +
			`unseparable, and NPI-truth scores most of them as errors even though merging is correct. The round **0.85 target ` +
			`is unreachable under this yardstick and should be dropped.**`,
		`2. The *real* irreducible over-merge — genuinely distinct co-located providers with identical names — is only ` +
			`~**${pct(collideDistinct, pairs)}** of the co-located population. Against an **entity-level truth** (subpart-aware), ` +
			`the achievable ceiling is much higher. But that ceiling can only be MEASURED with an entity-level / adjudicated ` +
			`gold set — NPI-truth alone can't tell a correct subpart-merge from a true over-merge. **This is why the gold set ` +
			`(the "second comparison") is necessary, not optional.**`,
		"",
		`Recommendation: drop 0.85. Set the bar against a subpart-aware / adjudicated entity truth, report NPI-level AND ` +
			`entity-level side by side, and target "separate the ~${pct(collideDistinct, pairs)} genuinely-distinct co-located ` +
			`pairs the GBT can still reach" rather than a round F1. The GBT's corroboration-feature work (#625 revised) ` +
			`attacks exactly that separable subset.`,
		"",
		`## Caveats`,
		"",
		`- **Geocode-free + exact address key.** "Co-located" here is an exact normalized-address match; geocoding would ` +
			`add near-but-not-exact neighbors (suite splits, slightly different formatting), which can only RAISE the ` +
			`collision count. So this is a LOWER bound on the irreducible over-merge.`,
		`- **Recall side under-measured.** NPPES same-NPI records almost always share an address or the org name, so the ` +
			`recall floor looks ~1.0 here; real-world feeds with distant + name-drifted same-entity records would lower it. ` +
			`The F1 ceiling reported tracks the PRECISION constraint, which is the binding one for the over-merge problem.`,
		`- **Token-Jaccard ≠ the model's name comparison.** A proxy for separability; the GBT uses the FS agreement ` +
			`levels. The collision SET (sim ≥ τ + shared phone) is robust to the exact similarity metric.`,
		"",
	]

	const md = lines.join("\n")

	console.log(md)

	if (OUT_MD) {
		await writeLocalFile(md, OUT_MD)
		report?.(`[written] ${OUT_MD}`)
	}

	return { markdown: md, pairs, collide }
}
