/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Geocoder validation against provided coordinates (#619) — a free, honest, real-world accuracy
 *   eval.
 *
 *   TX hhsc's nursing-facilities registry ships a `Geo Location` (`lat,lon`) per facility alongside
 *   its physical address. We geocode the address with mailwoman's real parser + resolver and
 *   measure the great-circle delta to the provided point — p50 / p90, broken down by the resolution
 *   tier we assign (address_point / interpolated / admin). This is an independent check of the
 *   geocoder on real facility addresses. it does not touch the matcher.
 *
 *   The provided coordinate is treated as ground truth for _this_ eval, with the honest caveat that
 *   it is itself a third-party geocode of unknown provenance — a large delta is a discrepancy to
 *   inspect rather than automatically our error.
 *
 *   Run: `mailwoman registry scorer-eval vs-provided-coords [--max 1176] [--wof <admin.db>]
 *   [--data-root <dir>] [--out-md docs/articles/evals/resolver-geo/<date>-...md]`
 */

import { dataRootPath } from "@mailwoman/core/data-root"
import { writeLocalFile } from "@mailwoman/core/fs/writers"
import { isPresent } from "@mailwoman/core/objects"
import { percentile } from "@mailwoman/core/stats"
import { haversineKm } from "@mailwoman/match"

import { streamRows } from "#index"
import type { EvalGeocoderFactory } from "#tools/eval-geocoder"
import { norm } from "#tools/shared"

/**
 * Largest absolute latitude in WGS-84 degrees.
 */
const MAX_ABS_LATITUDE = 90

/**
 * Largest absolute longitude in WGS-84 degrees.
 */
const MAX_ABS_LONGITUDE = 180

/**
 * Options for {@linkcode geocoderVsProvidedCoords}.
 */
export interface GeocoderVsProvidedCoordsOptions {
	/**
	 * The injected geocoder factory (the command wires `mailwoman/geocode-core`; see `./eval-geocoder.ts`).
	 */
	createGeocoder: EvalGeocoderFactory
	/**
	 * Record-matcher sources directory.
	 *
	 * Default `$MAILWOMAN_DATA_ROOT/record-matcher/sources`.
	 */
	sources?: string
	/**
	 * Facilities geocoded.
	 *
	 * Default 2000.
	 */
	max?: number
	/**
	 * Also write the markdown report here.
	 */
	outMd?: string
}

/**
 * Parse a `lat,lon` string into a coordinate, or null if malformed / out of range.
 *
 * Deliberately strict, and deliberately not `GeoPoint.from()`.
 * The provided coordinate is this eval's ground truth, so a row we cannot read exactly has
 * to be _dropped_ (counted in `noCoord`) rather than repaired into something plausible —
 * a silently repaired coordinate lands in the delta distribution as geocoder error.
 *
 * Two of the three divergences that originally justified this parser were defects in `GeoPoint`
 * and were fixed on 2026-08-05: it no longer guesses axis order from the magnitudes, and an
 * out-of-range value is now rejected instead of accepted (`200,-97.74` used to become a point).
 * What remains is not a defect and not negotiable.
 *
 * This source writes `latitude,longitude`; `GeoPoint` reads GeoJSON `[longitude, latitude]`,
 * so `31.5,-89.5` is a Mississippi row here and a South-Atlantic point there — and `GeoPoint.from`
 * maps 0,0 to null, which moves Null Island out of the measured outliers and into the skipped bucket.
 * The report below attributes part of its p99/max tail to malformed provided coordinates,
 * so those rows have to stay rejected or measured as-is, never rewritten.
 *
 * Strictness is the measurement rather than an unfinished migration.
 */
function parseLatLon(raw: string | undefined): { latitude: number; longitude: number } | null {
	if (!raw) return null
	const [a, b] = raw.split(",").map((x) => Number(x.trim()))

	if (!Number.isFinite(a) || !Number.isFinite(b)) return null

	if (Math.abs(a!) > MAX_ABS_LATITUDE || Math.abs(b!) > MAX_ABS_LONGITUDE) return null

	return { latitude: a!, longitude: b! }
}

// The core nearest-rank `percentile` (q in [0,100]) replaces the retired local `quantile(sorted, q)` —
// byte-identical semantics (floor index, clamped); `?? NaN` keeps empty-sample behavior.
const quantile = (xs: number[], q: number): number => percentile(xs, q * 100) ?? Number.NaN

/**
 * Geocoder validation against provided coordinates (#619) — see the module doc.
 *
 * Emits the report to stdout.
 */
export async function geocoderVsProvidedCoords(
	options: GeocoderVsProvidedCoordsOptions,
	report?: (line: string) => void
): Promise<{ markdown: string }> {
	const SOURCES = options.sources || dataRootPath("record-matcher", "sources")
	const MAX = options.max ?? 2000
	const OUT_MD = options.outMd || ""

	const FILE = `${SOURCES}/txhhsc_nursing-facilities_20260611.tsv`

	report?.("[A] building the geocoder…")
	const geocoder = await options.createGeocoder()

	report?.(`[B] geocoding ≤${MAX} TX nursing facilities + measuring delta to provided coords…`)

	interface Row {
		deltaM: number
		tier: string
	}

	const results: Row[] = []
	let scanned = 0
	let noCoord = 0
	let noPlace = 0

	for await (const r of streamRows(FILE)) {
		if (results.length >= MAX) break
		const provided = parseLatLon(r["Geo Location"])
		const line = norm(r["Physical Address"])
		const city = norm(r["Physical Address CITY"])
		const state = norm(r["Physical Address State"])
		const zip = norm(r["Physical Address Zipcode"])

		if (!provided || !line) {
			noCoord++

			continue
		}

		scanned++
		const address = [line, city, state, zip].filter(isPresent).join(", ")
		const g = await geocoder.geocode(address)

		if (g.lat === null || g.lon === null) {
			noPlace++

			continue
		}

		const deltaM = haversineKm(provided, { latitude: g.lat, longitude: g.lon }) * 1000
		results.push({ deltaM, tier: g.resolution_tier ?? "unknown" })
	}

	geocoder[Symbol.dispose]()

	// Overall + per-tier percentiles.
	const all = results.map((r) => r.deltaM).toSorted((a, b) => a - b)
	const byTier = new Map<string, number[]>()

	for (const r of results) {
		const list = byTier.get(r.tier) ?? []
		list.push(r.deltaM)
		byTier.set(r.tier, list)
	}

	const m = (x: number) => (x >= 1000 ? `${(x / 1000).toFixed(2)} km` : `${Math.round(x)} m`)

	report?.(
		`    geocoded ${results.length}/${scanned} placed (${noPlace} unplaced, ${noCoord} skipped no-coord/addr); ` +
			`p50 ${m(quantile(all, 0.5))}, p90 ${m(quantile(all, 0.9))}`
	)

	const lines: string[] = [
		`# Geocoder vs provided coordinates (#619)`,
		"",
		`_Generated by \`mailwoman registry scorer-eval vs-provided-coords\`. Source: TX HHSC ` +
			`nursing-facilities (\`Geo Location\` = provided \`lat,lon\`). We geocode each facility's physical address ` +
			`with mailwoman's parser + resolver and measure the great-circle delta to the provided point. The provided ` +
			`coordinate is a third-party geocode of unknown provenance — a large delta is a discrepancy to inspect, not ` +
			`automatically our error._`,
		"",
		`## Result`,
		"",
		`- facilities geocoded: **${results.length}** of ${scanned} with a usable address + provided coord`,
		`- unplaced by our geocoder: ${noPlace} · skipped (no coord / no address): ${noCoord}`,
		`- **overall delta: p50 ${m(quantile(all, 0.5))}, p90 ${m(quantile(all, 0.9))}, p99 ${m(quantile(all, 0.99))}** ` +
			`(max ${m(all.at(-1) ?? 0)})`,
		"",
		`## By resolution tier`,
		"",
		`| tier | n | p50 | p90 |`,
		`|---|---:|---:|---:|`,
	]

	for (const [tier, list] of [...byTier.entries()].toSorted((a, b) => b[1].length - a[1].length)) {
		const s = [...list].toSorted((a, b) => a - b)
		lines.push(`| ${tier} | ${list.length} | ${m(quantile(s, 0.5))} | ${m(quantile(s, 0.9))} |`)
	}

	lines.push("")
	lines.push(`## Reading`)
	lines.push("")

	lines.push(
		`Two regimes. **Street-tier placement is excellent** (the address_point + interpolated rows above) — ` +
			`rooftop-to-segment medians, the precision that makes geo-first blocking and the distance evidence ` +
			`trustworthy. The **admin (centroid) tier** is where no street extract covered the address: accuracy is ` +
			`necessarily km-scale, and it carries a catastrophic tail (the p90/p99/max above) from wrong-region admin ` +
			`resolutions and/or malformed provided coordinates — NOT street-tier error. Those extremes are a signal to ` +
			`inspect, and they motivate wider street-extract coverage for rural TX plus an admin-tier sanity bound. The ` +
			`self-reported-vs-independent coordinate discrepancy is itself a data-quality column the reconciliation ` +
			`surfaces (#621).`
	)

	lines.push("")

	const md = lines.join("\n")

	console.log(md)

	if (OUT_MD) {
		await writeLocalFile(md, OUT_MD)
		report?.(`\n[written] ${OUT_MD}`)
	}

	return { markdown: md }
}
