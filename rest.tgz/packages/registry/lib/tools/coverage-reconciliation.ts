/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Coverage reconciliation (#621) — the product output: what replaces inspecting the map by eye.
 *
 *   Over the entities resolved across sources (#618), classify each by which kind of source its
 *   records come from:
 *
 *   - **eligibility** sources — entities that exist as providers / facilities: NPPES org NPIs, TX hhsc
 *       nursing facilities.
 *   - **funding** source — entities enrolled in a funding program: FCC Rural Health Care filings.
 *
 *   Three buckets fall out:
 *
 *   - **enrolled** — resolves to both an eligibility and a funding record.
 *   - **eligible rather than enrolled** — an eligibility record with no funding record resolving to it (the
 *       anti-join: the set you currently find by eye).
 *   - **funded rather than in the eligibility set** — a funding record with no eligibility record resolving to
 *       it.
 *
 *   Output: GeoJSON (drops on the same map) + a table, each entity tagged with its bucket + source
 *   memberships. We produce the reconciled join. what a gap means — and whether it's real or a
 *   sampling artifact — is the consumer's call rather than ours. This is strictly a set-membership
 *   reconciliation, never an allegation.
 *
 *   Run: `mailwoman registry scorer-eval coverage-reconciliation [--cap 2000] [--wof <admin.db>]
 *   [--data-root <dir>] [--out-md <md>] [--out-geojson <geojson>]`
 */

import { dataRootPath } from "@mailwoman/core/data-root"
import { writeLocalFile, writeLocalJSONFile } from "@mailwoman/core/fs/writers"

import {
	ingestRows,
	reconcileCoverage,
	reconciliationGeoJSON,
	reconciliationReport,
	resolveEntities,
	streamRows,
	type GeocodeAddress,
	type ReconcileConfig,
	type SourceRecord,
} from "#index"
import type { EvalGeocoderFactory } from "#tools/eval-geocoder"
import { buildSpecs, stateOption } from "#tools/shared"

/**
 * Options for {@linkcode coverageReconciliation}.
 */
export interface CoverageReconciliationOptions {
	/**
	 * The injected geocoder factory (the command wires `mailwoman/geocode-core`; see `./eval-geocoder.ts`).
	 */
	createGeocoder: EvalGeocoderFactory
	/**
	 * Record-matcher sources directory.
	 *
	 * Default `$MAILWOMAN_DATA_ROOT/record-matcher/sources`.
	 */
	sources?: string
	/**
	 * Rows kept per source.
	 *
	 * Default 2000.
	 */
	cap?: number
	/**
	 * State filter.
	 *
	 * Default TX.
	 */
	state?: string
	/**
	 * Also write the markdown report here.
	 */
	outMd?: string
	/**
	 * Also write the bucket-tagged GeoJSON here.
	 */
	outGeojson?: string
}

/**
 * Which kind of source a record's provenance label denotes.
 */
const ELIGIBILITY = new Set(["nppes", "txhhsc-nursing"])
const FUNDING = new Set(["fcc-rhc"])

/**
 * Coverage reconciliation (#621) — see the module doc.
 * Emits the markdown report to stdout.
 */
export async function coverageReconciliation(
	options: CoverageReconciliationOptions,
	report?: (line: string) => void
): Promise<{ markdown: string }> {
	const SOURCES = options.sources || dataRootPath("record-matcher", "sources")
	const CAP = options.cap ?? 2000
	const STATE = stateOption(options)
	const OUT_MD = options.outMd || ""
	const OUT_GEOJSON = options.outGeojson || ""
	const SPECS = buildSpecs(`${SOURCES}`, STATE)

	// Ingest every source into one combined, geo-resolved record set.
	const rawBySource = new Map<string, Record<string, string>[]>()

	for (const spec of SPECS) {
		report?.(`[A] ${spec.source}: streaming + ${STATE} filter (cap ${CAP})…`)
		const kept: Record<string, string>[] = []

		for await (const row of streamRows(spec.path)) {
			if (!spec.inState(row)) continue
			kept.push(row)

			if (kept.length >= CAP) break
		}

		rawBySource.set(spec.source, kept)
		report?.(`    ${spec.source}: ${kept.length} rows`)
	}

	report?.("[B] building the geocoder…")
	const geocoder = await options.createGeocoder()

	let geo = 0
	let total = 0

	// Count placements at the boundary (parity with the retired in-script counter).
	const geocodeForIngest: GeocodeAddress = async (raw) => {
		const g = await geocoder.geocodeAddress(raw)

		total++

		if (g?.geocode) {
			geo++
		}

		return g
	}

	report?.("[C] geocoding + ingesting…")
	const records: SourceRecord[] = []

	for (const spec of SPECS) {
		const recs = await ingestRows(rawBySource.get(spec.source)!, spec.mapping, { geocodeAddress: geocodeForIngest })

		for (const r of recs) {
			r.id = `${spec.source}:${r.id}`
		}

		records.push(...recs)
	}

	geocoder[Symbol.dispose]()
	report?.(`    ${records.length} records; geocoded ${geo}/${total} (${((100 * geo) / total).toFixed(1)}%)`)

	report?.("[D] resolving + reconciling…")
	// learnedScorer:false — reconciliation joins eligibility ↔ funding across datasets
	// (recall-oriented): the same facility under different operational names is the signal we want,
	// which the dedup-calibrated GBT default rejects (measured: "enrolled" overlap 22→6).
	// Use the FS baseline for this cross-dataset join.
	const { entities } = resolveEntities(records, { trainEM: true, collapseSpatial: true, learnedScorer: false })

	// Reconcile sources through the shared @mailwoman/registry code path.
	// `mailwoman registry --reconcile`, so the script and the CLI can't drift. ---
	const config: ReconcileConfig = { eligibilitySources: [...ELIGIBILITY], fundingSources: [...FUNDING] }
	const result = reconcileCoverage(entities, config)
	const geojson = reconciliationGeoJSON(result)

	const md = reconciliationReport(result, {
		title: "Coverage reconciliation — eligibility ↔ enrollment (#621)",
		scopeNote:
			`Generated by \`mailwoman registry scorer-eval coverage-reconciliation\`. ${STATE}-scoped, ≤${CAP} rows per ` +
			`source, resolved BLIND across sources. **Eligibility** = NPPES org NPIs + TX HHSC nursing facilities; ` +
			`**funding/enrollment** = FCC Rural Health Care filings. Each resolved entity is classified by which kinds ` +
			`of source its records span.`,
		scorerNote:
			`Scored with the Fellegi-Sunter baseline (\`learnedScorer: false\`): this is a cross-dataset eligibility ↔ ` +
			`funding join (recall-oriented), so the dedup-calibrated GBT default (#603) — trained to reject the ` +
			`"same place, different operational name" pattern that IS the cross-source signal — is pinned off. See #655.`,
		sampleNote:
			`This is a **capped sample** (≤${CAP}/source), so "eligible, not enrolled" includes entities that ARE ` +
			`enrolled in reality but whose funding record fell outside the sample — a **sampling artifact, not a ` +
			`finding**. At full scale the anti-join tightens, but it is STILL only a set of candidates.`,
		spotCheckLimit: 15,
	})

	console.log(md)

	if (OUT_MD) {
		await writeLocalFile(md, OUT_MD)
		report?.(`[written] ${OUT_MD}`)
	}

	if (OUT_GEOJSON) {
		await writeLocalJSONFile(geojson, OUT_GEOJSON)
		report?.(`[written] ${OUT_GEOJSON} (${geojson.features.length} features)`)
	}

	return { markdown: md }
}
