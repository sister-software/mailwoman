#!/usr/bin/env node
/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Release-time fail-fast check: verify the shipped model's metadata has propagated to every human-
 *   facing surface before a publish goes out. Mirrors the Hugging Face weight-staging preflight in
 *   `.github/workflows/publish.yml` — head-check the surfaces, and on any miss print the exact
 *   remediation and stop, rather than shipping silently and backfilling a release later.
 *
 *   Why this exists (2026-07-17). When 6.4.0 shipped, three metadata surfaces were never updated and
 *   nobody noticed until 6.5.0 — all three were hand-backfilled during the 6.5.0 ship:
 *
 *   - `evals/scores-by-version.json` — the per-model score ledger (`mailwoman eval ledger-append`
 *       exists but was manual, so it froze).
 *   - `docs/records/site-2026-08/releases.mdx` — the version matrix, stuck showing an old `(current)` row.
 *   - `docs/articles/developers/status.mdx` — the status info box, citing a superseded release.
 *
 *   the model-vs-npm distinction (see the "Two version series" intro of releases.mdx). Two version
 *   series exist: the npm version (what `npm install` gives you, bumped in lockstep across all
 *   workspaces on every release) and the trained-model lineage recorded in the weights bundle's
 *   `model-card.json`. A code-only release bumps npm but not the model card — the model didn't
 *   change, so the ledger/docs shouldn't be forced to grow a new model row. This eval therefore keys
 *   off the model version (the `version` field of `neural-weights-en-us/model-card.json`), not npm /
 *   package.json, and asserts the ledger + docs are current FOR that model. A code-only npm bump on
 *   top of an unchanged model still passes, provided every release newer than the model version is
 *   itself a documented "model unchanged" row.
 *
 *   the three checks (keyed off the model-card version V):
 *
 *   1. `evals/scores-by-version.json` has a run whose `model_version === V`.
 *   2. `docs/records/site-2026-08/releases.mdx` has a matrix row for V, and the `(current)` marker sits on V's
 *      row — or on a newer row when every release above V is a "model unchanged" (code-only) row.
 *   3. `docs/articles/developers/status.mdx` cites V in its `:::info[Verified as of …]` box.
 *
 *   On any failure: one actionable error per surface (the exact command / file+section to fix), then
 *   exit 1. On success: one `OK` line per surface, exit 0.
 *
 *   Not covered here (tracked follow-up): the isotonic calibration tables in the weights bundle are
 *   still fitted on the v5.3.0 lineage and carried forward — a separate, larger re-fit workstream,
 *   deliberately out of scope for this eval.
 *
 *   Usage:
 *     yarn mwops release verify-metadata
 *     yarn mwops release verify-metadata \
 *       --card packages/neural-weights-en-us/model-card.json \
 *       --ledger evals/scores-by-version.json \
 *       --releases docs/records/site-2026-08/releases.mdx \
 *       --status docs/articles/developers/status.mdx
 *
 *   The path overrides exist so the surfaces can be pointed at doctored copies when exercising the
 *   failure modes. the defaults are the real repo files. Wired into `.github/workflows/publish.yml`
 *   as a step after the HF preflight and before release-it publishes.
 */

import { readLocalJSONFile, readLocalTextFile } from "@mailwoman/core/fs/readers"
import { escapeRegExp } from "@mailwoman/core/strings/regexp"
import { resolvePath } from "path-ts"
import { TextSpliterator } from "spliterator"

/**
 * Cells a markdown table row needs before it carries a version/date/status triple.
 */
const MIN_TABLE_CELLS = 3

/**
 * A word-boundary matcher for an exact version token (so `6.5.0` does not match `6.5.01`).
 */
function versionMatcher(version: string): RegExp {
	return new RegExp(`(?<![\\w.])${escapeRegExp(version)}(?![\\w.])`)
}

/**
 * One parsed data row of the releases.mdx version matrix, in file order (newest-first).
 */
interface MatrixRow {
	/**
	 * First column (the npm-version cell), with markdown bold stripped.
	 */
	versionCell: string
	/**
	 * Third column (the "Model lineage" cell).
	 */
	lineageCell: string
}

export interface VerifyReleaseMetadataOptions {
	repoRoot: string
	/**
	 * Repo-relative (or absolute) overrides for each surface.
	 * The defaults are the real repo files.
	 */
	card?: string
	ledger?: string
	releases?: string
	status?: string
	log: (line: string) => void
}

/**
 * The directory `docs/docusaurus.config.ts` publishes (`path: "articles"`).
 *
 * A status page outside it is not the page a reader opens, so citing the shipped model there proves nothing.
 */
const PUBLISHED_DOCS_ROOT = "docs/articles/"

/**
 * The page https://mailwoman.ai serves as "What ships today".
 */
const PUBLISHED_STATUS_PAGE = `${PUBLISHED_DOCS_ROOT}developers/status.mdx`

/**
 * Refuse a status path outside the published tree.
 *
 * This check verifies that A file cites the shipped version, and for four releases it
 * verified the archived August copy while the live page said 8.6.0 and model 7.0.0 (#2259).
 * A target that can move out from under a check while still resolving reports success
 * from the wrong place, and absence of failure was read as propagation.
 * So the path is constrained rather than merely defaulted.
 */
function assertPublishedStatusPage(statusPath: string): void {
	if (statusPath.startsWith(PUBLISHED_DOCS_ROOT)) return

	throw new Error(
		`verify-release-metadata: the status surface must be a page the site publishes, under ${PUBLISHED_DOCS_ROOT} ` +
			`(received ${statusPath}). Only that tree is built — a page elsewhere can cite the shipped model while ` +
			`the page a reader opens does not.`
	)
}

export interface SurfaceResult {
	surface: string
	ok: boolean
	/**
	 * On OK: a one-line summary.
	 *
	 * On failure: the actionable remediation (may be multi-line).
	 */
	message: string
}

/**
 * Read the shipped model version — the `version` field of the weights bundle's model card.
 *
 * This is the anchor for every check: not npm / package.json, so a code-only release
 * (which bumps npm but leaves the card untouched) is judged against the model it actually ships.
 */
async function readModelVersion(cardPath: string): Promise<string> {
	const card = await readLocalJSONFile<{ version?: string }>(cardPath)

	if (!card.version) throw new Error(`model card ${cardPath} has no "version" field`)

	return card.version
}

/**
 * Check 1 — the eval ledger carries a run for this model version.
 */
async function checkLedger(version: string, ledgerPath: string): Promise<SurfaceResult> {
	const ledger = await readLocalJSONFile<{
		runs?: Array<{ model_version?: string }>
	}>(ledgerPath)

	const runs = ledger.runs ?? []
	const found = runs.some((run) => run.model_version === version)

	if (found) {
		return {
			surface: "eval-ledger",
			ok: true,
			message: `eval ledger has a run for model_version ${version}`,
		}
	}

	return {
		surface: "eval-ledger",
		ok: false,
		message:
			`evals/scores-by-version.json has NO run with model_version === "${version}".\n` +
			`      Append it (the promotion-eval PASS prints this line pre-filled — fill --out-dir/--run-id from that run):\n` +
			`        node packages/mailwoman/out/cli/index.js eval ledger-append \\\n` +
			`          --out-dir <eval-out-dir> --model-version ${version} \\\n` +
			`          --run-id <label>-<yyyymmdd> \\\n` +
			`          --model-path "@mailwoman/neural-weights-en-us@${version}" --card packages/neural-weights-en-us/model-card.json`,
	}
}

/**
 * Parse the releases.mdx version matrix into ordered data rows.
 *
 * A data row is a `|`-delimited table line whose first cell carries a version-like token.
 * The header and `---` separator rows are skipped.
 *
 * The "## The matrix" table is the only one whose rows look like this, so a global scan is safe.
 */
function parseMatrixRows(markdown: string): MatrixRow[] {
	const rows: MatrixRow[] = []

	for (const line of TextSpliterator.from(markdown)) {
		const trimmed = line.trim()

		if (!trimmed.startsWith("|")) continue

		// Split into cells, dropping the leading/trailing empties from the outer pipes.
		const cells = trimmed
			.split("|")
			.slice(1, -1)
			.map((cell) => cell.trim())

		if (cells.length < MIN_TABLE_CELLS) continue

		const versionCell = cells[0]!.replaceAll("**", "")
		const lineageCell = cells[2]!

		// Skip header ("npm") and separator ("---") rows.
		// They carry no version token.
		if (!/\d/.test(versionCell)) continue

		rows.push({ versionCell, lineageCell })
	}

	return rows
}

/**
 * The version on the matrix row carrying the `(current)` marker, or null when no row does.
 *
 * Shared with `check-release-parity.ts`, which compares this surface against npm latest.
 */
export function currentMatrixVersion(markdown: string): string | null {
	const row = parseMatrixRows(markdown).find((candidate) => candidate.versionCell.includes("(current)"))

	return row?.versionCell.match(/\d[\d.]*/)?.[0] ?? null
}

/**
 * Check 2 — releases.mdx has a matrix row for V, and the `(current)` marker is on V's row
 * (or on a newer row when every release above V is a documented "model unchanged" code-only bump).
 */
async function checkReleases(version: string, releasesPath: string): Promise<SurfaceResult> {
	const surface = "releases-matrix"
	const markdown = await readLocalTextFile(releasesPath)
	const rows = parseMatrixRows(markdown)
	const matcher = versionMatcher(version)

	const vIndex = rows.findIndex((row) => matcher.test(row.versionCell))
	const currentIndex = rows.findIndex((row) => row.versionCell.includes("(current)"))

	const rowFix =
		`      Add a matrix row for ${version} under "## The matrix" in docs/records/site-2026-08/releases.mdx\n` +
		`      (newest-first; first column \`**${version}** (current)\`, with date / model lineage / what-it-added / per-tag-truth).`

	if (vIndex === -1) {
		return {
			surface,
			ok: false,
			message: `docs/records/site-2026-08/releases.mdx has NO matrix row for ${version}.\n` + rowFix,
		}
	}

	if (currentIndex === -1) {
		return {
			surface,
			ok: false,
			message:
				`docs/records/site-2026-08/releases.mdx has no "(current)" marker in the matrix.\n` +
				`      Mark ${version}'s first column as \`**${version}** (current)\`.`,
		}
	}

	if (currentIndex === vIndex) {
		return { surface, ok: true, message: `releases.mdx matrix row ${version} carries the "(current)" marker` }
	}

	const { versionCell } = rows[currentIndex]!

	// Rows are newest-first.
	// Current above V (smaller index) is fine only if every row strictly newer than
	// V is a code-only "model unchanged" bump — then V is still the live model
	// and the marker rightly sits on the newest npm row.
	if (currentIndex < vIndex) {
		const newerRows = rows.slice(currentIndex, vIndex)
		const nonCodeOnly = newerRows.filter((row) => !/unchanged/i.test(row.lineageCell))

		if (!nonCodeOnly.length) {
			return {
				surface,
				ok: true,
				message: `releases.mdx: model ${version} is current; the marker sits on a newer code-only row (as expected)`,
			}
		}

		return {
			surface,
			ok: false,
			message:
				`docs/records/site-2026-08/releases.mdx marks "${versionCell}" as (current), but a newer row above model ${version} introduces a NEW model:\n` +
				`        ${nonCodeOnly.map((row) => row.versionCell).join(", ")}\n` +
				`      Either the model card was not bumped for that model release, or that row is mislabeled. Reconcile the card version with the matrix.`,
		}
	}

	// current below V (larger index).
	// The marker is stuck on an older release than the shipped model.
	return {
		surface,
		ok: false,
		message:
			`docs/records/site-2026-08/releases.mdx marks "${versionCell}" as (current), but the shipped model is ${version}.\n` +
			`      Move the "(current)" marker to ${version}'s row (first column \`**${version}** (current)\`) and drop it from the stale row.`,
	}
}

/**
 * Check 3 — the status.mdx info box cites this model version.
 */
async function checkStatus(version: string, statusPath: string): Promise<SurfaceResult> {
	const surface = "status-infobox"
	const markdown = await readLocalTextFile(statusPath)

	const start = markdown.indexOf(":::info[")

	if (start === -1) {
		return {
			surface,
			ok: false,
			message:
				`docs/articles/developers/status.mdx has no ":::info[Verified as of …]" box.\n` +
				`      Add / restore the info box and cite release ${version}.`,
		}
	}

	const end = markdown.indexOf(":::", start + 1)
	const infoBox = markdown.slice(start, end === -1 ? undefined : end)

	if (versionMatcher(version).test(infoBox)) {
		return { surface, ok: true, message: `status.mdx info box cites ${version}` }
	}

	return {
		surface,
		ok: false,
		message:
			`docs/articles/developers/status.mdx ":::info[Verified as of …]" box does NOT cite the shipped model ${version}.\n` +
			`      Update the ":::info[Verified as of <date> — release ${version}]" header (and the body model paragraph) to ${version}.`,
	}
}

export interface VerifyReleaseMetadataReport {
	modelVersion: string
	surfaces: SurfaceResult[]
}

/**
 * Check every surface for the shipped model version.
 *
 * @throws when any surface is stale, with each remediation already reported through `log`,
 *   so a caller's exit code follows the verdict.
 */
export async function verifyReleaseMetadata(
	options: VerifyReleaseMetadataOptions
): Promise<VerifyReleaseMetadataReport> {
	const { repoRoot, log } = options

	const statusRelative = options.status ?? PUBLISHED_STATUS_PAGE

	assertPublishedStatusPage(statusRelative)

	const paths = {
		cardPath: resolvePath(repoRoot, options.card ?? "packages/neural-weights-en-us/model-card.json"),
		ledgerPath: resolvePath(repoRoot, options.ledger ?? "evals/scores-by-version.json"),
		// Not an archive, despite the directory.
		// `docs/records/site-2026-08/releases.mdx` is the maintained release matrix — agents.md names it as
		// where a version with no ledger row carries its headline, and it took 10.0.0 in `76c08d950`.
		// It is deliberately unpublished, so there is no live page to move this to.
		releasesPath: resolvePath(repoRoot, options.releases ?? "docs/records/site-2026-08/releases.mdx"),
		statusPath: resolvePath(repoRoot, statusRelative),
	}

	const version = await readModelVersion(paths.cardPath)

	log(`verify-release-metadata: shipped MODEL version (from model card) = ${version}\n`)

	const results: SurfaceResult[] = [
		await checkLedger(version, paths.ledgerPath),
		await checkReleases(version, paths.releasesPath),
		await checkStatus(version, paths.statusPath),
	]

	for (const result of results) {
		log(`  ${result.ok ? "✓" : "✗"} ${result.surface}: ${result.message}`)
	}

	const failures = results.filter((result) => !result.ok)

	if (failures.length) {
		throw new Error(
			`verify-release-metadata FAILED: ${failures.length} of ${results.length} surfaces stale for model ${version}. ` +
				`Fix the item(s) above (each surface is independent), commit, then re-dispatch the publish.`
		)
	}

	log(`\nverify-release-metadata OK: model ${version} is fully propagated to the ledger + docs.`)

	return { modelVersion: version, surfaces: results }
}
