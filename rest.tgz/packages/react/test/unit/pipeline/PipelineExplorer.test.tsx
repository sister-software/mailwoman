/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Composed test: drives the whole pipeline explorer (ClientOnly boundary → useParsePipeline →
 *   presentational units) against a mock runtime — no model, no gazetteer.
 */

import { makePipelineRuntime } from "@mailwoman/react/map/fake-runtime"
import { PipelineExplorer } from "@mailwoman/react/pipeline/PipelineExplorer"
import { expect, test, vi } from "vitest"
import { userEvent } from "vitest/browser"

import { renderComponent } from "../../render.tsx"

test("parses on submit and renders components + resolved place", async () => {
	const { container } = renderComponent(
		<PipelineExplorer runtime={makePipelineRuntime()} defaultAddress="350 5th Ave" />
	)

	// ClientOnly mounts asynchronously.
	// Wait for the form.
	await vi.waitFor(() => expect(container.querySelector("#mw-pipeline-input")).toBeTruthy())

	await userEvent.click(container.querySelector('button[type="submit"]') as HTMLButtonElement)

	await vi.waitFor(() => expect(container.textContent).toContain("Parsed components"))
	expect(container.textContent).toContain("house_number")
	expect(container.textContent).toContain("Resolved place")
	expect(container.textContent).toContain("New York")
})

test("selecting an alternate candidate updates the resolved panel", async () => {
	const { container } = renderComponent(
		<PipelineExplorer runtime={makePipelineRuntime()} defaultAddress="350 5th Ave" />
	)

	await vi.waitFor(() => expect(container.querySelector("#mw-pipeline-input")).toBeTruthy())
	await userEvent.click(container.querySelector('button[type="submit"]') as HTMLButtonElement)
	await vi.waitFor(() => expect(container.querySelectorAll(".mw-candidates__btn")).toHaveLength(2))

	// Pick the second candidate (the region).
	// The resolved panel should now show "region".
	await userEvent.click(container.querySelectorAll(".mw-candidates__btn")[1] as HTMLElement)
	await vi.waitFor(() => expect(container.querySelector(".mw-resolved")?.textContent).toContain("region"))
})

test("renders host-injected extras from the parse result", async () => {
	const { container } = renderComponent(
		<PipelineExplorer
			runtime={makePipelineRuntime()}
			defaultAddress="350 5th Ave"
			panels={{ extras: (result) => <div className="mw-test-extra">extra:{result.nodes.length}</div> }}
		/>
	)

	await vi.waitFor(() => expect(container.querySelector("#mw-pipeline-input")).toBeTruthy())
	await userEvent.click(container.querySelector('button[type="submit"]') as HTMLButtonElement)
	await vi.waitFor(() => expect(container.querySelector(".mw-test-extra")?.textContent).toBe("extra:3"))
})
