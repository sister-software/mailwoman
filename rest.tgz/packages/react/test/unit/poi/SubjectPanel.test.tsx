/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 */

import { SubjectPanel } from "@mailwoman/react/poi/SubjectPanel"
import type { CategoryRecord, POIBrandSubject, POICategorySubject } from "@mailwoman/react/poi/types"
import { expect, test } from "vitest"

import { renderComponent } from "../../render.tsx"

function subject(overrides: Partial<POICategorySubject> = {}): POICategorySubject {
	return {
		kind: "category",
		category: { id: "hospital", label: "Hospital" } as CategoryRecord,
		matchedPhrase: "hospital",
		confidence: 0.84,
		remainder: "New York",
		buildLocal: false,
		...overrides,
	}
}

function brandSubject(overrides: Partial<POIBrandSubject> = {}): POIBrandSubject {
	return {
		kind: "brand",
		name: "Chevron",
		wikidata: "Q319642",
		matchedPhrase: "chevron",
		confidence: 1,
		remainder: "Houston",
		...overrides,
	}
}

test("SubjectPanel renders the category, matched phrase, confidence, and anchor", () => {
	const { container } = renderComponent(<SubjectPanel subject={subject()} />)

	expect(container.querySelector(".mw-subject__chip")?.textContent).toBe("Hospital")
	expect(container.textContent).toContain("hospital")
	expect(container.textContent).toContain("84%")
	expect(container.textContent).toContain("New York")
	expect(container.querySelector(".mw-subject__badge")).toBeNull()
})

test("SubjectPanel shows the build-local badge + note when required", () => {
	const { container } = renderComponent(<SubjectPanel subject={subject({ buildLocal: true })} />)

	expect(container.querySelector(".mw-subject__badge")?.textContent).toContain("build-local")
	expect(container.querySelector(".mw-subject__note")).toBeTruthy()
})

test("SubjectPanel marks a missing anchor as a global query", () => {
	const { container } = renderComponent(<SubjectPanel subject={subject({ remainder: "" })} />)

	expect(container.textContent).toContain("global query")
})

test("SubjectPanel renders a brand subject with its name, brand badge, and a linked QID chip", () => {
	const { container } = renderComponent(<SubjectPanel subject={brandSubject()} />)

	expect(container.querySelector(".mw-subject__chip")?.textContent).toBe("Chevron")
	expect(container.querySelector(".mw-subject__badge--brand")?.textContent).toContain("brand")
	const qid = container.querySelector(".mw-subject__qid") as HTMLAnchorElement | null
	expect(qid?.textContent).toBe("Q319642")
	expect(qid?.getAttribute("href")).toContain("wikidata.org/wiki/Q319642")
	expect(container.textContent).toContain("Houston")
})

test("SubjectPanel omits the QID chip for a brand matched by name alone", () => {
	const { container } = renderComponent(<SubjectPanel subject={brandSubject({ wikidata: undefined })} />)

	expect(container.querySelector(".mw-subject__chip")?.textContent).toBe("Chevron")
	expect(container.querySelector(".mw-subject__qid")).toBeNull()
})
