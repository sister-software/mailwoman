/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Composed test for the whole geocoder over a fake runtime: render `<Geocoder>`, submit a query, and
 *   assert the geocoder responds — the result panel fills in (hard: it's plain DOM in the control panel,
 *   independent of WebGL) and the map drops a resolved-place marker (best-effort: react-map-gl mounts the
 *   `<Marker>` only once the map instance exists, which needs SwiftShader WebGL — its absence means no
 *   software GL in this Chromium rather than a component fault, exactly like `MapCanvas.test.tsx`). No network, no
 *   ONNX, no gazetteer, no tiles.
 */

import { makeFakeGeocoderRuntime } from "@mailwoman/react/map/fake-runtime"
import { Geocoder } from "@mailwoman/react/map/Geocoder"
import { act } from "react"
import { expect, test, vi } from "vitest"
import { userEvent } from "vitest/browser"

import { renderComponent } from "../../render.tsx"

/**
 * Poll `get` inside act() until truthy or timeout.
 * Never throws (returns null on timeout).
 */
async function settle<T>(get: () => T | null, timeout = 8000): Promise<T | null> {
	const start = Date.now()
	let found: T | null = null

	await act(async () => {
		while (Date.now() - start < timeout) {
			found = get()

			if (found) break

			await new Promise((resolve) => {
				setTimeout(resolve, 50)
			})
		}
	})

	return found
}

test("submit drives the result panel + a map marker over the fake runtime", async () => {
	// applyResultCamera=false keeps this deterministic: the marker + outline still render, but the animated fly/fit is skipped, exactly as the overlays test uses applyCamera=false. The camera has its own guard with a live map: see `ResultCamera.test.tsx`.
	const { container } = renderComponent(
		<Geocoder
			runtime={makeFakeGeocoderRuntime()}
			defaultAddress="350 5th Ave, New York, NY 10118"
			applyResultCamera={false}
		/>
	)

	// ClientOnly mounts asynchronously.
	// Wait for the reused QueryForm input.
	await vi.waitFor(() => expect(container.querySelector("#mw-pipeline-input")).toBeTruthy())

	// The pill carries no submit button, the way the reference map apps carry none: a search
	// field submits on Enter, and the leading magnifier is a mark rather than a control.
	await userEvent.click(container.querySelector("#mw-pipeline-input") as HTMLInputElement)
	await userEvent.keyboard("{Enter}")

	// hard: the result panel is plain DOM in the floating control panel — no WebGL needed.
	await vi.waitFor(() => expect(container.textContent).toContain("Parsed components"))
	expect(container.textContent).toContain("house_number")
	expect(container.textContent).toContain("Resolved place")
	expect(container.textContent).toContain("New York")

	// best-effort: the resolved-place marker mounts as a react-map-gl child once the map exists (SwiftShader GL).
	const marker = await settle(() => container.querySelector(".maplibregl-marker"))

	if (marker) {
		expect(marker).toBeInstanceOf(HTMLElement)
	}
})

test("mounts the map container + floating control panel", async () => {
	const { container } = renderComponent(<Geocoder runtime={makeFakeGeocoderRuntime()} defaultAddress="90210" />)

	await vi.waitFor(() => expect(container.querySelector(".mw-geocoder-demo")).toBeTruthy())
	// The chrome + the map wrapper both render synchronously (map canvas is best-effort, tested in MapCanvas).
	// The chrome is one panel — a left column on a desktop, a bottom drawer on a phone —
	// holding the search, the examples and the result, plus a control capsule down the right edge.
	expect(container.querySelector(".mw-map-panel")).not.toBeNull()
	expect(container.querySelector(".mw-map-panel__header")).not.toBeNull()
	expect(container.querySelector(".mw-map-searchbar")).not.toBeNull()
	expect(container.querySelector(".mw-map-control-stack")).not.toBeNull()
	expect(container.querySelector(".mw-geocoder-demo__map .mw-demo-map")).not.toBeNull()
})
