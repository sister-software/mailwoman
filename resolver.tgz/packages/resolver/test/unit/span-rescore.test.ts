/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Tests for the #370 span-rescore: the pure `findRescoreCandidate` (raw-token enumeration, longest-
 *   wins, postcode check) and its `resolveTree` integration (opt-in injection, the #685 brake, byte-
 *   stability when the flag is unset). A fixture backend stands in for the gazetteer.
 */

import type { AddressNode, AddressTree } from "@mailwoman/core/decoder"
import type { ResolvedPlace, ResolverBackend } from "@mailwoman/core/resolver"
import { createWOFResolver } from "@mailwoman/resolver/resolve"
import { findRescoreCandidate, hasResolvedPlace } from "@mailwoman/resolver/span-rescore"
import { describe, expect, it } from "vitest"

import { backendNameKey } from "../helpers/backend-name-key.ts"

const norm = backendNameKey

/**
 * A tiny gazetteer: exact-normalized-name matches only (so the walk can't fuzzy-resolve fragments),
 * with an optional alias surface per place.
 *
 * A row admitted by an alias stands in for the gazetteer's names table / alt_names bag,
 * which is what stamps the backend's `exactMatch` on name-or-alias equality.
 */
type FixturePlace = ResolvedPlace & { aliases?: string[] }

const PLACES: FixturePlace[] = [
	{
		id: 1,
		name: "Grudziądz",
		placetype: "locality",
		country: "PL",
		lat: 53.48,
		lon: 18.75,
		score: 10,
		exactMatch: true,
	},
	// Two same-prefix localities far apart — the longest-wins + postcode-consistency test.
	{
		id: 2,
		name: "Tomaszów",
		placetype: "locality",
		country: "PL",
		lat: 50.45,
		lon: 23.42,
		score: 30,
		exactMatch: true,
	},
	{
		id: 3,
		name: "Tomaszów Mazowiecki",
		placetype: "locality",
		country: "PL",
		lat: 51.53,
		lon: 20,
		score: 5,
		exactMatch: true,
	},
	// A postcode → point, near Tomaszów Mazowiecki (the check anchor).
	{ id: 900, name: "97-200", placetype: "postalcode", country: "PL", lat: 51.53, lon: 20.01, score: 1 },
	// #1537 namesake group: four same-named US localities, rank order as listed. The model reads a bare "Springfield" as a `street`, so the admin walk never touches it and span-rescore is the only tier that resolves it — which is why the runner-ups have to survive this path to reach a consumer.
	{
		id: 10,
		name: "Springfield",
		placetype: "locality",
		country: "US",
		lat: 37.19,
		lon: -93.29,
		score: 8,
		prominence: 5.23,
		exactMatch: true,
	},
	{
		id: 11,
		name: "Springfield",
		placetype: "locality",
		country: "US",
		lat: 39.78,
		lon: -89.64,
		score: 7,
		prominence: 5.19,
		exactMatch: true,
	},
	{
		id: 12,
		name: "Springfield",
		placetype: "locality",
		country: "US",
		lat: 42.1,
		lon: -72.59,
		score: 6,
		prominence: 5.05,
		exactMatch: true,
	},
	// Sits ~5 km from id 11 — the one same-name candidate that survives a 62701-anchored check alongside it.
	{
		id: 13,
		name: "Springfield",
		placetype: "locality",
		country: "US",
		lat: 39.8,
		lon: -89.7,
		score: 4,
		prominence: 4.1,
		exactMatch: true,
	},
	// The check anchor for the namesake group — resolves next to id 11 (IL).
	{ id: 901, name: "62701", placetype: "postalcode", country: "US", lat: 39.79, lon: -89.65, score: 1 },
	// A lone namesake: one place, one name. The "absent rather than empty" case.
	{
		id: 20,
		name: "Grudziądzek",
		placetype: "locality",
		country: "PL",
		lat: 53.4,
		lon: 18.7,
		score: 9,
		exactMatch: true,
	},
	// #1546: the non-Latin-primary namesake, modeled on the live shipped board. Moscow RU (pop 12.7M, primary "Москва") is admitted to a "Moscow" query only through its alias surface — the backend stamps exactMatch via the "Moscow" names row — and it ranks first (population-first). The old span-rescore filter re-checked the primary name folded to [a-z0-9 ], and norm("Москва") is "". So the RU entry was dropped and Moscow, Idaho won by default among the Latin-named bearers.
	{
		id: 30,
		name: "Москва",
		aliases: ["Moscow"],
		placetype: "locality",
		country: "RU",
		lat: 55.75,
		lon: 37.62,
		score: 10,
		prominence: 6.1,
		exactMatch: true,
	},
	{
		id: 31,
		name: "Moscow",
		placetype: "locality",
		country: "US",
		lat: 46.73,
		lon: -117,
		score: 9,
		prominence: 4.4,
		exactMatch: true,
	},
	{
		id: 32,
		name: "Moscow",
		placetype: "locality",
		country: "US",
		lat: 38.94,
		lon: -90.93,
		score: 8,
		prominence: 3.6,
		exactMatch: true,
	},
	// The check anchor for the #1546 group — resolves next to the Idaho bearer (id 31).
	{ id: 902, name: "83843", placetype: "postalcode", country: "US", lat: 46.73, lon: -116.99, score: 1 },
	// #1546: the alias surface is the recall for latin scripts too. A query equal to a place's alias ("New York City") but not its primary name ("New York") was dropped by the same primary-name re-check, even when the backend had already flagged it exact.
	{
		id: 40,
		name: "New York",
		aliases: ["New York City"],
		placetype: "locality",
		country: "US",
		lat: 40.71,
		lon: -74.01,
		score: 11,
		prominence: 7,
		exactMatch: true,
	},
	// The "Ave, France" guard's own place, and the name that must survive it: `Prairie` is a street suffix and the tail of a real locality, so the two cases differ only in whether the probed span is the affix or merely contains it.
	{ id: 60, name: "Ave", placetype: "locality", country: "FR", lat: 43.7, lon: 4.6, score: 2, exactMatch: true },
	{
		id: 61,
		name: "Eden Prairie",
		placetype: "locality",
		country: "US",
		lat: 44.85,
		lon: -93.47,
		score: 5,
		exactMatch: true,
	},
	// #2266: a two-character name that collides with a region code, scoring far above the locality the query is actually about. Both spans are one token, so only character extent separates them.
	{ id: 50, name: "Wa", placetype: "locality", country: "GH", lat: 10.06, lon: -2.5, score: 20, exactMatch: true },
	{
		id: 51,
		name: "Sammamish",
		placetype: "locality",
		country: "US",
		lat: 47.64,
		lon: -122.08,
		score: 4,
		exactMatch: true,
	},
	// #2266: `Worth` exists, `Fort Worth` does not — the shape of every row the context-remainder rule catches. Worth, Illinois carries a recorded population, so it wins its own name outright once `Fort` is discarded.
	{
		id: 60,
		name: "Worth",
		placetype: "locality",
		country: "US",
		lat: 41.687259,
		lon: -87.791282,
		score: 4,
		exactMatch: true,
	},
]

async function makeBackend(): Promise<ResolverBackend> {
	return {
		async findPlace(query) {
			const key = norm(query.text)

			return PLACES.filter(
				(p) =>
					(norm(p.name) === key || (p.aliases?.some((a) => norm(a) === key) ?? false)) &&
					(!query.country || p.country === query.country)
			).map((p) => ({ ...p }))
		},
	}
}

const node = (over: Partial<AddressNode> & Pick<AddressNode, "tag" | "value" | "start" | "end">): AddressNode => ({
	confidence: 0.95,
	children: [],
	...over,
})

describe("findRescoreCandidate", () => {
	it("recovers a fragmented locality from the raw text", async () => {
		// The model split "Grudziądz" into "Grudzi" + "dz"; neither resolves.
		// The raw word is intact.
		const raw = "86-300 Grudziądz, Daliowa 4"

		const roots: AddressNode[] = [
			node({ tag: "postcode", value: "86-300", start: 0, end: 6 }),
			node({ tag: "locality", value: "Grudzi", start: 7, end: 13 }),
			node({ tag: "locality", value: "dz", start: 14, end: 16, confidence: 0.9 }),
		]

		const hit = await findRescoreCandidate(raw, roots, await makeBackend(), { country: "PL", postcode: "86-300" })
		expect(hit?.text).toBe("Grudziądz")
		expect(hit?.place.id).toBe(1)
		// 86-300 isn't in the fixture → no anchor → unrestricted (flagged lower-precision).
		expect(hit?.postcodeVerified).toBe(false)
	})

	it("prefers the LONGEST exact match (specific name beats its own prefix)", async () => {
		const raw = "Tomaszów Mazowiecki" // gold is the longer name. shortest-wins would grab "Tomaszów"
		const hit = await findRescoreCandidate(raw, [], await makeBackend(), { country: "PL", thresholdKm: 0 })
		expect(hit?.text).toBe("Tomaszów Mazowiecki")
		expect(hit?.place.id).toBe(3)
		expect(hit?.postcodeVerified).toBe(false) // check disabled (thresholdKm 0)
	})

	it("#2266: orders equal-token spans by CHARACTER extent, so a region code cannot outrun the locality", async () => {
		// Both sub-spans are one token, so token-count ordering ties them and position decides —
		// probing "WA" first and returning Ghana without ever reaching "Sammamish".
		const hit = await findRescoreCandidate("WA Sammamish", [], await makeBackend(), { thresholdKm: 0 })
		expect(hit?.text).toBe("Sammamish")
		expect(hit?.place.id).toBe(51)
	})

	it("#2266: a sub-span dropping a NAME word is refused under spanRescoreRequireContextRemainder", async () => {
		// `Fort Worth` is absent from this fixture, as it was from the withheld-gold stratum.
		// Shipped, the probe falls through to `Worth` and answers Worth, Illinois.
		// The remainder `Fort` is a word of the name rather than a subdivision code,
		// so the rule refuses the truncation and the recovery abstains.
		const backend = await makeBackend()

		const shipped = await findRescoreCandidate("Fort Worth", [], backend, { thresholdKm: 0 })
		expect(shipped?.place.id).toBe(60)

		const ruled = await findRescoreCandidate("Fort Worth", [], backend, {
			thresholdKm: 0,
			spanRescoreRequireContextRemainder: true,
		})

		expect(ruled).toBeNull()
	})

	it("#2266: the rule keeps a sub-span whose remainder is a subdivision code", async () => {
		// The five rows a blanket sub-span refusal would have lost all have this shape.
		const hit = await findRescoreCandidate("WA Sammamish", [], await makeBackend(), {
			thresholdKm: 0,
			spanRescoreRequireContextRemainder: true,
		})

		expect(hit?.text).toBe("Sammamish")
		expect(hit?.place.id).toBe(51)
	})

	it("#2266: the rule keeps a sub-span whose remainder is a number", async () => {
		const hit = await findRescoreCandidate("86-300 Grudziądz", [], await makeBackend(), {
			thresholdKm: 0,
			spanRescoreRequireContextRemainder: true,
		})

		expect(hit?.place.id).toBe(1)
	})

	it("#2266: keeps a sub-span whose remainder the PARSE read as a street", async () => {
		// `Daliowa 4` is neither a subdivision code nor a number, and a bare-text reading
		// of the remainder refuses the truncation and loses the locality.
		// The parse says what it is: a `street` node of its own, disjoint from the span
		// under test, which is context the same way a subdivision code is.
		const raw = "86-300 Grudziądz, Daliowa 4"

		const roots: AddressNode[] = [
			node({ tag: "postcode", value: "86-300", start: 0, end: 6 }),
			node({ tag: "locality", value: "Grudziądz", start: 7, end: 16 }),
			node({
				tag: "street",
				value: "Daliowa",
				start: 18,
				end: 25,
				children: [node({ tag: "house_number", value: "4", start: 26, end: 27 })],
			}),
		]

		const hit = await findRescoreCandidate(raw, roots, await makeBackend(), {
			thresholdKm: 0,
			spanRescoreRequireContextRemainder: true,
		})

		expect(hit?.place.id).toBe(1)
	})

	it("#2266: a street node OVERLAPPING the span is not context — the `Fort Worth` shape", async () => {
		// The model reads a bare famous name as a street, so the dropped word
		// and the surviving fragment sit in one street node.
		// Admitting that remainder would readmit the corruption the rule exists to refuse.
		const raw = "86-300 Grudziądz, Daliowa 4"

		const roots: AddressNode[] = [
			node({ tag: "postcode", value: "86-300", start: 0, end: 6 }),
			node({ tag: "street", value: "Grudziądz, Daliowa", start: 7, end: 25 }),
		]

		const ruled = await findRescoreCandidate(raw, roots, await makeBackend(), {
			thresholdKm: 0,
			spanRescoreRequireContextRemainder: true,
		})

		expect(ruled).toBeNull()
	})

	it("flags a recovery CONDITIONAL when the postcode resolves and the match is within range", async () => {
		// 97-200 resolves (fixture) near Tomaszów Mazowiecki.
		// The longest match lands within 50km → conditional.
		const hit = await findRescoreCandidate("Tomaszów Mazowiecki", [], await makeBackend(), {
			country: "PL",
			postcode: "97-200",
			thresholdKm: 50,
		})

		expect(hit?.place.id).toBe(3)
		expect(hit?.postcodeVerified).toBe(true)
	})

	it("postcode check rejects a match far from where the postcode resolves", async () => {
		// "Tomaszów" alone exact-matches the FAR Tomaszów (id 2); the 97-200 postcode anchors
		// near the Mazowiecki one (~240 km away), so the check rejects it → no recovery.
		const hit = await findRescoreCandidate("Tomaszów", [], await makeBackend(), {
			country: "PL",
			postcode: "97-200",
			thresholdKm: 50,
		})

		expect(hit).toBeNull()
	})

	it("#1537: carries the same-span namesake runner-ups, in rank order, without moving the winner", async () => {
		const hit = await findRescoreCandidate("Springfield", [], await makeBackend(), { country: "US", thresholdKm: 0 })

		// The winner is what it always was — the first exact match in the backend's rank order.
		expect(hit?.place.id).toBe(10)
		expect(hit?.alternatives.map((a) => a.id)).toEqual([11, 12, 13])
	})

	it("#1537: the postcode check filters the runner-ups on the same rule as the winner", async () => {
		// 62701 anchors next to id 11 (IL).
		// MO (id 10) and MA (id 12) are >50 km out, so the check drops them from both roles:
		// id 11 wins, and only the ~5 km id 13 survives as an alternative.
		// A candidate the postcode already excluded is not a namesake worth offering.
		const hit = await findRescoreCandidate("Springfield", [], await makeBackend(), {
			country: "US",
			postcode: "62701",
			thresholdKm: 50,
		})

		expect(hit?.place.id).toBe(11)
		expect(hit?.postcodeVerified).toBe(true)
		expect(hit?.alternatives.map((a) => a.id)).toEqual([13])
	})

	it("#1537: a lone namesake yields an empty runner-up list", async () => {
		const hit = await findRescoreCandidate("Grudziądzek", [], await makeBackend(), { country: "PL", thresholdKm: 0 })
		expect(hit?.place.id).toBe(20)
		expect(hit?.alternatives).toEqual([])
	})

	it("#1546: admits a non-Latin-primary namesake via its alias surface — population-first then picks it", async () => {
		// The live Moscow board: the backend returns Moscow RU first (exactMatch via the "Moscow" alias row),
		// but the old filter re-checked only the primary name folded to [a-z0-9 ] — norm("Москва") is ""
		// and could never equal "moscow", so Moscow, Idaho won by default among the Latin-named bearers.
		// Population-first ranking was starved rather than violated.
		// Recall fixes it with no ranking change.
		const hit = await findRescoreCandidate("Moscow", [], await makeBackend(), { thresholdKm: 0 })
		expect(hit?.place.id).toBe(30)
		expect(hit?.place.name).toBe("Москва")
		expect(hit?.alternatives.map((a) => a.id)).toEqual([31, 32])
	})

	it("#1546: the postcode check still rejects the non-Latin namesake when it is far from the anchor", async () => {
		// "Moscow, ID 83843": the postcode anchors next to the Idaho bearer (id 31); Moscow RU
		// is thousands of km away, so the check excludes it and the Idaho winner is unchanged.
		// Admission is recall.
		// The check still decides.
		const hit = await findRescoreCandidate("Moscow", [], await makeBackend(), {
			country: "US",
			postcode: "83843",
			thresholdKm: 50,
		})

		expect(hit?.place.id).toBe(31)
		expect(hit?.postcodeVerified).toBe(true)
	})

	it("#1546: the alias surface is the recall for Latin scripts too (query equals an ALIAS, not the primary)", async () => {
		// "New York City" matches New York only through its alias row.
		// The old primary-name re-check (norm("New York") !== norm("New York City")) dropped the exact
		// match the backend had already flagged — the same recall defect, without any non-Latin script.
		const hit = await findRescoreCandidate("New York City", [], await makeBackend(), { thresholdKm: 0 })
		expect(hit?.place.id).toBe(40)
		expect(hit?.alternatives).toEqual([])
	})

	it("a span EQUAL to a confident street suffix is refused — the Ave, France guard", async () => {
		// "Ave" is a street suffix here and a commune in France.
		// Probing it as a locality pins the address to Provence, which is the failure
		// `confidentRanges` exists to prevent.
		const raw = "350 5th Ave"

		const roots: AddressNode[] = [
			node({ tag: "house_number", value: "350", start: 0, end: 3, confidence: 0.95 }),
			node({ tag: "street", value: "5th", start: 4, end: 7, confidence: 0.95 }),
			node({ tag: "street_suffix", value: "Ave", start: 8, end: 11, confidence: 0.95 }),
		]

		expect(await findRescoreCandidate(raw, roots, await makeBackend(), { thresholdKm: 0 })).toBeNull()
	})

	it("#2266: a span CONTAINING a confident street suffix is probed — the suffix is one token of a longer name", async () => {
		// `Prairie` carries a confident street_suffix tag while `MN Eden` is a street at 0.61, under the bar.
		// Refusing every span that touches `Prairie` makes `Eden Prairie` unreachable.
		const raw = "MN Eden Prairie"

		const roots: AddressNode[] = [
			node({ tag: "street", value: "MN Eden", start: 0, end: 7, confidence: 0.61 }),
			node({ tag: "street_suffix", value: "Prairie", start: 8, end: 15, confidence: 0.86 }),
		]

		const hit = await findRescoreCandidate(raw, roots, await makeBackend(), { thresholdKm: 0 })

		expect(hit?.text).toBe("Eden Prairie")
		expect(hit?.place.id).toBe(61)
	})

	it("skips a span overlapping a confident street/house_number/postcode constituent", async () => {
		// "Grudziądz" sits where a confident postcode node is declared → not eligible as a locality span.
		const raw = "Grudziądz 4"
		const roots: AddressNode[] = [node({ tag: "postcode", value: "Grudziądz", start: 0, end: 9, confidence: 0.95 })]
		const hit = await findRescoreCandidate(raw, roots, await makeBackend(), { country: "PL", thresholdKm: 0 })
		expect(hit).toBeNull()
	})
})

describe("hasResolvedPlace", () => {
	/**
	 * A node that resolved, carrying whichever metadata the reading under test looks at.
	 */
	const resolvedNode = (metadata: Record<string, unknown> = {}): AddressNode => ({
		...node({ tag: "locality", value: "x", start: 0, end: 1 }),
		placeID: "wof:1",
		metadata,
	})

	it("detects a resolved node anywhere in the tree", () => {
		expect(hasResolvedPlace([node({ tag: "locality", value: "x", start: 0, end: 1 })])).toBe(false)
		expect(hasResolvedPlace([resolvedNode()])).toBe(true)
	})

	it("#2264: each reading holds the brake on the evidence it does NOT name", () => {
		const scoreOnly = resolvedNode({ resolver_score: 0 })
		const containmentOnly = resolvedNode({ admin_containment: "no_contained_candidate" })

		expect(hasResolvedPlace([scoreOnly], "score")).toBe(false)
		expect(hasResolvedPlace([scoreOnly], "containment")).toBe(true)
		expect(hasResolvedPlace([containmentOnly], "score")).toBe(true)
		expect(hasResolvedPlace([containmentOnly], "containment")).toBe(false)

		for (const weak of [scoreOnly, containmentOnly]) {
			expect(hasResolvedPlace([weak], "either")).toBe(false)
			// Unset is the shipped brake: a `placeID` at face value, whatever the evidence under it.
			expect(hasResolvedPlace([weak])).toBe(true)
		}
	})

	it("#2264: a backend that could not answer containment is not a weak resolution", () => {
		// `unavailable` says the probe did not run.
		// Reading it as "nothing sat inside the qualifier" would lift the brake on every
		// row a backend without the ancestors sidecar touches.
		expect(hasResolvedPlace([resolvedNode({ admin_containment: "unavailable" })], "either")).toBe(true)
	})

	it("#2264: a recorded population holds the brake under every reading", () => {
		const strong = resolvedNode({ resolver_score: 155_226, admin_containment: "contained" })

		for (const reading of ["score", "containment", "either"] as const) {
			expect(hasResolvedPlace([strong], reading)).toBe(true)
		}
	})
})

describe("resolveTree + spanRescore", () => {
	const tree = (raw: string, roots: AddressNode[]): AddressTree => ({ raw, roots })

	it("injects a resolved locality when the tree resolved nothing (opt-in)", async () => {
		const resolver = createWOFResolver(await makeBackend())

		const input = tree("86-300 Grudziądz, Daliowa 4", [
			node({ tag: "locality", value: "Grudzi", start: 7, end: 13 }),
			node({ tag: "locality", value: "dz", start: 14, end: 16 }),
		])

		const out = await resolver.resolveTree(input, { defaultCountry: "PL", spanRescore: true })
		const injected = out.roots.find((n) => n.placeID === "wof:1")
		expect(injected).toBeDefined()
		expect(injected?.tag).toBe("locality")
		expect(injected?.value).toBe("Grudziądz")
		expect(injected?.lat).toBe(53.48)
		expect(injected?.metadata?.span_rescore).toBe(true)
		// No postcode node in this tree → no anchor → unrestricted, flagged so the consumer can threshold.
		expect(injected?.metadata?.rescore_postcode_verified).toBe(false)
	})

	it("injects by default when spanRescore is unset (#370 promoted to default-on 2026-06-25)", async () => {
		const resolver = createWOFResolver(await makeBackend())

		const input = tree("86-300 Grudziądz, Daliowa 4", [
			node({ tag: "locality", value: "Grudzi", start: 7, end: 13 }),
			node({ tag: "locality", value: "dz", start: 14, end: 16 }),
		])

		// No `spanRescore` in opts.
		// The default (on) must still recover the locality.
		const out = await resolver.resolveTree(input, { defaultCountry: "PL" })
		expect(out.roots.find((n) => n.placeID === "wof:1")?.value).toBe("Grudziądz")
	})

	it("is byte-stable when spanRescore is false (explicit opt-out — the #685/byte-stable interface)", async () => {
		const resolver = createWOFResolver(await makeBackend())
		const roots = [node({ tag: "locality", value: "Grudzi", start: 7, end: 13 })]

		const out = await resolver.resolveTree(tree("86-300 Grudziądz", roots), {
			defaultCountry: "PL",
			spanRescore: false,
		})

		expect(out.roots.some((n) => n.placeID)).toBe(false)
		expect(out.roots).toHaveLength(1)
	})

	it("#1537: the injected node carries the namesake runner-ups on `alternatives`", async () => {
		const resolver = createWOFResolver(await makeBackend())

		// The live shape: the model tags a bare famous namesake as a `street`,
		// so the admin walk resolves nothing and span-rescore is what recovers it.
		// Before #1537 this node was decorated with an empty alternatives list,
		// so the geocode path's candidate array held one entry and the dominance margin
		// `declared_ambiguity` reads could not be computed at all.
		const out = await resolver.resolveTree(
			tree("Springfield", [node({ tag: "street", value: "Springfield", start: 0, end: 11, confidence: 0.4 })]),
			{
				defaultCountry: "US",
			}
		)

		const injected = out.roots.find((n) => n.metadata?.span_rescore === true)
		expect(injected?.placeID).toBe("wof:10")
		// Unchanged winner: the coordinate this query answered with before the fix.
		expect(injected?.lat).toBe(37.19)
		expect((injected?.alternatives as ResolvedPlace[] | undefined)?.map((a) => a.id)).toEqual([11, 12, 13])
	})

	it("#1537: `alternatives` stays ABSENT (not empty) for a lone namesake — the walk path's interface", async () => {
		const resolver = createWOFResolver(await makeBackend())

		const out = await resolver.resolveTree(
			tree("Grudziądzek", [node({ tag: "street", value: "Grudziądzek", start: 0, end: 11, confidence: 0.4 })]),
			{ defaultCountry: "PL" }
		)

		const injected = out.roots.find((n) => n.metadata?.span_rescore === true)
		expect(injected?.placeID).toBe("wof:20")
		expect(injected?.alternatives).toBeUndefined()
	})

	it("#1546: the injected node for a bare Moscow is Москва RU — the winner flips only for the starved class", async () => {
		const resolver = createWOFResolver(await makeBackend())

		// The live shape: a bare famous namesake reads as a `street`
		// (no country prior — the #912 change abstains on a bare-locality tree),
		// the walk resolves nothing, span-rescore recovers it.
		// Before the fix the recovered place was Moscow, Idaho: Moscow RU never entered the candidate list.
		const out = await resolver.resolveTree(
			tree("Moscow", [node({ tag: "street", value: "Moscow", start: 0, end: 7, confidence: 0.4 })]),
			{}
		)

		const injected = out.roots.find((n) => n.metadata?.span_rescore === true)
		expect(injected?.placeID).toBe("wof:30")
		expect(injected?.lat).toBe(55.75)
		expect((injected?.alternatives as ResolvedPlace[] | undefined)?.map((a) => a.id)).toEqual([31, 32])
	})

	it("does not fire when the tree already resolved (the #685 brake)", async () => {
		const resolver = createWOFResolver(await makeBackend())

		// "Grudziądz" as a single locality node resolves in the walk → already has a coordinate.
		const out = await resolver.resolveTree(
			tree("Grudziądz", [node({ tag: "locality", value: "Grudziądz", start: 0, end: 9 })]),
			{
				defaultCountry: "PL",
				spanRescore: true,
			}
		)

		// Exactly one locality node (the resolved original), no injected duplicate.
		expect(out.roots.filter((n) => n.tag === "locality")).toHaveLength(1)
	})
})

describe("multi-token name interiors (#1678 thread 3)", () => {
	/**
	 * `Papua New Guinea` is absent from the gazetteer, so the tree resolves nothing
	 * and the rescore tier runs.
	 *
	 * Before this guard it enumerated raw token spans, matched the interior `New`
	 * against a real US place, and pinned the address to Kentucky.
	 * A confident answer to a question nobody asked.
	 * The parse was correct throughout.
	 */
	it("refuses a sub-span interior to a multi-token country name", async () => {
		const raw = "Papua New Guinea"

		const roots: AddressNode[] = [
			{ tag: "country", value: raw, start: 0, end: raw.length, confidence: 0.68, children: [] } as AddressNode,
		]

		const probed: string[] = []

		const backend = {
			async findPlace({ text }: { text: string }) {
				probed.push(text)

				return []
			},
		} as ResolverBackend

		await findRescoreCandidate(raw, roots, backend, {})

		// The whole span may be probed.
		// Its interior tokens may not.
		expect(probed).not.toContain("New")
		expect(probed).not.toContain("Papua")
		expect(probed).not.toContain("Guinea")
	})

	it("leaves a single-token country span probeable — there is no interior to protect", async () => {
		const raw = "Japan"

		const roots: AddressNode[] = [
			{ tag: "country", value: raw, start: 0, end: raw.length, confidence: 0.9, children: [] } as AddressNode,
		]

		const probed: string[] = []

		const backend = {
			async findPlace({ text }: { text: string }) {
				probed.push(text)

				return []
			},
		} as ResolverBackend

		await findRescoreCandidate(raw, roots, backend, {})

		expect(probed).toContain("Japan")
	})
})
