/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Unit tests for `WebONNXRunner`'s feed construction against a mocked onnxruntime-web session — no
 *   model files required, so these run in CI where the weights aren't linked.
 *
 *   What this suite guards (the live-demo regression of 2026-06-10): models since v4.2.0 are
 *   gazetteer-anchor-trained and their ONNX graphs declare `gazetteer_features` /
 *   `gazetteer_confidence` (and `anchor_features` / `anchor_confidence`) as required inputs. The
 *   runner must mirror `@mailwoman/neural`'s node `ONNXRunner`:
 *
 *   - Caller-provided anchor/gazetteer features are fed through.
 *   - When the graph declares the inputs but the caller provides nothing, zero-fill them (the
 *       confidence=0 identity) instead of letting ORT throw `input 'gazetteer_features' is missing
 *       in 'feeds'`. Zero-fill is a structural fallback only — the loader warns loudly about the
 *       quality trap — but the session must not crash.
 *   - The optional `locale_logits` output (v4.3.0+ locale head) surfaces as `localeLogits`.
 *   - The optional `span_scores` output (#727 stage-2, v3.x+) surfaces as `spanScores`, with the same
 *       (token, length, type) unflattening the node runner does — the two reads are duplicated across
 *       hosts, so a cross-runner parity test pins them together.
 */

import { ANCHOR_FEATURE_DIM } from "@mailwoman/neural/anchor-inference"
import { COUNTRY_FEATURE_DIM } from "@mailwoman/neural/country-inference"
import { GAZETTEER_FEATURE_DIM } from "@mailwoman/neural/gazetteer-inference"
import { afterAll, beforeEach, describe, expect, test, vi } from "vitest"

const { sessionCreateMock } = vi.hoisted(() => ({ sessionCreateMock: vi.fn() }))

vi.mock("onnxruntime-web/webgpu", () => {
	/**
	 * Captures constructor args so tests can assert on what the runner fed.
	 */
	class Tensor {
		readonly type: string
		readonly data: BigInt64Array | Float32Array
		readonly dims: readonly number[]

		constructor(type: string, data: BigInt64Array | Float32Array, dims: readonly number[]) {
			this.type = type
			this.data = data
			this.dims = dims
		}
	}

	return {
		Tensor,
		InferenceSession: { create: sessionCreateMock },
		env: { wasm: {} },
	}
})

// Shared-graph guard: the root vitest config runs `isolate: false`, so `./web-onnx-runner.ts` may
// already sit in the worker's cache — evaluated without this file's ORT mock by an earlier file
// (a cached module never re-evaluates, and vi.mock factories are only consulted at evaluation).
// Reset on the way in so the chain re-evaluates against the mock, and on the way out
// so the next file in this fork (e.g. Web-onnx-runner.test.ts, which needs the real runtime)
// never inherits our mocked ORT from the cache.
vi.resetModules()
afterAll(() => vi.resetModules())

// Import after the mock declaration + reset (vi.mock is hoisted, but keep the reading order honest).
const { WebONNXRunner } = await import("@mailwoman/neural/web-onnx-runner")

interface FedTensor {
	type: string
	data: BigInt64Array | Float32Array
	dims: readonly number[]
}

const SEQ = 128

function mockSession(
	inputNames: string[],
	opts: { localeLogits?: number[]; numLabels?: number; spanScores?: Float32Array; spanDims?: number[] } = {}
) {
	const numLabels = opts.numLabels ?? 3
	const runCalls: Array<Record<string, FedTensor>> = []

	const session = {
		inputNames,
		runCalls,
		run: vi.fn((feeds: Record<string, FedTensor>) => {
			runCalls.push(feeds)

			const output: Record<string, { data: Float32Array; dims: number[] }> = {
				logits: { data: new Float32Array(SEQ * numLabels), dims: [1, SEQ, numLabels] },
			}

			if (opts.localeLogits) {
				output.locale_logits = {
					data: new Float32Array(opts.localeLogits),
					dims: [1, opts.localeLogits.length],
				}
			}

			if (opts.spanScores && opts.spanDims) {
				output.span_scores = { data: opts.spanScores, dims: opts.spanDims }
			}

			return Promise.resolve(output)
		}),
	}

	sessionCreateMock.mockResolvedValue(session)

	return session
}

beforeEach(() => {
	sessionCreateMock.mockReset()
})

describe("WebONNXRunner feed construction (mocked session)", () => {
	test("gazetteer/anchor-trained graph + NO features provided → zero-filled structural fallback, not a throw", async () => {
		const session = mockSession([
			"input_ids",
			"attention_mask",
			"anchor_features",
			"anchor_confidence",
			"gazetteer_features",
			"gazetteer_confidence",
		])

		const runner = await WebONNXRunner.fromBytes(new Uint8Array([1]), { useWebGPU: false })

		// Pre-fix this rejected with ORT's `input 'gazetteer_features' is missing in 'feeds'`.
		const result = await runner.infer([5, 6, 7])
		expect(result.logits).toHaveLength(3)

		const feeds = session.runCalls[0]!

		expect(Object.keys(feeds).toSorted()).toEqual([
			"anchor_confidence",
			"anchor_features",
			"attention_mask",
			"gazetteer_confidence",
			"gazetteer_features",
			"input_ids",
		])

		expect(feeds.gazetteer_features!.dims).toEqual([1, SEQ, GAZETTEER_FEATURE_DIM])
		expect(feeds.gazetteer_confidence!.dims).toEqual([1, SEQ])
		expect(feeds.anchor_features!.dims).toEqual([1, SEQ, ANCHOR_FEATURE_DIM])
		// All-zero = the confidence=0 identity (the model's channel-off behavior).
		expect((feeds.gazetteer_features!.data as Float32Array).every((v) => v === 0)).toBe(true)
		expect((feeds.gazetteer_confidence!.data as Float32Array).every((v) => v === 0)).toBe(true)
		expect((feeds.anchor_features!.data as Float32Array).every((v) => v === 0)).toBe(true)
	})

	test("caller-provided gazetteer + anchor features are fed through verbatim", async () => {
		const session = mockSession([
			"input_ids",
			"attention_mask",
			"anchor_features",
			"anchor_confidence",
			"gazetteer_features",
			"gazetteer_confidence",
		])

		const runner = await WebONNXRunner.fromBytes(new Uint8Array([1]), { useWebGPU: false })

		const gazRow = [1, 0, 1, 0, 0] // country + po_box bits, lexicon featureDim = 5
		const anchorRow = Array.from({ length: ANCHOR_FEATURE_DIM }, (_, i) => (i === 0 ? 0.9 : 0))

		await runner.infer(
			[5, 6],
			{ features: [anchorRow, anchorRow.map(() => 0)], confidence: [0.9, 0] },
			{ features: [gazRow, gazRow.map(() => 0)], confidence: [1, 0] }
		)

		const feeds = session.runCalls[0]!
		const gf = feeds.gazetteer_features!.data as Float32Array
		expect(Array.from(gf.subarray(0, GAZETTEER_FEATURE_DIM))).toEqual(gazRow)
		expect(Array.from(gf.subarray(GAZETTEER_FEATURE_DIM, 2 * GAZETTEER_FEATURE_DIM))).toEqual([0, 0, 0, 0, 0])
		const gc = feeds.gazetteer_confidence!.data as Float32Array
		expect(gc[0]).toBe(1)
		expect(gc[1]).toBe(0)

		const af = feeds.anchor_features!.data as Float32Array
		expect(af[0]).toBeCloseTo(0.9)
		const ac = feeds.anchor_confidence!.data as Float32Array
		expect(ac[0]).toBeCloseTo(0.9)
	})

	test("plain graph (no gazetteer inputs) + gazetteer features provided → clue is NOT fed", async () => {
		// Mirrors the node ONNXRunner's `gazetteer && session.inputNames.includes(...)` guard:
		// feeding an undeclared input would itself crash ORT.
		const session = mockSession(["input_ids", "attention_mask"])
		const runner = await WebONNXRunner.fromBytes(new Uint8Array([1]), { useWebGPU: false })

		await runner.infer([5], undefined, { features: [[1, 0, 0, 0, 0]], confidence: [1] })

		const feeds = session.runCalls[0]!
		expect(Object.keys(feeds).toSorted()).toEqual(["attention_mask", "input_ids"])
	})

	// #1104 country channel — v6.2.0+ models declare `country_features`/`country_confidence`. The runner must feed them (real or zero-filled) exactly like the gazetteer channel, else ORT throws.
	test("country-channel graph (v6.2.0+) + NO country provided → zero-filled structural fallback, not a throw", async () => {
		const session = mockSession([
			"input_ids",
			"attention_mask",
			"anchor_features",
			"anchor_confidence",
			"gazetteer_features",
			"gazetteer_confidence",
			"country_features",
			"country_confidence",
		])

		const runner = await WebONNXRunner.fromBytes(new Uint8Array([1]), { useWebGPU: false })

		// Pre-wiring this rejected with ORT's `input 'country_features' is missing in 'feeds'` (the v263 browser break).
		const result = await runner.infer([5, 6, 7])
		expect(result.logits).toHaveLength(3)

		const feeds = session.runCalls[0]!
		expect(feeds.country_features!.dims).toEqual([1, SEQ, COUNTRY_FEATURE_DIM])
		expect(feeds.country_confidence!.dims).toEqual([1, SEQ])
		expect((feeds.country_features!.data as Float32Array).every((v) => v === 0)).toBe(true)
		expect((feeds.country_confidence!.data as Float32Array).every((v) => v === 0)).toBe(true)
	})

	test("caller-provided country features are fed through verbatim", async () => {
		const session = mockSession(["input_ids", "attention_mask", "country_features", "country_confidence"])
		const runner = await WebONNXRunner.fromBytes(new Uint8Array([1]), { useWebGPU: false })

		const countryRow = [1, 0]

		// [country_surface, country_ambiguous], featureDim = 2
		await runner.infer([5, 6], undefined, undefined, {
			features: [countryRow, countryRow.map(() => 0)],
			confidence: [1, 0],
		})

		const feeds = session.runCalls[0]!
		const cf = feeds.country_features!.data as Float32Array
		expect(Array.from(cf.subarray(0, COUNTRY_FEATURE_DIM))).toEqual(countryRow)
		expect(Array.from(cf.subarray(COUNTRY_FEATURE_DIM, 2 * COUNTRY_FEATURE_DIM))).toEqual([0, 0])
		const cc = feeds.country_confidence!.data as Float32Array
		expect(cc[0]).toBe(1)
		expect(cc[1]).toBe(0)
	})

	test("plain graph (no country inputs) + country features provided → clue is NOT fed", async () => {
		const session = mockSession(["input_ids", "attention_mask"])
		const runner = await WebONNXRunner.fromBytes(new Uint8Array([1]), { useWebGPU: false })

		await runner.infer([5], undefined, undefined, { features: [[1, 0]], confidence: [1] })

		const feeds = session.runCalls[0]!
		expect(Object.keys(feeds).toSorted()).toEqual(["attention_mask", "input_ids"])
	})

	test("locale_logits output surfaces as `localeLogits` when the graph exports it", async () => {
		mockSession(["input_ids", "attention_mask"], { localeLogits: [0.25, 0.5, 0.125, 0.125] })
		const runner = await WebONNXRunner.fromBytes(new Uint8Array([1]), { useWebGPU: false })

		const result = await runner.infer([5, 6])
		expect(result.localeLogits).toEqual([0.25, 0.5, 0.125, 0.125])
	})

	test("span_scores surfaces as `spanScores` with the (token, length, type) shape unflattened", async () => {
		// A 2-token, maxSpan=2, 3-type tensor with a known ramp, so a transposed unflatten fails loudly.
		const L = 2
		const T = 3
		const flat = new Float32Array(SEQ * L * T)

		for (let t = 0; t < SEQ; t++) {
			for (let l = 0; l < L; l++) {
				for (let ty = 0; ty < T; ty++) {
					flat[(t * L + l) * T + ty] = t * 100 + l * 10 + ty
				}
			}
		}

		mockSession(["input_ids", "attention_mask"], { spanScores: flat, spanDims: [1, SEQ, L, T] })
		const runner = await WebONNXRunner.fromBytes(new Uint8Array([1]), { useWebGPU: false })

		const result = await runner.infer([5, 6])
		expect(result.maxSpan).toBe(L)
		// Trimmed to the real token count (2), not the padded SEQ.
		expect(result.spanScores).toHaveLength(2)
		expect(result.spanScores![0]).toHaveLength(L)
		expect(result.spanScores![0]![0]).toEqual([0, 1, 2])
		expect(result.spanScores![0]![1]).toEqual([10, 11, 12])
		expect(result.spanScores![1]![0]).toEqual([100, 101, 102])
	})

	test("spanScores is absent (undefined) on pre-v3 graphs — the BIO path is unaffected", async () => {
		mockSession(["input_ids", "attention_mask"])
		const runner = await WebONNXRunner.fromBytes(new Uint8Array([1]), { useWebGPU: false })

		const result = await runner.infer([5])
		expect(result.spanScores).toBeUndefined()
		expect(result.maxSpan).toBeUndefined()
	})

	test("localeLogits is absent (undefined) on graphs without the locale head", async () => {
		mockSession(["input_ids", "attention_mask"])
		const runner = await WebONNXRunner.fromBytes(new Uint8Array([1]), { useWebGPU: false })

		const result = await runner.infer([5])
		expect(result.localeLogits).toBeUndefined()
	})

	test("inputNames is null before the session exists and populated after", async () => {
		mockSession(["input_ids", "attention_mask", "gazetteer_features", "gazetteer_confidence"])
		const runner = await WebONNXRunner.fromBytes(new Uint8Array([1]), { useWebGPU: false })
		expect(runner.inputNames).toBeNull()
		await runner.infer([5])
		expect(runner.inputNames).toContain("gazetteer_features")
	})
})

describe("defaultGazetteerLexiconURL", () => {
	test("derives the sibling anchor-lexicon-v1.json beside the model URL", async () => {
		const { defaultGazetteerLexiconURL } = await import("@mailwoman/neural/web-loader")

		expect(defaultGazetteerLexiconURL("https://public.mailwoman.ai/mailwoman/en-us/v4.4.0/model.onnx")).toBe(
			"https://public.mailwoman.ai/mailwoman/en-us/v4.4.0/anchor-lexicon-v1.json"
		)

		// Relative URLs stay relative.
		expect(defaultGazetteerLexiconURL("/static/mailwoman/model.onnx")).toBe("/static/mailwoman/anchor-lexicon-v1.json")
	})
})

describe("defaultCountryLexiconURL", () => {
	test("derives the sibling country-surface-lexicon-v1.json beside the model URL", async () => {
		const { defaultCountryLexiconURL } = await import("@mailwoman/neural/web-loader")

		expect(defaultCountryLexiconURL("https://public.mailwoman.ai/mailwoman/en-us/v6.2.0/model.onnx")).toBe(
			"https://public.mailwoman.ai/mailwoman/en-us/v6.2.0/country-surface-lexicon-v1.json"
		)

		expect(defaultCountryLexiconURL("/static/mailwoman/model.onnx")).toBe(
			"/static/mailwoman/country-surface-lexicon-v1.json"
		)
	})
})

describe("cross-runner parity (#727 span read)", () => {
	test("the web runner's span unflatten matches the node ONNXRunner's, byte for byte", async () => {
		// The (token, length, type) unflatten is duplicated in neural/onnx-runner.ts
		// and here — two hosts, one interface.
		// A silent divergence would make the browser decode a transposed tensor
		// and mis-tag every span (the PLACETYPE_ORDER failure mode, one layer down).
		// This pins them: the same flat buffer must produce the same nested array on both sides.
		const SEQ_LEN = 2
		const L = 3
		const T = 4
		const flat = new Float32Array(SEQ * L * T)

		for (let i = 0; i < flat.length; i++) {
			flat[i] = i * 0.5
		}

		mockSession(["input_ids", "attention_mask"], { spanScores: flat, spanDims: [1, SEQ, L, T] })
		const web = await WebONNXRunner.fromBytes(new Uint8Array([1]), { useWebGPU: false })
		const webResult = await web.infer([5, 6])

		// The node runner's read, replicated from neural/onnx-runner.ts.
		// If that file's loop changes and this expectation still passes,
		// the two hosts have diverged — which is the point.
		const expected: number[][][] = []

		for (let t = 0; t < SEQ_LEN; t++) {
			const perLength: number[][] = []

			for (let l = 0; l < L; l++) {
				const row: number[] = []

				for (let ty = 0; ty < T; ty++) {
					row.push(flat[(t * L + l) * T + ty]!)
				}

				perLength.push(row)
			}

			expected.push(perLength)
		}

		expect(webResult.spanScores).toEqual(expected)
	})
})
