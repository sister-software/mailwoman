/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Every shipped `pair-index-<country>.bin` must agree with the model card that describes it.
 *
 *   A model card is what a consumer, the release preflight and a future maintainer all read to learn
 *   what an artifact is. Nothing else compares the two, and a card can drift across several
 *   increments without any check noticing — leaving it not merely absent but confidently wrong. The
 *   artifact is the arbiter here. the card is graded against it.
 *
 *   what IT checks, and what IT deliberately does not. Pair count and the calibrated `delta` /
 *   `transitionBeta` are compared, because those are properties of the content and a rebuild from
 *   the same sources reproduces them exactly. The card's `md5` is not compared: a PIX1 header
 *   embeds `buildDate`, so identical sources produce different bytes on every rebuild, and asserting
 *   on it would fail constantly for a reason that is not a defect. The md5 documents the artifact
 *   staged for a release. the release-side check in `packages/release-kit/lib/release/verify-metadata.ts` is where
 *   staged bytes get checked.
 *
 *   Skips per-package when the binary is absent — these are derived artifacts, gitignored and built
 *   by each package's `link-dev-weights.ts`, so a lean checkout legitimately has none.
 */

import { readLocalBuffer, readLocalJSONFile, pathExists } from "@mailwoman/core/fs/readers"
import { parseJSONStrict } from "@mailwoman/core/json"
import { repoRootPath } from "@mailwoman/core/paths"
import { describe, expect, test } from "vitest"

/**
 * Which weights package ships which country's index, and where that package's card describes it.
 *
 * The card key is spelled out per package rather than discovered, because the naming is
 * genuinely inconsistent across the four (`us_artifacts` / `fr_artifacts` / `gb_artifacts`
 * / `nz_artifacts`, each with its own `pair_index_<cc>_bin` child).
 * A guard that guessed the key would silently pass on a card whose block had been renamed
 * or dropped — the exact failure it exists to catch — so the mapping is explicit
 * and a missing block is a failure rather than a skip.
 */
const PACKAGES = [
	{ pkg: "neural-weights-en-us", country: "us", cardKeys: ["us_artifacts", "pair_index_us_bin"] },
	{ pkg: "neural-weights-fr-fr", country: "fr", cardKeys: ["fr_artifacts", "pair_index_fr_bin"] },
	{ pkg: "neural-weights-en-gb", country: "gb", cardKeys: ["gb_artifacts", "pair_index_gb_bin"] },
	{ pkg: "neural-weights-de-de", country: "de", cardKeys: ["de_artifacts", "pair_index_de_bin"] },
	{ pkg: "neural-weights-en-in", country: "in", cardKeys: ["in_artifacts", "pair_index_in_bin"] },
	{ pkg: "neural-weights-es-es", country: "es", cardKeys: ["es_artifacts", "pair_index_es_bin"] },
	{ pkg: "neural-weights-it-it", country: "it", cardKeys: ["it_artifacts", "pair_index_it_bin"] },
	{ pkg: "neural-weights-en-nz", country: "nz", cardKeys: ["nz_artifacts", "pair_index_nz_bin"] },
] as const

const BIN_EXISTS = new Map<string, boolean>()

for (const { pkg, country } of PACKAGES) {
	BIN_EXISTS.set(pkg, await pathExists(String(repoRootPath(pkg, `pair-index-${country}.bin`))))
}

interface PairIndexFacts {
	pairs: number
	delta: number
	transitionBeta: number | undefined
	parentDelta: number | undefined
	bytes: number
}

/**
 * Read a PIX1 binary's header and entry count without constructing a resolver.
 *
 * This test cares about what the file says, so it deliberately does not route
 * through the reader that a bug could also affect.
 */
async function readPairIndexFacts(path: string): Promise<PairIndexFacts> {
	const bytes = await readLocalBuffer(path)
	const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength)
	// "PIX1" little-endian.
	const MAGIC = 0x31_58_49_50

	expect(view.getUint32(0, true), `${path} is not a PIX1 artifact`).toBe(MAGIC)

	const headerLen = view.getUint32(4, true)

	const header = parseJSONStrict<{
		delta: number
		transitionBeta?: number
		parentDelta?: number
	}>(bytes.subarray(8, 8 + headerLen).toString("utf8"))

	return {
		pairs: view.getUint32(8 + headerLen, true),
		delta: header.delta,
		transitionBeta: header.transitionBeta,
		parentDelta: header.parentDelta,
		bytes: bytes.length,
	}
}

describe("pair-index ↔ model-card parity", () => {
	for (const { pkg, country, cardKeys } of PACKAGES) {
		const binPath = String(repoRootPath(pkg, `pair-index-${country}.bin`))
		const cardPath = String(repoRootPath(pkg, "model-card.json"))

		test.skipIf(!BIN_EXISTS.get(pkg))(`${pkg}: the card describes the artifact on disk`, async () => {
			const card = await readLocalJSONFile<Record<string, unknown>>(cardPath)
			const [outerKey, innerKey] = cardKeys
			const outer = card[outerKey] as Record<string, unknown> | undefined
			const block = outer?.[innerKey] as Record<string, unknown> | undefined

			expect(
				block,
				`${cardPath} has no ${outerKey}.${innerKey} block — a shipped artifact must be described`
			).toBeDefined()

			const facts = await readPairIndexFacts(binPath)

			// Pair count is the required one: it is what changed, unnoticed, across three increments.
			expect(block!.pairs, `${pkg}: card pairs != artifact pairs — rebuild the artifact or update the card`).toBe(
				facts.pairs
			)

			// The calibrated magnitudes ride the header.
			// A card claiming a delta the binary does not carry would misdescribe the
			// shipped behaviour rather than just the shipped size.
			const cardDelta = String(block!.delta_calibration ?? "")

			expect(cardDelta, `${pkg}: card delta_calibration does not mention the artifact's δ=${facts.delta}`).toContain(
				`δ=${facts.delta}`
			)

			if (facts.transitionBeta !== undefined) {
				expect(
					`${cardDelta}${String(block!.transition_beta ?? "")}`,
					`${pkg}: artifact carries transitionBeta=${facts.transitionBeta} but the card does not record it`
				).toContain(String(facts.transitionBeta))
			}

			// The whole-edge parent bias (#46) is default-on for the locales that have a board,
			// and off (no header key) for the ones that don't.
			// Both directions are graded: a card that omits a shipped parentDelta misdescribes
			// the behaviour, and a card that claims one the artifact lacks is worse.
			// It reads as though the D-rule's per-locale check had been cleared when it hasn't.
			// The assertion spells out `parentDelta=<n>` rather than the bare number
			// because δ and β are both 5 today, so a substring match on "5" would pass
			// on a card that never mentioned the parent at all.
			const parentClaim = `parentDelta=${facts.parentDelta}`

			if (facts.parentDelta === undefined) {
				expect(
					cardDelta,
					`${pkg}: card claims a parentDelta but the artifact carries none — the parent bias is OFF for this locale`
				).not.toContain("parentDelta=")
			} else {
				expect(
					cardDelta,
					`${pkg}: artifact carries ${parentClaim} but the card's delta_calibration does not record it`
				).toContain(parentClaim)
			}
		})
	}
})
