/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   The authority-designation route, observation-only: after the resolver has produced a coordinate, an
 *   authority's own designation for that coordinate is recorded beside the answer — the zone the
 *   authority's map assigns, the product and version it was read from, and the coverage record stating
 *   that the authority made a determination there.
 *
 *   the route reads. IT never answers. It takes a finished coordinate and returns a record. Nothing here
 *   is consulted while an answer is being chosen, no candidate is read, no result is added, removed or
 *   re-ordered, and no abstain is reached or avoided because of it. A geocode with the route configured is
 *   the same geocode plus one advisory, which is a statement about construction rather than about a
 *   measurement.
 *
 *   presence is the switch, and IT is A layer path. There is no boolean: a boolean would make the caller's
 *   factory construct the reader itself and put a sealed layer open on the default construction path. A
 *   session resolves the layer path, opens it if the file is there, and hands the route in. a session that
 *   finds no file hands in nothing and is byte-identical to one built before this route existed.
 *
 *   what IT reports, and what IT refuses TO. Three readings come out of the layer and only two of them
 *   reach a caller. A `designated` reading carries the authority's zone code. A `designated_absence`
 *   carries the authority's own definition of the absent case — for the EA product that is Flood Zone 1.
 *   The Planning Practice Guidance defines Flood Zone 1 as land outside Zones 2 and 3. An empty answer
 *   inside England is therefore a designation rather than a gap. An `unknown` reading raises nothing: outside the
 *   authority's footprint there is no coverage row, and a marker there would be an advisory about a
 *   determination nobody made.
 *
 *   the observation is about the MAP, never about the property. The EA states that its data is "not
 *   suitable for showing whether an individual property is at risk of flooding". So the wording reports
 *   which zone the authority's map assigns at the location — a fact about the map — and the product's own
 *   exclusions ride on every observation, because a caller cannot see from a zone code that the answer is
 *   silent about surface water, groundwater and defended-area residual risk.
 */

import {
	FloodReadingKind,
	FloodZoneLookup,
	type FloodContainmentPath,
	type FloodLayerIdentity,
	type FloodZoneReading,
} from "@mailwoman/flood"

import {
	createDesignationRoute,
	describeCoverage,
	describeLayerProvenance,
	observationCoverageRecord,
	observationLayerRecord,
	type ObservationCoverageRecord,
	type ObservationLayerRecord,
} from "#observations/layer-record"

/**
 * One authority designation, recorded beside an answer.
 *
 * Everything a reader needs to check the claim is here: which authority, which product
 * and vintage, the code in that authority's own vocabulary with the authority's own
 * definition of it, how containment was established, and the coverage record — cell,
 * basis, completeness — that licenses an absence reading.
 * A reader holding the code alone cannot tell whether it was earned.
 */
export interface AuthorityDesignationObservation {
	/**
	 * `designated` or `designated_absence`.
	 *
	 * Never `unknown`: that reading produces no observation.
	 */
	reading: FloodReadingKind
	/**
	 * The authority's code, verbatim.
	 *
	 * Absent on a designated absence, which the authority represents by publishing nothing.
	 */
	code?: string
	/**
	 * The authority's own words for the answered code, and where they are published.
	 */
	definition?: { code: string; label: string; definition: string; definitionURL: string }
	/**
	 * The polygon the ray cast matched, where one did.
	 */
	areaID?: string
	containment: FloodContainmentPath
	/**
	 * The coverage side of the claim, present whenever the location falls inside the authority's footprint.
	 */
	coverage?: ObservationCoverageRecord
	/**
	 * The index cell probed.
	 */
	indexCellIndex: string
	/**
	 * The authority's own statement of what its map covers, and where it is published.
	 */
	extent: { authority: string; statement: string; statementURL: string }
	/**
	 * What the product excludes, in the authority's own words.
	 */
	limits: ReadonlyArray<string>
	layer: ObservationLayerRecord
	databasePath: string
	coordinate: { latitude: number; longitude: number }
}

/**
 * Why a coordinate produced no observation.
 *
 * Every one of these is a silence the route owes an account of.
 * An unnamed silence and a silence for the right reason read identically on a receipt.
 */
export const DESIGNATION_REFUSALS = [
	/**
	 * The geocode reached no coordinate, so there is nothing to ask the layer about.
	 */
	"no_coordinate",
	/**
	 * The layer holds no coverage row for the location. Outside the authority's footprint, which is unknown and never a low-hazard reading.
	 */
	"outside_authority_footprint",
] as const

export type DesignationRefusal = (typeof DESIGNATION_REFUSALS)[number]

/**
 * What the route decided about one coordinate: an observation, or a named silence.
 */
export type DesignationDecision =
	| { fired: true; observation: AuthorityDesignationObservation }
	| { fired: false; refusal: DesignationRefusal }

export interface AuthorityDesignationRoute extends Disposable {
	identity: FloodLayerIdentity
	/**
	 * Decide one resolved coordinate.
	 *
	 * Pure with respect to the pipeline: it reads the layer and returns a record.
	 *
	 * `null` and `undefined` are both accepted because a geocode result has nullable `lat`/`lon`.
	 * A caller that had to narrow them first would be narrowing on this route's behalf,
	 * and a coordinate-less answer is a named refusal here rather than a caller's problem.
	 */
	observe: (latitude: number | null | undefined, longitude: number | null | undefined) => DesignationDecision
}

export interface AuthorityDesignationRouteOptions {
	/**
	 * The sealed layer to read.
	 *
	 * Required: there is no default layer, and a route that guessed one would report
	 * a designation from an authority nobody asked about.
	 */
	databasePath: string
}

/**
 * Build the route against one sealed layer.
 *
 * Everything that would make the route answer a well-formed wrong thing is
 * refused by the reader's own constructor — a manifest naming a different layer,
 * a coverage table with no rows, a missing footprint row.
 * Each of those would otherwise present as a route that simply never fires, which on a
 * receipt is indistinguishable from a region the authority genuinely has not mapped.
 */
export function createAuthorityDesignationRoute(options: AuthorityDesignationRouteOptions): AuthorityDesignationRoute {
	const lookup = new FloodZoneLookup({ databasePath: options.databasePath })

	return createDesignationRoute(lookup, {
		read: (latitude, longitude) => lookup.lookup(latitude, longitude),
		refusalFor: (reading) => (reading.kind === FloodReadingKind.Unknown ? "outside_authority_footprint" : undefined),
		toObservation: (reading, latitude, longitude) =>
			toObservation(reading, lookup.identity, latitude, longitude, options.databasePath),
	})
}

/**
 * Build the observation for a reading the refusal check let through.
 */
function toObservation(
	reading: FloodZoneReading,
	identity: FloodLayerIdentity,
	latitude: number,
	longitude: number,
	databasePath: string
): AuthorityDesignationObservation {
	const { manifest, extent } = identity

	return {
		reading: reading.kind,
		...(reading.zoneCode ? { code: reading.zoneCode } : {}),
		...(reading.definition ? { definition: reading.definition } : {}),
		...(reading.areaID ? { areaID: reading.areaID } : {}),
		containment: reading.containment,
		...observationCoverageRecord(reading.coverage),
		indexCellIndex: reading.indexCellIndex,
		extent: {
			authority: extent.authority,
			statement: extent.statement,
			statementURL: extent.statementURL,
		},
		limits: reading.limits,
		layer: observationLayerRecord(manifest),
		databasePath,
		coordinate: { latitude, longitude },
	}
}

/**
 * What the authority's map assigns, in one wording — shared by the one-line
 * description and the marker message.
 */
export function floodZoneAssignmentClause(observation: AuthorityDesignationObservation): string {
	return observation.code
		? `assigns ${observation.code}`
		: `assigns no zone, which its own guidance defines as ${observation.definition?.label ?? "the absent case"}`
}

/**
 * One line a reader can check the claim from, with the authority and its vintage on it.
 */
export function describeAuthorityDesignation(observation: AuthorityDesignationObservation): string {
	return (
		`${observation.extent.authority}'s map ${floodZoneAssignmentClause(observation)} at ${observation.coordinate.latitude}, ${observation.coordinate.longitude} ` +
		`(${observation.containment}); ${describeCoverage(observation.coverage, { completeness: true })}; ${describeLayerProvenance(observation.layer)}`
	)
}
