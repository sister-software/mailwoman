/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   note(de-shell): forwarding shim. The both-order order-robustness harness now lives at
 *   `mailwoman/eval-harness/de-order-eval.ts` and `promotion-eval.ts` calls it IN-process. This shim
 *   keeps standalone invocation working unchanged. Output is byte-identical because the module owns
 *   every printed line. Do not add logic here.
 */

import { runIfScript } from "@mailwoman/core/scripting"
import { parseArguments } from "@mailwoman/core/scripting/arguments"

import { deOrderEval } from "#eval-harness/de-order-eval"

async function main(): Promise<void> {
	// strict parseArgs — the original switch errored on unknown args.
	// Parity preserved.
	let values: Record<string, string | boolean | undefined>

	try {
		values = parseArguments({
			options: {
				"anchor-lookup": { type: "string" },
				card: { type: "string" },
				limit: { type: "string" },
				"lookup-memo": { type: "boolean" },
				model: { type: "string" },
				out: { type: "string" },
				"profile-dir": { type: "string" },
				tokenizer: { type: "string" },
			},
		}).values
	} catch (error) {
		console.error(`unknown arg: ${error instanceof Error ? error.message : error}`)

		process.exitCode = 1

		return
	}

	const result = await deOrderEval({
		model: values["model"] as string | undefined,
		card: values["card"] as string | undefined,
		tokenizer: values["tokenizer"] as string | undefined,
		anchorLookup: values["anchor-lookup"] as string | undefined,
		out: values["out"] as string | undefined,
		limit: values["limit"] ? Number(values["limit"]) : undefined,
		lookupMemo: values["lookup-memo"] === true,
		profileDirectory: values["profile-dir"] as string | undefined,
	})

	// Parity with the old `need --model and --card` → exit 1.
	if (!result.ok) {
		process.exitCode = 1
	}
}

runIfScript(import.meta, main)
