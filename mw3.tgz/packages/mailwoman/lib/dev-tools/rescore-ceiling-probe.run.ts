import { dataRootPath } from "@mailwoman/core/data-root"
/**
 * @copyright Sister Software · @license AGPL-3.0 · @author Teffen Ellis, et al.
 *
 *   #370 rescore-ceiling probe — sizes how much of the unresolved tail a parse<->resolve rescoring
 *   loop could recover, vs a true gazetteer coverage gap. For each coord-golden row: parse (the shipped
 *   v4.13.0 model) -> resolveTree -> resolved? For each unresolved row, ask whether the gold locality is
 *   in the gazetteer (findPlace) and what the model emitted, and bucket the failure:
 *     - swap     : gold is in the gazetteer and the model emitted a different (wrong) locality token
 *                  -> a constrained rescore that swaps in the gold token recovers it. The clearest #370 win.
 *     - needsK   : gold is in the gazetteer and the model emitted no locality -> only a K-best decode
 *                  that surfaces the gold token could recover it (harder).
 *     - emitUnres: model emitted the gold locality but resolveTree still didn't resolve -> a resolver
 *                  ranking/country-filter issue rather than a rescore opportunity.
 *     - covGap   : gold not in the gazetteer -> rescoring can't help. it's a coverage gap.
 *   recoverable = swap + needsK = #370's ceiling. Same resolver for baseline + gold-check (consistent).
 *
 *   Run: node packages/mailwoman/lib/dev-tools/rescore-ceiling-probe.run.ts [--model out/v191/model.onnx] [--n 150]
 */
import { decodeAsJSON, firstNodeWhere } from "@mailwoman/core/decoder"
import { pathExists } from "@mailwoman/core/fs/readers"
import { parseArguments } from "@mailwoman/core/scripting/arguments"
import { percentile } from "@mailwoman/core/stats"
import { createWOFResolver } from "@mailwoman/resolver"
import { haversineKm } from "@mailwoman/spatial"
import { resolvePath } from "path-ts"
import { JSONSpliterator } from "spliterator"

// Loose scan parity with the retired scripts/lib/cli-args helpers: unknown flags tolerated.
const { values: rawValues } = parseArguments({
	options: { model: { type: "string" }, n: { type: "string" } },
	strict: false,
	allowPositionals: true,
})

// Typed view: strict:false loosens TS inference, but declared options always parse to their schema type.
const values = rawValues as { model?: string; n?: string }
const TOK = dataRootPath("models", "tokenizer", "v0.6.0-a0", "tokenizer.model")
const CARD = "packages/neural-weights-en-us/model-card.json"
const ANCHOR = dataRootPath("anchor", "pilot-anchor-lookup.json")
const WOF = dataRootPath("wof", "admin-global-priority.db")
const MODEL = values["model"] || "out/v191/model.onnx"
const N = Number(values["n"] || "150")

const LOCALES: [string, string][] = [
	["IT", "data/eval/external/oa-it-coord-150.jsonl"],
	["PT", "data/eval/external/oa-pt-coord-150.jsonl"],
	["PL", "data/eval/external/oa-pl-coord-150.jsonl"],
	["AT", "data/eval/external/oa-at-coord-150.jsonl"],
	["CZ", "data/eval/external/oa-cz-coord-150.jsonl"],
	["FR", "data/eval/external/oa-fr-coord-150.jsonl"],
	["AU", "data/eval/external/oa-au-coord-150.jsonl"],
]

async function main() {
	const { createScorer } = await import("@mailwoman/neural/scorer")
	const { WOFSQLitePlaceLookup } = await import("@mailwoman/resolver-wof-sqlite")
	using lookup = new WOFSQLitePlaceLookup({ databasePath: resolvePath(WOF) })
	const resolver = createWOFResolver(lookup)

	const model = await createScorer({
		modelPath: MODEL,
		tokenizerPath: TOK,
		modelCardPath: CARD,
		anchorLookupPath: ANCHOR,
		strict: true,
		tier: "server",
	})

	console.log(`loc | n   res  unres | swap needsK emitUnres covGap | swapKm p50/p90 (top1·best5)`)

	const T = { n: 0, res: 0, unres: 0, swap: 0, needsK: 0, emitUn: 0, cov: 0 }
	// falsifier accumulators: great-circle error (km) from the postcode-disambiguated
	// gold-locality resolution to truth, over the swap cases. top1 = resolver's ranked choice.
	// best5 = the ceiling if same-name disambiguation picks the right candidate from the top 5.
	const swapTop1: number[] = []
	const swapBest5: number[] = []

	for (const [cc, file] of LOCALES) {
		if (!(await pathExists(file))) {
			console.log(`${cc}: golden missing — skipped`)

			continue
		}

		const s = { n: 0, res: 0, unres: 0, swap: 0, needsK: 0, emitUn: 0, cov: 0 }
		const sT1: number[] = []
		const sB5: number[] = []

		for await (const row of JSONSpliterator.fromAsync<{
			raw: string
			components?: Record<string, string>
			lat: number
			lon: number
		}>(file).take(N)) {
			s.n++
			const tree = await model.parse(row.raw, { postcodeRepair: true })
			const r = await resolver.resolveTree(tree, { defaultCountry: cc })

			if (firstNodeWhere(r.roots, (n) => Boolean(n.placeID?.startsWith("wof:")))) {
				s.res++

				continue
			}

			s.unres++
			const emitted = ((decodeAsJSON(tree) as Record<string, string>).locality ?? "").toString().trim()
			const gold = ((row.components?.locality as string) ?? "").toString().trim()
			const goldCands = gold ? await lookup.findPlace({ text: gold, country: cc, limit: 5 }) : []

			if (!goldCands.length) {
				s.cov++
			} else if (emitted && emitted.toLowerCase() !== gold.toLowerCase()) {
				s.swap++

				// falsifier: resolve the gold locality with the row's postcode
				// (what the rescore keeps as an anchor) and measure great-circle to truth.
				// p50 < 10km → the swap recovers a real coordinate.
				// Scatter → the gold name resolves to a same-name collision (a label-F1 mirage, the #685 trap).
				// (0,0) placeholders are dropped — WOF ships them on some rows.
				const tLat = Number(row.lat),
					tLon = Number(row.lon)

				if (Number.isFinite(tLat) && Number.isFinite(tLon)) {
					const pc = ((row.components?.postcode ?? row.components?.postal_code ?? "") as string).toString().trim()
					const dis = pc ? await lookup.findPlace({ text: gold, country: cc, postcode: pc, limit: 5 }) : goldCands

					// findPlace candidates carry lat/lon (not the ResolvedPlace latitude/longitude).
					const dists = dis
						.filter((c) => Number.isFinite(c.lat) && Number.isFinite(c.lon) && (c.lat !== 0 || c.lon !== 0))
						.map((c) => haversineKm(tLat, tLon, c.lat, c.lon))

					if (dists.length) {
						sT1.push(dists[0]!)
						sB5.push(Math.min(...dists))
					}
				}
			} else if (!emitted) {
				s.needsK++
			} else {
				s.emitUn++
			}
		}

		const swapKm = sT1.length
			? `${(percentile(sT1, 50) ?? Number.NaN).toFixed(1)}/${(percentile(sT1, 90) ?? Number.NaN).toFixed(0)} · ${(percentile(sB5, 50) ?? Number.NaN).toFixed(1)}/${(percentile(sB5, 90) ?? Number.NaN).toFixed(0)} (n${sT1.length})`
			: "—"

		console.log(
			`${cc.padEnd(3)} | ${String(s.n).padEnd(3)} ${String(s.res).padEnd(3)}  ${String(s.unres).padEnd(4)} | ${String(s.swap).padEnd(3)}  ${String(s.needsK).padEnd(5)}  ${String(s.emitUn).padEnd(8)}  ${String(s.cov).padEnd(2)} | ${swapKm}`
		)

		for (const k of Object.keys(s) as (keyof typeof s)[]) {
			T[k] += s[k]
		}

		swapTop1.push(...sT1)
		swapBest5.push(...sB5)
	}

	const recoverable = T.swap + T.needsK

	console.log(`ALL | n=${T.n} res=${T.res} unres=${T.unres}`)
	console.log(
		`\n#370 CEILING: of ${T.unres} unresolved → recoverable (gold-in-gazetteer) = ${recoverable} ` +
			`(${((100 * recoverable) / Math.max(T.unres, 1)).toFixed(0)}% of the tail) [swap=${T.swap}, needsK=${T.needsK}]\n` +
			`              emitted-but-unresolved (resolver-side) = ${T.emitUn}\n` +
			`              coverage-gap (rescore can't help)      = ${T.cov} (${((100 * T.cov) / Math.max(T.unres, 1)).toFixed(0)}%)`
	)

	// falsifier verdict (DeepSeek-specified): does the gold-locality swap recover a real coordinate?
	const t1p50 = percentile(swapTop1, 50) ?? Number.NaN,
		t1p90 = percentile(swapTop1, 90) ?? Number.NaN,
		b5p50 = percentile(swapBest5, 50) ?? Number.NaN,
		b5p90 = percentile(swapBest5, 90) ?? Number.NaN

	const verdict = !swapTop1.length
		? "INCONCLUSIVE — no swap cases with a truth coord + resolvable gold"
		: t1p50 < 10
			? "PASS (top-1) — the postcode-disambiguated gold locality lands <10 km p50; build the span-rescore"
			: b5p50 < 10
				? "PASS (best-5 only) — the right candidate is in the top 5 but ranking misses it; the rescore NEEDS the postcode-anchor disambiguation, not just the name swap"
				: "FAIL — gold name resolves far from truth (same-name-collision mirage / #685 trap); a bare span-rescore would chase label-F1, not coordinates"

	console.log(
		`\n#370 FALSIFIER (swap-case gold→truth great-circle, n=${swapTop1.length}):\n` +
			`   top-1 (resolver-ranked, postcode-disambiguated): p50 ${t1p50.toFixed(1)} km · p90 ${t1p90.toFixed(0)} km\n` +
			`   best-of-5 (ceiling if disambiguation is perfect):  p50 ${b5p50.toFixed(1)} km · p90 ${b5p90.toFixed(0)} km\n` +
			`   → ${verdict}`
	)
}

await main()
