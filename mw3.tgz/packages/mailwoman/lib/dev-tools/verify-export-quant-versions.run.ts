/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Verify the local export/quant toolchain matches the pinned training-image set (#480).
 *
 *   Why this exists: the set was once unpinned (`>=`) and drifted between v0.9.3 and v0.9.7, silently
 *   breaking int8 quant for Safari WebGPU (the value_info/opset incident — see
 *   project-v4.1.0-release + the pinned block in corpus-python/launch/app.py, which is the source
 *   OF truth this script reads). Run before any local quantize. CI-able (exit 1 on mismatch). A
 *   bumped dep here is never a free upgrade — it must re-prove the Safari int8 graph (opset <= 17,
 *   value_info strip) end to end.
 *
 *   Plain-node tool-script (no env banner, no zx). Run: node packages/mailwoman/lib/dev-tools/verify-export-quant-versions.run.ts
 */

import { pathExists, readLocalTextFile } from "@mailwoman/core/fs/readers"
import { runFileSync } from "@mailwoman/core/process"

import { $public } from "#env"

const PYTHON = $public.PYTHON ?? "corpus-python/.venv/bin/python"
const TRAIN_REMOTE = "corpus-python/launch/app.py"

if (!(await pathExists(PYTHON))) {
	console.error(`✗ ${PYTHON} not found — create the corpus-python venv first`)

	process.exit(2)
}

/**
 * Local quantize needs only the quant subset (onnx, onnxruntime) — export runs on Modal,
 * where the full image pins apply.
 *
 * Export-side packages absent locally are a warning.
 * Present-but-mismatched is a failure either way (a wrong version is worse than a missing one).
 */
const QUANT_PKGS = new Set(["onnx", "onnxruntime"])

/**
 * Read the pinned `"pkg==1.2.3"` literals straight out of the Modal training-image source of truth.
 */
async function pinnedVersions(): Promise<Array<[string, string]>> {
	const src = await readLocalTextFile(TRAIN_REMOTE)
	const matches = src.matchAll(/"(torch|transformers|onnx|onnxruntime|onnxscript)==([0-9.]+)"/g)

	return [...matches].map((m) => [m[1], m[2]] as [string, string])
}

function installedVersion(pkg: string): string {
	try {
		// stderr → "ignore" mirrors the bash `2>/dev/null`: a not-installed package throws
		// PackageNotFoundError with a noisy traceback we deliberately swallow (it's the missing path).
		return runFileSync(PYTHON, ["-c", `import importlib.metadata as m; print(m.version('${pkg}'))`], {
			encoding: "utf8",
			stdio: ["ignore", "pipe", "ignore"],
		}).trim()
	} catch {
		return "MISSING"
	}
}

let fail = false

for (const [pkg, pinned] of await pinnedVersions()) {
	const actual = installedVersion(pkg)

	if (actual === pinned) {
		console.error(`✓ ${pkg} ${actual}`)
	} else if (actual === "MISSING" && !QUANT_PKGS.has(pkg)) {
		console.error(`⚠ ${pkg}: not installed locally (export-side; required on Modal, fine here)`)
	} else {
		console.error(`✗ ${pkg}: local=${actual} pinned=${pinned}`)

		fail = true
	}
}

if (fail) {
	console.error("")
	console.error(`Toolchain drift vs ${TRAIN_REMOTE} — do NOT quantize for release with this env.`)

	process.exit(1)
}

console.error("toolchain matches the pinned training-image set")
