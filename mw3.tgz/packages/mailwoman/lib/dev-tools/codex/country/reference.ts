/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Regenerate `codex/country/reference-data.ts` — the per-country calling code (E.164) + currency
 *   (ISO 4217) table — from mledoze/countries (https://github.com/mledoze/countries, ODbL). The
 *   output is committed. this tool makes it reproducible (provenance), not a hand-typed dictionary.
 *
 *   Calling-code rule: mledoze splits the code as `idd.root` + `idd.suffixes`. For most countries a
 *   single suffix completes the code (GB `+4` + `4` = 44); nanp members share root `+1` with their
 *   area code as the suffix, so they map to 1.
 *
 *   Usage: mailwoman dev generate country-reference
 */

import { APIClient, pluckResponseData } from "@mailwoman/core/api"
import { writeLocalTextFile } from "@mailwoman/core/fs/writers"
import { prettyJSON } from "@mailwoman/core/json"
import { resolvePackagePath } from "@mailwoman/core/module/resolvers"

const SOURCE = "https://raw.githubusercontent.com/mledoze/countries/master/countries.json"

/**
 * The committed output path, anchored at the `@mailwoman/codex` package root rather than at
 * this module, so it names the same file from the source tree, `out/`, and a published tarball.
 *
 * The codegen is repo-only: it rewrites codex's checked-in source, which is why the target is a `lib/` path.
 */
const DEFAULT_OUT = resolvePackagePath("@mailwoman/codex", "lib", "country", "reference-data.ts")

/**
 * A single country record from mledoze/countries, narrowed to the fields this tool reads.
 */
interface MledozeCountry {
	cca2?: string
	idd?: { root?: string; suffixes?: string[] }
	currencies?: Record<string, { name?: string; symbol?: string }>
}

/**
 * The emitted per-country reference row.
 */
interface CountryReferenceEntry {
	callingCode?: number
	currency?: { isoCode: string; name?: string; symbol?: string }
}

/**
 * Options for {@linkcode generateCountryReference}.
 */
export interface GenerateCountryReferenceOptions {
	/**
	 * Output path override.
	 *
	 * Default: `codex/country/reference-data.ts` (the committed table).
	 */
	out?: string
}

/**
 * Summary returned by {@linkcode generateCountryReference}.
 */
export interface GenerateCountryReferenceSummary {
	countries: number
	outPath: string
}

function callingCode(country: MledozeCountry): number | undefined {
	const root = (country.idd?.root ?? "").replace("+", "")
	const suffixes = country.idd?.suffixes ?? []

	if (!root) return undefined

	if (root === "1") return 1

	if (suffixes.length === 1) {
		const n = Number(root + suffixes[0])

		return Number.isFinite(n) ? n : undefined
	}

	const n = Number(root)

	return Number.isFinite(n) ? n : undefined
}

const serialize = (o: CountryReferenceEntry): string =>
	prettyJSON(o)
		.replaceAll('"isoCode"', "isoCode")
		.replaceAll('"callingCode"', "callingCode")
		.replaceAll('"currency"', "currency")
		.replaceAll('"name"', "name")
		.replaceAll('"symbol"', "symbol")

/**
 * Fetch mledoze/countries and regenerate the committed `COUNTRY_REFERENCE` table.
 */
export async function generateCountryReference(
	options: GenerateCountryReferenceOptions = {},
	report?: (line: string) => void
): Promise<GenerateCountryReferenceSummary> {
	const outPath = options.out ?? DEFAULT_OUT

	const countries = await new APIClient({ displayName: "mledoze-countries", retry: true })
		.fetch<MledozeCountry[]>({ url: SOURCE })
		.then(pluckResponseData)

	const rows: Record<string, CountryReferenceEntry> = {}

	for (const country of countries) {
		const alpha2 = country.cca2

		if (!alpha2) continue
		const entry: CountryReferenceEntry = {}
		const cc = callingCode(country)

		if (cc != null) {
			entry.callingCode = cc
		}

		const currencyCodes = Object.keys(country.currencies ?? {}).toSorted()

		if (currencyCodes.length) {
			const code = currencyCodes[0]!
			const info = country.currencies![code] ?? {}
			entry.currency = { isoCode: code }

			if (info.name) {
				entry.currency.name = info.name
			}

			if (info.symbol) {
				entry.currency.symbol = info.symbol
			}
		}

		if (Object.keys(entry).length) {
			rows[alpha2] = entry
		}
	}

	const body = Object.keys(rows)
		.toSorted()
		.map((k) => `\t${k}: ${serialize(rows[k]!)},`)
		.join("\n")

	const header = `/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   generated — do not edit by hand. Country calling codes (E.164) + currencies (ISO 4217), derived
 *   from mledoze/countries (https://github.com/mledoze/countries, ODbL). nanp members map to 1.
 *   Regenerate with: mailwoman dev generate country-reference
 */

/** Static per-country reference: calling code + currency. */
export interface CountryReference {
	callingCode?: number
	currency?: { isoCode: string; name?: string; symbol?: string }
}

/** ISO 3166-1 alpha-2 → reference. */
export const COUNTRY_REFERENCE: Record<string, CountryReference> = {`

	await writeLocalTextFile(`${header}\n${body}\n}\n`, outPath)
	report?.(`wrote ${outPath} (${Object.keys(rows).length} countries)`)

	return { countries: Object.keys(rows).length, outPath }
}
