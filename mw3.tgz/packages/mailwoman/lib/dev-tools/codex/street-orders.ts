/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Where the house number sits relative to the street name, per country — the one fact libaddressinput does not carry.
 *
 *   Its `fmt` models the street address as a single opaque `%A`, so a skeleton transcribed from it says which line the
 *   street occupies and nothing about how that line is spelled. The split — house number leading or following — is read
 *   from the OpenCage `address-formatting` templates (MIT), which model both slots, and it is read once: this table is
 *   the result, committed as data. Therefore, the layout generator needs no third-party package at run time.
 *
 *   210 of the 251 template countries name both slots. the other 41 say nothing, and their absence here is the answer
 *   rather than a gap. A country this table does not name takes the number-first order, which
 *   `@mailwoman/codex/address-layouts`'s generator applies as its default.
 *
 *   refreshing IT is deliberate work rather than a command: the source is no longer a dependency of this repository. Re-read
 *   `address-formatting`'s `templates.json`, take each country's `address_template`, collapse every `{{#first}}`
 *   alternation to the `{{{road}}}` it may contain (an alternation names the road as a fallback for a place name, and
 *   the position inside one is not the street's real position), then compare the offsets of `{{{house_number}}}` and
 *   `{{{road}}}`.
 */

/**
 * Where the house number sits relative to the street name.
 */
export type StreetOrder = "number-first" | "number-last"

/**
 * Countries that separate the street name and the house number with a comma
 * rather than a space — `Calle Mayor, 12`.
 *
 * Measured the same way, and on the same rendered output: 183 of the 213 template countries
 * space-join, 22 comma-join, and 8 name only one of the two slots so the question does not arise.
 * The separator is not cosmetic.
 *
 * Spain's corpus recipe renders both forms on purpose, and collapsing the comma
 * is what its `nativeHouseJoin` option does.
 */
export const COMMA_JOINED_STREET_COUNTRIES: ReadonlySet<string> = new Set([
	"BJ",
	"BN",
	"BR",
	"BY",
	"CD",
	"CG",
	"ES",
	"IN",
	"KG",
	"KZ",
	"LA",
	"MD",
	"MR",
	"MU",
	"MZ",
	"RU",
	"SY",
	"TG",
	"TM",
	"UA",
	"XK",
	"YE",
])

/**
 * How the street line is written in a country's own script, for the countries that write two.
 *
 * `STREET_ORDERS` below is read from the OpenCage templates.
 * It render in Latin.
 *
 * Therefore, it states the romanized form of every country including these.
 * Hong Kong's entry is `21 Jordan Road`; its Chinese register writes `佐敦道21號`, which is a
 * different order and a different separator, and neither is derivable from the other.
 *
 * The values are the codex's street-node names, so the generator emits the node rather than deriving one.
 * `han` is the unseparated name-then-number line the Chinese-writing systems use,
 * and the entries follow the split `LINE_JOINS` already makes: CN and TW join
 * their lines with `""`, JP and KR with `" "`.
 *
 * Absent from this table means the country writes one street order in both scripts,
 * which is every country but these.
 */
export const LOCAL_STREET_NODES: Readonly<Record<string, "han">> = {
	CN: "han",
	HK: "han",
	MO: "han",
	TW: "han",
}

/**
 * Street order by ISO 3166-1 alpha-2.
 *
 * Absence means the source named only one of the two slots.
 */
export const STREET_ORDERS: Readonly<Record<string, StreetOrder>> = {
	AD: "number-first",
	AE: "number-first",
	AF: "number-last",
	AG: "number-first",
	AI: "number-last",
	AL: "number-last",
	AM: "number-first",
	AO: "number-last",
	AR: "number-last",
	AT: "number-last",
	AU: "number-first",
	AW: "number-last",
	AZ: "number-first",
	BA: "number-last",
	BB: "number-first",
	BD: "number-first",
	BE: "number-last",
	BF: "number-first",
	BG: "number-last",
	BH: "number-first",
	BI: "number-last",
	BJ: "number-first",
	BM: "number-first",
	BN: "number-first",
	BO: "number-last",
	BR: "number-last",
	BS: "number-last",
	BT: "number-last",
	BW: "number-last",
	BY: "number-last",
	BZ: "number-first",
	CD: "number-first",
	CF: "number-last",
	CG: "number-first",
	CH: "number-last",
	CI: "number-first",
	CK: "number-first",
	CL: "number-last",
	CM: "number-last",
	CN: "number-last",
	CO: "number-last",
	CR: "number-last",
	CU: "number-last",
	CV: "number-last",
	CW: "number-last",
	CY: "number-last",
	CZ: "number-last",
	DE: "number-last",
	DJ: "number-first",
	DK: "number-last",
	DM: "number-first",
	DO: "number-last",
	DZ: "number-first",
	EC: "number-last",
	EE: "number-last",
	EG: "number-first",
	EH: "number-last",
	ER: "number-last",
	ES: "number-last",
	ET: "number-last",
	FI: "number-last",
	FJ: "number-first",
	FM: "number-first",
	FO: "number-last",
	FR: "number-first",
	GA: "number-first",
	GB: "number-first",
	GD: "number-last",
	GE: "number-last",
	GH: "number-first",
	GI: "number-first",
	GL: "number-last",
	GM: "number-first",
	GN: "number-first",
	GQ: "number-last",
	GR: "number-last",
	GT: "number-last",
	GW: "number-last",
	GY: "number-first",
	HK: "number-first",
	HN: "number-last",
	HR: "number-last",
	HT: "number-last",
	HU: "number-last",
	ID: "number-last",
	IE: "number-first",
	IL: "number-last",
	IN: "number-first",
	IQ: "number-first",
	IR: "number-last",
	IS: "number-last",
	IT: "number-last",
	JM: "number-first",
	JO: "number-last",
	JP: "number-first",
	KE: "number-first",
	KG: "number-last",
	KH: "number-first",
	KI: "number-last",
	KM: "number-last",
	KN: "number-first",
	KP: "number-last",
	KR: "number-last",
	KW: "number-last",
	KY: "number-first",
	KZ: "number-last",
	LA: "number-first",
	LB: "number-first",
	LC: "number-last",
	LK: "number-first",
	LR: "number-last",
	LS: "number-first",
	LT: "number-last",
	LU: "number-first",
	LV: "number-last",
	LY: "number-last",
	MA: "number-first",
	MC: "number-first",
	MD: "number-last",
	ME: "number-last",
	MG: "number-first",
	MH: "number-first",
	MK: "number-last",
	ML: "number-last",
	MM: "number-first",
	MN: "number-last",
	MO: "number-last",
	MR: "number-first",
	MS: "number-first",
	MT: "number-first",
	MU: "number-first",
	MV: "number-first",
	MW: "number-first",
	MX: "number-last",
	MY: "number-first",
	MZ: "number-last",
	NA: "number-first",
	NE: "number-first",
	NG: "number-first",
	NI: "number-last",
	NL: "number-last",
	NO: "number-last",
	NP: "number-last",
	NR: "number-first",
	NU: "number-first",
	NZ: "number-first",
	OM: "number-first",
	PA: "number-last",
	PE: "number-last",
	PG: "number-first",
	PH: "number-first",
	PK: "number-first",
	PL: "number-last",
	PT: "number-last",
	PW: "number-last",
	PY: "number-last",
	QA: "number-last",
	RO: "number-last",
	RS: "number-last",
	RU: "number-last",
	RW: "number-first",
	SA: "number-first",
	SB: "number-last",
	SC: "number-first",
	SD: "number-last",
	SE: "number-last",
	SG: "number-first",
	SI: "number-last",
	SK: "number-last",
	SL: "number-first",
	SN: "number-first",
	SO: "number-last",
	SR: "number-last",
	SS: "number-last",
	ST: "number-last",
	SV: "number-last",
	SX: "number-last",
	SY: "number-last",
	SZ: "number-last",
	TC: "number-first",
	TD: "number-last",
	TG: "number-first",
	TH: "number-first",
	TJ: "number-last",
	TL: "number-last",
	TM: "number-first",
	TN: "number-first",
	TO: "number-first",
	TR: "number-last",
	TT: "number-first",
	TV: "number-first",
	TW: "number-last",
	TZ: "number-first",
	UA: "number-last",
	UG: "number-first",
	US: "number-first",
	UY: "number-last",
	UZ: "number-last",
	VC: "number-last",
	VE: "number-last",
	VG: "number-first",
	VN: "number-first",
	VU: "number-last",
	WS: "number-last",
	XC: "number-first",
	XK: "number-first",
	YE: "number-first",
	ZA: "number-first",
	ZM: "number-first",
	ZW: "number-first",
}
