/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Raw-angle-bracket MDX lint. Docusaurus compiles both .md and .mdx through micromark's MDX-JSX
 *   extension, so a bare `<55` or `{word` in prose is a build-breaking parse error ("Unexpected
 *   character before name"). This class broke three builds on 2026-06-10 alone (the consolidation
 *   session doc, the deep-dive review, the fill-rate record) — hence this check.
 *
 *   Checks staged docs markdown by default (pre-commit), or explicit paths when given. Skips fenced
 *   code blocks and inline code. flags raw `<` before a digit or `{` before a letter.
 *
 *   Stays quiet and fast — it runs on every `main` commit via the husky pre-commit hook. Run:
 *   mailwoman dev lint mdx-angles [files...]
 */

import { pathExists, readLocalTextFile } from "@mailwoman/core/fs/readers"
import { runFileSync } from "@mailwoman/core/process"
import { TextSpliterator } from "spliterator"

/**
 * The build-breaking class is `<55`-style numeric prose and `{word`-style MDX JSX expressions.
 *
 * Uppercase `<Component>` is legitimate MDX JSX and lowercase `<word>` is usually real html —
 * flagging them false-positives on valid docs (bit the pipeline-interface page, night-11).
 * Braces joined 2026-06-11: bare `{word` in prose is an MDX JSX expression.
 *
 * `{raw, components}` broke main's SSG with `ReferenceError: raw is not defined`.
 *
 * Same fix menu: backtick it.
 */
const RAW_ANGLE = /<[0-9]|\{[a-zA-Z]/

/**
 * Options for {@linkcode lintMDXAngles}.
 */
export interface LintMDXAnglesOptions {
	/**
	 * Files to check.
	 *
	 * Default: staged `docs/**` markdown (the pre-commit mode).
	 */
	files?: string[]
}

/**
 * One flagged file: its path + the offending 1-based `line:text` hits.
 */
export interface MDXAngleFinding {
	file: string
	hits: string[]
}

/**
 * Findings summary returned by {@linkcode lintMDXAngles}.
 */
export interface LintMDXAnglesSummary {
	/**
	 * Number of files flagged — the command exits 1 when nonzero.
	 */
	errors: number
	warnings: number
	filesChecked: number
	findings: MDXAngleFinding[]
}

function stagedDocsMarkdown(): string[] {
	const out = runFileSync("git", ["diff", "--cached", "--name-only", "--diff-filter=ACM"], { encoding: "utf8" })

	return [...TextSpliterator.from(out)].map((f) => f.trim()).filter((f) => /^docs\/.*\.(md|mdx)$/.test(f))
}

/**
 * Strip fenced code blocks, then inline code spans, then collect 1-based lines that hit {@link RAW_ANGLE}.
 */
async function violations(file: string): Promise<string[]> {
	const hits: string[] = []
	let fenced = false
	// oxlint-disable-next-line mailwoman/prefer-spliterator -- A synchronous pre-commit check over staged MDX. the async spliterator would make this function and its caller async for files of a few hundred lines.
	const lines = (await readLocalTextFile(file)).split("\n")

	for (const [i, line] of lines.entries()) {
		if (line.startsWith("```")) {
			fenced = !fenced

			continue
		}

		if (fenced) continue
		const stripped = line.replaceAll(/`[^`]*`/g, "")

		if (RAW_ANGLE.test(stripped)) {
			hits.push(`${i + 1}:${line}`)
		}
	}

	return hits
}

/**
 * Lint the given (or staged) docs markdown for build-breaking raw angles/braces.
 */
export async function lintMDXAngles(
	options: LintMDXAnglesOptions = {},
	report?: (line: string) => void
): Promise<LintMDXAnglesSummary> {
	const targets = options.files?.length ? options.files : stagedDocsMarkdown()
	const findings: MDXAngleFinding[] = []
	let filesChecked = 0

	for (const f of targets) {
		if (!(await pathExists(f))) continue

		filesChecked++
		const hits = await violations(f)

		if (hits.length) {
			report?.(`✗ ${f} — raw '<' before alphanumeric (MDX parses it as a JSX tag; build will fail):`)

			for (const h of hits.slice(0, 5)) {
				report?.(`    ${h}`)
			}

			findings.push({ file: f, hits })
		}
	}

	if (findings.length) {
		report?.("")
		report?.("Fix: backtick the expression, spell it out, or escape the brace/angle.")
	}

	return { errors: findings.length, warnings: 0, filesChecked, findings }
}
