import { dataRootPath } from "@mailwoman/core/data-root"
/**
 * @copyright Sister Software · @license AGPL-3.0 · @author Teffen Ellis, et al.
 *
 *   #148 diagnostic — dump-and-read why v1.9.0 (multi-locale retrain) regressed EU resolve. For each
 *   golden row, parse with two models (baseline + candidate), extract the emitted `locality` span, and
 *   resolve each tree → record whether it resolved + the emitted locality. Lets us see whether the
 *   candidate emits a different locality string (grain mismatch) or the same string that stopped
 *   resolving (boundary/anchor), or drops the locality entirely. Verify-before-verdict rather than assurance.
 *
 *   Run: node packages/mailwoman/lib/dev-tools/locality/emit-diff.run.ts \
 *     --base out/v180/model.onnx --cand out/v190-int8/model.onnx \
 *     --golden data/eval/external/oa-pt-coord-150.jsonl --default-country PT --n 30
 */
import { type AddressTree, decodeAsJSON } from "@mailwoman/core/decoder"
import { parseArguments } from "@mailwoman/core/scripting/arguments"
import { createWOFResolver } from "@mailwoman/resolver"
import { resolvePath } from "path-ts"

import { loadGoldenRows } from "#dev-tools/two-model-probe"

// Loose scan parity with the retired scripts/lib/cli-args helpers: unknown flags tolerated.
const { values: rawValues } = parseArguments({
	options: {
		base: { type: "string" },
		cand: { type: "string" },
		"default-country": { type: "string" },
		golden: { type: "string" },
		n: { type: "string" },
	},
	strict: false,
	allowPositionals: true,
})

// Typed view: strict:false loosens TS inference, but declared options always parse to their schema type.
const values = rawValues as { base?: string; cand?: string; "default-country"?: string; golden?: string; n?: string }
const TOK = dataRootPath("models", "tokenizer", "v0.6.0-a0", "tokenizer.model")
const CARD = "packages/neural-weights-en-us/model-card.json"
const ANCHOR = dataRootPath("anchor", "pilot-anchor-lookup.json")
const WOF = dataRootPath("wof", "admin-global-priority.db")

async function main() {
	const n = Number(values["n"] || "30")
	const cc = values["default-country"] || "PT"

	const rows = await loadGoldenRows(values["golden"] || "", n)

	const { createScorer } = await import("@mailwoman/neural/scorer")
	const { WOFSQLitePlaceLookup } = await import("@mailwoman/resolver-wof-sqlite")

	const mk = (m: string) =>
		createScorer({
			modelPath: m,
			tokenizerPath: TOK,
			modelCardPath: CARD,
			anchorLookupPath: ANCHOR,
			strict: true,
			tier: "server",
		})

	const base = await mk(values["base"] || "")
	const cand = await mk(values["cand"] || "")
	const resolver = createWOFResolver(new WOFSQLitePlaceLookup({ databasePath: resolvePath(WOF) }))
	const opts = { defaultCountry: cc }

	const didResolve = async (tree: AddressTree): Promise<boolean> => {
		const r = await resolver.resolveTree(tree, opts)

		const has = (node: { placeID?: string; children: unknown[] }): boolean =>
			!!node.placeID?.startsWith("wof:") || (node.children as { placeID?: string; children: unknown[] }[]).some(has)

		return (r.roots as { placeID?: string; children: unknown[] }[]).some(has)
	}

	let diff = 0,
		baseRes = 0,
		candRes = 0,
		candLostThatBaseHad = 0

	for (const row of rows) {
		const bt = await base.parse(row.raw, { postcodeRepair: true })
		const ct = await cand.parse(row.raw, { postcodeRepair: true })
		const bl = (decodeAsJSON(bt) as Record<string, string>).locality ?? ""
		const cl = (decodeAsJSON(ct) as Record<string, string>).locality ?? ""
		const br = await didResolve(bt)
		const cr = await didResolve(ct)

		if (bl !== cl) {
			diff++
		}

		if (br) {
			baseRes++
		}

		if (cr) {
			candRes++
		}

		if (br && !cr) {
			candLostThatBaseHad++
		}

		const flag = br && !cr ? " <<< base resolved, cand DIDN'T" : ""

		console.log(
			`gold=${(row.components.locality ?? "").padEnd(22)} | v180="${bl}"[${br ? "R" : "-"}]  v190="${cl}"[${cr ? "R" : "-"}]${flag}`
		)
	}

	console.log(
		`\n${cc}: n=${rows.length} | locality differs v180≠v190: ${diff} (${((100 * diff) / rows.length).toFixed(0)}%)`
	)
	console.log(`resolve: v180=${baseRes} v190=${candRes} | rows v180-resolved-but-v190-didn't: ${candLostThatBaseHad}`)
}

await main()
