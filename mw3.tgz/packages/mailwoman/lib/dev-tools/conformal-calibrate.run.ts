/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Split-conformal confidence wrapper for the street-level coordinate tier (#374, heuristic-radius
 *   variant). The interpolation tier stamps an `uncertainty_m` radius on each hit (half the matched
 *   tiger segment length) and the exact address-point tier stamps no radius — it is a real situs
 *   point, assigned a fixed 10 m floor (building-centroid precision).
 *
 *   The heuristic radius is a prior rather than a guarantee. This script turns it into a provably-calibrated
 *   interval: the conformal threshold Q̂ tells you "multiply the claimed radius by Q̂ and you now
 *   have a 90% coverage guarantee on held-out data."
 *
 *   recipe (DeepSeek scope, #374):
 *
 *   1. Run the full cascade (parser → resolver with situs + interp extracts) on a holdout set. For each
 *        resolved street-level row capture: (a) coordinate error in meters (haversine to the true
 *        lat/lon) (b) claimed radius in meters (uncertainty_m for interp hits. 10 m fixed floor for
 *        situs hits)
 *   2. Nonconformity score per row: s_i = error_m / claimed_radius_m
 *   3. Conformal threshold Q̂ = the ⌈(n_cal + 1) × 0.9⌉ / n_cal empirical quantile of {s_i} over a
 *        calibration split (split the holdout ≈50/50, deterministic seed).
 *   4. Calibrated 90% interval at inference = claimed_radius × Q̂.
 *   5. validate on the test split: empirical coverage = fraction where error_m ≤ calibrated_radius.
 *        Target ≈ 90%.
 *
 *   calibration data (pre-built, Texas E-911 Travis County):
 *
 *   - Holdout : /tmp/ood-truth.jsonl (1965 rows, {input, lat, lon, …})
 *   - Situs : /tmp/tx-situs.db (--address-points)
 *   - Interp : /tmp/tx-metro-interp.db (--interpolation)
 *
 *   output: threshold Q̂, empirical 90% coverage, median calibrated radius per tier, plus a 3-line
 *   calibration summary.
 *
 *   Run (no pre-compile needed — : node packages/mailwoman/lib/dev-tools/conformal-calibrate.run.ts\
 *   [--holdout /tmp/ood-truth.jsonl]\
 *   [--address-points /tmp/tx-situs.db]\
 *   [--interpolation /tmp/tx-metro-interp.db]\
 *   [--model neural-weights-en-us/model.onnx]\
 *   [--tokenizer neural-weights-en-us/tokenizer.model]\
 *   [--model-card neural-weights-en-us/model-card.json]\
 *   [--wof $MAILWOMAN_DATA_ROOT/wof/admin-global-priority.db,…]\
 *   [--cal-frac 0.5] [--alpha 0.9] [--seed 20260614]
 *
 *   Do not change the resolver or parser — this script only reads stamped metadata.
 */

import { dataRootPath, tempRootPath } from "@mailwoman/core/data-root"
import { walkNodes, type AddressTree } from "@mailwoman/core/decoder"
import { readLocalJSONFile } from "@mailwoman/core/fs/readers"
import { makeGlibcLcgFloat64, shuffleBy } from "@mailwoman/core/random"
import { runIfScript } from "@mailwoman/core/scripting"
import { parseArguments } from "@mailwoman/core/scripting/arguments"
import { median } from "@mailwoman/core/stats"
import { createWOFResolver } from "@mailwoman/resolver"
import { haversine } from "@mailwoman/spatial"
import { JSONSpliterator } from "spliterator"

// Loose scan parity with the retired local argv helpers: unknown flags tolerated.
/**
 * How far empirical coverage may sit from the nominal level and still count as calibrated.
 */
const COVERAGE_TOLERANCE = 0.03

/**
 * Interval-width ratio above which the calibrated radius is reported as inflated rather than tight.
 */
const INFLATED_INTERVAL_RATIO = 1.1

const { values: rawValues } = parseArguments({
	options: {
		"address-points": { type: "string" },
		alpha: { type: "string" },
		"cal-frac": { type: "string" },
		holdout: { type: "string" },
		interpolation: { type: "string" },
		model: { type: "string" },
		"model-card": { type: "string" },
		seed: { type: "string" },
		tokenizer: { type: "string" },
		wof: { type: "string" },
	},
	strict: false,
	allowPositionals: true,
})

// Typed view: strict:false loosens TS inference, but declared options always parse to their schema type.
const values = rawValues as {
	"address-points"?: string
	alpha?: string
	"cal-frac"?: string
	holdout?: string
	interpolation?: string
	model?: string
	"model-card"?: string
	seed?: string
	tokenizer?: string
	wof?: string
}

//#region CLI helpers

//#endregion

//#region Conformal quantile

function conformalThreshold(calScores: number[], targetCoverage: number): number {
	const n = calScores.length

	if (n === 0) return Infinity
	const rank = Math.ceil((n + 1) * targetCoverage)

	if (rank > n) return Infinity

	// can't guarantee at this level
	return [...calScores].toSorted((a, b) => a - b)[rank - 1]!
}

//#endregion

//#region Seeded deterministic shuffle — a reproducibility PIN

/**
 * Keep this exact glibc-constant LCG stream: the published conformal thresholds were
 * selected under it, and `@mailwoman/core/utils`' `makeLcg` uses different constants —
 * swapping streams re-splits calibration/test and silently moves Q̂.
 */

function seededShuffle<T>(arr: T[], seed: number): T[] {
	const out = [...arr]
	const step = makeGlibcLcgFloat64((seed * 2_654_435_761 + 1) & 0xff_ff_ff_ff)

	// The sampler takes the raw state modulo the bound rather than scaling a float,
	// which is why this reaches for `shuffleBy` and not `shuffleWith`.
	// Both are the same walk.
	// The published conformal thresholds were selected under this sampler, so it stays exactly as it is.
	shuffleBy(out, (bound) => step() % bound)

	return out
}

//#endregion

//#region Tree walkers — read STAMPED metadata, never alter resolution

/**
 * Fixed floor for an exact situs point (building-centroid precision).
 */
const SITUS_FLOOR_M = 10

interface StreetHit {
	tier: "address_point" | "interpolated"
	lat: number
	lon: number
	/**
	 * Claimed uncertainty radius in metres (10 m floor for situs, uncertainty_m for interp).
	 */
	claimedRadiusM: number
}

/**
 * Kept local rather than tree-hits' `findAddressPointHit` / `findInterpolatedHit`:
 * those answer only a coordinate, and this walk also needs the stamped `resolution_tier`
 * and the interpolation `uncertainty_m` to price the claimed radius.
 * Neither of which the shared readers carry.
 */
function findStreetHit(tree: AddressTree): StreetHit | null {
	for (const n of walkNodes(tree.roots)) {
		if (n.tag === "street") {
			const meta = n.metadata as Record<string, unknown> | undefined

			if (meta?.["resolution_tier"] === "address_point") {
				const ap = meta["address_point"] as { lat: number; lon: number } | undefined

				if (ap) {
					return { tier: "address_point", lat: ap.lat, lon: ap.lon, claimedRadiusM: SITUS_FLOOR_M }
				}
			}

			if (meta?.["resolution_tier"] === "interpolated") {
				const ip = meta["interpolated_point"] as { lat: number; lon: number } | undefined
				const uM = meta["uncertainty_m"]

				if (ip && typeof uM === "number") {
					return { tier: "interpolated", lat: ip.lat, lon: ip.lon, claimedRadiusM: uM }
				}
			}
		}
	}

	return null
}

//#endregion

//#region Holdout row type (matches /tmp/ood-truth.jsonl)

interface HoldoutRow {
	input: string
	lat: number
	lon: number
	expected?: { locality?: string; region?: string; postcode?: string }
	state?: string
}

//#endregion

//#region Main

/**
 * Build the parse → resolve cascade this calibration measures.
 *
 * Mirrors `oa-resolver-eval.ts`'s construction exactly.
 * The whole point of a conformal threshold is that it was fitted against the same
 * stack that will later apply it, so the two must not drift.
 */
async function buildCascade(paths: {
	modelPath: string
	tokenizerPath: string
	modelCardPath: string
	wofPaths: string[]
	addressPointsDB: string
	interpolationDB: string
}) {
	const { NeuralAddressClassifier } = await import("@mailwoman/neural")
	const { ONNXRunner } = await import("@mailwoman/neural/onnx-runner")
	const { MailwomanTokenizer } = await import("@mailwoman/neural/tokenizer")
	const modelCard = await readLocalJSONFile<{ labels: string[] }>(paths.modelCardPath)

	const [tokenizer, runner] = await Promise.all([
		MailwomanTokenizer.loadFromFile(paths.tokenizerPath),
		ONNXRunner.create(paths.modelPath),
	])

	const neural = new NeuralAddressClassifier({ tokenizer, runner, labels: modelCard.labels })

	const { WOFSQLitePlaceLookup, AddressPointSqliteLookup, StreetInterpolator } =
		await import("@mailwoman/resolver-wof-sqlite")

	const backend = new WOFSQLitePlaceLookup({
		databasePath: paths.wofPaths.length === 1 ? paths.wofPaths[0]! : paths.wofPaths,
	})

	return {
		neural,
		resolver: createWOFResolver(backend),
		addressPoints: new AddressPointSqliteLookup(paths.addressPointsDB),
		interpolation: new StreetInterpolator({ dbPath: paths.interpolationDB }),
	}
}

async function main(): Promise<void> {
	const holdoutPath = values["holdout"] || tempRootPath("ood-truth.jsonl")
	const addressPointsDB = values["address-points"] || tempRootPath("tx-situs.db")
	const interpolationDB = values["interpolation"] || tempRootPath("tx-metro-interp.db")
	const modelPath = values["model"] || "packages/neural-weights-en-us/model.onnx"
	const tokenizerPath = values["tokenizer"] || "packages/neural-weights-en-us/tokenizer.model"
	const modelCardPath = values["model-card"] || "packages/neural-weights-en-us/model-card.json"

	const wofPaths = (
		values["wof"] ||
		`${dataRootPath("wof", "admin-global-priority.db")},${dataRootPath("wof", "postcode-locality-intl.db")}`
	)
		.split(",")
		.map((s) => s.trim())

	const calFrac = Number(values["cal-frac"] || "0.5")
	const alpha = Number(values["alpha"] || "0.9") // target coverage level
	const seed = Number(values["seed"] || "20260614")

	// Load the held-out rows before running the calibration cascade.
	const rows: HoldoutRow[] = await JSONSpliterator.fromAsync<HoldoutRow>(holdoutPath).toArray()

	console.error(`[conformal-calibrate] ${rows.length} holdout rows from ${holdoutPath}`)
	console.error(`[conformal-calibrate] situs: ${addressPointsDB}  interp: ${interpolationDB}`)
	console.error(`[conformal-calibrate] model: ${modelPath}`)

	const { neural, resolver, addressPoints, interpolation } = await buildCascade({
		modelPath,
		tokenizerPath,
		modelCardPath,
		wofPaths,
		addressPointsDB,
		interpolationDB,
	})

	// Run the resolver cascade over every held-out row.
	interface Row {
		errorM: number
		claimedRadiusM: number
		tier: "address_point" | "interpolated"
	}

	const resolved: Row[] = []
	let nTotal = 0
	let nNoStreetHit = 0

	console.error("[conformal-calibrate] running cascade …")

	const parseOpts = { postcodeRepair: true } as Parameters<typeof neural.parse>[1]
	const resolveOpts = { defaultCountry: "US", addressPoints, interpolation }

	for (const row of rows) {
		nTotal++

		if (nTotal % 200 === 0) {
			console.error(`  ${nTotal}/${rows.length}`)
		}

		try {
			const tree = await neural.parse(row.input, parseOpts)
			const decorated: AddressTree = await resolver.resolveTree(tree, resolveOpts)
			const hit = findStreetHit(decorated)

			if (!hit) {
				nNoStreetHit++

				continue
			}

			const errorM = haversine({ lat: hit.lat, lng: hit.lon }, { lat: row.lat, lng: row.lon }, "meters")
			resolved.push({ errorM, claimedRadiusM: hit.claimedRadiusM, tier: hit.tier })
		} catch {
			nNoStreetHit++
		}
	}

	const nResolved = resolved.length

	console.error(
		`[conformal-calibrate] street-level hits: ${nResolved}/${nTotal}` +
			`  (${((100 * nResolved) / Math.max(1, nTotal)).toFixed(1)}%)` +
			`  no-hit (abstain/admin-only): ${nNoStreetHit}`
	)

	if (nResolved === 0) {
		console.error("ERROR: zero street-level hits — nothing to calibrate")

		process.exit(1)
	}

	// Deterministically split resolved rows into calibration and test sets.
	const shuffled = seededShuffle(resolved, seed)
	const nCal = Math.floor(shuffled.length * calFrac)
	const calRows = shuffled.slice(0, nCal)
	const testRows = shuffled.slice(nCal)

	// Compute calibration nonconformity scores.
	const calScores = calRows.map((r) => r.errorM / r.claimedRadiusM)
	const Q = conformalThreshold(calScores, alpha)

	// Measure empirical coverage on the held-out test set.
	const testScores = testRows.map((r) => r.errorM / r.claimedRadiusM)
	const covered = testScores.filter((s) => s <= Q).length
	const coverage = covered / Math.max(1, testScores.length)

	// Break the report down by resolution tier.
	type Tier = "address_point" | "interpolated"
	const tiers: Tier[] = ["address_point", "interpolated"]
	const byTier: Record<Tier, Row[]> = { address_point: [], interpolated: [] }

	for (const r of resolved) {
		byTier[r.tier].push(r)
	}

	// Median calibrated radius = median(claimedRadiusM) × Q per tier on all resolved rows
	const tierStats = tiers.map((t) => {
		const innerRows = byTier[t]

		if (!innerRows.length)
			return { tier: t, n: 0, medianClaimedM: Number.NaN, medianCalibratedM: Number.NaN, medianErrorM: Number.NaN }

		// innerRows rather than the outer holdout `rows`.
		// The previous lax scripts tsconfig let the wrong array through and the per-tier medians silently printed
		// NaN (the headline Q/coverage were computed on the correct splits. Only this breakdown was dead).
		const claimedMeds = median(innerRows.map((r) => r.claimedRadiusM)) ?? Number.NaN
		const errMeds = median(innerRows.map((r) => r.errorM)) ?? Number.NaN

		return {
			tier: t,
			n: innerRows.length,
			medianClaimedM: claimedMeds,
			medianCalibratedM: claimedMeds * Q,
			medianErrorM: errMeds,
		}
	})

	// Uncalibrated coverage: fraction where error_m ≤ claimed_radius_m (threshold=1)
	const uncalCovered = resolved.filter((r) => r.errorM <= r.claimedRadiusM).length
	const uncalCoverage = uncalCovered / Math.max(1, resolved.length)

	// Compute conformal thresholds for each resolution tier.
	// Split each tier's rows independently: shuffled order is fixed, just filter by tier.
	// "Too few rows" warning fires when rank > n_cal (conformal_threshold returns ∞).
	const tierConformal = tiers.map((t) => {
		const allRows = byTier[t]
		// Maintain the same shuffle order as the overall split for reproducibility.
		const shuffledTier = seededShuffle(allRows, seed)
		const nCalT = Math.floor(shuffledTier.length * calFrac)
		const calT = shuffledTier.slice(0, nCalT)
		const testT = shuffledTier.slice(nCalT)
		const calScoresT = calT.map((r) => r.errorM / r.claimedRadiusM)
		const QT = conformalThreshold(calScoresT, alpha)

		const covT = testT.length
			? testT.filter((r) => r.errorM / r.claimedRadiusM <= QT).length / testT.length
			: Number.NaN

		const uncalCovT = allRows.length
			? allRows.filter((r) => r.errorM <= r.claimedRadiusM).length / allRows.length
			: Number.NaN

		return {
			tier: t,
			nAll: allRows.length,
			nCal: nCalT,
			nTest: testT.length,
			Q: QT,
			coverage: covT,
			uncalCov: uncalCovT,
		}
	})

	// Print the complete calibration report.
	const hr = "─".repeat(72)

	console.log("")
	console.log("Conformal-prediction confidence wrapper — street-level coordinate tier  (#374)")
	console.log(hr)
	console.log(`holdout  : ${holdoutPath}  (${nTotal} rows)`)
	console.log(
		`resolved : ${nResolved}  (${((100 * nResolved) / Math.max(1, nTotal)).toFixed(1)}% street-level hit rate)`
	)
	console.log(`abstained: ${nNoStreetHit}  (no street-level coordinate — admin-centroid fallback)`)
	console.log(`split    : cal=${nCal}  test=${testRows.length}  seed=${seed}`)
	console.log(hr)
	console.log(`target coverage (α=1−${(1 - alpha).toFixed(2)})                  : ${(alpha * 100).toFixed(0)}%`)
	console.log(
		`combined conformal threshold Q̂                       : ${Number.isFinite(Q) ? Q.toFixed(6) : "∞"}` +
			(Number.isFinite(Q) ? `  (× claimed_radius = calibrated interval)` : "  (insufficient data at this α)")
	)
	console.log(
		`empirical coverage on test split (combined)           : ${(coverage * 100).toFixed(1)}%` +
			`  (${covered}/${testRows.length})` +
			(Math.abs(coverage - alpha) <= COVERAGE_TOLERANCE
				? "  ✓ within 3pp of target"
				: `  ✗ ${((coverage - alpha) * 100).toFixed(1)}pp off target`)
	)
	console.log(hr)
	console.log(
		`uncalibrated coverage (Q̂=1, as-is, combined)        : ${(uncalCoverage * 100).toFixed(1)}%  (${uncalCovered}/${nResolved})`
	)
	console.log(hr)
	console.log("")
	console.log("Per-tier calibration stats (ALL resolved rows, separate conformal splits):")
	console.log("")

	const fmtM = (v: number): string =>
		Number.isNaN(v) ? "—" : v < 1000 ? `${v.toFixed(1)} m` : `${(v / 1000).toFixed(2)} km`

	const fmtPct = (v: number): string => (Number.isNaN(v) ? "—" : `${(v * 100).toFixed(1)}%`)
	const fmtQ = (v: number): string => (Number.isFinite(v) ? v.toFixed(4) : "∞")

	console.log(
		`  ${"tier".padEnd(14)} ${"n".padStart(5)} ${"Q̂".padStart(8)} ${"coverage".padStart(10)} ${"uncal.cov".padStart(10)} ${"median err".padStart(12)} ${"med.claimed r".padStart(14)} ${"med.cal. r".padStart(12)}`
	)
	console.log(
		`  ${"".padEnd(14, "-")} ${"".padStart(5, "-")} ${"".padStart(8, "-")} ${"".padStart(10, "-")} ${"".padStart(10, "-")} ${"".padStart(12, "-")} ${"".padStart(14, "-")} ${"".padStart(12, "-")}`
	)

	for (const ts of tierStats) {
		const tc = tierConformal.find((x) => x.tier === ts.tier)!
		const calRadM = Number.isFinite(tc.Q) ? ts.medianClaimedM * tc.Q : Infinity
		const calRadFmt = !Number.isFinite(calRadM) ? "∞" : fmtM(calRadM)

		console.log(
			`  ${ts.tier.padEnd(14)} ${String(ts.n).padStart(5)} ${fmtQ(tc.Q).padStart(8)} ${fmtPct(tc.coverage).padStart(10)} ${fmtPct(tc.uncalCov).padStart(10)} ${fmtM(ts.medianErrorM).padStart(12)} ${fmtM(ts.medianClaimedM).padStart(14)} ${calRadFmt.padStart(12)}`
		)
	}

	console.log("")
	console.log(hr)

	// Print the concise three-line calibration summary.
	// Characterise the dominant tier (address_point here. Interp may lack sufficient rows).
	const situsTC = tierConformal.find((x) => x.tier === "address_point")!
	const interpTC = tierConformal.find((x) => x.tier === "interpolated")!

	console.log("")
	console.log("CALIBRATION SUMMARY")
	console.log("")

	// Line 1: overall verdict on the heuristic prior
	if (!Number.isFinite(Q)) {
		console.log(
			`  The combined conformal threshold is ∞ — not enough calibration data to guarantee ${(alpha * 100).toFixed(0)}% coverage.`
		)
		console.log(`  Collect more holdout rows or lower the target α.`)
		console.log(`  Uncalibrated (Q̂=1) coverage is ${(uncalCoverage * 100).toFixed(1)}%.`)
	} else if (Q < 1) {
		// The heuristic is conservative — can shrink and still cover
		const situsVerdict = Number.isFinite(situsTC.Q)
			? `situs floor (${SITUS_FLOOR_M} m) is ${(1 / situsTC.Q).toFixed(0)}× too large`
			: "situs tier: insufficient rows for per-tier threshold"

		const interpVerdict =
			interpTC.nAll === 0
				? "interpolation tier: 0 hits in this holdout"
				: !Number.isFinite(interpTC.Q)
					? `interpolation tier (n=${interpTC.nAll}): too few rows for per-tier ${(alpha * 100).toFixed(0)}% threshold`
					: interpTC.Q > 1
						? `interpolation tier: Q̂=${interpTC.Q.toFixed(3)} — uncertainty_m UNDERESTIMATES the true spread`
						: `interpolation tier: Q̂=${interpTC.Q.toFixed(3)} — uncertainty_m is conservative`

		console.log(`  Combined Q̂ = ${Q.toFixed(6)} ≪ 1: the heuristic prior is HIGHLY CONSERVATIVE — ${situsVerdict}.`)
		console.log(`  ${interpVerdict}.`)
		console.log(
			`  Uncalibrated coverage ${(uncalCoverage * 100).toFixed(1)}% (as-is) already beats ${(alpha * 100).toFixed(0)}% by a large margin; the conformal correction mainly tightens the reported interval.`
		)
	} else if (Q > INFLATED_INTERVAL_RATIO) {
		// The heuristic underestimates the spread
		console.log(
			`  Combined Q̂ = ${Q.toFixed(4)} > 1: the heuristic radius UNDERESTIMATES the true spread — multiply by ${Q.toFixed(2)}× for ${(alpha * 100).toFixed(0)}% coverage.`
		)
		console.log(
			`  Uncalibrated coverage is only ${(uncalCoverage * 100).toFixed(1)}%; the conformal correction is essential.`
		)
		console.log(`  Use Q̂ × claimed_radius as the reported interval at inference.`)
	} else {
		// Q near 1 — well-calibrated
		console.log(`  Combined Q̂ ≈ ${Q.toFixed(4)} (near 1): the heuristic radius is WELL-CALIBRATED as-is.`)
		console.log(
			`  Empirical coverage ${(coverage * 100).toFixed(1)}% on the test split is within 3pp of the ${(alpha * 100).toFixed(0)}% target; no correction needed.`
		)
		console.log(`  The raw uncertainty_m / situs floor is a reliable confidence bound to ship.`)
	}

	console.log("")
}

runIfScript(import.meta, main)

//#endregion
