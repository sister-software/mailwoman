/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   `mailwoman situs build` — national address-point (situs) database build driver. The situs
 *   counterpart to `mailwoman situs interpolation`, but downloadless: every US address point
 *   already lives in one pinned Overture parquet, so this fans the per-state `mailwoman situs
 *   address-points` command out across every covered state.
 *
 *   parallelism: states build concurrently via spliterator's `parallelMap` (the house
 *   bounded-concurrency primitive — same one `build-unified-wof` uses to fan out file reads behind
 *   a single writer). Each state is an isolated child process (its own DuckDB + SQLite heap), so N
 *   states run at once with no shared-memory risk. To avoid oversubscribing cores, each child's
 *   DuckDB scan is capped at `--threads` (default: cores / concurrency), so concurrency × threads ≈
 *   cores. The per-state steady-state bottleneck is the single-threaded SQLite insert loop rather than the
 *   scan, so N concurrent inserts is where the wall-clock saving comes from. Sequentialise via `--concurrency 1`.
 *
 *   Each per-state child owns its own DB's atomic write. this driver only spawns children (skipping
 *   complete databases) and writes the small `attribution.json` manifest incrementally — so there is
 *   no national-DB temp-then-rename here, the large-artifact atomicity lives one level down in the
 *   database builder. Progress streams to stderr. the final summary lands on stdout.
 *
 *   licensing (measured 2026-06-14): US Overture addresses are NAD (68%, US public domain) +
 *   OpenAddresses (32%, government open data) with zero OpenStreetMap/ODbL rows. So the default is
 *   no license filter — `--license-filter NAD` would drop a third of coverage for no benefit. The
 *   only obligation is attribution: the per-row `overture:<dataset>` provenance is summarized into
 *   `<out-dir>/attribution.json`. Pass `--license-filter <datasets>` to build a narrowed database.
 *
 *   idempotency: a state is skipped only if its database is complete — non-empty `address_point` table
 *   and the `idx_ap_streetkey` index present. A half-built database (data inserted, indexing/vacuum
 *   not reached — e.g. a killed run) is detected as incomplete and rebuilt. `--force` rebuilds
 *   regardless.
 */

import { pathExists } from "@mailwoman/core/fs/readers"
import { makeDirectories, writeLocalJSONFile } from "@mailwoman/core/fs/writers"
import { spawnProcess } from "@mailwoman/core/process"
import { isoDate } from "@mailwoman/core/utils"
import { availableParallelism } from "@mailwoman/core/utils/system"
import type { AddressPointDatabase } from "@mailwoman/resolver-wof-sqlite/address"
import { DatabaseClient } from "@mailwoman/sqlite/client"
import { countRows, indexExists } from "@mailwoman/sqlite/introspection"
import { Box, Text } from "ink"
import { join } from "path-ts"

import {
	type CommandSpec,
	CommandTaskResult,
	type CommandComponent,
	positiveInteger,
	splitUSStateCodes,
	stripAnsi,
	useCommandTask,
} from "#cli-kit"

/**
 * Native command-line interface consumed by the filesystem command router.
 */
export const spec = {
	name: "build",
	description: "Build state address-point databases",
	options: {
		"out-dir": { type: "string", description: "Output directory" },
		release: { type: "string", default: "2026-05-20.0", description: "Overture release" },
		states: { type: "string", description: "Comma-separated states" },
		"license-filter": { type: "string", description: "Dataset allow-list" },
		concurrency: { type: "number", default: 4, validate: positiveInteger, description: "Parallel state builds" },
		threads: { type: "number", validate: positiveInteger, description: "DuckDB threads per child" },
		force: { type: "boolean", default: false, description: "Rebuild complete databases" },
	},
} as const satisfies CommandSpec

/**
 * Coverage-ranked (largest first, from the 2026-05-20.0 parquet probe).
 *
 * NH + HI carry zero Overture address coverage in this release, so they're absent —
 * interpolation-only states.
 * VI (territory) included for completeness.
 * Harmless if the parser's region→slug map skips it.
 */
const STATES_BY_COVERAGE = [
	"CA",
	"FL",
	"TX",
	"NY",
	"NC",
	"OH",
	"IL",
	"TN",
	"OR",
	"VA",
	"NJ",
	"AZ",
	"MA",
	"IN",
	"WA",
	"AL",
	"MD",
	"CO",
	"KY",
	"MN",
	"AR",
	"MO",
	"IA",
	"WI",
	"OK",
	"UT",
	"CT",
	"MS",
	"PA",
	"NM",
	"WV",
	"KS",
	"NE",
	"MI",
	"ME",
	"GA",
	"MT",
	"DE",
	"ND",
	"DC",
	"RI",
	"ID",
	"VT",
	"AK",
	"LA",
	"WY",
	"SC",
	"SD",
	"NV",
	"VI",
]

interface StateResult {
	state: string
	skipped?: boolean
	code?: number | null
	seconds?: number
	out?: string
	err?: string
}

interface StateManifestEntry {
	ok: boolean
	points?: number
	seconds?: number
	datasets?: Record<string, number>
}

const SitusBuild: CommandComponent<typeof spec> = ({ options }) => {
	const state = useCommandTask(async () => {
		const { scriptEntryPath } = await import("@mailwoman/core/scripting/utils")
		const { dataRootPath } = await import("@mailwoman/core/utils")

		const outDir = options.outDir ?? dataRootPath("address-points")

		const states = options.states ? splitUSStateCodes(options.states) : [...STATES_BY_COVERAGE]

		await makeDirectories(outDir)

		const concurrency = Math.max(1, options.concurrency || 4)
		const cores = availableParallelism()
		const threads = Math.max(1, options.threads || Math.floor(cores / concurrency))
		// The per-state address-point builder is now the sibling `situs address-points` command
		// (the old `scripts/build-address-point-database.ts` was migrated into the CLI).
		// Re-invoke the same CLI entry this process was started from, so dev +
		// published installs both resolve correctly.
		const cliEntry = scriptEntryPath()

		console.error(
			`national situs build — ${states.length} states, concurrency=${concurrency}, ${threads} DuckDB threads/state (of ${cores} cores)`
		)

		// spliterator is a heavy bounded-concurrency primitive — imported lazily so merely
		// loading the command tree (e.g. `mailwoman --help`) doesn't pull it at module-eval.
		const { parallelMap } = await import("spliterator")

		// A database is complete iff its address_point table has rows and the streetkey index exists.
		// The index is the last build step, so its presence means insert + index + vacuum all finished.
		const isComplete = async (dbPath: string): Promise<boolean> => {
			if (!(await pathExists(dbPath))) return false

			try {
				using db = new DatabaseClient<AddressPointDatabase>(dbPath, { readOnly: true })

				return countRows(db, "address_point") > 0 && indexExists(db, "idx_ap_streetkey")
			} catch {
				return false
			}
		}

		const buildOneState = async (stateCode: string): Promise<StateResult> => {
			const dbPath = join(outDir, `address-points-us-${stateCode.toLowerCase()}.db`)

			if (!options.force && (await isComplete(dbPath))) return { state: stateCode, skipped: true }

			return new Promise((resolve) => {
				const argv = [
					cliEntry,
					"situs",
					"address-points",
					"--state",
					stateCode,
					"--release",
					options.release,
					"--out",
					dbPath,
					"--threads",
					String(threads),
				]

				if (options.licenseFilter) {
					argv.push("--license-filter", options.licenseFilter)
				}

				const t = Date.now()
				const child = spawnProcess(process.execPath, argv)

				let out = "",
					err = ""

				child.stdout.on("data", (d) => (out += d))
				child.stderr.on("data", (d) => (err += d))

				child.on("close", (code) =>
					resolve({ state: stateCode, code, seconds: Number(((Date.now() - t) / 1000).toFixed(1)), out, err })
				)
			})
		}

		const t0 = Date.now()

		const manifest: {
			release: string
			builtAt: string | null
			licenseFilter: string | null
			states: Record<string, StateManifestEntry>
			datasetTotals: Record<string, number>
		} = {
			release: options.release,
			builtAt: null,
			licenseFilter: options.licenseFilter ?? null,
			states: {},
			datasetTotals: {},
		}

		let built = 0,
			skipped = 0,
			failed = 0,
			totalRows = 0

		const attributionPath = join(outDir, "ATTRIBUTION.json")

		// parallelMap yields results AS they complete (out of order), capped at `concurrency` in flight.
		// Each result includes its own state, so out-of-order is fine for the state-keyed manifest.
		for await (const r of parallelMap(states, buildOneState, { concurrency })) {
			if (r.skipped) {
				console.error(`[skip] ${r.state} — complete (use --force to rebuild)`)

				skipped++

				continue
			}

			if (r.code !== 0) {
				console.error(`[FAIL] ${r.state} (${r.seconds}s)\n${stripAnsi(r.err || "").slice(-600)}`)

				manifest.states[r.state] = { ok: false }

				failed++

				continue
			}

			// The child's parse-relevant facts span its Ink summary (stdout) + plain
			// progress (stderr) — combine + strip ansi, then match without line anchors
			// so the summary's "✓ "/" " render prefixes don't defeat the regex.
			const text = stripAnsi(`${r.out ?? ""}\n${r.err ?? ""}`)
			const pts = Number(text.match(/(\d+) points →/)?.[1] ?? 0)
			const datasets: Record<string, number> = {}

			for (const m of text.matchAll(/overture:(\S+)\s+([\d,]+) rows/g)) {
				const ds = m[1]!,
					n = Number(m[2]!.replaceAll(",", ""))

				datasets[ds] = n
				manifest.datasetTotals[ds] = (manifest.datasetTotals[ds] ?? 0) + n
			}

			manifest.states[r.state] = { ok: true, points: pts, seconds: r.seconds, datasets }
			totalRows += pts

			built++

			console.error(`[ok]   ${r.state} — ${pts.toLocaleString()} points (${r.seconds}s)`)

			manifest.builtAt = isoDate(new Date(t0))
			await writeLocalJSONFile(manifest, attributionPath)
		}

		const mins = ((Date.now() - t0) / 60_000).toFixed(1)

		const lines = [
			`situs: ${outDir}`,
			`built ${built} · skipped ${skipped} · failed ${failed} · ${totalRows.toLocaleString()} total points · ${mins} min`,
			`dataset families:`,
		]

		for (const [ds, n] of Object.entries(manifest.datasetTotals)
			.toSorted((a, b) => b[1] - a[1])
			.slice(0, 8)) {
			lines.push(`  ${ds.padEnd(28)} ${n.toLocaleString()}`)
		}

		lines.push(`attribution manifest → ${attributionPath}`)

		return lines
	})

	if (state.status !== "done") return <CommandTaskResult state={state} />

	if (state.status === "done") {
		return (
			<Box flexDirection="column">
				{state.result.map((line, i) => (
					<Text key={i} color={i === 0 ? "green" : undefined}>
						{i === 0 ? "✓ " : "  "}
						{line}
					</Text>
				))}
			</Box>
		)
	}

	return null // progress streams to stderr until the summary lands
}

export default SitusBuild
