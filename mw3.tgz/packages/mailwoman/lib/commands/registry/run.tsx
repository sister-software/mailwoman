/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   `mailwoman registry <csv>` — the geocode-first record matcher, end to end (#613).
 *
 *   This is the integration that runs `@mailwoman/registry`'s cascade on real data: it constructs the
 *   heavy geocoder (neural parser + WOF resolver + per-state situs/interp databases — the same wiring
 *   as `geocode`) and injects it into the matcher's `GeocodeAddress` interface, so the registry package
 *   itself never imports the runtime. Then:
 *
 *   CSV → ingest (column-map + normalize) → geocode (the injected step) → resolveEntities (block →
 *   Fellegi-Sunter score, EM-trained label-free → cluster) → GeoJSON.
 *
 *   The thesis it grades: two rows reading `123 Main St` and `123 Main Street Apt 2` — different
 *   strings — collapse to one entity because they resolve to the same place. Blocking is
 *   geographic rather than textual. Needs the weights + databases in hand, so the real run is
 *   operator-verifiable (not CI).
 */

import { Spinner } from "@inkjs/ui"
import { mailwomanDataRoot } from "@mailwoman/core/data-root"
import { errorMessage } from "@mailwoman/core/errors/schema"
import { readLocalTextFile } from "@mailwoman/core/fs/readers"
import { writeLocalFile, writeLocalJSONFile } from "@mailwoman/core/fs/writers"
import { tryParsingJSON, prettyJSON } from "@mailwoman/core/json"
import { isPresent } from "@mailwoman/core/objects"
import { CommandError } from "@mailwoman/core/scripting/command"
import type { NeuralAddressClassifier } from "@mailwoman/neural"
import type { ColumnMapping, EntityGeoData, GeocodeAddress, SourceRecord } from "@mailwoman/registry"
import type { EvalGeocoder, EvalGeocoderFactory } from "@mailwoman/registry/tools"
import type { GeoFeatureCollection, PointLiteral } from "@mailwoman/spatial"
import { Text } from "ink"

import {
	type CommandSpec,
	CommandTaskResult,
	type OptionsOf,
	type ParsedCommandComponent,
	useCommandTask,
} from "#cli-kit"
import { resolverDefaultCountry } from "#country-scope"
import type { RegionDatabaseResolver } from "#geocode/regions"
/**
 * Bare `mailwoman registry <csv>` stays the end-to-end matcher now that `registry/` hosts subcommands.
 */
export const isDefault = true

//#region CLI interface — args + options

/**
 * Native command-line interface consumed by the filesystem command router.
 */
export const spec = {
	name: "run",
	description: "Resolve records into matched entities",
	positionals: [{ name: "csv", multiple: true, description: "CSV input paths" }],
	options: {
		mapping: { type: "string", description: "Column mapping JSON or path" },
		"infer-mapping": { type: "boolean", default: false, description: "Infer mapping from headers" },
		sources: { type: "string", description: "Multi-source specification JSON or path" },
		out: { type: "string", description: "GeoJSON output" },
		"map-out": { type: "string", description: "Standalone HTML map output" },
		"train-em": { type: "boolean", default: true, description: "Train Fellegi-Sunter parameters" },
		threshold: { type: "number", default: 0, description: "Entity link threshold" },
		"max-block-size": { type: "number", description: "Maximum scanned block size" },
		reconcile: { type: "boolean", default: false, description: "Run coverage reconciliation" },
		source: { type: "string", description: "Provenance label" },
		locale: {
			type: "string",
			default: "en-US",
			validate: (v: string) => /^[a-z]{2}(-[A-Z]{2})?$/u.test(v),
			description: "BCP-47 locale",
		},
		"default-country": { type: "string", description: "Resolver country scope" },
		"place-country": { type: "boolean", default: true, description: "Enable coarse country prior" },
		"resolve-db": { type: "string", description: "WOF admin database" },
		"data-root": { type: "string", default: mailwomanDataRoot(), description: "Per-state database root" },
	},
} as const satisfies CommandSpec

type Options = OptionsOf<typeof spec>

//#endregion

//#region Column mapping

/**
 * Built-in best-effort mapping for tidy contact/org CSVs.
 *
 * Multi-column fields are joined (so a CSV that splits the address across columns composes one string).
 * Real datasets with bespoke headers (e.g. NPPES "Provider First Line Business Practice Location Address")
 * pass an explicit --mapping.
 * Inferring it from the header is the #603 fast-follow.
 */
export const DEFAULT_MAPPING: ColumnMapping = {
	id: "id",
	name: ["name", "full_name", "first_name", "last_name"],
	organization: ["organization", "org", "company"],
	address: ["address", "address1", "street", "city", "state", "zip", "postal_code"],
	phone: "phone",
	email: "email",
}

/**
 * Resolve --mapping (a file path or inline JSON) and merge it over `base` (default {@link DEFAULT_MAPPING}).
 */
export async function loadMapping(
	option: string | undefined,
	source: string | undefined,
	base: ColumnMapping = DEFAULT_MAPPING
): Promise<ColumnMapping> {
	let provided: Partial<ColumnMapping> = {}

	if (option) {
		const text = option.trim().startsWith("{") ? option : await readLocalTextFile(option)
		const parsed = tryParsingJSON<Partial<ColumnMapping>>(text)

		if (!parsed) {
			throw new CommandError(`--mapping is neither a readable file nor a JSON object: ${text}`)
		}

		provided = parsed
	}

	return { ...base, ...provided, ...(source ? { source } : {}) }
}

async function resolveWOFPath(options: Options): Promise<string> {
	const { requireWOFPath } = await import("#resolver-backend")

	try {
		return await requireWOFPath(options.resolveDB)
	} catch (error) {
		throw new CommandError(errorMessage(error), { cause: error })
	}
}

/**
 * Construct the heavy geocoder once (neural parser + WOF resolver + per-state databases)
 * and wire it into the matcher's {@link GeocodeAddress} interface.
 *
 * Returns it plus a disposal hook for the database handles.
 * Shared by the single-CSV and multi-source paths.
 */
async function buildGeocoder(options: Options): Promise<{ geocodeAddress: GeocodeAddress } & Disposable> {
	const { decodeAsJSON } = await import("@mailwoman/core/decoder")
	const { NeuralAddressClassifier } = await import("@mailwoman/neural")
	const { geocodeAddressVia } = await import("@mailwoman/registry")
	const { createWOFResolver } = await import("@mailwoman/resolver")

	const [{ geocodeAddress }, { RegionDatabaseProvider }] = await Promise.all([
		import("#geocode/core"),
		import("#geocode/regions"),
	])

	const { INTERP_RADIUS_CALIBRATION } = await import("#interp-calibration")
	const { createResolverBackend, resolveCandidateDBPath } = await import("#resolver-backend")

	const wofPath = await resolveWOFPath(options)

	let classifier: NeuralAddressClassifier

	try {
		classifier = await NeuralAddressClassifier.loadFromWeights({ locale: options.locale })
	} catch {
		throw new CommandError(
			"registry requires the neural weights. Install @mailwoman/neural-weights-en-us (or a --locale match)."
		)
	}

	let mod: typeof import("@mailwoman/resolver-wof-sqlite")

	try {
		mod = await import("@mailwoman/resolver-wof-sqlite")
	} catch {
		throw new CommandError("registry requires `@mailwoman/resolver-wof-sqlite` to be installed.")
	}

	// $MAILWOMAN_CANDIDATE_DB → the demo-parity candidate backend.
	// Else FTS over wofPath.
	const lookup = await createResolverBackend(mod, { wofPaths: wofPath })
	const regionDatabaseProvider = await RegionDatabaseProvider.create(mod, options.dataRoot)
	const databases: RegionDatabaseResolver = regionDatabaseProvider.for
	const defaultCountry = resolverDefaultCountry(options, !!(await resolveCandidateDBPath())) || undefined
	const resolver = createWOFResolver(lookup)

	const geocodeForIngest = geocodeAddressVia({
		parse: async (raw) => decodeAsJSON(await classifier.parse(raw, { postcodeRepair: true })),
		geocode: (raw) =>
			geocodeAddress(raw, {
				classifier,
				resolver,
				databases,
				defaultCountry,
				interpCalibration: INTERP_RADIUS_CALIBRATION,
				...(options.placeCountry ? {} : { placeCountry: false }),
			}),
		country: defaultCountry,
	})

	return {
		geocodeAddress: geocodeForIngest,
		[Symbol.dispose]: () => {
			regionDatabaseProvider[Symbol.dispose]()
			lookup[Symbol.dispose]()
		},
	}
}

/**
 * Command-level wiring for the record-matcher tool geocoder (`--wof`/`--data-root`/`--locale` + model swaps).
 */
export interface EvalGeocoderFlags {
	/**
	 * WOF admin SQLite path.
	 *
	 * Default `$MAILWOMAN_DATA_ROOT/wof/admin-global-priority.db`.
	 */
	wof?: string
	/**
	 * Per-state database root.
	 *
	 * Default `$MAILWOMAN_DATA_ROOT`.
	 */
	dataRoot?: string
	/**
	 * Weights locale.
	 *
	 * Default en-US.
	 */
	locale?: string
	/**
	 * Model-swap overrides (`nppes-benchmark` multi-version curves).
	 *
	 * `modelCardPath` is mandatory with `modelPath`.
	 */
	modelPath?: string
	tokenizerPath?: string
	modelCardPath?: string
}

/**
 * Build the {@link EvalGeocoderFactory} the `@mailwoman/registry/tools` record-matcher tools take.
 *
 * This is the eval scripts' historical construction, preserved exactly: a plain `WOFSQLitePlaceLookup`
 * over an explicit WOF path (not the candidate-table backend {@link buildGeocoder} uses),
 * `defaultCountry: "US"`, `placeCountry: false`, and `postcodeRepair: true` at the parse —
 * so migrated evals reproduce the retired scripts' numbers.
 * Shared by the `registry train-scorer` and `registry scorer-eval` commands.
 */
export function evalGeocoderFactory(flags: EvalGeocoderFlags): EvalGeocoderFactory {
	return async (init): Promise<EvalGeocoder> => {
		const { dataRootPath } = await import("@mailwoman/core/utils")
		const { decodeAsJSON } = await import("@mailwoman/core/decoder")
		const { NeuralAddressClassifier } = await import("@mailwoman/neural")
		const { geocodeAddressVia } = await import("@mailwoman/registry")
		const { createWOFResolver } = await import("@mailwoman/resolver")

		const [{ geocodeAddress }, { RegionDatabaseProvider }] = await Promise.all([
			import("#geocode/core"),
			import("#geocode/regions"),
		])

		const wof = flags.wof || String(dataRootPath("wof", "admin-global-priority.db"))
		const dataRoot = flags.dataRoot || mailwomanDataRoot()

		const classifier = await NeuralAddressClassifier.loadFromWeights({
			locale: flags.locale || "en-US",
			...(flags.modelPath ? { modelPath: flags.modelPath } : {}),
			...(flags.tokenizerPath ? { tokenizerPath: flags.tokenizerPath } : {}),
			...(flags.modelCardPath ? { modelCardPath: flags.modelCardPath } : {}),
		})

		const mod = await import("@mailwoman/resolver-wof-sqlite")
		const lookup = new mod.WOFSQLitePlaceLookup({ databasePath: wof })
		const resolver = createWOFResolver(lookup)
		const regionDatabaseProvider = await RegionDatabaseProvider.create(mod, dataRoot)

		const geocode = (raw: string) =>
			geocodeAddress(raw, {
				classifier,
				resolver,
				databases: regionDatabaseProvider.for,
				defaultCountry: "US",
				placeCountry: false,
				...(init?.normalizeCase !== undefined ? { normalizeCase: init.normalizeCase } : {}),
			})

		const geocodeForIngest = geocodeAddressVia({
			parse: async (raw) => decodeAsJSON(await classifier.parse(raw, { postcodeRepair: true })),
			geocode,
			country: "US",
		})

		return {
			geocodeAddress: geocodeForIngest,
			geocode,
			[Symbol.dispose]: () => {
				regionDatabaseProvider[Symbol.dispose]()
				lookup[Symbol.dispose]()
			},
		}
	}
}

/**
 * One dataset in a `--sources` config: where it lives, its mapping, an optional provenance label + row cap.
 */
interface MultiSourceSpec {
	path: string
	delimiter?: "comma" | "tab"
	mapping: ColumnMapping
	source?: string
	/**
	 * For --reconcile: whether this dataset denotes eligibility/membership or funding/enrollment.
	 */
	role?: "eligibility" | "funding"
	/**
	 * Read at most this many rows (the head of the file) — sampling a huge source without pre-filtering.
	 */
	limit?: number
}

/**
 * Parse `--sources` (a file path or inline JSON) into specs.
 */
export async function loadSources(option: string): Promise<MultiSourceSpec[]> {
	const text = /^[[{]/.test(option.trim()) ? option : await readLocalTextFile(option)
	const parsed = tryParsingJSON(text)

	if (parsed === null) {
		throw new CommandError(`--sources is neither a readable file nor valid JSON: ${text}`)
	}

	if (!Array.isArray(parsed) || parsed.some((s) => !s || typeof (s as MultiSourceSpec).path !== "string")) {
		throw new CommandError("--sources must be a JSON array of { path, mapping, source?, delimiter?, limit? }.")
	}

	return parsed as MultiSourceSpec[]
}

/**
 * Write the artifacts requested via `--out` (GeoJSON) and/or `--map-out` (standalone html map),
 * returning the lines to append to the run summary.
 *
 * @returns `null` when neither is set — the signal to dump GeoJSON to stdout (the original default).
 *   Shared by both pipeline paths.
 */
async function writeOutputs(
	geojson: GeoFeatureCollection<PointLiteral, EntityGeoData>,
	options: Options
): Promise<string | null> {
	if (!options.out && !options.mapOut) return null

	const { toMapHTML } = await import("@mailwoman/registry")
	const lines: string[] = []

	if (options.out) {
		await writeLocalJSONFile(geojson, options.out)
		lines.push(`wrote ${geojson.features.length} features → ${options.out}`)
	}

	if (options.mapOut) {
		await writeLocalFile(
			toMapHTML(geojson, options.source ? { title: `Mailwoman — ${options.source}` } : {}),
			options.mapOut
		)

		lines.push(`wrote map → ${options.mapOut} (serve over localhost to view)`)
	}

	return lines.join("\n")
}

/**
 * Multi-source mode (#618): stream each dataset under its own mapping + provenance
 * label into one combined record set, geocode, resolve, and report the entities
 * that span ≥2 sources — the cross-dataset links.
 *
 * No shared key required.
 * Geography is the join.
 */
async function runMultiSource(specs: MultiSourceSpec[], options: Options): Promise<string> {
	const {
		ingestRows,
		reconcileCoverage,
		reconciliationGeoJSON,
		reconciliationReport,
		resolveEntities,
		streamRows,
		toGeoJSON,
	} = await import("@mailwoman/registry")

	using geocoder = await buildGeocoder(options)
	const { geocodeAddress: geocodeForIngest } = geocoder

	const records: SourceRecord[] = []
	const perSource: string[] = []

	for (const sourceSpec of specs) {
		const label = sourceSpec.source ?? sourceSpec.path
		const mapping: ColumnMapping = { ...sourceSpec.mapping, source: label }
		let read = 0

		const rows = (async function* () {
			for await (const row of streamRows(
				sourceSpec.path,
				sourceSpec.delimiter ? { delimiter: sourceSpec.delimiter } : {}
			)) {
				if (sourceSpec.limit !== undefined && read >= sourceSpec.limit) break

				read++
				yield row
			}
		})()

		const recs = await ingestRows(rows, mapping, { geocodeAddress: geocodeForIngest })

		for (const record of recs) {
			record.id = `${label}:${record.id}`
		}

		// namespace ids so cross-source ids never collide
		records.push(...recs)
		perSource.push(`${label} ${recs.length}`)
	}

	// learnedScorer:false — multi-source is cross-dataset link discovery (recall-oriented):
	// the same facility under different operational names across sources is the signal we want.
	// The default GBT is dedup-calibrated and rejects exactly that
	// (it learned "same place + name drift = distinct"), so the cross-dataset path uses the FS spine.
	// (Single-CSV dedup below keeps the GBT default.)
	const result = resolveEntities(records, {
		trainEM: options.trainEm,
		threshold: options.threshold,
		learnedScorer: false,
		...(options.maxBlockSize !== undefined ? { maxBlockSize: options.maxBlockSize } : {}),
	})

	const geocoded = records.filter((r) => r.address?.geocode).length

	// Reconciliation mode (#621): classify entities by eligibility/funding role membership,
	// via the same @mailwoman/registry library as `registry scorer-eval coverage-reconciliation`.
	if (options.reconcile) {
		const labelOf = (s: MultiSourceSpec) => s.source ?? s.path
		const eligibilitySources = specs.filter((s) => s.role === "eligibility").map(labelOf)
		const fundingSources = specs.filter((s) => s.role === "funding").map(labelOf)

		if (!eligibilitySources.length || !fundingSources.length) {
			throw new CommandError(
				'--reconcile needs each --sources entry tagged with `role: "eligibility"` or `role: "funding"` ' +
					"(at least one of each)."
			)
		}

		const recon = reconcileCoverage(result.entities, { eligibilitySources, fundingSources })
		const geojson = reconciliationGeoJSON(recon)

		const report = reconciliationReport(recon, {
			scopeNote:
				`Resolved BLIND across ${specs.length} sources via \`mailwoman registry --reconcile\` ` +
				`(${perSource.join(", ")}). Eligibility: ${eligibilitySources.join(", ")}; funding/enrollment: ` +
				`${fundingSources.join(", ")}.`,
			scorerNote:
				"Scored with the Fellegi-Sunter spine (cross-dataset join, recall-oriented): the dedup-calibrated " +
				'GBT default (#603) rejects the "same place, different operational name" pattern that IS the ' +
				"cross-source signal, so it is pinned off here. See #655.",
		})

		const written = await writeOutputs(geojson, options)

		return written === null ? report : `${report}\n\n${written}`
	}

	const geojson = toGeoJSON(result.entities)

	const crossSource = result.entities.filter(
		(e) => new Set(e.records.map((r) => r.source).filter(isPresent)).size >= 2
	).length

	const summary =
		`registry --sources: ${specs.length} sources (${perSource.join(", ")}) → ${records.length} records ` +
		`(${geocoded} geocoded) → ${result.entities.length} entities; ${crossSource} span ≥2 sources (cross-dataset links)`

	const written = await writeOutputs(geojson, options)

	return written === null ? prettyJSON(geojson) : `${summary}\n${written}`
}

//#endregion

//#region Core

async function runRegistry(csvPath: string, options: Options): Promise<string> {
	const { inferMapping, ingestRows, streamRows, resolveEntities, toGeoJSON } = await import("@mailwoman/registry")

	if (options.reconcile) {
		throw new CommandError(
			"--reconcile is a cross-source mode: pass --sources <config.json> (each entry tagged with a " +
				"`role`), not a single positional CSV."
		)
	}

	const rows = await Array.fromAsync(streamRows(csvPath))
	// --infer-mapping reads the header (the first row's keys) and guesses the mapping.
	// An explicit --mapping still merges on top of it.
	// Otherwise the base is the built-in default.
	const base = options.inferMapping && rows[0] ? inferMapping(Object.keys(rows[0])) : DEFAULT_MAPPING
	const mapping = await loadMapping(options.mapping, options.source, base)
	using geocoder = await buildGeocoder(options)
	const { geocodeAddress: geocodeForIngest } = geocoder

	const records = await ingestRows(rows, mapping, { geocodeAddress: geocodeForIngest })

	const result = resolveEntities(records, {
		trainEM: options.trainEm,
		threshold: options.threshold,
		...(options.maxBlockSize !== undefined ? { maxBlockSize: options.maxBlockSize } : {}),
	})

	const geojson = toGeoJSON(result.entities)

	const geocoded = records.filter((r) => r.address?.geocode).length

	const summary =
		`registry: ${rows.length} rows → ${records.length} records (${geocoded} geocoded) → ` +
		`${result.entities.length} entities ` +
		`(${result.candidatePairs} candidate pairs${result.droppedBlocks.length ? `, ${result.droppedBlocks.length} oversized blocks skipped` : ""})`

	const written = await writeOutputs(geojson, options)

	return written === null ? prettyJSON(geojson) : `${summary}\n${written}`
}

//#endregion

//#region React command component

const RegistryCommand: ParsedCommandComponent<Options> = ({ args, options }) => {
	const state = useCommandTask(async () => {
		// `loadSources` can throw on a malformed config — the hook routes its error to the same handler.
		if (options.sources) {
			return await runMultiSource(await loadSources(options.sources), options)
		}

		const csv = args?.[0]

		if (!csv || !csv.trim().length) {
			throw new CommandError(
				"registry requires a positional CSV path (or --sources <config.json> for multi-source). " +
					"e.g. mailwoman registry contacts.csv --out entities.geojson"
			)
		}

		return await runRegistry(csv.trim(), options)
	})

	if (state.status !== "done") return <CommandTaskResult state={state} running={<Spinner />} />

	return <Text>{state.result}</Text>
}

export default RegistryCommand

//#endregion
