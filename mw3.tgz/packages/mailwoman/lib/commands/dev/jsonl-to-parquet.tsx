/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   `mailwoman dev jsonl-to-parquet --input <labeled.jsonl> --output <database.parquet>` — convert a
 *   jsonl of LabeledRow objects to a Parquet database matching the v0.5.0 corpus schema. The #519
 *   char-offset span triple is required on every row. a row without it fails loudly with its line
 *   number.
 */

import { Text } from "ink"

import { type CommandSpec, CommandTaskResult, type CommandComponent, reportToStderr, useCommandTask } from "#cli-kit"

/**
 * Native command-line interface consumed by the filesystem command router.
 */
export const spec = {
	name: "jsonl-to-parquet",
	description: "Convert labeled-row JSONL to a Parquet corpus database.",
	options: {
		input: { type: "string", required: true, description: "The labeled-row JSONL to convert" },
		out: { type: "string", required: true, description: "The parquet database to write", deprecatedName: "output" },
		"row-group-size": { type: "number", default: 50_000, description: "Parquet row-group size" },
	},
} as const satisfies CommandSpec

const DevJSONLToParquet: CommandComponent<typeof spec> = ({ options }) => {
	const state = useCommandTask(async () => {
		const { jsonlToParquet } = await import("@mailwoman/corpus/tools")

		return jsonlToParquet(
			{ input: options.input, output: options.out, rowGroupSize: options.rowGroupSize },
			reportToStderr
		)
	})

	if (state.status !== "done") return <CommandTaskResult state={state} />

	if (state.status === "done") {
		return (
			<Text color="green">
				✓ {state.result.read} rows read, {state.result.written} written → {state.result.outPath}
			</Text>
		)
	}

	return null
}

export default DevJSONLToParquet
