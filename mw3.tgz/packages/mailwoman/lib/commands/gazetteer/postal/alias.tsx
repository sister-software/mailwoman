/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   `mailwoman gazetteer postal-alias` — build the postal-city alias table (#475) from the
 *   pinned-release Overture US Parquet: per-address ground truth for the
 *   postal-city/geographic-city split that the resolver's coordinate-first soft-scorer currently
 *   approximates geometrically.
 *
 *   The signal: 45.9M US rows carry both `postal_city` (what the postal system calls the place — USPS
 *   "acceptable city names", vanity cities) and a geographic locality (`address_levels[2]`); 16.0M
 *   of them (34.9%) diverge. Aggregated per `(postcode, postal_city, geo_locality)` with observed
 *   counts, that divergence is the alias evidence: "postcode 10954's mail says Nanuet. the polygon
 *   says Clarkstown".
 *
 *   sibling table by design (`postal_city_alias`, its own sqlite) — never mixed into the PIP-derived
 *   `postcode_locality` rows: one table = one provenance class (feedback-no-irrelevant-trivia). A
 *   count floor drops typo noise. everything kept is observed-in-the-wild N times, with N
 *   recorded.
 *
 *   Writes the output DB directly (deletes any prior file, then builds in place) — same behavior as
 *   the original `scripts/build-postal-city-alias.ts`. Progress streams to stderr. the final
 *   summary is on stdout. @duckdb/node-api is an optional peer, imported dynamically inside the
 *   build.
 */

import { removePathIfPresent, makeDirectories } from "@mailwoman/core/fs/writers"
import type { PostalCityAliasDatabase } from "@mailwoman/resolver-wof-sqlite"
import { Box, Text } from "ink"
import { dirname } from "path-ts"

import { type CommandSpec, CommandTaskResult, type CommandComponent, useCommandTask } from "#cli-kit"

/**
 * Native command-line interface consumed by the filesystem command router.
 */
export const spec = {
	name: "postal-alias",
	description: "Build the postal-city alias database",
	options: {
		release: { type: "string", default: "2026-05-20.0", description: "Pinned Overture release" },
		"min-count": {
			type: "number",
			default: 25,
			validate: (value: number) => Number.isInteger(value) && value > 0,
			description: "Minimum aggregate observation count",
		},
		out: { type: "string", description: "Output DB path. Default <data-root>/wof/postal-city-alias-us.db" },
	},
} as const satisfies CommandSpec

const GazetteerPostalAlias: CommandComponent<typeof spec> = ({ options }) => {
	const state = useCommandTask(async () => {
		const { DatabaseClient } = await import("@mailwoman/sqlite/client")
		const { dataRootPath } = await import("@mailwoman/core/utils")

		const out = options.out ?? dataRootPath("wof", "postal-city-alias-us.db")
		const parquet = dataRootPath("overture", options.release, "addresses-us.parquet")
		const minCount = options.minCount

		await makeDirectories(dirname(out))
		await removePathIfPresent(out)

		// @duckdb/node-api is an optional peer dep — import it dynamically so merely loading this
		// command (e.g. `mailwoman --help`, which eagerly imports every command) doesn't fault when the peer isn't installed.
		const { DuckDBInstance } = await import("@duckdb/node-api")

		console.error(`▸ aggregating ${parquet} (min-count ${minCount})`)

		const instance = await DuckDBInstance.create()
		const duck = await instance.connect()

		const result = await duck.runAndReadAll(`
			SELECT
				trim(postcode) AS postcode,
				lower(trim(postal_city)) AS postal_city,
				lower(trim(address_levels[2].value)) AS geo_locality,
				count(*)::BIGINT AS n
			FROM read_parquet('${parquet}')
			WHERE nullif(trim(postcode), '') IS NOT NULL
				AND nullif(trim(postal_city), '') IS NOT NULL
				AND nullif(trim(address_levels[2].value), '') IS NOT NULL
			GROUP BY 1, 2, 3
			HAVING count(*) >= ${minCount}
		`)

		const rows = result.getRowObjects() as {
			postcode: string
			postal_city: string
			geo_locality: string
			n: bigint
		}[]

		console.error(`▸ writing ${rows.length.toLocaleString()} rows → ${out}`)

		await using kdb = new DatabaseClient<PostalCityAliasDatabase>(out)
		kdb.exec("PRAGMA journal_mode = WAL;")
		// DDL via the shared createPostalCityAliasTable builder.
		// The exact table the reader + tests use, so this producer can't drift from postal-city-alias-schema.ts.
		// DuckDB above is the raw parquet reader.
		// The hot insert below stays on the raw `db` handle.
		const { createPostalCityAliasTable } = await import("@mailwoman/resolver-wof-sqlite/postal")

		await createPostalCityAliasTable(kdb)

		const insert = kdb.prepare(
			"INSERT INTO postal_city_alias (postcode, postal_city, geo_locality, n, divergent, source, release) VALUES (?, ?, ?, ?, ?, ?, ?)"
		)

		kdb.exec("BEGIN")
		let divergent = 0

		for (const r of rows) {
			const isDivergent = r.postal_city !== r.geo_locality ? 1 : 0
			divergent += isDivergent

			insert.run(
				r.postcode,
				r.postal_city,
				r.geo_locality,
				Number(r.n),
				isDivergent,
				"overture:US",
				String(options.release)
			)
		}

		kdb.exec("COMMIT")
		// Indexes were created by createPostalCityAliasTable above.
		// Just checkpoint + compact.
		kdb.exec("PRAGMA wal_checkpoint(TRUNCATE); VACUUM;")

		return [
			`postal-city alias: ${out}`,
			`${rows.length.toLocaleString()} (postcode, postal_city, geo_locality) pairs (n >= ${minCount})`,
			`divergent pairs: ${divergent.toLocaleString()} (${((100 * divergent) / Math.max(1, rows.length)).toFixed(1)}%)`,
		]
	})

	if (state.status !== "done") return <CommandTaskResult state={state} />

	if (state.status === "done") {
		return (
			<Box flexDirection="column">
				{state.result.map((line, i) => (
					<Text key={i} color={i === 0 ? "green" : undefined}>
						{i === 0 ? "✓ " : "  "}
						{line}
					</Text>
				))}
			</Box>
		)
	}

	return null // progress streams to stderr until the summary lands
}

export default GazetteerPostalAlias
