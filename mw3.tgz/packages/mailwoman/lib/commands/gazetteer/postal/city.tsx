/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   `mailwoman gazetteer postal-city` — build the postal-city candidate side-index (#741 / #475) into
 *   a candidate gazetteer so the candidate-backend resolver (the demo/CLI default) can resolve a
 *   user-typed postal city to its geographic locality. Adds one table,
 *   `postal_city_candidate(name_key, postcode → spr_id, …)`, keyed exactly by `(name_key,
 *   postcode)`.
 *
 *   Bridge (no admin-DB join): for each divergent `(postcode, postal_city)` in the alias DB, the
 *   `postcode_locality` database gives the postcode's containing `locality_id`; that locality's
 *   coordinate and name come straight from the candidate table's own row for that `spr_id`. So a
 *   postal-city query with the postcode resolves to exactly the geographic locality the FTS
 *   coordinate-first path would pick — but via one exact probe, no population/region ranking.
 *
 *   Idempotent: drops + recreates the table each run. Modifies the candidate DB IN place — run it on
 *   a copy to validate, then fold it into the canonical candidate build before republish. Progress
 *   streams to stderr. the final summary is on stdout.
 */

import { allRows } from "@mailwoman/core/utils"
import type { PostalCityCandidateDatabase } from "@mailwoman/resolver-wof-sqlite"
import { Box, Text } from "ink"

import { type CommandSpec, CommandTaskResult, type CommandComponent, useCommandTask } from "#cli-kit"

/**
 * Native command-line interface consumed by the filesystem command router.
 */
export const spec = {
	name: "postal-city",
	description: "Add the postal-city side index to a candidate database",
	options: {
		"candidate-db": { type: "string", required: true, description: "Candidate DB to modify in place" },
		"alias-db": { type: "string", description: "Postal-city alias DB" },
		"postcode-locality-db": { type: "string", description: "Postcode-to-locality DB" },
	},
} as const satisfies CommandSpec

const GazetteerPostalCity: CommandComponent<typeof spec> = ({ options }) => {
	const state = useCommandTask(async () => {
		const { DatabaseClient } = await import("@mailwoman/sqlite/client")
		const { dataRootPath } = await import("@mailwoman/core/utils")

		const candidateDB = options.candidateDB

		const aliasDB = options.aliasDB ?? dataRootPath("wof", "postal-city-alias-us.db")
		const postcodeLocalityDB = options.postcodeLocalityDB ?? dataRootPath("wof", "postcode-locality-us.db")

		const { createPostalCityCandidateTable, POSTAL_CITY_CANDIDATE_COLUMNS, POSTAL_CITY_CANDIDATE_TABLE } =
			await import("@mailwoman/resolver-wof-sqlite")

		const { normalizeLocalityForKey } = await import("@mailwoman/resolver-wof-sqlite/street")

		using db = new DatabaseClient<PostalCityCandidateDatabase>(candidateDB)

		// postcode → containing locality_id (the geo-locality the postcode sits in).
		console.error(`▸ loading postcode → locality from ${postcodeLocalityDB}`)

		using pcl = new DatabaseClient<PostalCityCandidateDatabase>(postcodeLocalityDB, { readOnly: true })
		const pcToLocality = new Map<string, number>()

		for (const r of allRows<{ postcode: string; locality_id: number }>(
			pcl.prepare("SELECT postcode, locality_id FROM postcode_locality WHERE is_containing = 1")
		)) {
			// First containing locality per postcode wins (postcodes with one containing polygon — the norm).
			if (!pcToLocality.has(String(r.postcode))) {
				pcToLocality.set(String(r.postcode), Number(r.locality_id))
			}
		}

		// spr_id → {name, lat, lon} from the candidate table's own rows (the coord bridge).
		console.error(`▸ loading candidate coordinates from ${candidateDB}`)

		const sprToPlace = new Map<number, { name: string; lat: number; lon: number }>()

		for (const r of allRows<{ spr_id: number; name: string | null; lat: number; lon: number }>(
			db.prepare("SELECT spr_id, name, latitude AS lat, longitude AS lon FROM candidate WHERE latitude IS NOT NULL")
		)) {
			if (!sprToPlace.has(Number(r.spr_id))) {
				sprToPlace.set(Number(r.spr_id), { name: String(r.name ?? ""), lat: Number(r.lat), lon: Number(r.lon) })
			}
		}

		// Divergent postal-city edges.
		console.error(`▸ loading divergent postal-city edges from ${aliasDB}`)

		using alias = new DatabaseClient<PostalCityCandidateDatabase>(aliasDB, { readOnly: true })

		const edges = allRows<{ postcode: string; postal_city: string }>(
			alias.prepare("SELECT postcode, postal_city FROM postal_city_alias WHERE divergent = 1")
		)

		// DDL via the Kysely schema-builder (the house idiom); the hot insert loop below
		// stays on the raw `node:sqlite` handle for speed.
		// `db` wraps `db` — the two share the one connection.
		await db.schema.dropTable(POSTAL_CITY_CANDIDATE_TABLE).ifExists().execute()
		await createPostalCityCandidateTable(db)

		const insert = db.prepare(
			`INSERT OR IGNORE INTO ${POSTAL_CITY_CANDIDATE_TABLE} (${POSTAL_CITY_CANDIDATE_COLUMNS.join(", ")})
			 VALUES (${POSTAL_CITY_CANDIDATE_COLUMNS.map(() => "?").join(", ")})`
		)

		let inserted = 0
		let noLocality = 0
		let noCoord = 0
		db.exec("BEGIN")

		for (const e of edges) {
			const localityID = pcToLocality.get(String(e.postcode))

			if (localityID === undefined) {
				noLocality++

				continue
			}

			const place = sprToPlace.get(localityID)

			if (!place) {
				noCoord++

				continue
			}

			const key = normalizeLocalityForKey(e.postal_city)

			if (!key) continue
			insert.run(key, String(e.postcode), localityID, place.name, place.lat, place.lon)

			inserted++
		}

		db.exec("COMMIT")
		await db.schema.createIndex("idx_pcc_spr").ifNotExists().on(POSTAL_CITY_CANDIDATE_TABLE).column("spr_id").execute()

		// closes the underlying `db` handle

		const summary = [
			`postal_city_candidate built → ${candidateDB}`,
			`${inserted.toLocaleString()} edges inserted`,
			`${noLocality.toLocaleString()} skipped — postcode has no containing locality in the postcode_locality database`,
			`${noCoord.toLocaleString()} skipped — locality not in candidate table`,
		]

		return summary
	})

	if (state.status !== "done") return <CommandTaskResult state={state} />

	if (state.status === "done") {
		return (
			<Box flexDirection="column">
				{state.result.map((line, i) => (
					<Text key={i} color={i === 0 ? "green" : undefined}>
						{i === 0 ? "✓ " : "  "}
						{line}
					</Text>
				))}
			</Box>
		)
	}

	return null // progress streams to stderr until the summary lands
}

export default GazetteerPostalCity
