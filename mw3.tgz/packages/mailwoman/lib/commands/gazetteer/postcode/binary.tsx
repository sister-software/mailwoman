/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   `mailwoman gazetteer postcode-binary` — build per-country browser postcode binaries (#240) from
 *   the SQLite databases. Emits one `postcode-<cc>.bin` per locale into the `--out` dir (default
 *   `docs/static/mailwoman/`, alongside `fst-en-US.bin`), each loadable by `@mailwoman/neural`'s
 *   `PostcodeBinaryResolver` in the wasm/browser parser. Per-country so the browser fetches only
 *   the locale it needs (the tiered-loading story in the design doc).
 *
 *   The database `name` is already the normalized postcode key (DE/FR `68161`/`75008`, NL space-less
 *   `1012LM`, US `94105`). It is exactly what the anchor queries. Therefore, it serializes verbatim.
 *
 *   **GB is special**, and it is where this command shipped two defects (#1509 — the derivation and
 *   the refusal both live in `gazetteer-pipeline/postcode/binary.ts`, with the reproduction). The
 *   outward district is now derived by shape (the inward code is the trailing three characters of the
 *   space-stripped form), so the same rule reads the spaced GeoNames-lineage database and the
 *   space-stripped Code-Point Open one. `--gb-granularity` picks the key set:
 *
 *   - `unit` (default) — every unit plus its outward district: 1,749,839 keys / 20.0 MB from
 *       `postalcode-gb-codepoint.db`. This is the train-faithful set. A model trained against
 *       `pilot-anchor-lookup-v2` was painted from unit centroids, so serving it anything coarser feeds
 *       the anchor channel a different distribution than training saw.
 *   - `outward` — districts only: 2,863 keys / 0.03 MB. The only GB set that fits a browser bundle, and
 *       the command's original behaviour.
 *
 *   Every locale's key count is checked against a documented floor before anything is written. a build
 *   below it exits nonzero with a named reason rather than shipping a valid, empty binary.
 *
 *   Defaults to `POSTCODE_BINARY_SOURCES` (`gazetteer-pipeline/postcode/binary.ts`): US, NL/FR/DE/ES/IT
 *   from `postalcode-intl.db`, and GB from `postalcode-gb-codepoint.db` (the licence-clean OGL v3.0
 *   source). Each `.bin` is written directly to `--out` (the original
 *   `scripts/build-postcode-binary.ts` behavior). Per-locale progress streams to stderr. the roll-up
 *   lands on stdout.
 */

import { ByteFormatter } from "@mailwoman/core/fs/formatters"
import { pathExists } from "@mailwoman/core/fs/readers"
import { writeLocalFile } from "@mailwoman/core/fs/writers"
import { allRows } from "@mailwoman/core/utils"
import type { WOFDatabase } from "@mailwoman/resolver-wof-sqlite/schema"
import { DatabaseClient } from "@mailwoman/sqlite/client"
import { Box, Text } from "ink"
import { join } from "path-ts"

import { type CommandSpec, CommandTaskResult, type CommandComponent, useCommandTask } from "#cli-kit"
import type { GBGranularity, PostcodeDatabaseRow } from "#gazetteer-pipeline/postcode/binary"

interface LocaleSource {
	country: string
	db: string
}

/**
 * Size past which a `.bin` written into the browser asset dir is worth a word.
 *
 * Not a limit and not enforced.
 * The command's default `--out` is `docs/static/mailwoman`, and a GB unit build lands 20
 * MB there, so the number exists to make the reader notice rather than to decide for them.
 */
const BROWSER_BUDGET_BYTES = 4 * 1024 * 1024

/**
 * Native command-line interface consumed by the filesystem command router.
 */
export const spec = {
	name: "postcode-binary",
	description: "Build postcode binary indexes",
	options: {
		out: { type: "string", default: "docs/static/mailwoman", description: "Output directory" },
		locale: { type: "string", multiple: true, description: "Repeatable <CC>:<db> source override" },
		"gb-granularity": {
			type: "string",
			choices: ["unit", "outward"],
			default: "unit",
			description: "GB key granularity",
		},
	},
} as const satisfies CommandSpec

const GazetteerPostcodeBinary: CommandComponent<typeof spec> = ({ options }) => {
	const state = useCommandTask(async () => {
		const { dataRootPath } = await import("@mailwoman/core/utils")
		// `@mailwoman/neural/postcode-binary-resolver` is a self-contained serializer
		// whose only imports are type-only, so this load costs a file read
		// rather than the ONNX runtime the package name suggests.
		const { serializePostcodeBinary } = await import("@mailwoman/neural/postcode")

		const { browserGranularityFor, buildPostcodeBinaryEntries, keyFloorViolation, POSTCODE_BINARY_SOURCES } =
			await import("#gazetteer-pipeline/postcode/binary")

		const wof = dataRootPath("wof")
		const outDir = options.out

		const locales: LocaleSource[] = []

		for (const localeSpec of options.locale ?? []) {
			const [country, db] = localeSpec.split(":")

			if (country && db) {
				locales.push({ country, db: db.startsWith("/") ? db : join(wof, db) })
			}
		}

		if (!locales.length) {
			locales.push(...POSTCODE_BINARY_SOURCES.map(({ country, database }) => ({ country, db: join(wof, database) })))
		}

		const granularity: GBGranularity = options.gbGranularity
		let written = 0

		for (const { country, db } of locales) {
			if (!(await pathExists(db))) {
				console.error(`skip ${country}: missing ${db}`)

				continue
			}

			using conn = new DatabaseClient<WOFDatabase>(db, { readOnly: true })

			const rows = allRows<PostcodeDatabaseRow>(
				conn.prepare(
					`SELECT name, latitude AS lat, longitude AS lon FROM spr
					 WHERE placetype='postalcode' AND is_current!=0 AND country=?`
				),
				country
			)

			const { entries, skipped, outwardKeys } = buildPostcodeBinaryEntries(country, rows, {
				gbGranularity: granularity,
			})

			// refuse before writing (#1509).
			// A magnitude never carries its own absence: a zero-key binary is structurally valid,
			// so the only place the failure can surface is here.
			const violation = keyFloorViolation(country, entries.length, granularity)

			if (violation) {
				throw new Error(
					`${violation} Read ${rows.length.toLocaleString()} rows from ${db}` +
						(skipped ? `, dropped ${skipped.toLocaleString()} as non-${country}-shaped.` : ".")
				)
			}

			const bytes = serializePostcodeBinary(entries)
			const outPath = join(outDir, `postcode-${country.toLowerCase()}.bin`)
			await writeLocalFile(bytes, outPath)

			written++
			const placed = entries.filter((e) => e.lat !== 0 || e.lon !== 0).length

			console.error(
				`${country}: ${entries.length.toLocaleString()} codes (${placed.toLocaleString()} placed` +
					(outwardKeys ? `, ${outwardKeys.toLocaleString()} outward districts` : "") +
					(skipped ? `, ${skipped.toLocaleString()} rows skipped as non-unit-shaped` : "") +
					`) → ${outPath} (${ByteFormatter.formatIEC(bytes.length)})`
			)

			// The GB default is `unit` because that is what the anchor-v2 model was trained
			// against, and a serving bundle shipping anything coarser feeds the channel
			// a different distribution than training painted.
			// But this command's default `--out` is the browser asset dir, where 20 MB is
			// not a postcode binary, it is the whole page budget.
			// The size is printed either way.
			// This names the setting rather than deciding for the operator.
			// Which countries carry a browser granularity is the source table's to say.
			const browserGranularity = browserGranularityFor(country)

			if (browserGranularity && granularity !== browserGranularity && bytes.length > BROWSER_BUDGET_BYTES) {
				console.error(
					`  NOTE: that is the TRAIN-FAITHFUL ${granularity} key set, sized for a serving weights package. ` +
						`For a browser bundle pass --gb-granularity ${browserGranularity} (2,863 keys, 0.02 MB).`
				)
			}
		}

		return [`postcode binaries → ${outDir}`, `wrote ${written} of ${locales.length} locale binary(ies)`]
	})

	if (state.status !== "done") return <CommandTaskResult state={state} />

	if (state.status === "done") {
		return (
			<Box flexDirection="column">
				{state.result.map((line, i) => (
					<Text key={i} color={i === 0 ? "green" : undefined}>
						{i === 0 ? "✓ " : "  "}
						{line}
					</Text>
				))}
			</Box>
		)
	}

	return null // per-locale progress streams to stderr until the roll-up lands
}

export default GazetteerPostcodeBinary
