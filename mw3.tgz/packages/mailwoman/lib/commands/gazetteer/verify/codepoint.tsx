/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   `mailwoman gazetteer verify-codepoint` — `promotion-eval.ts` for the Code-Point Open GB
 *   database. Compares it against the incumbent GeoNames `GB_full` rows on row membership, coordinate
 *   agreement, Northern Ireland coverage, and ten hand-checked landmark probes.
 *
 *   Reports. does not decide. Both databases are opened read-only.
 */

import { prettyJSON } from "@mailwoman/core/json"
import { Box, Text } from "ink"

import { type CommandSpec, CommandTaskResult, type CommandComponent, phaseReporter, useCommandTask } from "#cli-kit"

/**
 * Native command-line interface consumed by the filesystem command router.
 */
export const spec = {
	name: "verify-codepoint",
	description: "Compare a Code-Point Open database against its incumbent.",
	options: {
		codepoint: {
			type: "string",
			description: "Candidate database. Default <data-root>/wof/postalcode-gb-codepoint-<YYYY-MM-DD>.db",
		},
		incumbent: {
			type: "string",
			description: "Incumbent database. Default <data-root>/wof/frozen-backup-2026-08-04/postalcode-geonames-tail.db",
		},
		json: { type: "boolean", description: "Emit the raw report as JSON instead of the rendered table" },
	},
} as const satisfies CommandSpec

const GazetteerVerifyPostcodeCodePoint: CommandComponent<typeof spec> = ({ options }) => {
	const state = useCommandTask(async () => {
		const { dataRootPath, isoDate } = await import("@mailwoman/core/utils")

		const { runCodePointCheck, formatCodePointCheckReport } =
			await import("#gazetteer-pipeline/postcode/codepoint/comparison")

		const stamp = isoDate()

		const report = runCodePointCheck({
			codepointPath: options.codepoint ?? String(dataRootPath("wof", `postalcode-gb-codepoint-${stamp}.db`)),
			incumbentPath:
				options.incumbent ?? String(dataRootPath("wof", "frozen-backup-2026-08-04", "postalcode-geonames-tail.db")),
			onPhase: phaseReporter(),
		})

		return options.json ? [prettyJSON(report)] : formatCodePointCheckReport(report)
	})

	if (state.status !== "done") return <CommandTaskResult state={state} />

	if (state.status === "done") {
		return (
			<Box flexDirection="column">
				{state.result.map((line, i) => (
					<Text key={i} color={i === 0 ? "green" : undefined}>
						{i === 0 ? "✓ " : "  "}
						{line}
					</Text>
				))}
			</Box>
		)
	}

	return null
}

export default GazetteerVerifyPostcodeCodePoint
