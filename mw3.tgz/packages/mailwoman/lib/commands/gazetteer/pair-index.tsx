/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   `mailwoman gazetteer pair-index` — build the PIX1 placetype-pair index (placetype-pair-prior
 *   arc) from the HM Land Registry PPD tuples CSV (`corpus/src/tools/fetch/ppd.ts`'s
 *   `gb-tuples.csv`; columns `number,street,city,district,region,postcode`). Streams the CSV
 *   (CSVSpliterator, the `corpus/src/database-recipes/locale.ts` `readTuples` idiom), folds
 *   child=city/parent=district through `normalizeFSTToken` and tags every pair `dependent_locality`
 *   (`PairIndexBuilder`, `gazetteer-pipeline/pair-index.ts` — the extracted, unit-tested fold/dedupe/
 *   skip logic), then writes `pair-index-<country>.bin` via `serializePairIndex`.
 *
 *   `--delta` is required with no default: it's the soft-prior bias magnitude a probe hit will
 *   contribute at decode time, and the calibration task (not this one) owns the real value — a
 *   silent default here would let an uncalibrated number ship unnoticed. `--parent-delta` follows the
 *   same discipline one step weaker: optional, no default, and omitting it writes no header key, so
 *   an artifact whose locale nobody has boarded the parent side of ships with the parent bias off
 *   rather than with an inherited magnitude (the D-rule's per-locale check, expressed in the build).
 *
 *   parent tags (PIX2 / schema 3). Every entry records the parent's own `ComponentTag`, and each
 *   source states it from its own semantics — see {@link SOURCE_PARENT_TAGS} for the table and the
 *   evidence line behind each row. Nothing here defaults one.
 *
 *   Self-verifying (the sealed-artifact spirit — see agents.md's database section, which this
 *   mirrors for a flat binary): after writing, the command re-reads the bytes through a fresh
 *   `PairIndexResolver` and probes a few known (child, parent) pairs, printing `probe OK`/`probe
 *   miss` lines rather than trusting the write silently succeeded.
 *
 *   Also prints the raw (pre-fold) city word-length distribution (p50/p90/p99/max + a per-length
 *   count table) — this sizes the word-span window the decode-side prior walks.
 */

import type { ComponentTag } from "@mailwoman/codex/component"
import { pathExists } from "@mailwoman/core/fs/readers"
import { openReadStream } from "@mailwoman/core/fs/streams"
import { writeLocalFile } from "@mailwoman/core/fs/writers"
import { extractDelimited } from "@mailwoman/core/scripting/arguments"
import type { PairIndexHeaderInput } from "@mailwoman/neural/pair"
import { Box, Text } from "ink"
import { join } from "path-ts"

import { type CommandSpec, CommandTaskResult, type CommandComponent, useCommandTask } from "#cli-kit"

/**
 * The GB source's adjudicated production distinct-pair count.
 * The cross-check this build must reproduce.
 *
 * It sits below the rung-3 census's raw 19,431 lines (`scratchpad/gb-probe-grade/census-gb-pairs.jsonl`)
 * because the production fold merges punctuation-variant duplicates the raw census counts
 * separately (e.g. "St Helens" vs "St. Helens" fold to the same `(child, parent)` key).
 * The collision receipt: 221 merge groups — 220 groups where 2 raw census lines collapse to 1
 * production entry (220 × 1 collapsed line = 220) plus 1 group where 3 raw lines collapse to 1
 * entry (1 × 2 collapsed lines = 2) — 220 + 2 = 222 raw lines absorbed. 19,431 − 222 = 19,209.
 *
 * A mismatch against 19,209 on a real rebuild means this build's fold diverged from
 * the adjudicated baseline rather than that 19,209 is wrong.
 * Investigate before trusting the artifact.
 */
const EXPECTED_GB_PAIR_COUNT = 19_209

/**
 * The raw rung-3 census's pre-fold line count (`scratchpad/gb-probe-grade/census-gb-pairs.jsonl`) —
 * retained as a named constant for provenance/debugging (e.g. Diffing a future source
 * refresh against this cycle's raw count) rather than the cross-check target.
 *
 * See {@link EXPECTED_GB_PAIR_COUNT}'s doc comment for why the production target is lower.
 */
const RUNG3_PRE_FOLD_CENSUS_LINE_COUNT = 19_431

/**
 * The US instance's cross-check (hierarchy campaign R5), measured 2026-08-01
 * against the shipped `admin-global-priority.db`.
 *
 * Unlike GB there is no postal register in the mix.
 * Every pair is WOF-sourced (borough + neighbourhood children under locality/localadmin/borough
 * parents, see `PAIR_PLACETYPES_BY_COUNTRY`), so this number tracks the WOF snapshot alone.
 *
 * A snapshot refresh legitimately moves it.
 * Re-anchor the constant deliberately, after inspecting the diff, rather than relaxing the check.
 */
const EXPECTED_US_PAIR_COUNT = 47_878

/**
 * Known (child, parent) pairs probed after write as a self-check — PER country,
 * keyed by the `--country` code.
 *
 * Probing another country's names against a freshly built index prints reassuring-looking `probe miss`
 * lines that verify nothing (the en-nz first build ran the GB names — caught 2026-07-24).
 * A country without an entry gets a loud skip rather than a false verification.
 */
const PROBE_PAIRS_BY_COUNTRY: Readonly<Record<string, ReadonlyArray<readonly [city: string, district: string]>>> = {
	gb: [
		["Fishburn", "Stockton-on-Tees"],
		["Shoreditch", "London"],
		["Sedgefield", "Stockton-on-Tees"],
	],
	nz: [
		["Plimmerton", "Porirua"],
		// The repeated-name convention's identity pair — the (x,x) evidence the segment rule keys on.
		["Mangawhai", "Mangawhai"],
	],
	// R5 (hierarchy campaign): the US instance's probes.
	// Unlike GB/NZ these are not postal-format dependent localities — USPS routes
	// city/state/ZIP — they are the borough/neighbourhood class the schema's umbrella
	// term covers, sourced from WOF rather than a postal register.
	us: [
		["Astoria", "Queens"],
		["Park Slope", "Brooklyn"],
		["Manhattan", "New York"],
	],
	// R10: the IN instance.
	// Indian addresses carry an area/locality line above the city ("Indiranagar, Bengaluru"),
	// which is the dependent-locality slot.
	in: [
		["Indiranagar", "Bangalore"],
		["Mulund East", "Mumbai"],
	],
	// R11: the ES + IT instances.
	// Spanish barrios and Italian quartieri under their municipio/comune.
	es: [
		["Aravaca", "Madrid"],
		["Triana", "Sevilla"],
	],
	it: [
		["Barona", "Milano"],
		["Trastevere", "Roma"],
	],
	// R9: the DE instance.
	// Ortsteile/Stadtteile under their Gemeinde.
	// The line German addresses carry when they carry one at all
	// (the Ortsteil sits above "PLZ Stadt", never inside it).
	de: [
		["Nippes", "Köln"],
		["Schwabing", "München"],
	],
	// R6: the FR instance.
	// These are lieux-dits under their communes (BAN `nom_ld`) rather than quartiers —
	// see gazetteer-pipeline/lieudit-pairs.ts for why the French source differs from the US one.
	fr: [
		["Pinsonnac", "Montpeyroux"],
		["Line", "Salignac-Eyvigues"],
	],
}

/**
 * The parent-slot `ComponentTag` each source column carries (PIX2 / schema 3).
 *
 * PIX2 records the parent's tag per entry rather than deriving it from the child's,
 * so every source has to name the slot it read.
 * The evidence for each:
 *
 * - `registerDistrict` — the `--source` CSV's `district` column.
 *   On GB's PPD tuples that is the post town (`corpus/src/database-recipes/locale.ts`'s
 *   `districtAsLocality` check reads it as the locality line); on the NZ linz/OpenAddresses
 *   countrywide export it is the town/city above the suburb in `city`.
 *   Both are the locality slot.
 * - `secondaryPairsJSONL` — the `--pairs-jsonl` files.
 *   All three shipped ones pair a neighbourhood-class child with a town:
 *   `london-pairs-v2.jsonl` (966 London wards ∪ neighbourhoods under "London", R3/R4b),
 *   `ni-pairs-v1.jsonl` (87 Belfast-area, R7), `gb-regions-v1.jsonl`
 *   (10,708 Scotland/Wales/England villages under their post town or civil parish, R8 — with the parish's
 *   administrative suffix stripped precisely so the parent reads as the town an address writes).
 *   A line may override with its own `parentTag` when a future source is not that shape.
 *
 * The two remaining sources state their own and are not in this table:
 * `--borough-db` reads the WOF parent row's placetype per pair (`borough-pairs.ts`),
 * and `--ban-dir` is always the commune (`lieudit-pairs.ts`).
 */
const SOURCE_PARENT_TAGS = {
	registerDistrict: "locality",
	secondaryPairsJSONL: "locality",
} as const satisfies Record<string, ComponentTag>

/**
 * Split a comma-separated path list, tolerating whitespace and an absent value.
 *
 * Each secondary source stays its own file rather than being pre-merged into a blob,
 * so every one keeps a distinct provenance md5 in the header — which is what lets
 * a freshness guard notice that exactly one of them changed.
 */
function splitPathList(value: string | undefined): string[] {
	return extractDelimited(value)
}

/**
 * Native command-line interface consumed by the filesystem command router.
 */
export const spec = {
	name: "pair-index",
	description: "Build a placetype-pair index",
	options: {
		out: { type: "string", default: "docs/static/mailwoman", description: "Output directory" },
		country: { type: "string", default: "gb", description: "ISO country code" },
		source: { type: "string", description: "Source tuples CSV" },
		delta: { type: "number", required: true, description: "Soft-prior bias magnitude" },
		"transition-beta": { type: "number", description: "Transition-entry bonus" },
		"parent-delta": { type: "number", description: "Parent-window bias" },
		"holdout-fraction": {
			type: "number",
			default: 0,
			validate: (value: number) => value >= 0 && value <= 1,
			description: "Deterministic holdout fraction",
		},
		"pairs-jsonl": { type: "string", description: "Secondary pairs JSONL" },
		"borough-db": { type: "string", description: "WOF admin DB" },
		"ban-dir": { type: "string", description: "BAN source directory" },
		"holdout-seed": { type: "number", default: 42, description: "Holdout seed" },
	},
} as const satisfies CommandSpec

const GazetteerPairIndex: CommandComponent<typeof spec> = ({ options }) => {
	const state = useCommandTask(async () => {
		const { dataRootPath, md5File } = await import("@mailwoman/core/utils")
		// Both `@mailwoman/neural` subpaths are self-contained — `fst-prior` type-imports from a sibling
		// and `pair-index-resolver` reaches only `core/types` — so neither load pulls the ONNX runtime.
		const { normalizeFSTToken } = await import("@mailwoman/neural/fst-prior")
		const { PairIndexResolver, serializePairIndex } = await import("@mailwoman/neural/pair")
		const { PairIndexBuilder, applyPairIndexHoldout } = await import("#gazetteer-pipeline/pair/index/index")
		const { CSVSpliterator, JSONSpliterator } = await import("spliterator")
		const { extractBoroughPairs } = await import("#gazetteer-pipeline/borough-pairs")
		const { extractLieuDitPairs } = await import("#gazetteer-pipeline/lieudit-pairs")

		const country = options.country.toLowerCase()

		// The PPD tuples CSV is a GB national register.
		// There is no equivalent for the US instance (USPS routes city/state/ZIP,
		// so no postal source carries dependent localities).
		// A country whose pairs come entirely from the WOF/secondary sources below runs
		// with no CSV rather than being handed an empty one.
		const sourcePath =
			options.source ?? (country === "gb" ? String(dataRootPath("ppd", "2026-07-22", "gb-tuples.csv")) : undefined)

		if (sourcePath && !(await pathExists(sourcePath))) {
			throw new Error(`pair-index: source CSV not found: ${sourcePath}`)
		}

		if (!sourcePath && !options.boroughDB && !options.pairsJSONL && !options.banDir) {
			throw new Error(
				`pair-index: country "${country}" has no PPD default — pass --source, --borough-db, --pairs-jsonl or --ban-dir, ` +
					`or the build would write an empty index.`
			)
		}

		const builder = new PairIndexBuilder()
		let header: string[] | null = null
		let cityIx = -1
		let districtIx = -1

		// Same CSVSpliterator idiom as `corpus/src/database-recipes/locale.ts`'s `readTuples`:
		// array mode, no header row consumed by the parser (`header: false`), so we build the
		// column index off the first yielded row ourselves and skip forward from there.
		if (sourcePath) {
			for await (const cells of CSVSpliterator.fromAsync<string[]>(openReadStream(sourcePath), {
				mode: "array",
				header: false,
				enableQuoteHandling: true,
			})) {
				if (header === null) {
					header = cells.map((h) => h.trim().toUpperCase())
					cityIx = header.indexOf("CITY")
					districtIx = header.indexOf("DISTRICT")

					if (cityIx < 0 || districtIx < 0) {
						throw new Error(`pair-index: source header is missing CITY/DISTRICT: ${header.join(",")}`)
					}

					continue
				}

				builder.addRow(cells[cityIx] ?? "", cells[districtIx] ?? "", SOURCE_PARENT_TAGS.registerDistrict)
			}
		}

		// R2 (hierarchy campaign): borough pairs from the WOF admin DB, through the same fold/dedupe
		// as the CSV rows (boroughs project onto dependent_locality — plan/reference/placetype-evidence).
		let boroughsAdded = 0

		if (options.boroughDB) {
			const before = builder.distinctCount

			// `pair.parentTag` is the WOF parent row's placetype projection rather than a per-source constant.
			// A locality/localadmin parent is `locality`, a borough parent is `dependent_locality`.
			for (const pair of extractBoroughPairs(options.boroughDB, country.toUpperCase())) {
				builder.addRow(pair.child, pair.parent, pair.parentTag)
			}

			boroughsAdded = builder.distinctCount - before

			console.error(`pair-index: +${boroughsAdded} distinct borough pairs (WOF admin DB)`)
		}

		// R6: FR lieu-dit pairs from the raw BAN dump.
		// Streams ~26M rows, so it is the slowest source by far — deliberately
		// opt-in per build rather than a default.
		if (options.banDir) {
			const before = builder.distinctCount
			const { pairs, rowsWithLieuDit, filesRead } = await extractLieuDitPairs(options.banDir)

			for (const pair of pairs) {
				builder.addRow(pair.child, pair.parent, pair.parentTag)
			}

			boroughsAdded += builder.distinctCount - before

			console.error(
				`pair-index: +${builder.distinctCount - before} distinct lieu-dit pairs ` +
					`(${filesRead} départements, ${rowsWithLieuDit.toLocaleString()} rows with a clean lieu-dit)`
			)
		}

		// R3: generic secondary pairs (onspd-derived London ward pairs. Future NI/IE sources) —
		// the same fold/dedupe path, counted into the cross-check delta alongside the boroughs.
		if (options.pairsJSONL) {
			for (const path of splitPathList(options.pairsJSONL)) {
				const before = builder.distinctCount

				// Streamed — a `--pairs-jsonl` path is whatever the operator points at,
				// and the onspd ward export already runs to hundreds of thousands of rows.
				// A line may carry its own `parentTag`; all three shipped files are (neighbourhood, post town)
				// sets, so absent means `SOURCE_PARENT_TAGS.secondaryPairsJSONL` — see that table's evidence line.
				// The per-line key exists so a future source of a different shape declares itself
				// rather than inheriting a reading that was only ever true of these three.
				for await (const pair of JSONSpliterator.fromAsync<{
					child: string
					parent: string
					parentTag?: ComponentTag
				}>(path)) {
					builder.addRow(pair.child, pair.parent, pair.parentTag ?? SOURCE_PARENT_TAGS.secondaryPairsJSONL)
				}

				boroughsAdded += builder.distinctCount - before

				console.error(
					`pair-index: +${builder.distinctCount - before} distinct secondary pairs (${path.split("/").pop()})`
				)
			}
		}

		const built = builder.finish()
		const { rowsKept, rowsSkipped, distribution } = built

		// Falsifier-board dev flag: withhold a deterministic fraction of pairs from the build
		// so a downstream eval can measure decode-layer degradation on pairs the index never saw.
		// A no-op (`entries === built.entries` by value) when --holdout-fraction is the 0 default.
		const { kept: entries, heldOut } = applyPairIndexHoldout(
			built.entries,
			options.holdoutFraction,
			options.holdoutSeed
		)

		// Provenance covers every source that contributed rows, in the order they were folded in.
		// A US build has no CSV at all, so an unconditional single-element array would
		// have claimed a source the artifact never read.
		const sourceMD5s = [
			...(sourcePath ? [await md5File(sourcePath)] : []),
			...(options.boroughDB ? [await md5File(options.boroughDB)] : []),
			...(await Promise.all(splitPathList(options.pairsJSONL).map((path) => md5File(path)))),
		]

		// `transitionBeta` and `parentDelta` are spread conditionally so an omitted
		// flag writes no header key at all — not a null/0.
		// For both, an absent key means the mechanism is off, which is a different statement from "off
		// because the magnitude happens to be zero", and the reader treats them that way. schemaVersion +
		// tagTable are stamped by serializePairIndex — format-owned rather than builder claims.
		const pairIndexHeader: PairIndexHeaderInput = {
			country,
			delta: options.delta,
			foldVersion: 1,
			sourceMD5s,
			buildDate: new Date().toISOString(),
			...(options.transitionBeta !== undefined ? { transitionBeta: options.transitionBeta } : {}),
			...(options.parentDelta !== undefined ? { parentDelta: options.parentDelta } : {}),
		}

		const bytes = serializePairIndex(pairIndexHeader, entries)
		const outPath = join(options.out, `pair-index-${country}.bin`)

		await writeLocalFile(bytes, outPath)

		// Self-verifying readback: construct a fresh resolver over the bytes
		// we just wrote (not the in-memory `entries`) and probe known pairs,
		// rather than trusting the write silently succeeded.
		const resolver = new PairIndexResolver(bytes)
		const countryProbePairs = PROBE_PAIRS_BY_COUNTRY[country]

		if (!countryProbePairs) {
			throw new Error(
				`pair-index: no self-check probe pairs registered for country "${country}" — add an entry to ` +
					`PROBE_PAIRS_BY_COUNTRY (probing another country's names verifies nothing).`
			)
		}

		const probeLines = countryProbePairs.map(([city, district]) => {
			const child = normalizeFSTToken(city)
			const parent = normalizeFSTToken(district)
			const edge = resolver.probe(child, parent)

			// Print both ends: a readback that shows only the child tag cannot catch a builder that
			// wrote the wrong parent tag, which is the failure mode PIX2 newly makes possible.
			return edge
				? `PROBE OK: fold("${city}")/fold("${district}") → "${child}"/"${parent}" → ${edge.tag} under ${edge.parentTag}`
				: `PROBE MISS: fold("${city}")/fold("${district}") → "${child}"/"${parent}" → (no entry)`
		})

		const distLines = [
			`CITY word-length distribution (raw, pre-fold; n=${distribution.totalRows.toLocaleString()}): ` +
				`p50=${distribution.p50} p90=${distribution.p90} p99=${distribution.p99} max=${distribution.max}`,
			...distribution.counts.map(
				(b) => `  ${b.words} word${b.words === 1 ? "" : "s"}: ${b.rows.toLocaleString()} rows`
			),
		]

		// The rung-3 cross-check assumes a complete build.
		// A nonzero --holdout-fraction deliberately produces a smaller `entries.length` by design,
		// so the strict count-match check is meaningless (and would misreport "blocked") under holdout.
		// Check against `built.entries.length` (pre-holdout) instead in that case.
		const preHoldoutCount = built.entries.length
		// Pre-fold context suffix — the raw rung-3 census line count, for provenance/debugging
		// (e.g. Diffing a future source refresh against this cycle's raw count).
		// Not the cross-check target.
		// See `EXPECTED_GB_PAIR_COUNT`'s doc comment for the 221-group collision
		// receipt that separates the two numbers.
		const preFoldSuffix = ` (pre-fold rung-3 census: ${RUNG3_PRE_FOLD_CENSUS_LINE_COUNT.toLocaleString()} lines)`

		const checkLine =
			country === "gb"
				? options.holdoutFraction > 0
					? `(cross-check skipped under --holdout-fraction; ${preHoldoutCount.toLocaleString()} distinct pairs before holdout, expects ${(EXPECTED_GB_PAIR_COUNT + boroughsAdded).toLocaleString()})${preFoldSuffix}`
					: preHoldoutCount === EXPECTED_GB_PAIR_COUNT + boroughsAdded
						? `CROSS-CHECK PASS: ${preHoldoutCount.toLocaleString()} distinct pairs (baseline ${EXPECTED_GB_PAIR_COUNT.toLocaleString()} + ${boroughsAdded} borough)${preFoldSuffix}`
						: `CROSS-CHECK BLOCKED: ${preHoldoutCount.toLocaleString()} distinct pairs != baseline ${EXPECTED_GB_PAIR_COUNT.toLocaleString()} + ${boroughsAdded} borough — investigate fold divergence before trusting this artifact${preFoldSuffix}`
				: country === "us"
					? options.holdoutFraction > 0
						? `(cross-check skipped under --holdout-fraction; ${preHoldoutCount.toLocaleString()} distinct pairs before holdout, expects ${EXPECTED_US_PAIR_COUNT.toLocaleString()})`
						: preHoldoutCount === EXPECTED_US_PAIR_COUNT
							? `CROSS-CHECK PASS: ${preHoldoutCount.toLocaleString()} distinct pairs (all WOF-sourced; no postal register)`
							: `CROSS-CHECK BLOCKED: ${preHoldoutCount.toLocaleString()} distinct pairs != ${EXPECTED_US_PAIR_COUNT.toLocaleString()} — a WOF snapshot refresh moves this number, so re-anchor the constant DELIBERATELY (with the diff inspected) rather than trusting the artifact`
					: `(cross-check only registered for gb/us; ${preHoldoutCount.toLocaleString()} distinct pairs)`

		const holdoutLine =
			options.holdoutFraction > 0
				? `HOLDOUT: withheld ${heldOut.length.toLocaleString()}/${preHoldoutCount.toLocaleString()} pairs ` +
					`(fraction=${options.holdoutFraction}, seed=${options.holdoutSeed}) — ${entries.length.toLocaleString()} pairs written`
				: undefined

		return [
			`pair-index-${country}.bin → ${outPath} (${bytes.length.toLocaleString()} bytes)`,
			`header: delta=${options.delta}` +
				(options.transitionBeta !== undefined ? ` transitionBeta=${options.transitionBeta}` : " (no transitionBeta)") +
				(options.parentDelta !== undefined ? ` parentDelta=${options.parentDelta}` : " (no parentDelta)"),
			`rows kept ${rowsKept.toLocaleString()} / skipped ${rowsSkipped.toLocaleString()} (empty CITY)`,
			`distinct pairs: ${entries.length.toLocaleString()}`,
			...(holdoutLine ? [holdoutLine] : []),
			checkLine,
			...distLines,
			...probeLines,
		]
	})

	if (state.status !== "done") return <CommandTaskResult state={state} />

	if (state.status === "done") {
		return (
			<Box flexDirection="column">
				{state.result.map((line, i) => (
					<Text key={i} color={i === 0 ? "green" : undefined}>
						{i === 0 ? "✓ " : "  "}
						{line}
					</Text>
				))}
			</Box>
		)
	}

	return null
}

export default GazetteerPairIndex
