/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   `mailwoman gazetteer granularity` — the per-country gazetteer depth scorecard.
 *
 *   Answers "where does the admin gazetteer bottom out?" for every country it knows, which nobody
 *   had measured: the shipped artifact stocks 9 of WOF's 34 placetypes and carries a
 *   `dependent_locality` tier in 11 of 244 countries. Read-only, no network, no model — three
 *   grouped queries over `spr`/`ancestors` and a markdown render.
 *
 *   The report is a committed artifact (the `fill-rates.md` precedent), so the source md5 and the
 *   parent-coverage floor are pinned in its header. Re-running against a rebuilt gazetteer and
 *   diffing the report is the intended workflow.
 */

import { writeLocalFile, makeDirectories } from "@mailwoman/core/fs/writers"
import { Box, Text } from "ink"
import { dirname } from "path-ts"

import { type CommandSpec, CommandTaskResult, type CommandComponent, useCommandTask } from "#cli-kit"
import { DEFAULT_COVERAGE_FLOOR } from "#gazetteer-pipeline/defaults"

/**
 * Native command-line interface consumed by the filesystem command router.
 */
export const spec = {
	name: "granularity",
	description: "Build the gazetteer-depth scorecard.",
	options: {
		out: {
			type: "string",
			default: "docs/records/evals/coverage/gazetteer-depth-scorecard.md",
			description: "Output markdown",
		},
		source: { type: "string", description: "WOF admin DB" },
		floor: { type: "number", default: DEFAULT_COVERAGE_FLOOR, description: "Parent-coverage floor" },
	},
} as const satisfies CommandSpec

const GazetteerGranularity: CommandComponent<typeof spec> = ({ options }) => {
	const state = useCommandTask(async () => {
		const { dataRootPath, md5File } = await import("@mailwoman/core/utils")
		const { bottomsOutAt, buildGranularityLadder } = await import("#gazetteer-pipeline/granularity/index")
		const { renderGranularityReport } = await import("#gazetteer-pipeline/granularity/report")

		const sourcePath = options.source ?? String(dataRootPath("wof", "admin-global-priority.db"))
		const rows = buildGranularityLadder(sourcePath)

		if (!rows.length) {
			throw new Error(`granularity: no countries measured from ${sourcePath} — is this an admin DB?`)
		}

		const markdown = renderGranularityReport(rows, {
			// Display the portable form.
			// Never bake the resolved lab path into a committed artifact.
			sourcePath: "$MAILWOMAN_DATA_ROOT/wof/admin-global-priority.db",
			sourceMD5: await md5File(sourcePath),
			buildDate: new Date().toISOString(),
			floor: options.floor,
		})

		await makeDirectories(dirname(options.out))
		await writeLocalFile(markdown, options.out)

		const byBottom = new Map<string, number>()

		for (const row of rows) {
			const bottom = bottomsOutAt(row, options.floor) ?? "(none)"

			byBottom.set(bottom, (byBottom.get(bottom) ?? 0) + 1)
		}

		const distribution = [...byBottom.entries()]
			.toSorted((a, b) => b[1] - a[1])
			.map(([rung, n]) => `  ${rung}: ${n.toLocaleString()} countries`)

		return [
			`gazetteer depth scorecard → ${options.out}`,
			`countries measured: ${rows.length.toLocaleString()} (floor ${(options.floor * 100).toFixed(1)}%)`,
			"bottoms out at:",
			...distribution,
		]
	})

	if (state.status !== "done") return <CommandTaskResult state={state} />

	if (state.status === "done") {
		return (
			<Box flexDirection="column">
				{state.result.map((line, i) => (
					<Text key={i} color={i === 0 ? "green" : undefined}>
						{i === 0 ? "✓ " : "  "}
						{line}
					</Text>
				))}
			</Box>
		)
	}

	return null
}

export default GazetteerGranularity
