/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   `mailwoman data inventory` — what is in the data root, and which of it can say how it was built.
 *
 *   Phase 1 of the lab-reproducibility sequence. `data status` answers "did the download arrive"; this
 *   answers the different question underneath it — "if this machine were gone, could the artifact be
 *   rebuilt from what it says about itself".
 *
 *   Output goes through {@linkcode writeRawStdout} rather than Ink for the reason `data/index.tsx` gives:
 *   an Ink frame at least as tall as the viewport emits `\x1b[2J\x1b[3J\x1b[H`, and `3J` wipes the
 *   scrollback. A full listing is 200+ lines, so on any terminal it would.
 */

import { mailwomanDataRoot } from "@mailwoman/core/data-root"
import { ByteFormatter } from "@mailwoman/core/fs/formatters"
import { repoRootPath } from "@mailwoman/core/paths"

import { type CommandSpec, CommandTaskResult, type CommandComponent, useCommandTask, writeRawStdout } from "#cli-kit"
import {
	buildCommandGaps,
	inventorySentence,
	type InventoryEntry,
	Provenance,
	rebuildHint,
	takeInventory,
} from "#data/inventory"

export const description =
	"Report every database in the data root and whether it records how it was built. `layer_manifest` is " +
	"the interface (docs/engineering/reference/layer-interface.mdx); this says how much of the root implements it."

/**
 * Native command-line interface consumed by the filesystem command router.
 */
export const spec = {
	name: "inventory",
	description,
	options: {
		"data-root": { type: "string", description: "Override the data root" },
		depth: { type: "string", description: "Directory levels to walk. Default 2" },
		all: { type: "boolean", default: false, description: "List every artifact; the default shows only the summary" },
		json: { type: "boolean", default: false, description: "Emit the report as JSON" },
	},
} as const satisfies CommandSpec

/**
 * One line per directory: how many of its databases carry a manifest, and how much disk they hold.
 *
 * The rollup is the actionable view and the flat list is not.
 * The 2026-08-17 first run found 210 databases of which 53 were per-state
 * address-point databases from one builder.
 *
 * So a per-artifact list reads as 53 problems where the rollup reads as one,
 * which is also how many code changes it takes to fix.
 */
function rollup(entries: readonly InventoryEntry[]): string[] {
	const by = new Map<string, { total: number; manifested: number; bytes: number }>()

	for (const entry of entries) {
		if (entry.provenance === Provenance.Foreign) continue

		const dir = entry.path.split("/")[0] ?? ""
		const current = by.get(dir) ?? { total: 0, manifested: 0, bytes: 0 }

		current.total++
		current.bytes += entry.bytes

		if (entry.provenance === Provenance.Manifested) {
			current.manifested++
		}

		by.set(dir, current)
	}

	return [...by]
		.toSorted((a, b) => b[1].bytes - a[1].bytes)
		.map(([dir, c]) => {
			const mark = c.manifested === c.total ? "✓" : c.manifested === 0 ? "✗" : "·"

			return `  ${mark} ${String(c.manifested).padStart(3)}/${String(c.total).padEnd(4)} ${ByteFormatter.formatSI(c.bytes).padStart(10)}  ${dir}`
		})
}

const InventoryCommand: CommandComponent<typeof spec> = ({ options }) => {
	const state = useCommandTask(async () => {
		const dataRoot = options.dataRoot ?? String(mailwomanDataRoot())

		const report = await takeInventory({
			dataRoot,
			...(options.depth ? { maxDepth: Number(options.depth) } : {}),
		})

		if (options.json) {
			writeRawStdout(report)

			return { ok: true }
		}

		const lines = [
			`mailwoman data inventory`,
			``,
			inventorySentence(report),
			``,
			`by directory:`,
			...rollup(report.entries),
		]

		// A manifest whose build command cannot be run documents nothing, and both ways of
		// failing that were found on the shipped artifacts: a path the workspace regroup moved,
		// and a path under gitignored `scratchpad/` that exists only on the machine that built it.
		// Reported separately from the count, because these artifacts pass every "has a manifest" check.
		const repoRoot = String(repoRootPath())

		const manifested = report.entries.filter((e) => e.provenance === Provenance.Manifested)

		const broken = (
			await Promise.all(
				manifested.map(async (e) => ({ entry: e, gaps: await buildCommandGaps(e.manifest!.build_cmd, repoRoot) }))
			)
		).filter(({ gaps }) => gaps.length)

		if (broken.length) {
			lines.push(
				``,
				`${broken.length} manifested artifact(s) record a build command that does not resolve in this repo:`,
				...broken.map(
					({ entry, gaps }) =>
						`  ✗ ${entry.path}\n      ${entry.manifest!.build_cmd}\n      missing: ${gaps.join(", ")}`
				)
			)
		}

		if (report.entries.some((e) => e.linkTarget)) {
			lines.push(``, `symlinked — the live choice, recorded nowhere else:`)

			for (const entry of report.entries.filter((e) => e.linkTarget)) {
				lines.push(`  ${entry.path} → ${entry.linkTarget}`)
			}
		}

		if (options.all) {
			lines.push(``, `every artifact:`)

			for (const entry of report.entries) {
				lines.push(
					`  ${entry.provenance.padEnd(14)} ${ByteFormatter.formatSI(entry.bytes).padStart(10)}  ${entry.path}`
				)

				lines.push(`  ${" ".repeat(14)} ${" ".repeat(10)}  ↳ ${rebuildHint(entry)}`)
			}
		} else {
			lines.push(``, `Pass --all to list every artifact with the command that would rebuild it.`)
		}

		writeRawStdout(`${lines.join("\n")}\n`)

		return { ok: true }
	})

	if (state.status !== "done") return <CommandTaskResult state={state} />

	return null
}

export default InventoryCommand
