/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   `mailwoman eval promote` — `promotion-eval.ts` (#479): runs the standard eval battery against a
 *   candidate model, checks every number against an eval spec interface
 *   (`mailwoman/eval-harness/specs/*.json`), and emits `<out-dir>/verdict.json`. Exit 0 = every
 *   floor met and the mask-regression lock held. exit 1 = any miss. exit 2 = usage / lore-guard
 *   refusal. On `pass` it prints the pre-filled `eval ledger-append` command (#885). The module
 *   narrates everything (provenance, battery legs, verdict lines) — this wrapper only owns argv +
 *   the exit code.
 */

import { type CommandSpec, harnessCommand } from "#cli-kit"

export const description = "Promotion check (#479) — eval battery + check-spec floors → verdict.json"

/**
 * Native command-line interface consumed by the filesystem command router.
 */
export const spec = {
	name: "check",
	description,
	options: {
		model: { type: "string", description: "Candidate fp32 ONNX (required)" },
		int8: { type: "string", description: "Quantized int8 sibling — adds the int8 battery + delta cap" },
		check: { type: "string", description: "Check-spec JSON path or registered name (required)" },
		tokenizer: { type: "string", description: "Tokenizer path" },
		card: { type: "string", description: "Model-card JSON" },
		"gazetteer-lexicon": { type: "string", description: "Gazetteer lexicon JSON" },
		"weights-cache": { type: "string", description: "Package-shaped candidate weights directory" },
		"int8-weights-cache": { type: "string", description: "Package-shaped INT8 candidate directory" },
		"out-dir": { type: "string", description: "Battery output dir (default /tmp/eval-<label>-<hhmm>)" },
		"profile-json": { type: "string", description: "Per-leg wall-time ledger, written outside --out-dir" },
	},
} as const satisfies CommandSpec

// `promotion-eval.ts` narrates its own verdict lines, so no `json` — rendering
// anything here would pollute the captured report.
const EvalPromote = harnessCommand(
	spec,
	async (options) => {
		const { runPromotionEval } = await import("#eval-harness/promotion/eval/index")

		return await runPromotionEval(options)
	},
	{ exitCode: (exitCode) => exitCode }
)

export default EvalPromote
