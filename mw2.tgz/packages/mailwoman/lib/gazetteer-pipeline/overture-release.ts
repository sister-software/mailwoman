/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Does a pinned Overture release still exist?
 *
 *   Overture deletes releases from the bucket on roughly a monthly window — a 2026-08-19 listing held two. Every build
 *   that reads Overture carries its own pin (divisions for admin, places for POI, addresses for the corpus ingest.
 *   independent on purpose, because bumping one is a new-vintage decision for that artifact alone), and each pin dies
 *   silently when its release is pruned.
 *
 *   The cost of finding out late is the reason this exists. The admin build reaches `fold-overture` only after the WOF
 *   ingest, so a dead pin surfaced after 2.9 million records and ~30 minutes as `IO Error: No files found that match
 *   the pattern` — a message that reads like a network fault rather than an expired pin. The bucket listing answers in
 *   one request.
 *
 *   Anonymous http against the public bucket rather than the S3 SDK or DuckDB: this must be answerable before any heavy
 *   optional dependency loads and the same listing a human would check.
 */

import { APIClient } from "@mailwoman/core/api"
import { elementText, elementTexts } from "@mailwoman/core/html/document"

const BUCKET_URL = "https://overturemaps-us-west-2.s3.amazonaws.com"

/**
 * Releases currently in the bucket, oldest first.
 */
/**
 * What this function needs from an http client: one `fetch`.
 *
 * Narrower than {@link APIClient} on purpose.
 * A parameter shaped like the whole client makes a test double an assertion rather than
 * an object, and the assertion then survives a signature change that the double does not.
 */
export interface OvertureListingClient {
	fetch(request: {
		url: string
		params?: Record<string, string | number>
		responseType?: string
	}): Promise<{ data: unknown }>
}

/**
 * S3 returns at most 1,000 keys per `ListObjectsV2` response and reports the truncation in `IsTruncated`.
 *
 * A reader that only matches `<Prefix>` cannot see that field, so a truncated first page
 * reads as the whole bucket — and every release past the truncation reads as pruned,
 * which is the one answer this module exists to give correctly.
 */
const LISTING_PAGE_LIMIT = 100

export async function listOvertureReleases(client?: OvertureListingClient): Promise<string[]> {
	const api =
		client ??
		new APIClient({
			displayName: "overture-release-listing",
			axios: { baseURL: BUCKET_URL, timeout: 30_000 },
		})

	const releases: string[] = []
	let continuationToken: string | undefined

	for (let page = 0; page < LISTING_PAGE_LIMIT; page++) {
		const response = await api.fetch<string>({
			url: "/",
			params: {
				"list-type": 2,
				prefix: "release/",
				delimiter: "/",
				...(continuationToken ? { "continuation-token": continuationToken } : {}),
			},
			responseType: "text",
		})

		const body = String(response.data)

		// Every `<Prefix>` element, which includes the request echo `<Prefix>release/</Prefix>`
		// beside the `<CommonPrefixes>` entries.
		// The echo reduces to an empty name and is dropped with any other.
		for (const prefix of elementTexts(body, "Prefix", { xml: true })) {
			const release = prefix.replace(/^release\//, "").replace(/\/$/, "")

			if (release) {
				releases.push(release)
			}
		}

		if (elementText(body, "IsTruncated", { xml: true })?.trim() !== "true") {
			return releases.toSorted()
		}

		continuationToken = elementText(body, "NextContinuationToken", { xml: true })?.trim()

		if (!continuationToken) {
			throw new Error(
				"overture release listing: the bucket reported IsTruncated with no NextContinuationToken, so the remaining releases cannot be read — a short list here would read as a pruned release"
			)
		}
	}

	throw new Error(
		`overture release listing: still truncated after ${LISTING_PAGE_LIMIT} pages (${releases.length} releases read) — refusing to report a partial list as the bucket's contents`
	)
}

export interface ReleaseCheck {
	release: string
	present: boolean
	available: string[]
	/**
	 * `undefined` when the listing itself failed.
	 *
	 * An unreachable bucket is not evidence that a release was pruned, and a build
	 * must not refuse to start because the network blinked.
	 */
	reachable: boolean
	message: string
}

/**
 * Check one pin against the bucket.
 *
 * A failed listing reports `reachable: false` and `present: true` — deliberately permissive.
 * This is a pre-flight whose only job is to turn a 30-minute failure into an immediate one.
 *
 * Letting it block a build on its own network trouble would trade a slow failure for a spurious one.
 */
export async function checkOvertureRelease(release: string, client?: OvertureListingClient): Promise<ReleaseCheck> {
	let available: string[]

	try {
		available = await listOvertureReleases(client)
	} catch (error) {
		return {
			release,
			present: true,
			available: [],
			reachable: false,
			message: `could not list Overture releases (${(error as Error).message}) — proceeding, which is NOT confirmation that ${release} exists`,
		}
	}

	// An empty listing is not an empty bucket.
	// Overture has never held zero releases, so nothing-found means the query was wrong
	// or the response was not the listing — and the first version of this file proved the
	// point by dropping its own query parameters and then reporting a live pin as pruned.
	// Zero is treated as no answer, never as absence.
	if (!available.length) {
		return {
			release,
			present: true,
			available,
			reachable: false,
			message: `Overture release listing came back EMPTY, which is not a bucket with no releases — proceeding, which is NOT confirmation that ${release} exists`,
		}
	}

	const present = available.includes(release)

	return {
		release,
		present,
		available,
		reachable: true,
		message: present
			? `Overture ${release} present (${available.length} release(s) in the bucket: ${available.join(", ")})`
			: `Overture ${release} has been PRUNED — the bucket holds ${available.join(", ")}. ` +
				`Bump the pin for this artifact and treat it as a new-vintage decision.`,
	}
}
