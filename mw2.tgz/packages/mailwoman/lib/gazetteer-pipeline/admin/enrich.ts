/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Admin-gazetteer enrichment — the two post-build steps the #1015 rebuild missed because they lived
 *   as separate scripts, now unskippable pipeline steps:
 *
 *   1. **Region abbreviations** (ports `scripts/add-region-abbrevs.ts`): WOF region records carry only
 *      the full name ("Illinois"); `findPlace('IL')` returned nothing, killing the parent-constraint
 *      the whole resolve walk depends on. Source of truth is the packaged chromium-i18n /
 *      libaddressinput dataset (`core/data/chromium-i18n/ssl-address/<CC>.json`): `sub_keys`
 *      (abbreviations) ↔ `sub_names` (full names), tilde-delimited and index-aligned.
 *   2. **`place_abbr`** (the `id → abbreviation` join table, from `build-slim.ts`): lets the resolver
 *      accept a 2-letter region abbreviation as an exact match. Derived from the step-1 rows, so this
 *      must run after them — and both must precede the FTS build (`place_search` concatenates `names`).
 */

import { pathExists, readLocalJSONFile } from "@mailwoman/core/fs/readers"
import { corePackagePath } from "@mailwoman/core/paths"
import type { DatabaseClient } from "@mailwoman/sqlite/client"
import { join } from "path-ts"

export interface EnrichAdminOptions {
	/**
	 * Chromium-i18n ssl-address spec dir.
	 *
	 * Default: the dataset packaged with `@mailwoman/core`.
	 */
	specsDir?: string
}

export interface EnrichAdminResult {
	abbrevNamesAdded: number
	abbrevCountries: number
	placeAbbrRows: number
}

/**
 * Enrich an admin staging DB: region-abbreviation `names` rows + the `place_abbr` join table.
 *
 * Idempotent.
 */
export async function enrichAdmin<DB>(
	db: DatabaseClient<DB>,
	opts: EnrichAdminOptions = {}
): Promise<EnrichAdminResult> {
	const specsDir = opts.specsDir ?? corePackagePath("data", "chromium-i18n", "ssl-address")

	db.exec("DELETE FROM names WHERE language = 'abbr'")

	// idempotent re-run

	// One read of every region row, bucketed by country.
	// The per-country query it replaces was re-`prepare`d inside the loop, once for each of ~200 countries.
	const regionsByCountry = new Map<string, Array<{ id: number; name: string }>>()

	for (const row of db.prepare("SELECT id, name, country FROM spr WHERE placetype='region'").all() as Array<{
		id: number
		name: string
		country: string
	}>) {
		if (!row.country) continue
		let bucket = regionsByCountry.get(row.country)

		if (!bucket) {
			regionsByCountry.set(row.country, (bucket = []))
		}

		bucket.push({ id: row.id, name: row.name })
	}

	const insert = db.prepare(
		"INSERT INTO names (id, name, placetype, country, language, lastmodified) VALUES (?, ?, 'region', ?, 'abbr', 0)"
	)

	let added = 0

	for (const [cc, regions] of regionsByCountry) {
		const specPath = join(specsDir, `${cc}.json`)

		if (!(await pathExists(specPath))) continue
		const spec = await readLocalJSONFile<{ sub_keys?: string; sub_names?: string }>(specPath)

		if (!spec.sub_keys || !spec.sub_names) continue
		const keys = spec.sub_keys.split("~")
		const names = spec.sub_names.split("~")
		const nameToAbbr = new Map<string, string>()

		for (let i = 0; i < Math.min(keys.length, names.length); i++) {
			const n = names[i]?.trim().toLowerCase()

			if (n && keys[i]) {
				nameToAbbr.set(n, keys[i]!)
			}
		}

		db.exec("BEGIN")

		for (const r of regions) {
			const abbr = nameToAbbr.get(String(r.name).trim().toLowerCase())

			if (abbr && abbr.toLowerCase() !== String(r.name).toLowerCase()) {
				insert.run(r.id, abbr, cc)

				added++
			}
		}

		db.exec("COMMIT")
	}

	// `place_abbr` — the id → abbreviation join the resolver probes for 2-letter exact matches.
	// Rebuilt from the rows above (the build-slim.ts recipe); dropped first so a re-run stays idempotent.
	db.exec("DROP TABLE IF EXISTS place_abbr")
	db.exec("CREATE TABLE place_abbr (id INTEGER NOT NULL, abbr TEXT NOT NULL)")
	db.exec("INSERT INTO place_abbr (id, abbr) SELECT id, name FROM names WHERE language = 'abbr'")
	db.exec("CREATE INDEX place_abbr_by_abbr ON place_abbr (abbr COLLATE NOCASE)")
	db.exec("CREATE INDEX place_abbr_by_id ON place_abbr (id)")
	const placeAbbrRows = (db.prepare("SELECT COUNT(*) n FROM place_abbr").get() as { n: number }).n

	return { abbrevNamesAdded: added, abbrevCountries: regionsByCountry.size, placeAbbrRows }
}
