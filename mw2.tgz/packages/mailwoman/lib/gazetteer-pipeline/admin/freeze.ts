/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   The admin build's Freeze phase, extracted from `scripts/build-unified-wof.ts`: WAL checkpoint →
 *   journal freeze → ancestors closure → `ancestors(id)` index (before the −4 backfill — without it
 *   the backfill's per-candidate lookups full-scan the 13M-row table each time and the build stalls
 *   for hours, #1015) → `wof:hierarchy` −4 backfill (WOF ids only) → coincident_roles → indexes →
 *   analyze → integrity check. Runs IN place on the staging DB. the caller `vacuum into`s the final
 *   artifact afterwards.
 */

import { stringifyJSON } from "@mailwoman/core/json"
import { OVERTURE_ID_BASE } from "@mailwoman/core/resolver/synthetic-id-ranges"
import type { WOFDatabase } from "@mailwoman/resolver-wof-sqlite/schema"
import type { DatabaseClient } from "@mailwoman/sqlite/client"
import { assertDatabaseIntegrity } from "@mailwoman/sqlite/sealed-db"

export interface FreezeAdminOptions {
	/**
	 * Repos root for the `wof:hierarchy` −4 backfill (#440/#832 — NYC/London-class multi-parent orphans).
	 *
	 * Omit only in fixture tests.
	 * A real build without it leaves those metros unreachable by the region-descendant filter.
	 */
	dataDir?: string
	onPhase?: (phase: string, detail?: string) => void
}

export interface FreezeAdminResult {
	ancestorRows: number
	backfillPlacesFixed: number
	coincidentRoles: number
}

/**
 * Freeze an ingested admin staging DB (see the module docstring for the exact order and why it matters).
 */
export async function freezeAdmin(
	db: DatabaseClient<WOFDatabase>,
	opts: FreezeAdminOptions = {}
): Promise<FreezeAdminResult> {
	// resolver-wof-sqlite is an optional peer of mailwoman — import it lazily
	// (the gazetteer-pipeline convention) so importing this module never faults without it.
	const { backfillAncestorsFromHierarchy, discoverAdminDataRoots } =
		await import("@mailwoman/resolver-wof-sqlite/ancestry")

	const { buildCoincidentRoles } = await import("@mailwoman/resolver-wof-sqlite/coincident-roles")
	const { createUnifiedIndexes, populateAncestors } = await import("@mailwoman/resolver-wof-sqlite/unified-schema")
	const phase = opts.onPhase ?? (() => {})

	// An in-memory fixture has no WAL to checkpoint (journal_mode reports `memory`); skip the freeze pragmas there.
	const journal = (db.prepare("PRAGMA journal_mode").get() as { journal_mode: string }).journal_mode

	if (journal !== "memory") {
		phase("checkpoint")
		const checkpoint = db.prepare("PRAGMA wal_checkpoint(TRUNCATE)").get() as { busy: number }

		if (checkpoint.busy !== 0) {
			throw new Error(`freezeAdmin: WAL checkpoint did not finish: ${stringifyJSON(checkpoint)}`)
		}

		phase("journal", "delete")
		const mode = db.prepare("PRAGMA journal_mode = DELETE").get() as { journal_mode: string }

		if (mode.journal_mode !== "delete") {
			throw new Error(`freezeAdmin: journal_mode switch failed; still ${mode.journal_mode}`)
		}
	}

	phase("ancestors", "parent_id closure")
	const ancestorRows = populateAncestors(db)

	// Index `ancestors(id)` now — before the −4 backfill probes it.
	// `createUnifiedIndexes` (below) builds this same index, but it runs after the backfill.
	// Without it here the backfill's per-candidate lookups full-scan the closure table each time (#1015).
	// `if not exists` keeps the later createUnifiedIndexes a no-op.
	phase("ancestors-index")
	db.exec("CREATE INDEX IF NOT EXISTS ancestors_by_id ON ancestors(id)")

	let backfillPlacesFixed = 0

	if (opts.dataDir) {
		phase("hierarchy-backfill", "places whose ancestry chain never reaches a country")
		const geojsonRoots = await discoverAdminDataRoots(opts.dataDir)

		if (!geojsonRoots.length) {
			phase(
				"hierarchy-backfill",
				`WARNING: no */data geojson roots under ${opts.dataDir} — orphans like NYC stay unreachable`
			)
		} else {
			// Only real WOF places have `wof:hierarchy` geojson.
			// Synthetic Overture/GeoNames rows (ids >= OVERTURE_ID_BASE) never do,
			// and probing millions of them across every repo root turned this step into
			// a ~40-min stall on the wide-coverage build (#1015).
			// Their ancestry comes from the parent_id closure.
			const bf = await backfillAncestorsFromHierarchy(db, geojsonRoots, { maxID: OVERTURE_ID_BASE })
			backfillPlacesFixed = bf.placesFixed
			phase("hierarchy-backfill", `+${bf.rowsAdded} rows for ${bf.placesFixed} places (${bf.noGeojson} no-geojson)`)
		}
	}

	// Dual-role-place relation (#403, epic #402) — needs `ancestors` + `spr` bbox +
	// `place_population`, all present by now.
	// Drives the resolver's hierarchy completion (on by default).
	phase("coincident-roles")
	const roles = buildCoincidentRoles(db)

	phase("indexes")
	await createUnifiedIndexes(db)

	phase("analyze")
	db.exec("ANALYZE")
	db.exec("PRAGMA optimize")

	phase("integrity")
	assertDatabaseIntegrity(db, "admin")

	return { ancestorRows, backfillPlacesFixed, coincidentRoles: roles.rowCount }
}
