/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Overture `divisions`-theme backfill for the admin gazetteer — the zero-WOF-repo locales
 *   (project-eu-coverage-not-retrain, widened to the 86-country set. see `../defaults.ts`). Moved from
 *   `scripts/build-unified-wof.ts` (#1015/#1021) into the pipeline module.
 */

import { isOfficialLanguage } from "@mailwoman/codex/country"
import { simpleSHA3 } from "@mailwoman/core/crypto"
import { tryParsingJSON } from "@mailwoman/core/json"
import { OVERTURE_ID_BASE } from "@mailwoman/core/resolver/synthetic-id-ranges"
// Type-only, so it is erased at build and adds no runtime edge to what is an optional
// peer here (the caller reaches the package through a lazy `await import`).
import type { WOFDatabase } from "@mailwoman/resolver-wof-sqlite"
import type { DatabaseClient, StatementSync } from "@mailwoman/sqlite/client"
import { sql } from "kysely"

/**
 * Overture division subtypes that map to the resolver's admin placetypes.
 *
 * `country` is included (#1015) so an Overture-backfilled locale gets its country node.
 * Without it the reverse geocoder has no country tier to anchor to (Brussels → nearest
 * foreign place across the border), and forward resolution can't country-restrict the locale.
 */
export const OVERTURE_DIVISION_SUBTYPES = ["country", "locality", "region", "county", "localadmin"]

/**
 * Countries whose Overture `county` divisions are the addressable settlement tier,
 * and the placetype they take instead.
 *
 * Overture's subtype is its own taxonomy, and the fold otherwise writes it through verbatim.
 * Singapore's 55 planning areas — Ang Mo Kio, Bedok, Bukit Timah, Jurong East — arrive as `county`,
 * which no admin tag queries: `DEFAULT_PLACETYPE_MAP` sends both `locality` and `dependent_locality`
 * to WOF `locality`, and `PLACETYPE_FILTER_GROUPS` expands that to locality|borough|localadmin.
 *
 * So every planning area was unreachable, and Singapore's own `locality` row —
 * the city-state plus four villages — was the only thing a query could answer with.
 *
 * `borough` is the projection because a borough is a first-class locality answer by that
 * group's own rule (Brooklyn), and a city-state's planning area is its borough.
 *
 * Declared rather than derived, because the derived rule is refused by the rows it would admit.
 * Counted over every country in the promoted candidate table, three hold more `county` places than
 * tag-reachable ones — KW 137/13, QA 79/46, SG 55/5 — and their names say they are different problems.
 *
 * Kuwait's county names are underscore-joined ascii (`Abdulla_Al-Salem`, `Airport_District`)
 * while its Arabic names sit on `locality`; Qatar's are bare numbers (`13`, `14`, `18-19`).
 * Doha's zones, and admitting them would make every stray integer a candidate place.
 * Only Singapore's county tier carries names a person writes.
 */
const COUNTY_IS_SETTLEMENT_TIER: ReadonlyMap<string, string> = new Map([["SG", "borough"]])

/**
 * The placetype a division row is written at: its Overture subtype, unless
 * {@link COUNTY_IS_SETTLEMENT_TIER} names another for this country.
 */
export function foldedPlacetype(subtype: string, country: string): string {
	if (subtype !== "county") return subtype

	return COUNTY_IS_SETTLEMENT_TIER.get(country.trim().toUpperCase()) ?? subtype
}

/**
 * Width of the id range reserved for Overture rows — `OVERTURE_ID_BASE` up to
 * the GeoNames fold's base at 9e12.
 */
const OVERTURE_ID_SPAN = 1_000_000_000_000

/**
 * Bracket, pipe and delimiter characters Overture packs around an editorial aside rather than a name.
 */
const NAME_NOISE = /[()[\]{}<>|/\\_@#$%^*+=~`"]/u

/**
 * Longer than any division name Overture carries, and short enough to refuse a
 * description that ran into the name field.
 *
 * The rule this replaced had no length bound of its own.
 * Its character class was the bound.
 */
const NAME_MAX_LENGTH = 120

/**
 * Whether a `names.common` entry is a name.
 *
 * Admission never tests which script writes it.
 *
 * The rule this replaced kept Latin-script entries only, reasoning that the local-script
 * form survives as `names.primary` — which it does, and required: Russia keeps Москва
 * because Москва is Overture's primary for Moscow.
 * That premise fails for a country whose primary is already Latin, where `common`
 * is the only place the local script lives.
 *
 * Measured on the shipped artifact over the fold's own id range: Singapore 0 of
 * 228 names in Han, Sri Lanka 0 of 6,588 in Sinhala, Malaysia 6 of 9,111 in Jawi —
 * against Russia's 159,478 Cyrillic and Myanmar's 54,835, which the old rule never touched.
 *
 * Constructed languages are the tell.
 * Singapore's surviving names include Volapük, Lojban and Esperanto, all written in Latin, and no Chinese.
 *
 * Script is not a proxy for whether anyone types a name.
 */
export function isDivisionName(value: string): boolean {
	return value.length <= NAME_MAX_LENGTH && /\p{L}/u.test(value) && !NAME_NOISE.test(value)
}

/**
 * Digest bytes to draw per gers id.
 *
 * Six (48 bits, ~2.8e14) overshoots {@link OVERTURE_ID_SPAN} comfortably, so the modulo costs
 * nothing in collision terms, and the value stays exactly representable as a JS number.
 */
const ID_DIGEST_BYTES = 6

/**
 * Radix of {@link simpleSHA3}'s hex digest.
 */
const HEX_RADIX = 16

/**
 * Map each Overture gers id to a synthetic integer id, derived from the gers id itself.
 *
 * Consumers store these ids — gold rows, cached results, cross-artifact joins —
 * so an id has to be a function of the place rather than of the build that emitted it.
 * Gers ids are stable by design.
 *
 * Parquet scan order is not, and DuckDB's is a threaded read over a left join.
 *
 * Assignment is `idBase + (hash(gers) mod span)`.
 * Two gers ids can land on the same slot — at ~1.6 M rows in a 1e12 span the birthday
 * expectation is about one collision per build — so the loser probes forward.
 *
 * Probing is order- dependent.
 * It is exactly what this function exists to avoid.
 *
 * Therefore, the input is sorted first: a given gers id's outcome then depends only on the
 * set of ids that hash near it rather than on how the query happened to return them.
 *
 * Re-ingesting a division already present recomputes the same id, so an incremental augment is idempotent.
 */
export function assignSyntheticIDs(gersIDs: readonly string[], idBase: number = OVERTURE_ID_BASE): Map<string, number> {
	const idmap = new Map<string, number>()
	const taken = new Set<number>()

	for (const gers of gersIDs.toSorted()) {
		if (idmap.has(gers)) continue

		// SHAKE128 is an extendable-output function, so a six-byte digest is the primitive
		// doing what it was designed for rather than a truncation of a wider hash.
		let slot = Number.parseInt(simpleSHA3([gers], ID_DIGEST_BYTES), HEX_RADIX) % OVERTURE_ID_SPAN

		while (taken.has(slot)) {
			slot = (slot + 1) % OVERTURE_ID_SPAN
		}

		taken.add(slot)
		idmap.set(gers, idBase + slot)
	}

	return idmap
}

/**
 * Columns each bulk insert below writes, in the order its positional `run()` supplies them.
 *
 * `satisfies` checks every name against Kysely's `WOFDatabase` — the same interface
 * `createUnifiedSchema` builds these tables from — so a renamed or dropped column is a compile
 * error here rather than a runtime `no such column` in the middle of a multi-hour build.
 * The statements themselves stay raw positional prepares: this is the throughput path
 * (~1.6 M divisions, three writes each), which is the bulk-write carve-out the repo's SQL policy names.
 *
 * The run() argument order below must match these tuples.
 */
const SPR_COLUMNS = [
	"id",
	"parent_id",
	"name",
	"placetype",
	"country",
	"latitude",
	"longitude",
	"min_latitude",
	"min_longitude",
	"max_latitude",
	"max_longitude",
	"is_current",
	"is_deprecated",
	"is_ceased",
	"is_superseded",
	"is_superseding",
	"lastmodified",
] as const satisfies ReadonlyArray<keyof WOFDatabase["spr"]>

const NAMES_COLUMNS = [
	"id",
	"name",
	"placetype",
	"country",
	"language",
	"official",
	"lastmodified",
] as const satisfies ReadonlyArray<keyof WOFDatabase["names"]>

const POPULATION_COLUMNS = ["id", "population"] as const satisfies ReadonlyArray<keyof WOFDatabase["place_population"]>

const CONCORDANCE_COLUMNS = ["id", "other_id", "other_source", "lastmodified"] as const satisfies ReadonlyArray<
	keyof WOFDatabase["concordances"]
>

/**
 * Compile a positional insert for one of the tuples above.
 *
 * Built through Kysely's `sql` helper rather than by concatenation: `sql.table`/`sql.ref`
 * quote the identifiers, and the placeholder list is generated from the column list,
 * so the two cannot fall out of step.
 * The result is a plain SQL string for `db.prepare`.
 *
 * Kysely's own `insertInto().values()` binds a row per call, which is the wrong
 * shape for a statement prepared once and run 1.6 M times.
 */
function compileInsert(
	kdb: DatabaseClient<WOFDatabase>,
	table: keyof WOFDatabase,
	columns: readonly string[],
	orReplace = false
): string {
	const conflict = orReplace ? sql`or replace ` : sql``
	const names = sql.join(columns.map((column) => sql.ref(column)))
	const placeholders = sql.join(columns.map(() => sql.raw("?")))

	return sql`insert ${conflict}into ${sql.table(table)} (${names}) values (${placeholders})`.compile(kdb).sql
}

/**
 * The three bulk-write statements, prepared against an open unified DB.
 *
 * Exported so a test can run them against a real `createUnifiedSchema` database.
 * The `satisfies` above checks the column tuples against the `WOFDatabase` interface,
 * which is a different artifact from the DDL that builds the tables.
 *
 * The two can drift, and the only thing that catches it is binding a row.
 */
export function prepareInserts(db: DatabaseClient<WOFDatabase>): {
	spr: StatementSync
	names: StatementSync
	population: StatementSync
	concordances: StatementSync
} {
	// Wraps the caller's handle for statement compilation only.
	// The same one-connection idiom `createUnifiedSchema` uses for its DDL.
	// The caller owns `db`'s lifecycle, so this is not destroyed.
	const kdb = db

	return {
		spr: db.prepare(compileInsert(kdb, "spr", SPR_COLUMNS, true)),
		names: db.prepare(compileInsert(kdb, "names", NAMES_COLUMNS)),
		population: db.prepare(compileInsert(kdb, "place_population", POPULATION_COLUMNS, true)),
		concordances: db.prepare(compileInsert(kdb, "concordances", CONCORDANCE_COLUMNS)),
	}
}

/**
 * Backfill the Overture `divisions` theme into an already-open unified ingest DB,
 * for locales the WOF GeoJSON repos don't cover.
 *
 * Writes the same spr/names/place_population tables the WOF path uses — with synthetic ids
 * based at {@link OVERTURE_ID_BASE} so the two sources never collide — so the caller's
 * Freeze phase (ancestors closure, coincident_roles, indexes, FTS) treats them uniformly.
 * The Overture sub-tree is self-contained (locality → region → county via `parent_division_id`);
 * a division whose parent we didn't ingest tops out at -1.
 *
 * Country scoping rides `spr.country` (set on every row), not the ancestry —
 * but the `country` subtype ships the country node too (#1015).
 *
 * The heavy native `@duckdb/node-api` dependency is loaded lazily (the `overture-ingest.tsx` convention)
 * so importing the pipeline module never faults when the optional binding isn't installed.
 *
 * @returns The number of divisions ingested.
 */
export async function ingestOvertureDivisions(
	db: DatabaseClient<WOFDatabase>,
	countries: readonly string[],
	release: string,
	/**
	 * Starting synthetic id. Defaults to {@link OVERTURE_ID_BASE} (a single full build). An incremental augment of a DB that already holds Overture rows must pass `max(spr.id) + 1` so the new ids don't collide with — and `insert or replace` clobber — the existing ones.
	 */
	idBase: number = OVERTURE_ID_BASE
): Promise<number> {
	const inlist = countries.map((c) => `'${c.replaceAll("'", "''")}'`).join(",")
	const subtypes = OVERTURE_DIVISION_SUBTYPES.map((s) => `'${s}'`).join(",")
	const glob = `s3://overturemaps-us-west-2/release/${release}/theme=divisions/type=division/*`
	// #1015: the real boundary extent lives in the sibling `type=division_area` (the polygon). The `type=division` row is the label point. Its `bbox` is a degenerate point, so relying on it left every Overture-backfilled place with a point bbox, invisible to the reverse geocoder's bbox-containment (Brussels resolved to a foreign cross-border neighbour). Join the area's extent by `division_id`, falling back to the point bbox when a division has no area row (so nothing regresses).
	const areaGlob = `s3://overturemaps-us-west-2/release/${release}/theme=divisions/type=division_area/*`

	const { DuckDBInstance } = await import("@duckdb/node-api")
	const instance = await DuckDBInstance.create()
	const con = await instance.connect()

	await con.run(
		/* sql */ `install httpfs; load httpfs; install spatial; load spatial; install json; load json; SET s3_region='us-west-2';`
	)

	await con.run(/* sql */ `SET memory_limit='4GB'; SET threads=4;`)

	console.error(`  Overture divisions: querying ${countries.join(",")} @ release ${release}...`)

	const result = await con.runAndReadAll(/*sql*/ `
		WITH area AS (
			SELECT division_id,
				MIN(bbox.ymin) AS ymin, MAX(bbox.ymax) AS ymax, MIN(bbox.xmin) AS xmin, MAX(bbox.xmax) AS xmax
			FROM read_parquet('${areaGlob}')
			WHERE country IN (${inlist})
			GROUP BY division_id
		)
		SELECT d.id AS id,
			d.names.primary AS name,
			to_json(d.names.common) AS common_json,
			d.subtype AS subtype,
			d.country AS country,
			ST_Y(ST_Centroid(d.geometry)) AS lat,
			ST_X(ST_Centroid(d.geometry)) AS lon,
			COALESCE(a.ymin, d.bbox.ymin) AS min_lat, COALESCE(a.ymax, d.bbox.ymax) AS max_lat,
			COALESCE(a.xmin, d.bbox.xmin) AS min_lon, COALESCE(a.xmax, d.bbox.xmax) AS max_lon,
			d.parent_division_id AS parent_division_id,
			d.population AS population,
			d.wikidata AS wikidata
		FROM read_parquet('${glob}') d
		LEFT JOIN area a ON a.division_id = d.id
		WHERE d.country IN (${inlist}) AND d.subtype IN (${subtypes})
			AND d.names.primary IS NOT NULL AND d.geometry IS NOT NULL
	`)

	const rows = result.getRowObjects() as Array<Record<string, unknown>>

	console.error(`  Overture divisions: ${rows.length.toLocaleString()} pulled`)

	const idmap = assignSyntheticIDs(
		rows.map((r) => String(r.id)),
		idBase
	)

	const {
		spr: sprInsert,
		names: namesInsert,
		population: populationInsert,
		concordances: concordancesInsert,
	} = prepareInserts(db)

	const num = (v: unknown): number => (typeof v === "number" ? v : typeof v === "bigint" ? Number(v) : 0)

	db.exec("BEGIN")
	let n = 0
	let nWikidata = 0

	for (const r of rows) {
		const nid = idmap.get(String(r.id))!
		const pgers = r.parent_division_id == null ? null : String(r.parent_division_id)
		const pid = (pgers && idmap.get(pgers)) || -1
		const name = String(r.name)
		const country = String(r.country ?? "").toUpperCase()
		// The row's own placetype, which is its Overture subtype except where that taxonomy
		// puts a country's settlements on a tier no admin tag queries.
		const placetype = foldedPlacetype(String(r.subtype), country)

		// select aliases: min_lat=ymin, min_lon=xmin, max_lat=ymax, max_lon=xmax → spr
		// (lat, lon, min_latitude, min_longitude, max_latitude, max_longitude).
		sprInsert.run(
			nid,
			pid,
			name,
			placetype,
			country,
			num(r.lat),
			num(r.lon),
			num(r.min_lat),
			num(r.min_lon),
			num(r.max_lat),
			num(r.max_lon),
			1,
			0,
			0,
			0,
			0,
			0
		)

		namesInsert.run(nid, name, placetype, country, "", 0, 0)

		// Multilingual aliases (names.common — language→name) so a place resolves by every
		// name it is called, in every script those names are written in.
		// The candidate build explodes each into its own name_key.
		// Overture `common` is the standard name per language (no variant axis),
		// so #936 officialness is the language test alone.
		if (r.common_json) {
			// A malformed common map nulls out — keep the primary, skip aliases.
			const common = tryParsingJSON<Record<string, string>>(String(r.common_json))

			if (common) {
				const seen = new Set([name])

				for (const [lang, alias] of Object.entries(common)) {
					if (typeof alias === "string" && !seen.has(alias) && isDivisionName(alias)) {
						seen.add(alias)
						namesInsert.run(nid, alias, placetype, country, lang, isOfficialLanguage(country, lang) ? 1 : 0, 0)
					}
				}
			}
		}

		// #1884: carry Overture's own Wikidata id into `concordances` under the same `wd:id` source the WOF ingest uses. The `gazetteer importance` join reads exactly that predicate, so an Overture row with a Wikidata id gets the encyclopedia channel through the existing join and its #1497 fan-out guards. Before this, every Overture-origin city entered fame contests on the population proxy (measured: all 345 Cyrillic-named localities over 100k, Москва included).
		if (typeof r.wikidata === "string" && r.wikidata.startsWith("Q")) {
			concordancesInsert.run(nid, r.wikidata, "wd:id", 0)

			nWikidata++
		}

		const pop = num(r.population)

		if (pop > 0) {
			populationInsert.run(nid, pop)
		}

		n++
	}

	db.exec("COMMIT")

	console.error(
		`  Overture divisions: ${nWikidata.toLocaleString()} of ${n.toLocaleString()} carry a Wikidata concordance`
	)

	return n
}
