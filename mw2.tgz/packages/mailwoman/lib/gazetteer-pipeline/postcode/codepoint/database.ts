/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Build `postalcode-gb-codepoint-<date>.db` — the GB unit-postcode database from Ordnance Survey
 *   **Code-Point Open**, and the licensed replacement for the 1,839,678 GeoNames `GB_full` rows
 *   currently riding inside `postalcode-geonames-tail.db`.
 *
 *   ## Why a separate builder rather than a source mode on `geonames-tail.ts`
 *
 *   Folding this in was considered and rejected on the code rather than on taste. `geonames-tail.ts` is a
 *   reproducer: its docstring pins it to a frozen 946 MB artifact, its country order is required
 *   because `ingestGeonamesPostal` allocates ids from one counter so a rebuild stays id-comparable,
 *   and it is conditioned on per-country row-count parity against that artifact. Code-Point Open shares none
 *   of its inputs — different coordinate system (OSGB36 eastings/northings rather than degrees), different row
 *   grain (one row per unit postcode, so no medoid collapse), different licence block, and a row count
 *   that is supposed to differ from the frozen GB figure. Adding it as a mode would put a source that
 *   must change the numbers inside the one file whose job is to keep them identical.
 *
 *   What is shared is shared: the unified schema, `normalizePostcodeName` (the #920 name law),
 *   `populateAncestors`, `buildFTS`, `sealDatabase`. Only the read side is new.
 *
 *   ## The #920 name law still governs
 *
 *   `spr.name` is the sanitized form — every non-letter/number stripped, so `SW1A 1AA` is stored as
 *   `SW1A1AA` — because that is what `sanitizeFTSQuery` reduces a parsed postcode token to at lookup
 *   time. The display form `SW1A 1AA` rides along as an extra `names` row. Storing the spaced form as
 *   the primary name is the mistake that measured worse than no coverage at all on CZ (#920); it is
 *   not a cosmetic choice.
 *
 *   ## Coverage
 *
 *   England, Scotland and Wales. not Northern Ireland — see `CODEPOINT_COVERAGE_NOTE`. The `BT` hole is
 *   permanent for this source and is recorded in the artifact's `meta` so a consumer reads it at open.
 *
 *   ## Licence
 *
 *   OGL v3 with a mandatory three-line attribution block naming OS, Royal Mail and National Statistics.
 *   Baked into `meta` verbatim, alongside the source md5 and OS's own `Doc/licence.txt`.
 */

import { dataRootPath } from "@mailwoman/core/data-root"
import { stringifyJSON } from "@mailwoman/core/json"
import { CODEPOINT_ID_BASE } from "@mailwoman/core/resolver/synthetic-id-ranges"
import { isoDate } from "@mailwoman/core/utils"
import type { WOFDatabase } from "@mailwoman/resolver-wof-sqlite/schema"
import { DatabaseClient } from "@mailwoman/sqlite/client"
import { sealDatabase } from "@mailwoman/sqlite/sealed-db"
import { join, type PathBuilderLike } from "path-ts"

import {
	applyStagingPragmas,
	buildDatabaseFTS,
	freezeStagingDatabase,
	readAcquisitionSidecar,
	removeStagingArtifacts,
	UNKNOWN_PROVENANCE,
	vacuumDatabaseInto,
} from "#gazetteer-pipeline/database-lifecycle"
import type { BuildFTSResult } from "#gazetteer-pipeline/fts"
import {
	CODEPOINT_COVERAGE_NOTE,
	CODEPOINT_LICENSE,
	CODEPOINT_LICENSE_URL,
	NORTHERN_IRELAND_OPTIONS_NOTE,
	type CodePointMetadata,
	type CodePointParseStats,
	codePointAttribution,
	createCodePointParseStats,
	downloadCodePointOpen,
	extractCodePointOpen,
	readCodePointCSV,
} from "#gazetteer-pipeline/postcode/codepoint/index"
import { createDatabaseMetaTable, writeMetaRows } from "#gazetteer-pipeline/postcode/geonames/tail"

/**
 * ISO-3166-1 alpha-2 stamped on every row.
 *
 * Code-Point Open is a GB-only product.
 * The ONS country code distinguishing England/Scotland/Wales is carried separately
 * on the parsed record and is not what `spr.country` means.
 */
const COUNTRY = "GB"

export interface BuildPostcodeCodePointOptions {
	/**
	 * Acquisition directory holding (or to hold) `codepo_gb.zip` and its extracted `Data/CSV` tree.
	 *
	 * Default `<data-root>/codepoint/<yyyy-MM-DD>` — a new dated directory per acquisition.
	 */
	sourceDir?: PathBuilderLike
	/**
	 * Output artifact.
	 *
	 * Default `<data-root>/wof/postalcode-gb-codepoint-<yyyy-MM-DD>.db` — a new dated path every build.
	 * Promoting it into `DEFAULT_POSTCODE_DATABASES` is a deliberate, separate swap.
	 */
	out?: PathBuilderLike
	/**
	 * Skip the network entirely and use whatever is already in `sourceDir`.
	 *
	 * Fails if the CSVs are not there.
	 */
	offline?: boolean
	/**
	 * Build clock — stamped into `meta.built_at` and the default paths.
	 *
	 * Passed in so the module never reads the clock implicitly (the `defaultGazetteerVersion` convention).
	 */
	now?: Date
	onPhase?: (phase: string, detail?: string) => void
}

export interface BuildPostcodeCodePointResult {
	out: string
	sourceDir: string
	/**
	 * Distinct unit postcodes written.
	 */
	inserted: number
	/**
	 * Rows read and dropped, with the reason.
	 *
	 * See {@link CodePointParseStats}.
	 */
	stats: CodePointParseStats
	/**
	 * The archive's own manifest.
	 * The row-count oracle this build is conditioned on.
	 */
	metadata: CodePointMetadata
	/**
	 * Areas whose parsed count differs from the manifest, as `area: manifest→parsed`.
	 *
	 * Empty when every area agrees after accounting for the no-coordinate drops.
	 */
	manifestMismatches: string[]
	ancestorRows: number
	ftsRows: number
	bboxRows: number
	archiveMD5: string
	osVersion: string
	sealed: boolean
}

/**
 * The sidecar {@link downloadCodePointOpen} writes beside the archive.
 */
interface AcquisitionSidecar {
	product?: { version?: string }
	md5?: string
}

/**
 * Build the sealed GB Code-Point Open postcode database.
 */
export async function buildPostcodeCodePoint(
	options: BuildPostcodeCodePointOptions = {}
): Promise<BuildPostcodeCodePointResult> {
	const phase = options.onPhase ?? (() => {})
	const now = options.now ?? new Date()
	const stamp = isoDate(now)
	const sourceDir = (options.sourceDir ?? dataRootPath("codepoint", stamp)).toString()
	const out = (options.out ?? dataRootPath("wof", `postalcode-gb-codepoint-${stamp}.db`)).toString()

	// Acquire the Code-Point source archive.
	//
	// An offline build must not silently produce an artifact with blank provenance.
	// `downloadCodePointOpen` leaves an `acquisition.json` sidecar next to the archive precisely
	// so a later offline rebuild can recover the release label and md5 it would otherwise have to invent.
	// When even that is missing, the meta records the absence in words rather than an
	// empty string, because "" reads as "no release" to anyone grepping it.
	let archiveMD5: string
	let osVersion: string

	if (options.offline) {
		const sidecar = await readAcquisitionSidecar<AcquisitionSidecar>(sourceDir)

		archiveMD5 = sidecar?.md5 ?? UNKNOWN_PROVENANCE
		osVersion = sidecar?.product?.version ?? UNKNOWN_PROVENANCE

		phase(
			"offline",
			sidecar ? `provenance from acquisition.json (${osVersion})` : "NO acquisition.json — provenance unknown"
		)
	} else {
		const download = await downloadCodePointOpen({ destDir: sourceDir, onPhase: phase })

		archiveMD5 = download.md5
		osVersion = download.version
	}

	const archivePath = join(sourceDir, "codepo_gb.zip")
	const extracted = await extractCodePointOpen({ archivePath, destDir: sourceDir, onPhase: phase })

	phase(
		"manifest",
		`${extracted.metadata.totalRows.toLocaleString()} rows claimed across ${extracted.csvPaths.length} areas`
	)

	// resolver-wof-sqlite is an optional peer — lazy import (the gazetteer-pipeline convention).
	const { createUnifiedSchema, createUnifiedIndexes, populateAncestors } =
		await import("@mailwoman/resolver-wof-sqlite/unified-schema")

	const { normalizePostcodeName } = await import("@mailwoman/resolver-wof-sqlite/geonames")

	const ingestPath = `${out}.ingest`
	await removeStagingArtifacts(ingestPath)

	phase("staging", ingestPath)

	let inserted = 0
	const stats = createCodePointParseStats()
	const manifestMismatches = compareAgainstManifest(extracted.metadata, stats)

	let ancestorRows: number

	{
		using db = new DatabaseClient<WOFDatabase>(ingestPath)

		applyStagingPragmas(db)

		await createUnifiedSchema(db)

		// Hot positional INSERTs — raw prepared statements, per the agents.md bulk-load carve-out.
		const sprInsert = db.prepare(
			`INSERT OR REPLACE INTO spr (id, parent_id, name, placetype, country, latitude, longitude, min_latitude, min_longitude, max_latitude, max_longitude, is_current, is_deprecated, is_ceased, is_superseded, is_superseding, lastmodified) VALUES (?, -1, ?, 'postalcode', '${COUNTRY}', ?, ?, ?, ?, ?, ?, 1, 0, 0, 0, 0, 0)`
		)

		const namesInsert = db.prepare(
			`INSERT INTO names (id, name, placetype, country, language, lastmodified) VALUES (?, ?, 'postalcode', '${COUNTRY}', '', 0)`
		)

		phase("ingest", `${extracted.csvPaths.length} area CSVs`)
		db.exec("BEGIN")

		for (const csvPath of extracted.csvPaths) {
			for await (const record of readCodePointCSV(csvPath, stats)) {
				// The #920 name law: sanitized form is the name, display form is an alt.
				const name = normalizePostcodeName(record.postcode)
				const id = CODEPOINT_ID_BASE + inserted

				// Degenerate bbox — a unit postcode is a point in this product rather than a polygon.
				sprInsert.run(
					id,
					name,
					record.latitude,
					record.longitude,
					record.latitude,
					record.longitude,
					record.latitude,
					record.longitude
				)

				namesInsert.run(id, name)

				if (record.postcode !== name) {
					namesInsert.run(id, record.postcode)
				}

				inserted++
			}
		}

		db.exec("COMMIT")
		phase("ingest", `${inserted.toLocaleString()} unit postcodes`)

		// Check the archive's own manifest. codepoint/extract.ts explains this oracle.

		// Every row's parent_id is -1 (Code-Point carries no hierarchy), so this
		// writes the self row per place and nothing else.
		// Not decorative: the resolver's parent-constraint scopes a lookup with
		// `spr.id IN (select id from ancestors where ancestor_id = ?)`, and a place
		// absent from `ancestors` can never satisfy it.
		phase("ancestors")
		ancestorRows = populateAncestors(db)

		phase("indexes")
		await createUnifiedIndexes(db)

		phase("meta")

		await writeDatabaseMeta(db, {
			now,
			stats,
			metadata: extracted.metadata,
			inserted,
			archiveMD5,
			osVersion,
			extracted,
		})

		phase("freeze")
		freezeStagingDatabase(db)

		phase("vacuum", out)
		await vacuumDatabaseInto(db, out)
	}

	await removeStagingArtifacts(ingestPath)

	phase("fts")

	const fts: BuildFTSResult = await buildDatabaseFTS(out, (path) => new DatabaseClient<WOFDatabase>(path), phase)

	phase("seal")
	await sealDatabase(out)

	return {
		out,
		sourceDir,
		inserted,
		stats,
		metadata: extracted.metadata,
		manifestMismatches,
		ancestorRows,
		ftsRows: fts.ftsRows,
		bboxRows: fts.bboxRows,
		archiveMD5,
		osVersion,
		sealed: true,
	}
}

/**
 * Compare per-area parsed counts against the archive's `Doc/metadata.txt` manifest.
 *
 * The manifest counts rows IN the file.
 * It includes the positional-quality-90 rows we deliberately drop.
 *
 * Therefore, the identity being checked is `manifest[area] === parsed[area] + noCoordinateDrops[area]`.
 *
 * The tolerance must not include malformed rows, and the first version of this function got that
 * wrong in a way worth recording: it set `tolerance = skippedNoCoordinate + skippedMalformed`,
 * so when a CSV-parsing bug rejected all 1,746,976 coordinate-containing rows, the tolerance
 * grew to 1.75 M and every area "reconciled" against a database holding zero postcodes.
 * A check whose slack is derived from the size of the failure it is meant to catch cannot catch it.
 *
 * The tolerance is now the no-coordinate drops alone — a deliberate, bounded,
 * understood exclusion — and any malformed row at all is reported separately as a
 * defect by {@link buildPostcodeCodePoint}'s caller.
 */
function compareAgainstManifest(metadata: CodePointMetadata, stats: CodePointParseStats): string[] {
	const mismatches: string[] = []
	const tolerance = stats.skippedNoCoordinate

	for (const [area, expected] of Object.entries(metadata.rowsByArea)) {
		const actual = stats.yieldedByArea[area] ?? 0

		if (actual > expected || expected - actual > tolerance) {
			mismatches.push(`${area}: manifest ${expected} → parsed ${actual}`)
		}
	}

	for (const area of Object.keys(stats.yieldedByArea)) {
		if (!(area in metadata.rowsByArea)) {
			mismatches.push(`${area}: parsed ${stats.yieldedByArea[area]} but ABSENT from manifest`)
		}
	}

	// The national identity, which no per-area check implies: every manifest row is
	// either yielded or explicitly dropped for a known reason.
	// This is the assertion that would have failed loudly above.
	const accounted = stats.yielded + stats.skippedNoCoordinate + stats.skippedMalformed

	if (accounted !== metadata.totalRows) {
		mismatches.push(
			`TOTAL: manifest ${metadata.totalRows} but yielded ${stats.yielded} + no-coordinate ${stats.skippedNoCoordinate} + malformed ${stats.skippedMalformed} = ${accounted}`
		)
	}

	if (stats.skippedMalformed > 0) {
		mismatches.push(`MALFORMED: ${stats.skippedMalformed} rows failed to parse — expected zero`)
	}

	return mismatches
}

interface DatabaseMetaInput {
	now: Date
	stats: CodePointParseStats
	metadata: CodePointMetadata
	inserted: number
	archiveMD5: string
	osVersion: string
	extracted: { licenseText: string; csvPaths: string[]; totalBytes: number }
}

/**
 * Bake the provenance record into the staging DB (pre-vacuum, pre-seal — a shipped DB is never patched).
 *
 * The attribution year comes from OS's own `copyright date`, not from the build clock: republishing a 2026 extract in 2027 still attributes the 2026 data. Both dates are stored so the distinction stays visible.
 */
async function writeDatabaseMeta(db: DatabaseClient<WOFDatabase>, input: DatabaseMetaInput): Promise<void> {
	await createDatabaseMetaTable(db)

	const copyrightYear = Number(input.metadata.copyrightDate.slice(0, 4)) || input.now.getUTCFullYear()

	const rows: Array<[string, string]> = [
		["name", "mailwoman-postalcode-gb-codepoint"],
		[
			"description",
			"GB unit postcodes from Ordnance Survey Code-Point Open as first-class WOF `postalcode` places (England, Scotland, Wales)",
		],
		["schema_version", "1"],
		["built_at", input.now.toISOString()],
		["countries", COUNTRY],
		["postcode_rows", String(input.inserted)],
		["source", "Ordnance Survey Code-Point Open — https://osdatahub.os.uk/downloads/open/CodePointOpen"],
		["source_api", "https://api.os.uk/downloads/v1/products/CodePointOpen/downloads (open, unauthenticated)"],
		["source_release", input.osVersion],
		["source_product", input.metadata.product],
		["source_dataset_version", input.metadata.datasetVersion],
		["source_copyright_date", input.metadata.copyrightDate],
		["source_royal_mail_update_date", input.metadata.royalMailUpdateDate],
		["source_archive_md5", input.archiveMD5],
		["source_manifest_rows", String(input.metadata.totalRows)],
		["license", CODEPOINT_LICENSE],
		["license_url", CODEPOINT_LICENSE_URL],
		["attribution", codePointAttribution(copyrightYear)],
		["license_text_upstream", input.extracted.licenseText.trim()],
		["coverage", CODEPOINT_COVERAGE_NOTE],
		[
			"coverage_gap_northern_ireland",
			"ZERO Northern Ireland (BT) postcodes — measured, not assumed: the source's country codes are exactly " +
				"E92000001/S92000003/W92000004 across all rows. NI postcode geography is administered by Land & Property " +
				"Services (LPS) and is not published under OGL; filling this gap requires a separate licence, not a " +
				"different build.",
		],
		["coverage_gap_northern_ireland_options", NORTHERN_IRELAND_OPTIONS_NOTE],
		[
			"method",
			"#920 laws: `name` stored in the sanitized-query token shape (every non-letter/number stripped) with the " +
				"display form as an alt `names` row. One row per unit postcode (no medoid collapse — the source is already " +
				"one row per postcode). Coordinates converted OSGB36/EPSG:27700 → WGS84 via @mailwoman/spatial's " +
				"`osgb36ToWGS84` (7-parameter Helmert; measured p50 1.74 m / p95 4.18 m / max 4.91 m against OS's 40-point " +
				"OSTN15 test set). Rows with positional-quality-indicator 90 (no coordinate available) are DROPPED.",
		],
		[
			"quality_drops",
			stringifyJSON({
				read: input.stats.read,
				yielded: input.stats.yielded,
				skippedNoCoordinate: input.stats.skippedNoCoordinate,
				skippedMalformed: input.stats.skippedMalformed,
			}),
		],
		["builder", "mailwoman gazetteer build postcode-codepoint"],
		[
			"source_files",
			stringifyJSON({ count: input.extracted.csvPaths.length, uncompressedBytes: input.extracted.totalBytes }),
		],
	]

	writeMetaRows(db, rows)
}
