/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   CLI integration tests for `parse --neural --resolve` (Phase 4.3).
 *
 *   Schema-level tests run unconditionally. End-to-end tests check on a real WOF SQLite distribution
 *   being on disk (skip-if-missing via `describe.skipIf`), matching the pattern in
 *   `resolver-wof-sqlite/integration.test.ts`.
 */

import { dataRootPath } from "@mailwoman/core/data-root"
import { pathExists } from "@mailwoman/core/fs/readers"
import { parseJSONStrict } from "@mailwoman/core/json"
import { runFile } from "@mailwoman/core/process"
import { childEnv } from "@mailwoman/core/scripting/utils"
import { mailwomanCLIPath } from "mailwoman/cli-kit/metadata"
import { parseCommand } from "mailwoman/cli-native/spec"
import { spec as parseSpec } from "mailwoman/commands/parse"
import { $public } from "mailwoman/env"
import { describe, expect, test } from "vitest"

const cliBin = await mailwomanCLIPath()

const DEFAULT_WOF_PATH = String(dataRootPath("wof", "whosonfirst-data-admin-us-latest.db"))
const wofPath = $public.MAILWOMAN_WOF_DB ?? DEFAULT_WOF_PATH
const hasWOFDB = await pathExists(wofPath)
// oxlint-disable-next-line vitest/valid-title, vitest/valid-describe-callback -- an aliased describe. the title and callback arrive where it is invoked
const describeIfWOF = describe.skipIf(!hasWOFDB)

describe("--resolve option validation", () => {
	test("--resolve defaults to false", () => {
		expect(parseCommand(parseSpec, ["address"]).values.resolve).toBe(false)
	})

	test("--resolve accepts true", () => {
		expect(parseCommand(parseSpec, ["--resolve", "--neural", "address"]).values.resolve).toBe(true)
	})

	test("--resolve-db accepts an arbitrary path string", () => {
		expect(parseCommand(parseSpec, ["--resolve-db", "/tmp/wof.db", "address"]).values["resolve-db"]).toBe("/tmp/wof.db")
	})
})

describe("npx mailwoman parse --resolve error paths", () => {
	test("--resolve with no gazetteer at all exits non-zero with a clear message", async () => {
		// As of the pipeline-default flip, --resolve works without --neural —
		// the runtime pipeline handles classification + resolution end-to-end.
		// The remaining error path is "no gazetteer available", which means both backends
		// unreachable: no WOF database and no candidate.db.
		// `MAILWOMAN_CANDIDATE_DB=none` is what pins the second one off — leaving it unset lets
		// the convention path answer, and on any machine that has run `data pull candidate`
		// the command then succeeds and this test's premise is gone.
		await expect(
			runFile("node", [cliBin, "parse", "--resolve", "123 Main St"], {
				env: childEnv({ MAILWOMAN_WOF_DB: "", MAILWOMAN_CANDIDATE_DB: "none" }),
			})
		).rejects.toMatchObject({
			stdout: expect.stringMatching(/No WOF database configured/),
		})
	})
})

describeIfWOF(`npx mailwoman parse --neural --resolve against ${wofPath}`, () => {
	test("emits resolver-decorated XML for a known US locality", async () => {
		const result = await runFile(
			"node",
			[cliBin, "parse", "--neural", "--resolve", "--format", "xml", "Springfield, Illinois"],
			{ env: childEnv({ MAILWOMAN_WOF_DB: wofPath, NODE_NO_WARNINGS: "1" }), maxBuffer: 4 * 1024 * 1024 }
		)

		// The XML root is always present.
		expect(result.stdout).toContain("<address raw=")
		// At least one node gained resolver attribution.
		// The exact wof id varies by FTS ranking, but the `place="wof:<digits>"`
		// shape + the `lat=` / `lon=` attrs are stable.
		expect(result.stdout).toMatch(/src="resolver:[a-z_]+:\d+"/)
		expect(result.stdout).toMatch(/place="wof:\d+"/)
		expect(result.stdout).toMatch(/lat="-?\d+\.\d+"/)
		expect(result.stdout).toMatch(/lon="-?\d+\.\d+"/)
	}, 60_000)

	test("respects --resolve-db explicit path override (matches env default)", async () => {
		// Use the same input as the first test.
		// The neural classifier needs enough context to tag component spans.
		// Bare single-token names like "Houston" alone often parse to nothing.
		const result = await runFile(
			"node",
			[cliBin, "parse", "--neural", "--resolve", "--resolve-db", wofPath, "--format", "xml", "Springfield, Illinois"],
			{ env: childEnv({ NODE_NO_WARNINGS: "1" }), maxBuffer: 4 * 1024 * 1024 }
		)

		expect(result.stdout).toContain("<address raw=")
		expect(result.stdout).toMatch(/src="resolver:/)
	}, 60_000)

	test("works without --resolve (regression check — flag default is off)", async () => {
		const result = await runFile("node", [cliBin, "parse", "--neural", "--format", "xml", "Springfield, Illinois"], {
			env: childEnv({ NODE_NO_WARNINGS: "1" }),
			maxBuffer: 4 * 1024 * 1024,
		})

		expect(result.stdout).toContain("<address raw=")
		// Without --resolve, no resolver attribution.
		expect(result.stdout).not.toMatch(/src="resolver:/)
		expect(result.stdout).not.toMatch(/place="wof:/)
	}, 60_000)

	test("--candidates surfaces runner-up resolutions in XML", async () => {
		// "Springfield, Illinois" — the region qualifier helps the model produce a resolvable tag.
		// WOF returns multiple Springfields (or, PA, MA, etc.).
		// With --candidates 5 we expect at least one <alternative> element on the resolved node.
		const result = await runFile(
			"node",
			[cliBin, "parse", "--resolve", "--candidates", "5", "--format", "xml", "Springfield, Illinois"],
			{ env: childEnv({ MAILWOMAN_WOF_DB: wofPath, NODE_NO_WARNINGS: "1" }), maxBuffer: 4 * 1024 * 1024 }
		)

		expect(result.stdout).toContain("<address raw=")
		// At least one alternative element with a place attr.
		expect(result.stdout).toMatch(/<alternative[^>]*place="wof:\d+"/)
		expect(result.stdout).toMatch(/<alternative[^>]*name="/)
		expect(result.stdout).toMatch(/<alternative[^>]*lat="-?\d+\.\d+"/)
	}, 60_000)

	test("--candidates surfaces runner-up resolutions in JSON (tree shape)", async () => {
		const result = await runFile(
			"node",
			[cliBin, "parse", "--resolve", "--candidates", "3", "--format", "json", "Springfield, Illinois"],
			{ env: childEnv({ MAILWOMAN_WOF_DB: wofPath, NODE_NO_WARNINGS: "1" }), maxBuffer: 4 * 1024 * 1024 }
		)

		// JSON with --candidates dumps the full AddressTree rather than the libpostal-flat projection.
		// The tree carries `roots` with nodes that have `alternatives`
		// (possibly on nested children in containment-nesting trees like region → locality).
		const tree = parseJSONStrict<Record<string, unknown>>(stripAnsiSpinner(result.stdout))
		expect(tree).toHaveProperty("raw")
		expect(tree).toHaveProperty("roots")

		interface TreeNode {
			alternatives?: unknown[]
			children?: TreeNode[]
		}

		const findAlternatives = (nodes: TreeNode[]): boolean =>
			nodes.some(
				(n) =>
					(Array.isArray(n.alternatives) && n.alternatives.length) ||
					(Array.isArray(n.children) && findAlternatives(n.children))
			)

		expect(findAlternatives(tree.roots as TreeNode[])).toBe(true)
	}, 60_000)

	test("without --candidates, JSON stays libpostal-flat (no tree shape leak)", async () => {
		const result = await runFile("node", [cliBin, "parse", "--resolve", "--format", "json", "Springfield"], {
			env: childEnv({ MAILWOMAN_WOF_DB: wofPath, NODE_NO_WARNINGS: "1" }),
			maxBuffer: 4 * 1024 * 1024,
		})

		const out = parseJSONStrict(stripAnsiSpinner(result.stdout))
		// Libpostal-compat is flat: no `raw` / `roots` top-level keys.
		expect(out).not.toHaveProperty("raw")
		expect(out).not.toHaveProperty("roots")
	}, 60_000)
})

/**
 * Strip ansi escape sequences + ink spinner frames so the JSON parser can consume CLI stdout.
 */
function stripAnsiSpinner(stdout: string): string {
	const ansi = /\[[0-9;]*[a-zA-Z]/gu
	const cleaned = stdout.replace(ansi, "").trim()
	// Find the start of the JSON payload (`{` or `[`).
	const objStart = cleaned.search(/[{[]/)

	return objStart >= 0 ? cleaned.slice(objStart) : cleaned
}
