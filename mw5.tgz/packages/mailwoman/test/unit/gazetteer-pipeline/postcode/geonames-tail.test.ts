/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Fixture-scale guard for the GeoNames-postal tail reproducer. The real check is per-country row-count
 *   parity against the frozen 946 MB artifact (see the module docstring); this holds the three things
 *   that eval cannot express cheaply — the #920 name law survives a rebuild, a country with no dump is
 *   reported rather than silently zeroed, and the provenance `meta` table actually reaches the sealed
 *   artifact carrying source md5s.
 */

import { statPath } from "@mailwoman/core/fs/readers"
import { temporaryDirectory, type TemporaryDirectory } from "@mailwoman/core/fs/temporary"
import { writeLocalFile, writeLocalTextFile, makeDirectories } from "@mailwoman/core/fs/writers"
import { parseJSONStrict } from "@mailwoman/core/json"
import type { WOFDatabase } from "@mailwoman/resolver-wof-sqlite/schema"
import { DatabaseClient } from "@mailwoman/sqlite/client"
import { DEFAULT_GEONAMES_TAIL_COUNTRIES } from "mailwoman/gazetteer-pipeline/defaults"
import { buildPostcodeGeonamesTail } from "mailwoman/gazetteer-pipeline/postcode/geonames/tail"
import { join } from "path-ts"
import { afterAll, beforeAll, expect, test } from "vitest"

let root: TemporaryDirectory
let postalDir: string

/**
 * A GeoNames postal row: country, postcode, place, admin1, code1, admin2, code2,
 * admin3, code3, lat, lon, accuracy.
 */
function row(cc: string, postcode: string, place: string, lat: number, lon: number): string {
	return [cc, postcode, place, "R", "R1", "", "", "", "", String(lat), String(lon), "6"].join("\t")
}

beforeAll(async () => {
	root = await temporaryDirectory("geonames-tail-")
	postalDir = root.resolve("geonames-postal")
	await makeDirectories(postalDir)

	// CZ: one code written in the spaced display form, across three settlements — exercises both #920
	// laws at once (normalization to `11000`, and a medoid that must land on one of the three points).
	await writeLocalTextFile(
		[
			row("CZ", "110 00", "Praha 1", 50.1, 14.1),
			row("CZ", "110 00", "Stare Mesto", 50.2, 14.2),
			row("CZ", "110 00", "Josefov", 50.4, 14.4),
			row("CZ", "120 00", "Vinohrady", 50.07, 14.44),
		],
		join(postalDir, "CZ.txt")
	)

	// PL: the dashed display form.
	await writeLocalFile(row("PL", "11-041", "Olsztyn", 53.8, 20.4) + "\n", join(postalDir, "PL.txt"))
})

afterAll(() => root[Symbol.asyncDispose]())

test("buildPostcodeGeonamesTail: #920 laws survive a rebuild, and a missing dump is reported", async () => {
	const out = root.resolve("tail.db")

	const result = await buildPostcodeGeonamesTail({
		countries: ["CZ", "PL", "ZZ"],
		postalDir,
		out,
		now: new Date("2026-08-05T00:00:00.000Z"),
	})

	expect(result.inserted).toBe(3)
	expect(result.byCountry).toEqual({ CZ: 2, PL: 1 })
	// The meaning-of-zero rule: a country with no dump is a named absence rather than a zero row.
	expect(result.missing).toEqual(["ZZ"])
	expect(result.sources.map((s) => s.country)).toEqual(["CZ", "PL"])
	expect(result.sources.every((s) => /^[0-9a-f]{32}$/.test(s.md5))).toBe(true)
	// Sealed 0444 — the artifact is read-only from the moment it exists (mode bits rather than
	// accessSync: root.path ignores the permission and would pass a W_OK probe on a sealed file).
	expect((await statPath(out)).mode & 0o222).toBe(0)

	await using db = new DatabaseClient<WOFDatabase>(out, { readOnly: true })

	// Name law: `spr.name` is the sanitized-query token shape.
	// The display form is an alt `names` row.
	const names = db.prepare("SELECT name FROM spr WHERE country='CZ' ORDER BY name").all() as Array<{ name: string }>
	expect(names.map((n) => n.name)).toEqual(["11000", "12000"])

	const alt = db.prepare("SELECT COUNT(*) AS n FROM names WHERE name = '110 00'").get() as { n: number }
	expect(alt.n).toBe(1)

	const spaced = db.prepare("SELECT COUNT(*) AS n FROM spr WHERE name = '110 00'").get() as { n: number }
	expect(spaced.n).toBe(0)

	// Medoid law: the centroid is one of the three member points — here 50.2/14.2,
	// the one nearest the (50.2333, 14.2333) mean, which is itself not a member.
	// A mean-of-members build would store the mean and put the postcode on no settlement at all.
	const cz = db.prepare("SELECT latitude, longitude FROM spr WHERE country='CZ' AND name='11000'").get() as {
		latitude: number
		longitude: number
	}

	expect([
		[50.1, 14.1],
		[50.2, 14.2],
		[50.4, 14.4],
	]).toContainEqual([cz.latitude, cz.longitude])

	// Every place is searchable and has an ancestors self-row (the parent-constraint subquery reads it).
	const fts = db.prepare("SELECT COUNT(*) AS n FROM place_search").get() as { n: number }
	expect(fts.n).toBe(3)
	const anc = db.prepare("SELECT COUNT(*) AS n FROM ancestors").get() as { n: number }
	expect(anc.n).toBe(3)

	// Provenance travels IN the artifact.
	// The licence obligation the frozen database never carried.
	const meta = new Map(
		(db.prepare("SELECT key, value FROM meta").all() as Array<{ key: string; value: string }>).map((r) => [
			r.key,
			r.value,
		])
	)

	expect(meta.get("built_at")).toBe("2026-08-05T00:00:00.000Z")
	expect(meta.get("countries")).toBe("CZ,PL,ZZ")
	expect(meta.get("license")).toContain("CC-BY 4.0")
	expect(meta.get("license_gb")).toContain("Open Government Licence v3")
	expect(parseJSONStrict<unknown[]>(meta.get("source_files")!)).toHaveLength(2)
})

test("DEFAULT_GEONAMES_TAIL_COUNTRIES: the frozen artifact's ten lead, in its ingest order", () => {
	// `ingestGeonamesPostal` allocates ids from one counter in list order,
	// so a country's id range is its position.
	// Appending is therefore safe and reordering is not: these ten were recovered from the frozen
	// artifact's per-country spr.id ranges, and a rebuild stays id-comparable to it only while they lead.
	// Everything after them is coverage added since, which the frozen artifact never held an id for.
	expect([...DEFAULT_GEONAMES_TAIL_COUNTRIES].slice(0, 10)).toEqual([
		"FI",
		"CZ",
		"SK",
		"SI",
		"DK",
		"NO",
		"HR",
		"PL",
		"SE",
		"BE",
	])
})

test("DEFAULT_GEONAMES_TAIL_COUNTRIES: every entry is a distinct upper-case ISO-3166 alpha-2", () => {
	// A duplicate would ingest a country twice under two id ranges, and a lower-case entry would
	// miss its `<CC>.txt` and be reported missing — both silent, since neither stops the build.
	const list = [...DEFAULT_GEONAMES_TAIL_COUNTRIES]

	expect(list.filter((cc) => !/^[A-Z]{2}$/.test(cc))).toEqual([])
	expect(list).toHaveLength(new Set(list).size)
})

test("DEFAULT_GEONAMES_TAIL_COUNTRIES: the UAE is absent — Makani codes are not postcodes", () => {
	// GeoNames publishes AE's 10-digit Makani building geocodes in the postal dump.
	// They are a building reference rather than a postal code, and folding them stored
	// 178,171 rows under a placetype that means something else.
	expect([...DEFAULT_GEONAMES_TAIL_COUNTRIES]).not.toContain("AE")
})
