import { temporaryDirectory } from "@mailwoman/core/fs/temporary"
import { writeLocalTextFile, makeDirectories } from "@mailwoman/core/fs/writers"
import type { WOFDatabase } from "@mailwoman/resolver-wof-sqlite/schema"
import { createUnifiedSchema } from "@mailwoman/resolver-wof-sqlite/unified-schema"
/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 */
import { DatabaseClient } from "@mailwoman/sqlite/client"
import { fillPostcodeCentroids } from "mailwoman/gazetteer-pipeline/postcode/centroid-fills"
import { join } from "path-ts"
import { expect, test } from "vitest"

test("parent-borrow fills a (0,0) postcode from the admin gazetteer; real coordinates untouched", async () => {
	// The staging database: two postcodes.
	// One placeholder (parented), one already placed.
	await using dirDirectory = await temporaryDirectory("centroid-fills-")
	const dir = dirDirectory.path
	const databasePath = join(dir, "postalcode-tl.db")
	using database = new DatabaseClient<WOFDatabase>(databasePath)
	await createUnifiedSchema(database)

	const ins = database.prepare(
		"INSERT INTO spr (id, parent_id, name, placetype, country, latitude, longitude, min_latitude, min_longitude, max_latitude, max_longitude, is_current, is_deprecated, is_ceased, is_superseded, is_superseding, lastmodified) VALUES (?, ?, ?, ?, ?, ?, ?, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0)"
	)

	ins.run(100, 9, "1000", "postalcode", "TL", 0, 0) // placeholder → should fill from parent 9
	ins.run(101, 9, "2000", "postalcode", "TL", 5.5, 6.5) // real coordinate → must be untouched

	// The admin gazetteer carrying the parent locality.
	const adminPath = join(dir, "admin.db")
	using admin = new DatabaseClient<WOFDatabase>(adminPath)
	await createUnifiedSchema(admin)

	admin
		.prepare(
			"INSERT INTO spr (id, parent_id, name, placetype, country, latitude, longitude, min_latitude, min_longitude, max_latitude, max_longitude, is_current, is_deprecated, is_ceased, is_superseded, is_superseding, lastmodified) VALUES (9, -1, 'Testtown', 'locality', 'TL', 1.25, 2.5, 1, 2, 1.5, 3, 1, 0, 0, 0, 0, 0)"
		)
		.run()

	await using db = new DatabaseClient<WOFDatabase>(databasePath)
	const r = await fillPostcodeCentroids(db, { adminPath })
	expect(r.placedBefore).toBe(1)
	expect(r.placedAfter).toBe(2)
	expect(r.parentBorrowFixed).toBe(1)

	const filled = db.prepare("SELECT latitude, longitude FROM spr WHERE id = 100").get() as {
		latitude: number
		longitude: number
	}

	expect(filled).toEqual({ latitude: 1.25, longitude: 2.5 })

	const untouched = db.prepare("SELECT latitude, longitude FROM spr WHERE id = 101").get() as {
		latitude: number
		longitude: number
	}

	expect(untouched).toEqual({ latitude: 5.5, longitude: 6.5 })
})

test("GeoNames postal names each postcode's delivery city, including territories filed under their own ISO code", async () => {
	// A delivery city is not the geographic locality: 11201 is Brooklyn inside the locality
	// New York, and Queens uses neighbourhood names rather than the borough.
	// Both shapes are here on purpose.
	await using dirDirectory = await temporaryDirectory("centroid-names-")
	const dir = dirDirectory.path
	const databasePath = join(dir, "postalcode-us.db")
	using database = new DatabaseClient<WOFDatabase>(databasePath)

	await createUnifiedSchema(database)

	const ins = database.prepare(
		"INSERT INTO spr (id, parent_id, name, placetype, country, latitude, longitude, min_latitude, min_longitude, max_latitude, max_longitude, is_current, is_deprecated, is_ceased, is_superseded, is_superseding, lastmodified) VALUES (?, ?, ?, ?, ?, ?, ?, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0)"
	)

	ins.run(1, -1, "11201", "postalcode", "US", 40.69, -73.99) // already placed, still nameless
	ins.run(2, -1, "11375", "postalcode", "US", 40.72, -73.85) // Queens: a neighbourhood delivery city
	ins.run(3, -1, "00601", "postalcode", "US", 0, 0) // Puerto Rico, filed as US in WOF

	// GeoNames files a US territory under PR rather than US.
	// The database files it under US.
	// Reading only `US` rows leaves every territory postcode unnamed —
	// 149 of them against the 2024 Census zcta list.
	const geonamesDir = join(dir, "geonames-postal")

	await makeDirectories(geonamesDir)

	await writeLocalTextFile(
		[
			"US\t11201\tBrooklyn\tNew York\tNY\tKings\t047\t\t\t40.694\t-73.9903\t4",
			"US\t11375\tForest Hills\tNew York\tNY\tQueens\t081\t\t\t40.7229\t-73.8473\t4",
			"PR\t00601\tAdjuntas\tPuerto Rico\tPR\tAdjuntas\t001\t\t\t18.1801\t-66.7522\t4",
		].join("\n"),
		join(geonamesDir, "US.txt")
	)

	await using db = new DatabaseClient<WOFDatabase>(databasePath)

	const r = await fillPostcodeCentroids(db, { geonamesDir })

	expect(r.geonamesNames).toBe(3)

	const named = (postcode: string) =>
		(
			db
				.prepare(
					"SELECT n.name AS name FROM spr s JOIN names n ON n.id = s.id WHERE s.placetype = 'postalcode' AND s.name = ?"
				)
				.all(postcode) as Array<{ name: string }>
		).map((row) => row.name)

	expect(named("11201")).toEqual(["Brooklyn"])
	expect(named("11375")).toEqual(["Forest Hills"])
	// The country-alias case.
	// Without it this is [] and the postcode also keeps its (0,0) placeholder.
	expect(named("00601")).toEqual(["Adjuntas"])

	const pr = db.prepare("SELECT latitude FROM spr WHERE id = 3").get() as { latitude: number }

	expect(pr.latitude).toBeCloseTo(18.1801, 3)
})

test("falls back to the combined dump for a country the per-country directory has no file for", async () => {
	// The US case.
	// `<data-root>/geonames-postal/` carries CZ, DK, FI and eight others and no US.txt,
	// so without this branch the whole GeoNames pass short-circuits on existsSync and writes nothing.
	await using dirDirectory = await temporaryDirectory("centroid-combined-")
	const dir = dirDirectory.path
	const databasePath = join(dir, "postalcode-us.db")
	using database = new DatabaseClient<WOFDatabase>(databasePath)

	await createUnifiedSchema(database)

	database
		.prepare(
			"INSERT INTO spr (id, parent_id, name, placetype, country, latitude, longitude, min_latitude, min_longitude, max_latitude, max_longitude, is_current, is_deprecated, is_ceased, is_superseded, is_superseding, lastmodified) VALUES (1, -1, '11201', 'postalcode', 'US', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0)"
		)
		.run()

	// An empty per-country directory — the shape on disk that made this branch required.
	const geonamesDir = join(dir, "geonames-postal")

	await makeDirectories(geonamesDir)

	const geonamesCombined = join(dir, "allCountries-postal.txt")

	await writeLocalTextFile(
		["FI\t11201\tSomewhere\t\t\t\t\t\t\t60.1\t24.9\t4", "US\t11201\tBrooklyn\t\t\t\t\t\t\t40.694\t-73.9903\t4"].join(
			"\n"
		),
		geonamesCombined
	)

	await using db = new DatabaseClient<WOFDatabase>(databasePath)

	const r = await fillPostcodeCentroids(db, { geonamesDir, geonamesCombined })

	expect(r.geonamesNames).toBe(1)

	// FI carries the same postcode string — country scoping is what keeps Helsinki out of Brooklyn.
	const row = db.prepare("SELECT n.name AS name FROM names n WHERE n.id = 1").get() as { name: string }

	expect(row.name).toBe("Brooklyn")

	const placed = db.prepare("SELECT latitude FROM spr WHERE id = 1").get() as { latitude: number }

	expect(placed.latitude).toBeCloseTo(40.694, 3)
})
