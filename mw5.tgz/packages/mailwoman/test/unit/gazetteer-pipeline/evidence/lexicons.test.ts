/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   The three-law selectivity's unit surface (pure functions) + a DB-conditional integration pass for the
 *   locality-surface build. Each law traces to a falsified training run (v3.16→v3.18) — these tests
 *   are the regression fence around that tuition.
 */

import { tempRootPath } from "@mailwoman/core/data-root"
import { readLocalJSONFile } from "@mailwoman/core/fs/readers"
import {
	buildStreetTypeLexicon,
	clearsProminenceFloor,
	isSubPhraseAlias,
	loadDERegionVocabulary,
	loadDirectionalSurfaces,
	loadPersonNameSurfaces,
	loadUSRegionVocabulary,
	ONE_TOKEN_IMPORTANCE_FLOOR,
	painterFold,
	PERSON_NAME_IMPORTANCE_FLOOR,
} from "mailwoman/gazetteer-pipeline/evidence-lexicons"
import { loadDegenerateSurfaces } from "mailwoman/gazetteer-pipeline/fst"
import { describe, expect, it } from "vitest"

const personNames = await loadPersonNameSurfaces()

describe("three-law selectivity — pure units", () => {
	it("law 3: person-name surfaces exist and carry the flip-row names", () => {
		// The v3.17→v3.18 flip rows: given names that are prominent-place homographs.
		for (const name of ["joseph", "pierre", "louis", "thomas"]) {
			expect(personNames.has(name), name).toBe(true)
		}

		// Titles ride personal_titles ("Rue Baron Desgenettes").
		expect(personNames.has("baron")).toBe(true)
	})

	it("law 3: metros clear the person-name tier, given names do not", () => {
		// paris/lyon/nancy are IN the name lists.
		// The tiered floor keeps them at metro prominence.
		expect(clearsProminenceFloor("paris", 0.85, personNames)).toBe(true)
		expect(clearsProminenceFloor("lyon", 0.6, personNames)).toBe(true)
		// A given-name homograph at ordinary-town prominence is refused…
		expect(clearsProminenceFloor("joseph", 0.3, personNames)).toBe(false)
		// …while the same prominence on a non-name surface passes (law 2 only applies).
		expect(clearsProminenceFloor("rennes", 0.3, personNames)).toBe(true)
	})

	it("law 2: the plain prominence floor", () => {
		expect(clearsProminenceFloor("smallville", ONE_TOKEN_IMPORTANCE_FLOOR - 0.01, personNames)).toBe(false)
		expect(clearsProminenceFloor("smallville", ONE_TOKEN_IMPORTANCE_FLOOR, personNames)).toBe(true)
	})

	it("floors are ordered: person-name tier is strictly higher", () => {
		expect(PERSON_NAME_IMPORTANCE_FLOOR).toBeGreaterThan(ONE_TOKEN_IMPORTANCE_FLOOR)
	})

	it("law-3 guard: parent prominence never launders a person-name surface", () => {
		// A neighbourhood named "Joseph" inside a metropolis (parent 0.9) is still the Rue-Joseph
		// hazard — only own metropolis-tier importance clears a person-name surface.
		expect(clearsProminenceFloor("joseph", 0.1, personNames, 0.9)).toBe(false)
		expect(clearsProminenceFloor("joseph", PERSON_NAME_IMPORTANCE_FLOOR, personNames, 0)).toBe(true)
		// Non-name neighbourhoods do inherit parent prominence (the Montmartre-class fix).
		expect(clearsProminenceFloor("belleville", 0, personNames, 0.9)).toBe(true)
		expect(clearsProminenceFloor("obscureplace", 0, personNames, 0.1)).toBe(false)
	})

	it("law 1: the degenerate set carries the shipped-index victims", async () => {
		const { surfaces, stopwordTokens } = await loadDegenerateSurfaces()

		// The case-folded alias collisions + street vocabulary the FST curation prunes.
		for (const s of ["la", "op", "boulevard", "lane", "street"]) {
			expect(surfaces.has(s), s).toBe(true)
		}

		// The compositional clause's token source ("de la" class).
		expect(stopwordTokens.has("de")).toBe(true)
		expect(stopwordTokens.has("la")).toBe(true)
	})

	it("law-1 directional closure (v5): the census flip surfaces are in the directional set", async () => {
		const directionals = await loadDirectionalSurfaces()

		// The v3.19 flip census: US neighbourhoods literally named these painted evidence onto
		// street directionals ("3rd Ave East" → street "3rd", "Fargo" → locality "North").
		for (const s of ["east", "west", "north", "south", "northeast", "northwest", "southeast", "southwest"]) {
			expect(directionals.has(s), s).toBe(true)
		}

		// The set stays out of the shipped FST policy — loadDegenerateSurfaces alone must not carry
		// "northeast" (policy separation: degenerate-surface-exclusion v1.1 is baked into FST trailers).
		expect((await loadDegenerateSurfaces(undefined, painterFold)).surfaces.has("northeast")).toBe(false)
	})

	it("law 4 (v5): US region vocabulary carries the census flip surfaces", () => {
		const region = loadUSRegionVocabulary()

		// The evidence→region rotation rows: Washington DC, Missouri Break Ln, Frannie Wyoming, Vermont 05454.
		for (const s of ["washington", "wyoming", "vermont", "missouri", "wy", "ct", "dc", "north dakota"]) {
			expect(region.has(s), s).toBe(true)
		}

		// Not a blanket word ban — ordinary locality surfaces stay out.
		expect(region.has("fargo")).toBe(false)
		expect(region.has("springfield")).toBe(false)
	})

	it("law 4 (v7): DE region vocabulary excludes the territorial Länder but keeps the city-states", () => {
		const region = loadDERegionVocabulary()

		// The 13 territorial-state names — native, exonym, and the everyday aliases —
		// are region vocabulary ("bayern" as locality evidence teaches the v3.19 rotation class).
		for (const s of [
			"bayern",
			"bavaria",
			"sachsen",
			"saxony",
			"nrw",
			"nordrhein-westfalen",
			"thüringen",
			"baden-württemberg",
		]) {
			expect(region.has(s), s).toBe(true)
		}

		// The city-states stay OUT of the exclusion: Land and Stadt are one coextensive place
		// and the locality reading dominates user text ("10115 berlin").
		for (const s of ["berlin", "hamburg", "bremen"]) {
			expect(region.has(s), s).toBe(false)
		}

		// Not a blanket word ban — ordinary DE locality surfaces stay out.
		expect(region.has("münchen")).toBe(false)
		expect(region.has("leipzig")).toBe(false)
	})

	it("alt-name sub-phrase hygiene (v5): sub-phrases rejected, real nicknames kept", () => {
		// "East" ⊂ "East Nashville", "Washington" ⊂ "Mount Washington" — the names-table leak.
		expect(isSubPhraseAlias(painterFold("East"), painterFold("East Nashville"))).toBe(true)
		expect(isSubPhraseAlias(painterFold("Washington"), painterFold("Mount Washington"))).toBe(true)
		expect(isSubPhraseAlias(painterFold("Nashville"), painterFold("East Nashville"))).toBe(true)
		// Equality is not a sub-phrase (re-adding the primary through names is harmless)…
		expect(isSubPhraseAlias(painterFold("Frisco"), painterFold("Frisco"))).toBe(false)
		// …and genuine nicknames survive.
		expect(isSubPhraseAlias(painterFold("Frisco"), painterFold("San Francisco"))).toBe(false)
		// Contiguity required — a scattered subsequence is not a sub-phrase.
		expect(isSubPhraseAlias(painterFold("East Village"), painterFold("East Nashville Village Green"))).toBe(false)
	})
})

/**
 * The street-type lexicon artifact, narrowed to the fields these tests read.
 */
interface StreetTypeLexicon {
	rules: { digit_guard: boolean }
	entries: Record<string, number>
	code_entries: Record<string, number>
}

describe("street-type lexicon build", () => {
	it("canonical lowercase words in entries, short abbreviations uppercase-conditional", async () => {
		const tmp = tempRootPath(`street-type-lexicon-test.json`)
		const built = await buildStreetTypeLexicon({ output: tmp })

		expect(built.entries).toBeGreaterThan(400)
		const j = await readLocalJSONFile<StreetTypeLexicon>(tmp)

		// "rue" must match lowercase (the FR probe class); "R" only as an uppercase code.
		expect(j.rules.digit_guard).toBe(true)
		expect(j.entries.rue).toBe(1)
		expect(j.code_entries.R).toBe(1)
		expect(j.entries.r).toBeUndefined()
		expect(j.entries.boulevard).toBe(1)
	})

	it("v2 / census family F1: US-state-homograph codes withheld, directionals kept", async () => {
		const tmp = tempRootPath(`street-type-lexicon-v2-test.json`)
		const built = await buildStreetTypeLexicon({ output: tmp })

		expect(built.skippedRegionVocabulary).toBeGreaterThanOrEqual(4)
		const j = await readLocalJSONFile<StreetTypeLexicon>(tmp)

		// "mountain WAY WY 82601" / "susie CT WY 83101".
		// The state token must carry no street evidence.
		for (const code of ["WY", "CT", "KY", "MT", "PR"]) {
			expect(j.code_entries[code], code).toBeUndefined()
		}

		// Directional codes stay (single-letter CA forms. None collide with a state).
		expect(j.code_entries.N).toBe(1)
		expect(j.code_entries.W).toBe(1)
		// The canonical words behind the dropped codes are untouched.
		expect(j.entries.way).toBe(1)
		expect(j.entries.court).toBe(1)
	})
})
