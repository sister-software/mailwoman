/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 */

import type { AddressTree } from "@mailwoman/core/decoder"
import type { POIIntent } from "@mailwoman/core/pipeline"
import type { POISearchHit, POISearchQuery } from "@mailwoman/resolver-wof-sqlite/poi"
import { createPOIExecutor, type POIExecutorLookup, resolvePOIAnchorCountry } from "mailwoman/poi"
import { describe, expect, it } from "vitest"

const SPRINGFIELD_TREE: AddressTree = {
	raw: "Springfield IL",
	roots: [
		{
			tag: "locality",
			value: "Springfield",
			start: 0,
			end: 11,
			confidence: 0.9,
			children: [],
			lat: 39.78,
			lon: -89.65,
		},
	],
}

const HOSPITAL_HIT: POISearchHit = {
	name: "Springfield General",
	categoryID: "hospital",
	brandWikidata: null,
	latitude: 39.781,
	longitude: -89.651,
	country: "US",
	confidence: 0.8,
	gersID: "08f2836a5411a2ff0300b0a0b0c0d0e0",
	distanceM: 120,
}

function stubLookup(fn: (query: POISearchQuery) => POISearchHit[]): POIExecutorLookup {
	return { search: fn }
}

const NEVER_BUILD_LOCAL = () => false

describe("createPOIExecutor", () => {
	it("category happy path: resolves the center from the anchor tree and returns mapped results", () => {
		const seenQueries: POISearchQuery[] = []

		const executor = createPOIExecutor({
			lookup: stubLookup((query) => {
				seenQueries.push(query)

				return [HOSPITAL_HIT]
			}),
			requiresBuildLocal: NEVER_BUILD_LOCAL,
		})

		const intent: POIIntent = {
			subject: { kind: "category", categoryIDs: ["hospital"], matched: "hospital" },
			anchor: { text: "Springfield IL", tree: SPRINGFIELD_TREE },
		}

		const outcome = executor(intent)

		expect(outcome.type).toBe("intent")

		if (outcome.type !== "intent") throw new Error("unreachable")

		expect(outcome.results).toEqual([
			{
				name: "Springfield General",
				categoryID: "hospital",
				brandWikidata: null,
				latitude: 39.781,
				longitude: -89.651,
				country: "US",
				confidence: 0.8,
				gersID: "08f2836a5411a2ff0300b0a0b0c0d0e0",
				distanceM: 120,
			},
		])

		expect(seenQueries).toEqual([
			{ categoryIDs: ["hospital"], center: { latitude: 39.78, longitude: -89.65 }, limit: undefined },
		])
	})

	it("category fan-out: probes the injected Overture leaves and re-tags hits to the canonical seed id", () => {
		const seenQueries: POISearchQuery[] = []
		// The db stores the raw Overture leaf id on each row.
		// The executor must re-tag it back to `supermarket`.
		const groceryHit: POISearchHit = { ...HOSPITAL_HIT, name: "Jewel-Osco", categoryID: "grocery_store" }

		const executor = createPOIExecutor({
			lookup: stubLookup((query) => {
				seenQueries.push(query)

				return [groceryHit]
			}),
			requiresBuildLocal: NEVER_BUILD_LOCAL,
			resolveOvertureCategories: (id) => (id === "supermarket" ? ["grocery_store", "organic_grocery_store"] : [id]),
		})

		const outcome = executor({
			subject: { kind: "category", categoryIDs: ["supermarket"], matched: "grocery" },
			anchor: { text: "Chicago IL", tree: SPRINGFIELD_TREE },
		})

		expect(outcome.type).toBe("intent")

		if (outcome.type !== "intent") throw new Error("unreachable")

		// The query fans out over the leaves (not the raw seed id); the emitted id is the canonical seed id.
		expect(seenQueries).toEqual([
			{
				categoryIDs: ["grocery_store", "organic_grocery_store"],
				center: { latitude: 39.78, longitude: -89.65 },
				limit: undefined,
			},
		])

		expect(outcome.results![0]!.categoryID).toBe("supermarket")
		expect(outcome.results![0]!.name).toBe("Jewel-Osco")
	})

	it("category identity default: no injected resolver ⇒ probes [categoryID] and re-tag is a no-op", () => {
		const seenQueries: POISearchQuery[] = []

		const executor = createPOIExecutor({
			lookup: stubLookup((query) => {
				seenQueries.push(query)

				return [HOSPITAL_HIT]
			}),
			requiresBuildLocal: NEVER_BUILD_LOCAL,
		})

		const outcome = executor({
			subject: { kind: "category", categoryIDs: ["hospital"], matched: "hospital" },
			anchor: { text: "Springfield IL", tree: SPRINGFIELD_TREE },
		})

		expect(outcome.type).toBe("intent")

		if (outcome.type !== "intent") throw new Error("unreachable")

		expect(seenQueries).toEqual([
			{ categoryIDs: ["hospital"], center: { latitude: 39.78, longitude: -89.65 }, limit: undefined },
		])

		expect(outcome.results![0]!.categoryID).toBe("hospital")
	})

	// The union: every category the subject reached goes into one search, so the reader's
	// own k-ring walk unions the rows and distance-sorts the pool.
	// Two searches taken in turn would need something here to decide which set of results wins,
	// and that decision is the candidate ordering this path does not author.
	it("union: probes every category the subject reached in a single search", () => {
		const seenQueries: POISearchQuery[] = []

		const executor = createPOIExecutor({
			lookup: stubLookup((query) => {
				seenQueries.push(query)

				return []
			}),
			requiresBuildLocal: NEVER_BUILD_LOCAL,
		})

		executor({
			subject: { kind: "category", categoryIDs: ["drugstore", "pharmacy"], matched: "prescription" },
			anchor: { text: "Coalinga CA", tree: SPRINGFIELD_TREE },
		})

		expect(seenQueries).toEqual([
			{
				categoryIDs: ["drugstore", "pharmacy"],
				center: { latitude: 39.78, longitude: -89.65 },
				limit: undefined,
			},
		])
	})

	// Each hit keeps the identity of the category it came from, so a caller reading
	// `results[0].categoryID` is told which class answered rather than which class was asked for first.
	it("union: re-tags each hit to the canonical seed whose fan-out reached it", () => {
		const drugstoreHit: POISearchHit = { ...HOSPITAL_HIT, name: "Rite Aid", categoryID: "drugstore", distanceM: 770 }
		const pharmacyHit: POISearchHit = { ...HOSPITAL_HIT, name: "Walgreens Rx", categoryID: "rx", distanceM: 1710 }

		const executor = createPOIExecutor({
			lookup: stubLookup(() => [drugstoreHit, pharmacyHit]),
			requiresBuildLocal: NEVER_BUILD_LOCAL,
			resolveOvertureCategories: (id) => (id === "pharmacy" ? ["rx"] : [id]),
		})

		const outcome = executor({
			subject: { kind: "category", categoryIDs: ["drugstore", "pharmacy"], matched: "prescription" },
			anchor: { text: "Coalinga CA", tree: SPRINGFIELD_TREE },
		})

		if (outcome.type !== "intent") throw new Error("unreachable")

		expect(outcome.results!.map((result) => [result.name, result.categoryID])).toEqual([
			["Rite Aid", "drugstore"],
			["Walgreens Rx", "pharmacy"],
		])
	})

	// The order the reader returned, kept exactly.
	// The executor sorts nothing and applies no per-category weight, so the nearest
	// row leads whichever category it came from.
	it("union: leaves the reader's ordering alone", () => {
		const far: POISearchHit = { ...HOSPITAL_HIT, name: "far pharmacy", categoryID: "pharmacy", distanceM: 4000 }
		const near: POISearchHit = { ...HOSPITAL_HIT, name: "near drugstore", categoryID: "drugstore", distanceM: 770 }

		const executor = createPOIExecutor({
			lookup: stubLookup(() => [near, far]),
			requiresBuildLocal: NEVER_BUILD_LOCAL,
		})

		const outcome = executor({
			subject: { kind: "category", categoryIDs: ["drugstore", "pharmacy"], matched: "prescription" },
			anchor: { text: "Coalinga CA", tree: SPRINGFIELD_TREE },
		})

		if (outcome.type !== "intent") throw new Error("unreachable")

		expect(outcome.results!.map((result) => result.name)).toEqual(["near drugstore", "far pharmacy"])
	})

	// Two seeds rolling up into a shared leaf probe it once.
	// A repeated leaf would return the same rows twice and read as two premises at one coordinate.
	it("union: probes a leaf two seeds share exactly once", () => {
		const seenQueries: POISearchQuery[] = []

		const executor = createPOIExecutor({
			lookup: stubLookup((query) => {
				seenQueries.push(query)

				return []
			}),
			requiresBuildLocal: NEVER_BUILD_LOCAL,
			resolveOvertureCategories: (id) => (id === "drugstore" ? ["drugstore", "rx"] : ["rx"]),
		})

		executor({
			subject: { kind: "category", categoryIDs: ["drugstore", "pharmacy"], matched: "prescription" },
			anchor: { text: "Coalinga CA", tree: SPRINGFIELD_TREE },
		})

		expect(seenQueries[0]!.categoryIDs).toEqual(["drugstore", "rx"])
	})

	// The abstain is about what the shipped layer can answer, so it needs every member to be build-local.
	// One member the layer carries makes the search answerable, and abstaining
	// would report a gap the search does not have.
	it("union: does not abstain when one member of the set is not build-local", () => {
		const executor = createPOIExecutor({
			lookup: stubLookup(() => []),
			requiresBuildLocal: (categoryID) => categoryID === "fire_hydrant",
		})

		const outcome = executor({
			subject: { kind: "category", categoryIDs: ["fire_hydrant", "hospital"], matched: "water" },
			anchor: { text: "Springfield IL", tree: SPRINGFIELD_TREE },
		})

		expect(outcome.type).toBe("intent")
	})

	it("union: abstains when EVERY member is build-local and the search comes back empty", () => {
		const executor = createPOIExecutor({
			lookup: stubLookup(() => []),
			requiresBuildLocal: () => true,
		})

		const outcome = executor({
			subject: { kind: "category", categoryIDs: ["fire_hydrant", "drinking_water"], matched: "water" },
			anchor: { text: "Springfield IL", tree: SPRINGFIELD_TREE },
		})

		expect(outcome).toEqual({ type: "abstain", reason: "requires_build_local_layer" })
	})

	it("anchor_required: category subject, lookup present, no resolvable center", () => {
		const executor = createPOIExecutor({
			lookup: stubLookup(() => [HOSPITAL_HIT]),
			requiresBuildLocal: NEVER_BUILD_LOCAL,
		})

		const outcome = executor({ subject: { kind: "category", categoryIDs: ["hospital"], matched: "hospital" } })

		expect(outcome).toEqual({ type: "abstain", reason: "anchor_required" })
	})

	it("anchor_required: a bare biasPoint anchor is honored (no abstain)", () => {
		const executor = createPOIExecutor({
			lookup: stubLookup(() => [HOSPITAL_HIT]),
			requiresBuildLocal: NEVER_BUILD_LOCAL,
		})

		const outcome = executor({
			subject: { kind: "category", categoryIDs: ["hospital"], matched: "hospital" },
			anchor: { biasPoint: { latitude: 1, longitude: 2 } },
		})

		expect(outcome.type).toBe("intent")
	})

	it("requires_build_local_layer: fire_hydrant, lookup present, empty result set", () => {
		const executor = createPOIExecutor({
			lookup: stubLookup(() => []),
			requiresBuildLocal: (categoryID) => categoryID === "fire_hydrant",
		})

		const intent: POIIntent = {
			subject: { kind: "category", categoryIDs: ["fire_hydrant"], matched: "fire hydrant" },
			anchor: { text: "Springfield IL", tree: SPRINGFIELD_TREE },
		}

		const outcome = executor(intent)

		expect(outcome).toEqual({ type: "abstain", reason: "requires_build_local_layer" })
	})

	it("requires_build_local_layer: fires with NO lookup at all, even with no anchor", () => {
		const executor = createPOIExecutor({
			lookup: undefined,
			requiresBuildLocal: (categoryID) => categoryID === "fire_hydrant",
		})

		const outcome = executor({ subject: { kind: "category", categoryIDs: ["fire_hydrant"], matched: "fire hydrant" } })

		expect(outcome).toEqual({ type: "abstain", reason: "requires_build_local_layer" })
	})

	it("intent-only passthrough: no lookup configured, non-build-local category", () => {
		const executor = createPOIExecutor({ lookup: undefined, requiresBuildLocal: NEVER_BUILD_LOCAL })

		const intent: POIIntent = { subject: { kind: "category", categoryIDs: ["hospital"], matched: "hospital" } }
		const outcome = executor(intent)

		expect(outcome).toEqual({ type: "intent", intent })
	})

	it("name search without center: OK, no abstain, search runs un-anchored", () => {
		const seenQueries: POISearchQuery[] = []

		const nameHit: POISearchHit = {
			name: "Joe's Diner",
			categoryID: null,
			brandWikidata: null,
			latitude: 10,
			longitude: 20,
			country: "US",
			confidence: 0.6,
			gersID: null,
		}

		const executor = createPOIExecutor({
			lookup: stubLookup((query) => {
				seenQueries.push(query)

				return [nameHit]
			}),
			requiresBuildLocal: NEVER_BUILD_LOCAL,
		})

		const outcome = executor({ subject: { kind: "name", text: "Joe's Diner" } })

		expect(outcome.type).toBe("intent")

		if (outcome.type !== "intent") throw new Error("unreachable")

		expect(outcome.results).toEqual([
			{
				name: "Joe's Diner",
				categoryID: null,
				brandWikidata: null,
				latitude: 10,
				longitude: 20,
				country: "US",
				confidence: 0.6,
				gersID: null,
			},
		])

		expect(seenQueries).toEqual([{ name: "Joe's Diner", center: undefined, limit: undefined }])
	})

	it("ancestry is ABSENT (no key at all) when no reverseGeocode fn is wired", () => {
		const executor = createPOIExecutor({
			lookup: stubLookup(() => [HOSPITAL_HIT]),
			requiresBuildLocal: NEVER_BUILD_LOCAL,
		})

		const outcome = executor({
			subject: { kind: "category", categoryIDs: ["hospital"], matched: "hospital" },
			anchor: { text: "Springfield IL", tree: SPRINGFIELD_TREE },
		})

		expect(outcome.type).toBe("intent")

		if (outcome.type !== "intent") throw new Error("unreachable")
		expect(outcome.results![0]).not.toHaveProperty("ancestry")
	})

	it("ancestry is decorated per-result when reverseGeocode is wired, capped at the result count", () => {
		const seenCoords: Array<[number, number]> = []

		const ancestry = [
			{ placetype: "locality", name: "Springfield", wofID: 1 },
			{ placetype: "region", name: "Illinois", wofID: 2 },
			{ placetype: "country", name: "United States", wofID: 3 },
		]

		const executor = createPOIExecutor({
			lookup: stubLookup(() => [HOSPITAL_HIT]),
			requiresBuildLocal: NEVER_BUILD_LOCAL,
			reverseGeocode: (latitude, longitude) => {
				seenCoords.push([latitude, longitude])

				return ancestry
			},
		})

		const outcome = executor({
			subject: { kind: "category", categoryIDs: ["hospital"], matched: "hospital" },
			anchor: { text: "Springfield IL", tree: SPRINGFIELD_TREE },
		})

		expect(outcome.type).toBe("intent")

		if (outcome.type !== "intent") throw new Error("unreachable")
		expect(outcome.results![0]!.ancestry).toEqual(ancestry)
		// Exactly one reverseGeocode call per result — the ≤20 (≤limit) call budget.
		expect(seenCoords).toEqual([[HOSPITAL_HIT.latitude, HOSPITAL_HIT.longitude]])
	})

	it("ancestry stays ABSENT for a result when reverseGeocode returns undefined (e.g. open ocean)", () => {
		const executor = createPOIExecutor({
			lookup: stubLookup(() => [HOSPITAL_HIT]),
			requiresBuildLocal: NEVER_BUILD_LOCAL,
			reverseGeocode: () => undefined,
		})

		const outcome = executor({
			subject: { kind: "category", categoryIDs: ["hospital"], matched: "hospital" },
			anchor: { text: "Springfield IL", tree: SPRINGFIELD_TREE },
		})

		expect(outcome.type).toBe("intent")

		if (outcome.type !== "intent") throw new Error("unreachable")
		expect(outcome.results![0]).not.toHaveProperty("ancestry")
	})

	it("ancestry stays ABSENT for a result when reverseGeocode returns an empty array ([] leaks the truthy check)", () => {
		const executor = createPOIExecutor({
			lookup: stubLookup(() => [HOSPITAL_HIT]),
			requiresBuildLocal: NEVER_BUILD_LOCAL,
			reverseGeocode: () => [],
		})

		const outcome = executor({
			subject: { kind: "category", categoryIDs: ["hospital"], matched: "hospital" },
			anchor: { text: "Springfield IL", tree: SPRINGFIELD_TREE },
		})

		expect(outcome.type).toBe("intent")

		if (outcome.type !== "intent") throw new Error("unreachable")
		expect("ancestry" in outcome.results![0]!).toBe(false)
	})
})

describe("resolvePOIAnchorCountry", () => {
	const stamped = (country: string | undefined, child = false): AddressTree => {
		const node = {
			tag: "locality" as const,
			value: "Springfield",
			start: 0,
			end: 11,
			confidence: 0.9,
			children: [],
			lat: 39.78,
			lon: -89.65,
			...(country ? { metadata: { resolver_country: country } } : {}),
		}

		return child
			? {
					raw: "Springfield IL",
					roots: [{ tag: "region", value: "IL", start: 12, end: 14, confidence: 0.9, children: [node] }],
				}
			: { raw: "Springfield", roots: [node] }
	}

	it("reads the country off the node the search is centred on, upper-cased", () => {
		expect(resolvePOIAnchorCountry({ subject: { kind: "name", text: "x" }, anchor: { tree: stamped("us") } })).toBe(
			"US"
		)
	})

	it("falls back to a stamped root when the centred child carries none", () => {
		const tree = stamped(undefined, true)
		tree.roots[0]!.metadata = { resolver_country: "US" }

		expect(resolvePOIAnchorCountry({ subject: { kind: "name", text: "x" }, anchor: { tree } })).toBe("US")
	})

	it("answers null for a country-less node, a biasPoint anchor, and no anchor", () => {
		const subject = { kind: "name" as const, text: "x" }

		expect(resolvePOIAnchorCountry({ subject, anchor: { tree: stamped(undefined) } })).toBeNull()
		expect(resolvePOIAnchorCountry({ subject, anchor: { biasPoint: { latitude: 1, longitude: 2 } } })).toBeNull()
		expect(resolvePOIAnchorCountry({ subject })).toBeNull()
	})
})
