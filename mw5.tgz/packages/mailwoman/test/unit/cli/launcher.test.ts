/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   The bin entry's argument handling, which sits in front of every command.
 *
 *   The launcher cannot know the union of every command's flags, and it decides only two things before dispatching: is
 *   this a bare version request, and should an interactive geocode print a loading line. Both cases below are ones a
 *   stricter reading of the argument vector gets wrong while still looking correct for `mw --version`.
 */

import { resolvePackagePath } from "@mailwoman/core/module/resolvers"
import { runFile, runFileSync } from "@mailwoman/core/process"
import { childEnv } from "@mailwoman/core/scripting/utils"
import { describe, expect, it } from "vitest"

const CLI = resolvePackagePath("mailwoman", "lib", "cli", "index.ts")

/**
 * Combined stdout+stderr, whatever the exit code.
 * A launcher crash is the thing under test.
 */
function runCLI(...args: string[]): string {
	try {
		return runFileSync("node", [CLI, ...args], { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] })
	} catch (error) {
		const failure = error as { stdout?: string; stderr?: string }

		return `${failure.stdout ?? ""}${failure.stderr ?? ""}`
	}
}

describe("the CLI launcher", () => {
	it("prints the version for a bare --version", () => {
		expect(runCLI("--version").trim()).toMatch(/^\d+\.\d+\.\d+$/)
	})

	it("passes a command's own flags through instead of rejecting them", () => {
		// The launcher declares three options.
		// Every other flag in the CLI belongs to a command.
		// Parsing strictly here makes `mw parse … --json` throw ERR_PARSE_ARGS_UNKNOWN_OPTION
		// before dispatch — the whole CLI, for any flag.
		const output = runCLI("nosuchcommand", "--json")

		expect(output).not.toContain("ERR_PARSE_ARGS_UNKNOWN_OPTION")
		expect(output).toContain("Unknown command: nosuchcommand")
	})

	it("prints the license notice on stderr and keeps stdout to the bare version", async () => {
		const { stdout, stderr } = await runFile("node", [CLI, "--version"], {
			env: childEnv({ MAILWOMAN_LICENSE_KEY: "" }),
		})

		expect(stdout.trim()).toMatch(/^\d+\.\d+\.\d+$/)
		expect(stderr).toContain("mailwoman is licensed AGPL-3.0-only")
		expect(stderr).toContain("/license")
	})

	it("prints the notice for a key this build does not trust", async () => {
		const { stderr } = await runFile("node", [CLI, "--version"], {
			env: childEnv({ MAILWOMAN_LICENSE_KEY: "mwl1.eyJ2IjoxfQ.AAAA" }),
		})

		expect(stderr).toContain("mailwoman is licensed AGPL-3.0-only")
	})

	it("treats --version as a root request only, not as one belonging to a subcommand", () => {
		// `mw geocode --version` is geocode's flag to answer.
		// Reading the flag from anywhere in the vector makes the launcher swallow it
		// and print the package version instead of dispatching.
		const output = runCLI("nosuchcommand", "--version")

		expect(output).toContain("Unknown command: nosuchcommand")
	})
})
