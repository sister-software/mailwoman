/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Pure-implementation tests for the CLI weights guard (plan 3). The interactive component is exercised
 *   live under a pty in the plan's Task-4 verification. here we pin the npm invocation, the probe
 *   semantics against a cache layout, and the probe's rejection of metadata-only installs.
 */

import { temporaryDirectory, type TemporaryDirectory } from "@mailwoman/core/fs/temporary"
import { makeDirectories, writeLocalTextFile } from "@mailwoman/core/fs/writers"
import { weightsCachePackageDir } from "@mailwoman/neural/weights"
import { buildWeightsInstallArgs, probeWeights } from "mailwoman/cli-kit/weights-guard"
import { join } from "path-ts"
import { afterEach, beforeEach, describe, expect, test } from "vitest"

// A locale with no weights package, which is the whole point: these cases assert the not-resolvable path.
// Therefore, the locale must be one nothing can resolve.
// It was `de-DE` until 2026-08-02, when campaign R9 shipped `@mailwoman/neural-weights-de-de`
// and silently invalidated the premise — `resolveWeights` started finding the real
// workspace package and every "nothing resolves" assertion inverted.
//
// `pt-BR` is the current choice because Brazil has no carrier package.
// If one ever ships, this breaks the same way, and the fix is the same:
// move to a locale that is still unclaimed.
const LOCALE = "pt-BR"

let cacheRoot: TemporaryDirectory

beforeEach(async () => {
	cacheRoot = await temporaryDirectory("mailwoman-guard-")
})

afterEach(() => cacheRoot[Symbol.asyncDispose]())

describe("buildWeightsInstallArgs", () => {
	test("targets the cache prefix with the locale package at latest", () => {
		expect(buildWeightsInstallArgs("en-US", "/cache/root")).toEqual([
			"install",
			"--prefix",
			"/cache/root",
			"--no-audit",
			"--no-fund",
			"--loglevel",
			"error",
			"@mailwoman/neural-weights-en-us@latest",
		])
	})

	test("honors an explicit spec", () => {
		expect(buildWeightsInstallArgs("fr-FR", "/c", "6.0.0")).toContain("@mailwoman/neural-weights-fr-fr@6.0.0")
	})
})

describe("probeWeights", () => {
	test("ok=false with an actionable detail when nothing resolves", async () => {
		const probe = await probeWeights(LOCALE, cacheRoot.path.toString())

		expect(probe.ok).toBe(false)
		expect(probe.detail).toMatch(/Could not resolve/)
		expect(probe.detail).toContain(weightsCachePackageDir(cacheRoot.path, LOCALE).toString())
	})

	test("ok=true against a binary-carrying cache install", async () => {
		const packageDir = weightsCachePackageDir(cacheRoot.path, LOCALE)

		await makeDirectories(packageDir)
		await writeLocalTextFile("stub", join(packageDir, "model.onnx"))
		await writeLocalTextFile("stub", join(packageDir, "tokenizer.model"))

		expect(await probeWeights(LOCALE, cacheRoot.path.toString())).toEqual({ ok: true })
	})

	test("ok=false against a metadata-only cache install (the code-only-release tarball)", async () => {
		const packageDir = weightsCachePackageDir(cacheRoot.path, LOCALE)

		await makeDirectories(packageDir)
		await writeLocalTextFile("{}", join(packageDir, "model-card.json"))

		expect((await probeWeights(LOCALE, cacheRoot.path.toString())).ok).toBe(false)
	})
})
