/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   #1731 pins. The field is tri-state and the absent states are the interface: a missing sidecar or a place-less entry
 *   must stay ungraded — `false` is a measured contradiction, never a default.
 */

import * as HIERARCHY_LINEAGE from "mailwoman/hierarchy-lineage"
import {
	annotateHierarchyLineage,
	assembleHierarchy,
	type HierarchyLineageEntry,
	type HierarchySourceNode,
} from "mailwoman/hierarchy-lineage"
import { describe, expect, it } from "vitest"

function entry(placeID?: string): HierarchyLineageEntry {
	return placeID ? { placeID } : {}
}

describe("annotateHierarchyLineage (#1731)", () => {
	it("marks the recorded Astoria chimera: the out-of-lineage region grades false, the winner true", () => {
		// The pre-fix shape: locality resolved to Astoria oregon (wof:101715747, chain Clatsop → Oregon → US)
		// while the parsed region resolved independently to New York (wof:85688543).
		const locality = entry("wof:101715747")
		const region = entry("wof:85688543")

		annotateHierarchyLineage([locality, region], {
			placeID: "wof:101715747",
			metadata: { ancestors: [{ id: 102_087_589 }, { id: 85_688_513 }, { id: 85_633_793 }] },
		})

		expect(locality.in_winner_lineage).toBe(true)
		expect(region.in_winner_lineage).toBe(false)
	})

	it("vouches for an entry the winner's chain contains", () => {
		const locality = entry("wof:85803821")
		const region = entry("wof:85688543")

		annotateHierarchyLineage([locality, region], {
			placeID: "wof:85803821",
			metadata: { ancestors: [{ id: 85_688_543 }, { id: 85_633_793 }] },
		})

		expect(locality.in_winner_lineage).toBe(true)
		expect(region.in_winner_lineage).toBe(true)
	})

	it("without a sidecar, grades only the winner's own entry and leaves the rest ABSENT", () => {
		const locality = entry("wof:85803821")
		const region = entry("wof:85688543")

		annotateHierarchyLineage([locality, region], { placeID: "wof:85803821", metadata: {} })

		expect(locality.in_winner_lineage).toBe(true)
		expect(region.in_winner_lineage).toBeUndefined()
	})

	it("leaves everything ABSENT with no anchor or a place-less anchor", () => {
		const a = entry("wof:1")
		const b = entry("wof:2")

		annotateHierarchyLineage([a, b], undefined)
		annotateHierarchyLineage([a, b], { metadata: { ancestors: [{ id: 1 }] } })

		expect(a.in_winner_lineage).toBeUndefined()
		expect(b.in_winner_lineage).toBeUndefined()
	})

	it("anchors at the DEEPEST resolved admin node — a descendant is never flagged by its ancestor's chain", () => {
		const { lineageAnchorNode } = HIERARCHY_LINEAGE
		// Tree order resolves the region first (the 1600-Pennsylvania shape); the locality must anchor.
		const region = { tag: "region", value: "DC", placeID: "wof:85688741" }
		const locality = { tag: "locality", value: "Washington", placeID: "wof:85931779" }

		expect(lineageAnchorNode([region, locality])?.placeID).toBe("wof:85931779")

		// With the locality anchoring, the region grades true through the locality's own chain.
		const entries = [
			{ placeID: "wof:85931779" } as HierarchyLineageEntry,
			{ placeID: "wof:85688741" } as HierarchyLineageEntry,
		]

		annotateHierarchyLineage(entries, {
			placeID: "wof:85931779",
			metadata: { ancestors: [{ id: 85_688_741 }, { id: 85_633_793 }] },
		})

		expect(entries[0]!.in_winner_lineage).toBe(true)
		expect(entries[1]!.in_winner_lineage).toBe(true)
	})

	it("never grades a place-less entry (the street-register locality unshift)", () => {
		const registerLocality = entry()
		const region = entry("wof:85688543")

		annotateHierarchyLineage([registerLocality, region], {
			placeID: "wof:85803821",
			metadata: { ancestors: [{ id: 85_688_543 }] },
		})

		expect(registerLocality.in_winner_lineage).toBeUndefined()
		expect(region.in_winner_lineage).toBe(true)
	})
})

describe("assembleHierarchy — the JP tiers", () => {
	it("lists a resolved prefecture, municipality and district most specific first, municipality above district", () => {
		const nodes: HierarchySourceNode[] = [
			{
				tag: "prefecture",
				value: "宮崎県",
				lat: 31.9,
				lon: 131.4,
				placeID: "wof:85672707",
				metadata: { resolver_name: "Miyazaki" },
			},
			{ tag: "district", value: "下長飯町", lat: 31.7, lon: 131.1, placeID: "wof:1" },
			{
				tag: "municipality",
				value: "都城市",
				lat: 31.73,
				lon: 131.08,
				placeID: "wof:102031529",
				metadata: { resolver_name: "Miyakonojō" },
			},
			{ tag: "house_number", value: "1867-2" },
		]

		const hierarchy = assembleHierarchy(nodes, null, undefined)

		expect(hierarchy.map((h) => [h.tag, h.name])).toEqual([
			["municipality", "Miyakonojō"],
			["district", "下長飯町"],
			["prefecture", "Miyazaki"],
		])
	})
})
