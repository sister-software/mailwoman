/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Browser ONNX inference wrapper. Implements the same `NeuralRunner` interface `@mailwoman/neural`'s
 *   classifier consumes, but backed by `onnxruntime-web` (wasm + optional WebGPU) instead of
 *   `onnxruntime-node`.
 *
 *   Execution provider strategy:
 *
 *   - Try WebGPU first when `useWebGPU !== false`. ~10× faster than wasm on supported devices, but
 *       availability depends on browser (Chromium 113+, Safari Tech Preview) and hardware. The
 *       runtime surfaces a clean error when WebGPU is unavailable, so the constructor falls back to
 *       wasm automatically.
 *   - wasm (simd when available) is the universal fallback. ~2× slower than WebGPU on the same model
 *       but works everywhere onnxruntime-web does — including in Node, which is how the test
 *       harness exercises this file.
 *
 *   Tensor shape + I/O interface matches `ONNXRunner` exactly: the packing and the output decode are
 *   the same functions (`ort-feeds.ts`), so the two hosts cannot drift. only the `ort.Tensor`
 *   construction is host-specific.
 */

import * as ort from "onnxruntime-web/webgpu"

import type { NeuralRunner } from "#classifier/index"
import {
	decodeInferOutput,
	packCharFeed,
	packSoftChannelFeeds,
	packTokenFeed,
	type InferCharsFunction,
	type InferFunction,
	type OutputTensor,
} from "#ort-feeds"

export interface WebONNXRunnerOpts {
	/**
	 * Try the WebGPU execution provider first.
	 *
	 * Defaults to true.
	 * Set false to skip the WebGPU probe — useful in test environments where WebGPU
	 * isn't available and the probe failure adds latency.
	 */
	useWebGPU?: boolean
	/**
	 * Fixed sequence length the model expects.
	 *
	 * Matches `ONNXRunner.DEFAULT_FIXED_SEQ_LEN` (128) by default.
	 * Re-quantized models can override.
	 */
	fixedSeqLen?: number
	/**
	 * Optional override for where onnxruntime-web should load its `.wasm` assets from.
	 *
	 * Defaults to the package's CDN paths. bundlers usually want to point this at a self-hosted copy.
	 *
	 * Example: `setWASMPaths("/static/ort/")` and put the .wasm files at /static/ort/.
	 */
	wasmPathsRoot?: string
}

/**
 * Sequence length the web runtime pads to when the model was exported with a fixed input shape.
 *
 * WebGPU requires static shapes, so a fixed length is the portable default.
 */
export const DEFAULT_FIXED_SEQ_LEN = 128

/**
 * Fetch a URL into bytes, throwing on any non-OK status.
 *
 * Raw `fetch`: this is the browser runtime.
 * `APIClient` carries axios, which has no place in the client bundle,
 * and the platform primitive is what the browser already has.
 */
export async function fetchBytes(url: string, fetchImpl: typeof fetch = fetch): Promise<Uint8Array> {
	const res = await fetchImpl(url)

	if (!res.ok) throw new Error(`fetch ${url} failed: ${res.status} ${res.statusText}`)

	return new Uint8Array(await res.arrayBuffer())
}

/**
 * Apply `wasmPathsRoot` once at module init.
 *
 * Safe to call multiple times.
 */
function configureWASMPaths(root: string | undefined): void {
	if (!root) return
	// onnxruntime-web ships this on `ort.env.wasm`.
	// We assign directly rather than calling `setWASMPaths` so it works across the
	// slightly different shapes the typings have had.
	ort.env.wasm.wasmPaths = root
}

/**
 * The `{data, dims}` view `decodeInferOutput` reads.
 *
 * The float32 dtype is the
 * export interface's rather than a runtime check.
 */
function outputTensor(tensor: ort.Tensor): OutputTensor {
	return { data: tensor.data as Float32Array, dims: tensor.dims }
}

export interface WebONNXRunnerDiagnostics {
	backend: "webgpu" | "wasm"
	modelBytes: number
}

export class WebONNXRunner implements NeuralRunner {
	public readonly fixedSeqLen: number
	public diagnostics: WebONNXRunnerDiagnostics | null = null
	#session: ort.InferenceSession | null = null
	#loadPromise: Promise<ort.InferenceSession> | null = null
	/**
	 * The model source, dropped the moment a session owns it.
	 *
	 * `InferenceSession.create` copies the graph into the runtime's own heap, so holding
	 * this afterwards keeps a second full copy of the model alive for the life of the page —
	 * 38 MB for the shipped int8 bundle, on top of the runtime's.
	 */
	#modelBytes: Uint8Array | null
	/**
	 * Kept because `diagnostics` reports it and the bytes themselves are released.
	 */
	readonly #modelByteLength: number
	private readonly opts: WebONNXRunnerOpts

	private constructor(modelBytes: Uint8Array, opts: WebONNXRunnerOpts) {
		this.#modelBytes = modelBytes
		this.#modelByteLength = modelBytes.byteLength
		this.opts = opts
		this.fixedSeqLen = opts.fixedSeqLen ?? DEFAULT_FIXED_SEQ_LEN
	}

	/**
	 * Construct from already-fetched model bytes.
	 */
	static async fromBytes(modelBytes: Uint8Array, opts: WebONNXRunnerOpts = {}): Promise<WebONNXRunner> {
		configureWASMPaths(opts.wasmPathsRoot)
		const runner = new WebONNXRunner(modelBytes, opts)

		return runner
	}

	/**
	 * Fetch the model from a URL and construct.
	 */
	static async fromURL(modelURL: string, opts: WebONNXRunnerOpts = {}): Promise<WebONNXRunner> {
		return WebONNXRunner.fromBytes(await fetchBytes(modelURL), opts)
	}

	async #ensureSession(): Promise<ort.InferenceSession> {
		if (this.#session) return this.#session

		if (!this.#loadPromise) {
			this.#loadPromise = (async () => {
				const modelBytes = this.#modelBytes

				if (!modelBytes) throw new Error("the ONNX runner has been released")

				const wantWebGPU = this.opts.useWebGPU !== false

				if (wantWebGPU) {
					try {
						const session = await ort.InferenceSession.create(modelBytes, {
							executionProviders: ["webgpu", "wasm"],
							graphOptimizationLevel: "all",
						})

						this.#session = session
						this.diagnostics = { backend: "webgpu", modelBytes: this.#modelByteLength }
						// The session owns the graph now.
						// A retry cannot happen either way — `#loadPromise` caches the rejection —
						// so there is nothing left for these bytes to do.
						this.#modelBytes = null

						return session
					} catch {
						// WebGPU probe failed — fall through to wasm
					}
				}

				const session = await ort.InferenceSession.create(modelBytes, {
					executionProviders: ["wasm"],
					graphOptimizationLevel: "all",
				})

				this.#session = session
				this.diagnostics = { backend: "wasm", modelBytes: this.#modelByteLength }
				this.#modelBytes = null

				return session
			})()
		}

		return this.#loadPromise
	}

	/**
	 * Free the session's native memory.
	 *
	 * An `InferenceSession` holds its weights and arenas in the wasm heap (or on the GPU),
	 * which the JavaScript garbage collector does not own and cannot reclaim — dropping the
	 * last reference to a runner frees the wrapper and leaves the model resident.
	 * `release()` is the only thing that gives it back, and before this it was
	 * called nowhere in the repository.
	 *
	 * That matters because a release bundle is reloaded whenever the version or the
	 * backend force changes, so picking a different model version, toggling "Force wasm",
	 * or entering compare mode each added a model's worth of native memory that never came back.
	 * Safari is the first browser to complain, because it kills a tab on memory pressure rather than swapping.
	 *
	 * Safe to call more than once, and safe to call while a load is still in flight —
	 * the in-flight session is awaited and then released, so an aborted load does
	 * not leak the session it was part-way through building.
	 */
	async release(): Promise<void> {
		this.#modelBytes = null

		const pending = this.#loadPromise

		this.#loadPromise = null
		this.#session = null

		if (!pending) return

		try {
			const session = await pending

			await session.release()
		} catch {
			// A session that failed to build holds nothing to free.
		}
	}

	/**
	 * Names of the inputs the loaded ONNX graph declares.
	 *
	 * `null` until the session has been created (first `infer()` call).
	 * Lets callers (e.g. the web loader) detect anchor/gazetteer-trained models
	 * and warn loudly when the corresponding feature source wasn't provided —
	 * running such a model on the zero-filled fallback is the measured train/inference
	 * mismatch ("the zero-fill trap"), not a quality-neutral degrade.
	 */
	get inputNames(): readonly string[] | null {
		return this.#session?.inputNames ?? null
	}

	/**
	 * Mirror of the node `ONNXRunner.inferChars` — the char-path graph, no soft-feed channels (#2164).
	 */
	inferChars: InferCharsFunction = async (charIDs, attentionMask) => {
		const session = await this.#ensureSession()
		const packed = packCharFeed(charIDs, attentionMask)

		const output = await session.run({
			char_ids: new ort.Tensor("int64", packed.charIDs.data, packed.charIDs.dims),
			attention_mask: new ort.Tensor("int64", packed.attentionMask.data, packed.attentionMask.dims),
		})

		return decodeInferOutput(
			{
				...(output.logits ? { logits: outputTensor(output.logits) } : {}),
				...(output.locale_logits ? { localeLogits: outputTensor(output.locale_logits) } : {}),
			},
			packed.seqLen
		)
	}

	/**
	 * Mirror of the node `ONNXRunner.infer` — see {@link InferFunction}.
	 *
	 * Every soft-feed channel is present-conditional on the graph's declared inputs,
	 * with the zero-fill confidence=0 identity for a declared-but-unsupplied channel,
	 * so the session never throws on a missing required input (`packSoftChannelFeeds`).
	 */
	infer: InferFunction = async (tokenIDs, anchor, gazetteer, country, evidence) => {
		const session = await this.#ensureSession()
		const { inputIDs, attentionMask, seqLen } = packTokenFeed(tokenIDs, this.fixedSeqLen)

		const feeds: Record<string, ort.Tensor> = {
			input_ids: new ort.Tensor("int64", inputIDs.data, inputIDs.dims),
			attention_mask: new ort.Tensor("int64", attentionMask.data, attentionMask.dims),
		}

		const packed = packSoftChannelFeeds(
			session.inputNames,
			this.fixedSeqLen,
			seqLen,
			anchor,
			gazetteer,
			country,
			evidence
		)

		for (const [name, feed] of packed) {
			feeds[name] = new ort.Tensor("float32", feed.data, feed.dims)
		}

		const output = await session.run(feeds)
		const logits = output["logits"]
		const localeLogits = output["locale_logits"]
		const spanScores = output["span_scores"]

		return decodeInferOutput(
			{
				...(logits ? { logits: outputTensor(logits) } : {}),
				...(localeLogits ? { localeLogits: outputTensor(localeLogits) } : {}),
				...(spanScores ? { spanScores: outputTensor(spanScores) } : {}),
			},
			seqLen
		)
	}
}
