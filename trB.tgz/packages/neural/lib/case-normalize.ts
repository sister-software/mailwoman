/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   #690: input case-normalization for the neural parser. all-caps registry/compliance data (`214
 *   jones RD, elkhart, TX 75839`) is partly out-of-domain for a model trained on mixed-case text —
 *   it drops/mis-bounds tokens (`palestine` → locality `alestine`). Title-casing an all-caps input
 *   before the model recovers it (measured: TX hhsc locality 90.1% → 99.7%,
 *   `docs/articles/evals/resolver-geo/2026-06-17-geocoder-vs-provided-coords.md`).
 *
 *   Detection is deliberately strict — only a fully-shouting input qualifies — so mixed-case input is
 *   never touched (the caller's byte-stable path). Distinct from the identifier-casing all-caps
 *   idiom in `core/strings/case.ts` (`smartSnakeCase`/`smartCamelCase`): those skip _case
 *   conversion_ when a name is already uppercase. this _applies_ a title-case to address text for
 *   the model.
 */

/**
 * A Latin-script letter, in either case and with any diacritic.
 *
 * Case conversion is applied to Latin script only: other scripts are either uncased or carry
 * locale-sensitive rules (Turkish dotted and dotless I, Greek final sigma) that the length guard
 * in {@link titleCaseInput} would refuse run by run anyway, so they are left alone as a whole.
 */
const LATIN_LETTER = /\p{Script=Latin}/u
const LATIN_RUN = /\p{Script=Latin}+/gu
const UPPER = /\p{Lu}/u
const LOWER = /\p{Ll}/u
const ANY_LETTER = /\p{L}/u
/**
 * Highest ascii code point. {@link isAllLowerInput} still binds to pure ascii: a lowercase
 * input with diacritics parses as typed (measured on the case-folding conformance suite),
 * so the #829 restore has no accented population to serve.
 */
const ASCII_MAX = 127
/**
 * Code point of `A`.
 */
const ASCII_UPPER_A = 65
/**
 * Code point of `Z`.
 */
const ASCII_UPPER_Z = 90
/**
 * Code point of `a`.
 */
const ASCII_LOWER_A = 97
/**
 * Code point of `z`.
 */
const ASCII_LOWER_Z = 122
/**
 * Cased letters an input needs before it counts as uniformly-cased rather than
 * shouting punctuation or a stray token.
 *
 * The floor exists so a digit- or punctuation-only input is not treated as a whole shouting address.
 */
const MIN_CASED_LETTERS = 3

/**
 * True when `text` is latin-script all-caps: every letter in it is Latin script,
 * it has at least three uppercase letters, and no lowercase letter anywhere.
 *
 * Diacritics are admitted (`RUE DU faubourg saint-honorÉ` qualifies): an accented uppercase
 * input reaches the model as single-character pieces otherwise, which is the #1938 defect.
 * A letter from another script disqualifies the whole input, because its case
 * rules are locale-sensitive and can change length.
 *
 * The 3-letter floor avoids treating a digit/punctuation-only or tiny-token
 * input as a whole shouting address.
 */
export function isAllCapsInput(text: string): boolean {
	let upper = 0

	for (const ch of text) {
		if (!ANY_LETTER.test(ch)) continue

		if (!LATIN_LETTER.test(ch)) return false

		if (LOWER.test(ch)) return false

		if (UPPER.test(ch)) {
			upper++
		}
	}

	return upper >= MIN_CASED_LETTERS
}

/**
 * Title-case each Latin alphabetic run ≥3 letters (`palestine` → `Palestine`, `honorÉ` → `Honoré`), preserving runs of
 * ≤2 letters. The preserve is the #690→#252 fix (the Gauntlet's casing-invariance catch): an all-caps input title-cased
 * blindly turns a 2-letter region code into a non-region form the model mis-parses — `NY`→`Ny`, `DC`→`Dc` land as a
 * _locality_ rather than a region, so `350 5TH AVE, new york, NY` lost its state. Every ≤2-letter all-caps token in a
 * US address is an abbreviation the model already reads correctly all-caps (state codes NY/DC, directionals N/NW/SE,
 * suffixes ST/RD), so keeping them shouting restores the model's correct input — `1600 pennsylvania AVE NW, washington
 * DC` now title-cases to exactly the mixed-case form that parses `region:DC`.
 *
 * Length-preserving by construction: a run whose lowercase form is a different length
 * (`İ` lowercases to two code units) is kept as typed, so token offsets never move.
 */
export function titleCaseInput(text: string): string {
	return text.replaceAll(LATIN_RUN, (w) => {
		if (w.length <= 2) return w

		const rest = w.slice(1).toLowerCase()

		return rest.length === w.length - 1 ? w[0]!.toUpperCase() + rest : w
	})
}

/**
 * True when `text` is pure-ascii all-lowercase: it has cased ascii letters and zero uppercase, and no non-ascii
 * characters. The mirror of {@link isAllCapsInput} for the #829 class — fully-lowercase input (`1600 pennsylvania ave
 * nw, washington dc`) is as out-of-domain as all-caps for a mixed-case-trained model: it fragments the street and drops
 * the state code (the Gauntlet metamorphic INV[lower] failures). Same pure-ascii + 3-letter guards as the all-caps
 * detector, for the same reasons (accented/non-Latin casing is locale-sensitive + length-changing → left untouched).
 */
export function isAllLowerInput(text: string): boolean {
	let lower = 0

	for (let i = 0; i < text.length; i++) {
		const c = text.charCodeAt(i)

		if (c > ASCII_MAX) return false

		// any non-ascii (accented/non-Latin) → leave it alone
		if (c >= ASCII_UPPER_A && c <= ASCII_UPPER_Z) return false

		// any [A-Z] → mixed case, leave it alone
		if (c >= ASCII_LOWER_A && c <= ASCII_LOWER_Z) {
			lower++
		}
	}

	return lower >= MIN_CASED_LETTERS
}

/**
 * Restore a fully-lowercase input to the canonical mixed-case the model was trained on: title-case each ascii run ≥3
 * letters (`pennsylvania` → `Pennsylvania`) and uppercase each run ≤2 letters (`dc` → `DC`, `nw` → `NW`, `lg` → `LG`).
 * The ≤2 handling is where this differs from {@link titleCaseInput}: on all-caps input those tokens are already shouting
 * so #690 preserves them. on all-lowercase input they arrive as `dc`/`ny` and must be uppercased to reach the same form
 * — every ≤2-letter token in an address is an abbreviation the model reads best uppercase (state codes NY/DC,
 * directionals N/NW/SE, suffixes ST/RD, the NL postcode suffix LG). Length-preserving — token offsets unchanged. Net:
 * `1600 pennsylvania ave nw, washington dc` and `1600 pennsylvania AVE NW, washington DC` both canonicalize to `1600
 * Pennsylvania Ave NW, Washington DC`, the exact mixed-case form that parses `region:DC`.
 */
export function restoreLowerInput(text: string): string {
	return text.replaceAll(/[A-Za-z]+/g, (w) =>
		w.length <= 2 ? w.toUpperCase() : w[0]!.toUpperCase() + w.slice(1).toLowerCase()
	)
}

/**
 * Normalize a shouting or whispering ascii input to canonical mixed-case before the
 * model. mixed-case and accented/non-Latin input pass through byte-identically.
 *
 * The parser's #690 (all-caps) + #829 (all-lowercase) hook.
 */
export function normalizeInputCase(text: string): string {
	if (isAllCapsInput(text)) return titleCaseInput(text)

	if (isAllLowerInput(text)) return restoreLowerInput(text)

	return text
}
