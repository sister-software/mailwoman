/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Postcode regex repair pass — v0.7 task #35 ("postcode regex pre-pass").
 *
 *   The 2026-05-29 postcode diagnostic showed the neural model fragments alphanumeric postcodes at
 *   the SentencePiece layer (GB/CA/NL at 0%, US 80.5%, FR 70.1%). Three failure modes were visible
 *   in the data:
 *
 *   1. Total miss — "London SW1A 1AA" → (no postcode label)
 *   2. Truncation — "M5V 2T6" → "2T6"; "B12 8QX" → "B12"
 *   3. Char-drift — "75008" → "5008"; "62701" → "2701" (and smear: "1200-030 Lisboa" → "200-030 Lis")
 *
 *   This pass runs after the model's per-token BIO labels are decoded but before `buildAddressTree`.
 *   It detects postcode-shaped substrings with per-country regexes and repairs the label sequence
 *   so the postcode span matches the detected shape. The model is untouched — this is a
 *   deterministic decoder-side correction, the "lowest risk" change in the v0.7 plan (vs. #36's soft
 *   FST shallow-fusion or #41's char-level encoder).
 *
 *   precision guards (so we never regress the countries already passing):
 *
 *   - Alphanumeric shapes (GB/CA/NL/DE-prefixed) are high-confidence "this is a postcode" patterns →
 *       eligible to ADD a span where the model emitted none, but only over non-structural labels
 *       (never over house_number/street/etc.).
 *   - Numeric shapes (\d{5}, ZIP+4, BR, JP, PT, PL) are ambiguous (a bare 5-digit could be a house number)
 *       → snap-only: they expand/clip an existing postcode span, never create one from scratch.
 *   - A designated shape carries the writing system's own postal marker: `〒506-0025` is a postcode by Japan Post's
 *       convention, and no house number is ever written behind 〒. It may overwrite any label, structural ones
 *       included — the one override the discipline below allows, because the mark rather than the digit shape, decides. The
 *       span excludes the mark: the resolver keys `506-0025`, and the character model was trained to leave 〒 outside.
 *   - Smear cleanup is local: only postcode tokens immediately flanking a snapped span are cleared. We
 *       never globally clear unmatched postcode tokens — that would regress shapes we don't
 *       pattern-match (AU 4-digit, IN 6-digit, …).
 *
 *   A missing shape is not neutral for a hyphenated postcode. The local smear cleanup is local to a
 *   match, and an unlisted compound shape still matches at its numeric head: `NUM5` claims the five
 *   digits of an unlisted `nnnnn-NNN`, snaps the span down to them, and clips the suffix the model
 *   correctly labeled. That is how BR CEPs were truncated for the pass's whole life (#35, diagnosed
 *   2026-08-10) while the unhyphenated shapes above degraded gracefully. Before concluding a hyphenated
 *   postcode is a model failure, re-parse it with `postcodeRepair: false`.
 */

import { POSTCODE_SHAPES } from "@mailwoman/codex/postcode-shapes"
import type { DecoderToken } from "@mailwoman/core/decoder"

import {
	collectMatchesFor,
	createLabelSetter,
	isAddSafe,
	isTagLabel,
	type RepairResult,
	type SpanMatch,
	tagOf,
	tokenIndicesOverlapping,
} from "#span/repair"

export type { RepairResult } from "#span/repair"

/**
 * A detected postcode-shaped substring with its char range and confidence class.
 */
export interface PostcodeMatch extends SpanMatch {
	/**
	 * "alnum" shapes may ADD over container labels.
	 *
	 * "numeric" shapes may only snap an existing span. a "designated" shape
	 * (the digits behind a postal marker) may overwrite any label.
	 */
	kind: "alnum" | "numeric" | "designated"
}

/**
 * Per-country postcode shape patterns, ordered most-specific → least.
 *
 * The table itself is data, in `@mailwoman/codex/postcode-shapes`, because two runtimes
 * read it: this module, and the Python trainer's `features/postcode_shapes.py`,
 * which paints the train-side anchor on the spans this finds.
 * Held as two typed copies they drifted twice, each time leaving the trainer
 * painting one fewer shape than inference.
 */
export const POSTCODE_PATTERNS: ReadonlyArray<{
	label: string
	kind: "alnum" | "numeric" | "designated"
	re: RegExp
}> = POSTCODE_SHAPES

/**
 * Labels a postcode span is allowed to overwrite when the model emitted no postcode at all (ADD path).
 *
 * These are the geographic-container tags postcodes get confused with per the
 * diagnostic ("often labeled as locality or O").
 * Structural tags (house_number, street*, unit, po_box, venue, …) are intentionally absent
 * so we never clobber a confidently-labeled street/number with a false postcode.
 */
const ADD_OVER_TAGS = new Set<string>(["locality", "dependent_locality", "region", "subregion", "country"])

const POSTCODE_B = "B-postcode" as DecoderToken["label"]
const POSTCODE_I = "I-postcode" as DecoderToken["label"]
const LOCALITY_B = "B-locality" as DecoderToken["label"]
const LOCALITY_I = "I-locality" as DecoderToken["label"]
const OUTSIDE = "O" as DecoderToken["label"]

/**
 * Collect non-overlapping postcode matches, preferring more-specific (earlier) patterns.
 */
export function collectMatches(text: string): PostcodeMatch[] {
	return collectMatchesFor(POSTCODE_PATTERNS, text).map(({ start, end, priority, pattern }) => ({
		start,
		end,
		kind: pattern.kind,
		priority,
	}))
}

/**
 * Repair postcode label spans in a decoded token sequence using per-country regexes.
 *
 * Returns a new token array (inputs are not mutated) plus a change count.
 */
export function repairPostcodeLabels(text: string, input: readonly DecoderToken[]): RepairResult {
	const matches = collectMatches(text)
	const tokens = input.map((t) => ({ ...t }))

	if (!matches.length) return { tokens, changed: 0 }

	const { setLabel, changeCount } = createLabelSetter(tokens)

	for (const m of matches) {
		const overlap = tokenIndicesOverlapping(tokens, m.start, m.end)

		if (!overlap.length) continue

		const hasPostcode = overlap.some((i) => isTagLabel(tokens[i]!.label, "postcode"))

		if (!hasPostcode) {
			// ADD path — a designated shape over any label. an alphanumeric shape only
			// over safe labels. a numeric shape never.
			if (m.kind === "numeric") continue

			if (m.kind === "alnum" && !isAddSafe(tokens, overlap, ADD_OVER_TAGS)) continue
		}

		// snap/ADD: relabel the matched run as a single postcode span.
		overlap.forEach((i, k) => setLabel(i, k === 0 ? POSTCODE_B : POSTCODE_I))

		// Leading smear clip: postcode tokens immediately before the snapped run are noise
		// (e.g. a house-number digit the model over-labeled) — clear to O as before.
		for (let j = overlap[0]! - 1; j >= 0 && isTagLabel(tokens[j]!.label, "postcode"); j--) {
			setLabel(j, OUTSIDE)
		}

		// Trailing smear: the model over-extended the postcode to the right.
		// In postcode-before-city locales (DE/FR/ES/IT, "08523 Plauen") this swallows the
		// leading characters of the city, which the historical clip-to-O then discarded
		// ("08523 Pl|auen Vogtl" → postcode "08523" + O + locality "auen Vogtl", dropping the "Pl").
		// When the smear connects to a following locality run, hand those characters
		// back to the city — reassign them to locality and demote the city's leading B
		// so the prefix + city form one span ("Pl"+"auen"+"Vogtl" → "Plauen Vogtl").
		// A standalone neighbour with no following locality (a country, "Paris 75008 France")
		// keeps the historical clip-to-O.
		// This is the decoder-side repair for the cross-tag postcode→city absorption
		// diagnosed in the PR3 Pilot A postmortem (+36pp DE exact-locality, no-op on US,
		// where the postcode sits at the end with nothing to trim).
		const trailing: number[] = []

		for (let j = overlap.at(-1)! + 1; j < tokens.length && isTagLabel(tokens[j]!.label, "postcode"); j++) {
			trailing.push(j)
		}

		if (trailing.length) {
			const after = trailing.at(-1)! + 1
			const connectsToCity = after < tokens.length && tagOf(tokens[after]!.label) === "locality"

			if (connectsToCity) {
				trailing.forEach((j, k) => setLabel(j, k === 0 ? LOCALITY_B : LOCALITY_I))

				if (tokens[after]!.label === "B-locality") {
					setLabel(after, LOCALITY_I)
				}
			} else {
				for (const j of trailing) {
					setLabel(j, OUTSIDE)
				}
			}
		}
	}

	return { tokens, changed: changeCount() }
}

// repairLeadingHouseNumber (#723) was removed 2026-06-24.
// It relabelled a leading 5-digit postcode → house_number under conventions=auto (US) —
// an override that contradicted the model's own label, which the project's repair
// discipline forbids (a repair may add spans on O-tokens or snap boundaries,
// never re-classify a token from one entity to another).
// Net on the US golden set it was −302 postcode / +16 house_number. an anchor-ablation
// probe showed the model is 100% correct on the target rows once the binary postcode anchor
// (which fires on a leading number that is a valid ZIP elsewhere) is removed.
// The disambiguation is being absorbed model-side: a region-congruence anchor
// upgrade + augmented postcode-leading extracts.
// See the 2026-06-24 postmortem + DeepSeek consult 019ef789.
