/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Browser-safe aggregate of this package. It is the main entry minus `./weights.ts` and
 *   `./scorer.ts` — the only two modules left that statically reach `node:fs`, and so the only two a
 *   browser graph cannot contain. Everything else here is reachable from a bundle by construction:
 *   `neural/onnx-runner` resolves to a throwing browser counterpart under the `browser` condition,
 *   and oxlint holds the rest to a no-`node:*` rule.
 *
 *   The soft-feature channels below are not optional decoration. A gazetteer-, country-, or
 *   pair-trained model requires its channel fed at inference. a zero-filled clue is a train/inference
 *   mismatch rather than a neutral default (see CONTRIBUTING_MODEL_WORK.mdx, "zero-fill trap"). A browser
 *   caller fetches each lexicon alongside the model and feeds it.
 */

export * from "#anchor-inference"
export * from "#classifier/index"
export * from "#country-inference"
export * from "#gazetteer-inference"
export * from "#labels"
// Resolution rather than curation: the `browser` condition on this subpath serves a counterpart
// whose every entry point throws, so the value exports below are safe to name from a bundle.
export * from "#onnx-runner"
export * from "#pair/index/resolver"
export * from "#postcode/binary-resolver"
export * from "#soft-features"
export * from "#tokenizer"
// `./placetype-pair-prior.ts` is reached only through the classifier's decode,
// so callers need the option shape and not the module.
// A `type` re-export is fully erased.
export type { PlacetypePairPriorOpts, PlacetypePairPriorResult } from "#placetype/pair-prior"
