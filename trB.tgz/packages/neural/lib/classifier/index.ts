/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   `NeuralAddressClassifier` ties together the tokenizer, the ONNX inference runner, and the
 *   `@mailwoman/core` decoder. Single user-facing entrypoint: `parse(text)` returns an
 *   `AddressTree` ready for projection into JSON / tuple / XML.
 *
 *   Convenience wrappers `parseJSON` / `parseTuples` / `parseXML` project the tree on the way out.
 */

import { conventionsForSystem, type SystemCode } from "@mailwoman/codex"
import type { ComponentTag } from "@mailwoman/codex/component"
import {
	buildAddressTree,
	decodeAsJSON,
	decodeAsTuples,
	decodeAsXML,
	type AddressTree,
	type DecoderToken,
	type SerializeJSONOpts,
	type SerializeTuplesOpts,
	type UnknownSpan,
} from "@mailwoman/core/decoder"
import { proposeSpans, type ProposedSpan, WORD_CONSISTENCY_SHIP_DEFAULT } from "@mailwoman/core/pipeline"
import type { PathBuilderLike } from "path-ts"

import { confidentLocaleCountry, LOCALE_COUNTRIES, resolveSystemVerdict } from "#address-system"
import { normalizeInputCase } from "#case-normalize"
import { encodeCharUnits } from "#char-encoder"
import type {
	NeuralAddressClassifierConfig,
	ParseOpts,
	ParseWithLogitsResult,
	SpanProposerConfig,
} from "#classifier/options"
import type { ScriptRoutedClassifier } from "#classifier/script-router"
import { buildFSTEmissionPriors } from "#fst-prior"
import { STAGE2_BIO_LABELS } from "#labels"
import type { InferFunction, InferCharsFunction } from "#ort-feeds"
import type { PlacetypeCensusLike } from "#placetype/census"
import { buildPlacetypePairPriors, type PlacetypePairProbeTrace } from "#placetype/pair-prior"
import { repairPostcodeLabels } from "#postcode/repair"
import { addEmissionMatrix, buildEmissionPriors } from "#query-shape-prior"
import { repairJPMunicipalityLabels, repairKRSubregionLabels } from "#register-boundary-repair"
import type { SemiCRFTransitions } from "#semi-markov-decode"
import { buildSoftFeatures, type SoftFeatureChannel, type SoftFeatures } from "#soft-features"
import { bridgePunctuationGaps } from "#span/bridge"
import { buildSpanProposalPriors } from "#span/proposal-prior"
import { buildCodexSpanLexicon } from "#span/proposer-lexicon"
import { buildStreetMorphologyEmissionPriors } from "#street-morphology-prior"
import type { MailwomanTokenizer, TokenizedPiece } from "#tokenizer"
import { TRACE_PRIOR_KINDS } from "#trace"
import type { NeuralParseTrace, TracePrior, TraceRepair, TraceRepairPass } from "#trace"
import { repairUnitLabels } from "#unit-repair"
import {
	argmaxWithConfidence,
	buildBIOEndMask,
	buildBIOStartMask,
	buildBIOTransitionMask,
	softmax,
	viterbi,
} from "#viterbi"
import { enforceWordConsistency } from "#word-consistency"

export type {
	NeuralAddressClassifierConfig,
	ParseOpts,
	ParseWithLogitsResult,
	SpanProposerConfig,
} from "#classifier/options"

export {
	type RoutableClassifier,
	carriesFamilySegment,
	routeFamilyForText,
	routeFamilyWithLeadingRun,
	routeFamilyWithPostcode,
	ScriptRoutedClassifier,
	scriptFamilyForText,
	type ScriptRoutedClassifierOpts,
} from "#classifier/script-router"

export {
	carriesFamilySegmentFor,
	FAMILIES,
	FAMILY_SCRIPTS,
	FAMILY_VOCABULARY_ARTIFACT,
	familyByID,
	FamilyEncoder,
	familyFallbackFor,
	familyForLocale,
	familyForScript,
	leadsWithFamilyScriptFor,
	RouteSource,
	type RoutingDecision,
	type WeightsFamily,
} from "#weights/families"

/**
 * Structural type the classifier needs from a runner.
 *
 * Lets callers swap the Node-side `ONNXRunner` for a browser-side runner
 * (e.g. `@mailwoman/neural/web-onnx-runner`'s `WebONNXRunner`) without inheritance —
 * the classifier only ever calls `infer(ids)`.
 * The signature is {@link InferFunction}, the one interface both runners implement.
 */
export interface NeuralRunner {
	infer: InferFunction
	/**
	 * The char-path graph's entry (#2164).
	 *
	 * Absent on a runner built for a SentencePiece graph. a classifier configured with a
	 * `charEncoder` refuses a runner without it at construction rather than at the first parse.
	 */
	inferChars?: InferCharsFunction
}

/**
 * The parse-facing tree, with the locale head's confident verdict riding along when there is one
 * (#1684) — shared by `parse` and `parseWithLogits` so the two tree paths cannot drift on the stamp.
 */
function treeWithLocaleCountry(
	text: string,
	tokens: DecoderToken[],
	calibrate: { calibrate: NonNullable<ParseOpts["calibrate"]> } | undefined,
	localeCountry: { country: string; confidence: number } | null
): AddressTree {
	return Object.assign(buildAddressTree(text, tokens, calibrate), localeCountry ? { localeCountry } : {})
}

export class NeuralAddressClassifier {
	private readonly labels: readonly string[]
	private readonly decodeMode: "viterbi" | "argmax"
	private readonly transitions: number[][]
	/**
	 * Lazily-built default Stage 2.7 config (codex lexicon, frozen scales) — see `cfg.spanProposer`.
	 */
	#defaultProposerCfg: SpanProposerConfig | undefined
	private readonly startTransitions: number[]
	private readonly endTransitions: number[]
	private readonly cfg: NeuralAddressClassifierConfig

	/**
	 * The config this classifier was built from, for diagnostics.
	 *
	 * Read-only and deliberately narrow in intent: a channel-coverage report needs to see
	 * which lexicons and indexes were actually wired, and the alternative it
	 * replaces is a script asserting its way into `#cfg` — which then keeps working
	 * after the field is renamed, and reports every channel as absent.
	 */
	get config(): Readonly<NeuralAddressClassifierConfig> {
		return this.cfg
	}

	/**
	 * Which encoder feeds the graph.
	 *
	 * A caller preparing the input reads it: the character path wants the postal mark 〒 kept,
	 * the SentencePiece path wants it stripped (`NormalizeOpts.postalMark`).
	 */
	get encoder(): "sentencepiece" | "char" {
		return this.cfg.charEncoder ? "char" : "sentencepiece"
	}

	constructor(cfg: NeuralAddressClassifierConfig) {
		if (!cfg.tokenizer && !cfg.charEncoder) {
			throw new Error("NeuralAddressClassifier needs a tokenizer (SentencePiece graph) or a charEncoder (char graph)")
		}

		if (cfg.charEncoder && !cfg.runner.inferChars) {
			throw new Error("NeuralAddressClassifier: a charEncoder needs a runner with inferChars (a char_ids graph)")
		}

		this.cfg = cfg
		this.labels = cfg.labels ?? STAGE2_BIO_LABELS
		this.decodeMode = cfg.decode ?? "viterbi"
		const structural = buildBIOTransitionMask(this.labels)

		this.transitions = cfg.transitions ? addMatrices(structural, cfg.transitions) : structural
		this.startTransitions = cfg.startTransitions ?? buildBIOStartMask(this.labels)
		this.endTransitions = cfg.endTransitions ?? buildBIOEndMask(this.labels)
	}

	/**
	 * The parsed semi-Markov segment-transition grammar (`semi-crf-transitions.json`),
	 * when the loaded bundle shipped it.
	 *
	 * Consumed by the #727 phase-4c k-best name-evidence rerank; `undefined` on a pre-v3 (span-less) bundle.
	 */
	get spanGrammar(): SemiCRFTransitions | undefined {
		return this.cfg.semiCRFGrammar
	}

	/**
	 * Path to the per-locale FST gazetteer binary (`fst-<locale>.bin`) when the resolved weights package shipped one,
	 * else `undefined`. The runtime pipeline deserializes + auto-wires it as the default `opts.fst` (opt out with `fst:
	 * false` at pipeline construction); direct `classifier.parse` callers can do the same or pass their own.
	 */
	get fstPath(): PathBuilderLike | undefined {
		return this.cfg.fstPath
	}

	/**
	 * Path to the locale-general street-morphology FST (`fst-street-morphology.bin`)
	 * when the resolved weights package (or its base) shipped one, else `undefined`.
	 *
	 * The runtime pipeline's street-context check (#1315) deserializes it through the shared
	 * loader ladder instead of rebuilding from the libpostal dictionaries per process.
	 */
	get streetMorphologyPath(): string | undefined {
		return this.cfg.streetMorphologyPath
	}

	/**
	 * The `model.onnx` this instance loaded, and which rung of the resolution ladder produced it.
	 *
	 * `undefined` on an instance built through the plain constructor rather than
	 * {@link loadFromWeights} — there was no resolution, so there is nothing to report,
	 * which is absence and not an unknown model.
	 */
	get resolvedWeights(): { modelPath: string; source: string } | undefined {
		return this.cfg.modelPath && this.cfg.weightsSource
			? { modelPath: this.cfg.modelPath, source: this.cfg.weightsSource }
			: undefined
	}

	/**
	 * The default-on Stage 2.7 config: codex lexicon (us/au/nz), frozen measured
	 * scales (the prior builder's own defaults).
	 *
	 * Built once per instance, only when a parse actually needs it.
	 */
	private defaultProposer(): SpanProposerConfig {
		this.#defaultProposerCfg ??= { lexicon: buildCodexSpanLexicon() }

		return this.#defaultProposerCfg
	}

	/**
	 * One-call factory — see `classifier-loader.ts`, where the whole resolution lives.
	 *
	 * **Node-only.** `#classifier/loader` carries a `browser` condition that resolves
	 * to a refusing module, so a browser bundle that follows this import stays free of
	 * `onnxruntime-node` and the fs-reading weights resolver, and calling it there throws.
	 * The `webpackIgnore` comment keeps webpack's SSR bundle, which resolves the
	 * `node` condition, from following the Node half.
	 *
	 * Browser callers use `loadNeuralClassifierFromURLs`.
	 */
	static async loadFromWeights(
		...args: Parameters<typeof import("#classifier/loader").loadClassifierFromWeights>
	): Promise<NeuralAddressClassifier> {
		const { loadClassifierFromWeights } = await import(/* webpackIgnore: true */ "#classifier/loader")

		return loadClassifierFromWeights(...args)
	}

	/**
	 * {@link loadFromWeights} behind a {@link ScriptRoutedClassifier}: the caller's locale is the primary, and an input
	 * whose script names another weights family runs on that family's classifier, loaded on first use.
	 *
	 * The served entry points (`mailwoman geocode`, the drop-in servers, the batch worker) load through
	 * this one, so a bare kanji or Hangul line reaches the character-path model without a `--locale`.
	 * Node-only, as {@link loadFromWeights} is.
	 */
	static async loadRoutedFromWeights(
		...args: Parameters<typeof import("#classifier/loader").loadScriptRoutedClassifier>
	): Promise<ScriptRoutedClassifier<NeuralAddressClassifier>> {
		const { loadScriptRoutedClassifier } = await import(/* webpackIgnore: true */ "#classifier/loader")

		return loadScriptRoutedClassifier(...args)
	}
	/**
	 * Tokenize → infer → Viterbi (or argmax) → decoder tree.
	 */
	async parse(text: string, opts?: ParseOpts): Promise<AddressTree> {
		if (!text.length) return { raw: text, roots: [] }
		// #690: title-case all-caps ascii input so the mixed-case-trained model doesn't go OOD.
		// Detection-restricted (mixed-case + non-ascii untouched).
		// Default-on (#895 settled drift D2 — the geocode path had run it since #713
		// while the pipeline factory + raw classifier defaulted off); `false` restores
		// the raw-case parse. ascii title-case is char-for-char length-preserving,
		// so token offsets are unaffected. the tree is built from the normalized text
		// (values come out title-cased — the shouting is gone, the resolver name-matches case-insensitively).
		const modelText = opts?.normalizeCase !== false ? normalizeInputCase(text) : text
		const { tokens, localeCountry } = await this.#decode(modelText, opts)

		return treeWithLocaleCountry(
			modelText,
			tokens,
			opts?.calibrate ? { calibrate: opts.calibrate } : undefined,
			localeCountry
		)
	}

	/**
	 * Like `parse`, but also returns the raw per-token logits and piece offsets needed
	 * for per-span logit aggregation (Option C joint-reconcile integration).
	 *
	 * Shares the entire decode path with `parse` (one `#decode`, #481) — repair passes included, because
	 * reconcile must consume the same tokens the argmax path serves users, under the same repair opts.
	 * `logits` stay RAW (pre-prior, pre-repair) — they are the model's emissions
	 * rather than the decode's opinions.
	 */
	async parseWithLogits(text: string, opts?: ParseOpts): Promise<ParseWithLogitsResult> {
		if (!text.length) {
			return { tree: { raw: text, roots: [] }, logits: [], pieces: [] }
		}

		const { tokens, logits, pieces, localeCountry } = await this.#decode(text, opts)

		return {
			tree: treeWithLocaleCountry(
				text,
				tokens,
				opts?.calibrate ? { calibrate: opts.calibrate } : undefined,
				localeCountry
			),
			logits,
			pieces: pieces.map((p) => ({ start: p.start, end: p.end })),
		}
	}

	/**
	 * Like `parse`, but returns the full decode-path trace instead of a tree: pieces,
	 * soft-feature channels as fed, raw logits, locale head, prior participation,
	 * post-prior emissions, viterbi path, repair diffs, and the final tokens.
	 *
	 * Shares the entire decode path with `parse` (one `#decode`, #481) and mirrors `parse`'s
	 * case normalization, so `buildAddressTree(trace.text, trace.tokens)` reproduces
	 * `parse(text)`'s tree exactly — modulo `opts.calibrate`, which `parse` forwards into
	 * the tree build to recalibrate node confidences and which the trace does not carry
	 * (tokens/labels/spans still match. re-pass the calibrator to the rebuild if calibrated confidences matter).
	 * Serializable by construction — see `./trace.js` for the schema and the spec reference.
	 */
	async traceParse(text: string, opts?: ParseOpts): Promise<NeuralParseTrace> {
		const labels = [...this.labels] as string[]

		if (!text.length) {
			// Mirror #decode's interface on the degenerate input: systemSource still reflects
			// the resolved conventions mode (opts over config), and every prior kind gets its
			// participation record (applied: false — nothing can fire on zero pieces).
			return {
				text,
				caseNormalized: false,
				pieces: [],
				logits: [],
				detectedSystem: null,
				systemSource: resolveSystemVerdict(
					opts?.addressSystemConventions ?? this.cfg.addressSystemConventions,
					undefined
				).systemSource,
				priors: TRACE_PRIOR_KINDS.map((kind) => ({ kind, applied: false })),
				emissions: [],
				labels,
				path: [],
				decode: this.decodeMode,
				repairs: [],
				tokens: [],
			}
		}

		const modelText = opts?.normalizeCase !== false ? normalizeInputCase(text) : text
		const { tokens, logits, pieces, trace } = await this.#decode(modelText, opts, true)

		if (!trace) throw new Error("traceParse: #decode returned no trace despite trace=true (invariant)")

		return {
			text: modelText,
			caseNormalized: modelText !== text,
			pieces: pieces.map((p) => ({ piece: p.piece, id: p.id, start: p.start, end: p.end })),
			...(trace.anchor ? { anchor: trace.anchor } : {}),
			...(trace.gazetteer ? { gazetteer: trace.gazetteer } : {}),
			...(trace.country ? { country: trace.country } : {}),
			logits,
			// The axis rides with the values (self-describing — consumers must not hardcode the order).
			...(trace.localeLogits ? { localeLogits: trace.localeLogits, localeCountries: [...LOCALE_COUNTRIES] } : {}),
			...(trace.spanScores ? { spanScores: trace.spanScores } : {}),
			detectedSystem: trace.detectedSystem,
			systemSource: trace.systemSource,
			priors: trace.priors,
			emissions: trace.emissions,
			labels,
			path: trace.path,
			decode: this.decodeMode,
			repairs: trace.repairs,
			tokens: tokens.map((t) => ({ ...t })),
		}
	}

	/**
	 * The decode path (#481): tokenize → anchor/gazetteer features → infer →
	 * priors → CRF/argmax → tokens → repairs.
	 *
	 * Both `parse` and `parseWithLogits` consume this — never fork it. the 2026-06 audit
	 * found three drift surfaces across duplicated copies of this path.
	 */
	// Deliberately one function, long on purpose — every caller funnels through here so there is nowhere
	// for a second copy to drift.
	// oxlint-disable-next-line complexity -- 104, and splitting it is what drifted last time
	async #decode(
		text: string,
		opts?: ParseOpts,
		trace = false
	): Promise<{
		tokens: DecoderToken[]
		logits: number[][]
		pieces: ReturnType<MailwomanTokenizer["encode"]>["pieces"]
		/**
		 * The locale head's confident country verdict, or null — computed on every
		 * parse (the #1684 scope check reads it).
		 */
		localeCountry: { country: string; confidence: number } | null
		/**
		 * Present iff `trace` — the retained intermediates `traceParse` assembles.
		 */
		trace?: {
			anchor?: SoftFeatureChannel
			gazetteer?: SoftFeatureChannel
			country?: SoftFeatureChannel
			localeLogits?: number[]
			spanScores?: number[][][]
			detectedSystem: SystemCode | null
			systemSource: "off" | "auto" | "pinned"
			priors: TracePrior[]
			emissions: number[][]
			path: number[]
			repairs: TraceRepair[]
		}
	}> {
		const encoded = this.encode(text)
		// Reassigned after inference — the runner clamps to the model's fixed sequence length
		// and `pieces` has to follow it.
		// See the clamp below.
		let pieces = encoded.pieces
		// Soft-feature channels (#718): the postcode-anchor (#239/#240) + gazetteer-anchor (#464)
		// clues the model conditions on alongside the ids, plus the near-postcode gazetteer choreography.
		// The build + choreography is the single pure `buildSoftFeatures` (soft-features.ts) —
		// both this decode path and the ProductionScorer feed channels identically,
		// so there is exactly one choreography.
		// Each channel is undefined when its source is unconfigured (no-op).
		//
		// The evidence-bundle channels are register-conditional (Decision A, see ParseOpts.inputMode):
		// formatted mode withholds both lexicons so the model runs its curriculum-trained absence
		// identity — the fed channels improve fragment parses but damage full-address parses.
		const evidenceOn = (opts?.inputMode ?? "fragmented") === "fragmented"

		// The char path is channel-free by interface (D5): no anchor, gazetteer, country or evidence
		// features are built or fed, so `soft` stays empty and the trace reports every channel silent.
		const soft: SoftFeatures = encoded.charIDs
			? {}
			: buildSoftFeatures(text, pieces, {
					postcodeAnchorLookup: this.cfg.postcodeAnchorLookup,
					postcodeAnchorSpanMode: this.cfg.postcodeAnchorSpanMode,
					gazetteerLexicon: this.cfg.gazetteerLexicon,
					countryLexicon: this.cfg.countryLexicon,
					suppressGazetteerNearPostcode: this.cfg.suppressGazetteerNearPostcode,
					streetTypeLexicon: evidenceOn ? this.cfg.streetTypeLexicon : undefined,
					localitySurfaceLexicon: evidenceOn ? this.cfg.localitySurfaceLexicon : undefined,
				})

		const { logits, localeLogits, spanScores } = encoded.charIDs
			? await this.cfg.runner.inferChars!(encoded.charIDs, encoded.attentionMask!)
			: await this.cfg.runner.infer(
					encoded.ids,
					soft.anchor,
					soft.gazetteer,
					soft.country,
					soft.streetType || soft.localitySurface
						? { streetType: soft.streetType, localitySurface: soft.localitySurface }
						: undefined
				)

		this.assertEmissionWidth(logits)

		// invariant for everything below: one row of emissions per piece.
		// `ONNXRunner.infer` truncates its input to `fixedSeqLen` and trims `logits` to what it ran,
		// so an untruncated `pieces` breaks that pairing and every lockstep consumer indexes off the end —
		// the token build reading `logits[i]`, `enforceWordConsistency` reading `emissions[pi]`.
		//
		// The limit is reachable by ordinary input: 128 pieces is roughly 330 characters,
		// which a form-concatenated delivery address clears.
		// Dropping the tail is the runner's existing choice made visible. the
		// alternative is throwing on a valid address.
		// Note the tail is lost rather than deferred — components past the window never reach the model at all.
		//
		// `logits.length`, not a literal 128, so this holds for any `fixedSeqLen` — including models
		// whose window differs, and non-Latin scripts that reach it at far shorter character counts.
		if (pieces.length > logits.length) {
			pieces = pieces.slice(0, logits.length)
		}

		// Trace retention (spec 2026-07-03): capture-by-reference of arrays this method already builds.
		// Null when not tracing — the non-trace path allocates nothing new
		// (every recording call below sits behind a `tracePriors?` / `if (traceRepairs)` guard,
		// so even snapshot arguments are never built for a plain parse).
		const tracePriors: TracePrior[] | null = trace ? [] : null
		const traceRepairs: TraceRepair[] | null = trace ? [] : null

		const recordRepair = (pass: TraceRepairPass, before: string[], after: string[]): void => {
			if (!traceRepairs) return

			if (before.length === after.length && before.every((label, i) => label === after[i])) return
			traceRepairs.push({ pass, before, after })
		}

		// TraceRepair before/after are PER-piece (index-aligned with `pieces`).
		// Token-count-preserving passes can read labels 1:1, but the span bridge merges fragments
		// (dropping later tokens), so labels are projected back onto pieces via char offsets:
		// each piece carries the label of the token covering its start.
		// Keeps the alignment interface true for every pass.
		const labelsPerPiece = (toks: readonly DecoderToken[]): string[] => {
			let t = 0

			return pieces.map((p) => {
				while (t + 1 < toks.length && toks[t + 1]!.start <= p.start) {
					t++
				}

				const tok = toks[t]

				return (tok && tok.start <= p.start && p.start < tok.end ? tok.label : "O") as string
			})
		}

		// `applied` reports effect (see TracePrior): a composed prior counts only if any cell is nonzero.
		const matrixHasBias = (m: readonly (readonly number[])[]): boolean => m.some((row) => row.some((v) => v !== 0))

		// Address-system conventions (#511 Tier A): resolve which system's rules apply —
		// caller-pinned system, or the model's own locale-head detection under a high confidence bar.
		// Null = no constraints. the parse below is byte-identical to the pre-conventions path.
		const conventionsOpt = opts?.addressSystemConventions ?? this.cfg.addressSystemConventions
		const { detectedSystem, systemSource } = resolveSystemVerdict(conventionsOpt, localeLogits)
		const conventions = conventionsForSystem(detectedSystem)

		const queryShapePrior = opts?.queryShape
			? buildEmissionPriors(opts.queryShape, pieces, this.labels, {
					biasScale: opts.queryShapeBiasScale ?? 1,
					inputText: text,
				})
			: undefined

		let emissions = queryShapePrior ? addEmissionMatrix(logits, queryShapePrior) : logits

		tracePriors?.push({ kind: "queryShape", applied: queryShapePrior !== undefined && matrixHasBias(queryShapePrior) })

		const fstPrior = opts?.fst
			? buildFSTEmissionPriors(opts.fst, pieces, this.labels, {
					biasScale: opts.fstBiasScale ?? 1,
					...(opts.fstImportanceLengthScaleMode
						? { importanceLengthScaleMode: opts.fstImportanceLengthScaleMode }
						: {}),
					// Street-context check (#1142): reuse the morphology FST already loaded
					// for the street-morphology prior.
					// Inert when the morphology FST isn't loaded.
					...(opts.fstStreetMorphology && opts.fstStreetContextRequirement !== false
						? {
								streetContext: {
									fst: opts.fstStreetMorphology,
									...(opts.fstStreetContextPositiveScale !== undefined
										? { positiveScale: opts.fstStreetContextPositiveScale }
										: {}),
								},
							}
						: {}),
				})
			: undefined

		if (fstPrior) {
			emissions = addEmissionMatrix(emissions, fstPrior)
		}

		tracePriors?.push({ kind: "fst", applied: fstPrior !== undefined && matrixHasBias(fstPrior) })

		const morphologyPrior = opts?.fstStreetMorphology
			? buildStreetMorphologyEmissionPriors(
					opts.fstStreetMorphology,
					pieces,
					this.labels,
					opts.fstStreetMorphologyOpts ?? {}
				)
			: undefined

		if (morphologyPrior) {
			emissions = addEmissionMatrix(emissions, morphologyPrior)
		}

		tracePriors?.push({
			kind: "streetMorphology",
			applied: morphologyPrior !== undefined && matrixHasBias(morphologyPrior),
		})

		// Stage 2.7 span proposer (#518, M2+M3): typed span proposals consumed as phrase
		// priors. default on since 2026-06-12 (operator ruling): an omitted config builds
		// the codex lexicon lazily with the frozen measured scales; `spanProposer: false`
		// (config or per-parse) is the proposer-free baseline.
		// Disabled = byte-stable (no proposals computed).
		const configured = this.cfg.spanProposer === false ? undefined : (this.cfg.spanProposer ?? this.defaultProposer())
		const proposerCfg = (opts?.spanProposer ?? true) ? configured : undefined
		const spanProposals: ProposedSpan[] = proposerCfg ? proposeSpans(text, proposerCfg.lexicon) : []

		if (spanProposals.length) {
			emissions = addEmissionMatrix(emissions, buildSpanProposalPriors(spanProposals, pieces, this.labels, proposerCfg))
		}

		tracePriors?.push({ kind: "spanProposer", applied: spanProposals.length > 0 })

		// (defaultProposer lives below decode helpers — one lazy build per classifier instance.)

		// Placetype-pair prior (placetype-pair-prior arc): retrieval-augmented complement to
		// the encoder — see placetype-pair-prior.ts for the full windowing/matching interface.
		// Config-level default set by loadFromWeights (its country-restricted construction);
		// per-call opts override it, same "opts ?? cfg default" shape as
		// bridgePunctuationGaps/enforceWordConsistency below.
		// Default off (neither set → byte-stable).
		// Composed before the conventions mask so an ungrammatical tag it might
		// bias toward still gets masked out.
		const placetypePairOpt = opts?.placetypePair ?? this.cfg.placetypePair
		// Trace-only out-record: which probe-chain path fired (segment vs anchored vs window) —
		// see PlacetypePairProbeTrace.
		// Only allocated when tracing, like the tracePriors list itself.
		const pairProbeTrace: PlacetypePairProbeTrace | undefined = trace ? {} : undefined
		// PCN1 census observability rung: passed to the prior so its parent-candidate probes
		// also probe the census, recording what it knows onto `pairProbeTrace`.
		// Injected only when tracing — the prior writes census observations nowhere else,
		// so on a plain `parse()` there is nothing for it to fill and no lookup to pay for.
		// It never reaches a logit. the `placetypeCensus` record below is its entire output.
		const placetypeCensusOpt = opts?.placetypeCensus ?? this.cfg.placetypeCensus

		const censusForProbe: PlacetypeCensusLike | undefined = trace && placetypeCensusOpt ? placetypeCensusOpt : undefined

		const placetypePairResult = placetypePairOpt
			? buildPlacetypePairPriors(
					{
						...placetypePairOpt,
						inputText: text,
						probeTrace: pairProbeTrace ?? placetypePairOpt.probeTrace,
						...(censusForProbe ? { census: censusForProbe } : {}),
					},
					pieces,
					this.labels
				)
			: undefined

		const placetypePairPrior = placetypePairResult?.matrix

		if (placetypePairPrior) {
			emissions = addEmissionMatrix(emissions, placetypePairPrior)
		}

		// transition-beta: convert the prior's label-string adjustments to the decoder's index axis.
		// Empty (the overwhelmingly common case — no hit, or a beta-less index) stays `undefined`
		// so the viterbi call below is argument-identical to the pre-beta path.
		// A label the vocabulary doesn't carry is dropped, mirroring `applyWindowBias`'s own unknown-label skip.
		const pairTransitionAdjustments = placetypePairResult?.transitionAdjustments.length
			? placetypePairResult.transitionAdjustments.flatMap((adj) => {
					const toLabel = this.labels.indexOf(adj.toLabel)

					return toLabel !== -1 ? [{ timestep: adj.pieceIndex, toLabel, bonus: adj.bonus }] : []
				})
			: undefined

		const placetypePairApplied = placetypePairPrior !== undefined && matrixHasBias(placetypePairPrior)

		tracePriors?.push({
			kind: "placetypePair",
			applied: placetypePairApplied,
			// `probePath` rides only when a bias actually landed — an applied:false record stays
			// shape-identical to every trace produced before the probe chain existed.
			...(placetypePairApplied && pairProbeTrace?.firedPath ? { probePath: pairProbeTrace.firedPath } : {}),
		})

		// PCN1 census observability (2026-08-05).
		// `applied` is hard-coded false rather than computed: this rung composes no matrix to
		// test for a nonzero cell, and it must stay that way until a calibration rung measures a
		// δ (the artifact header deliberately ships none — see `PlacetypeCensusHeader.delta`).
		// The observation list and its probe-count denominator ride only when a census was
		// actually wired, so a build without the artifact produces `{kind, applied: false}`
		// and every other field of the trace is unchanged.
		tracePriors?.push({
			kind: "placetypeCensus",
			applied: false,
			...(pairProbeTrace?.censusProbedParents === undefined
				? {}
				: {
						census: pairProbeTrace.censusObservations ?? [],
						censusProbedParents: pairProbeTrace.censusProbedParents,
					}),
		})

		// Conventions emission mask: tags that are ungrammatical in the detected system
		// are removed from the decoder's vocabulary outright (-1e9 ≈ log 0).
		// Copy-on-mask — `emissions` may alias `logits`, which the per-token confidence below reads unmasked.
		let conventionsMaskApplied = false

		if (conventions?.forbiddenTags?.length) {
			const forbidden = new Set<number>()

			for (const tag of conventions.forbiddenTags) {
				const b = this.labels.indexOf(`B-${tag}`)
				const i = this.labels.indexOf(`I-${tag}`)

				if (b !== -1) {
					forbidden.add(b)
				}

				if (i !== -1) {
					forbidden.add(i)
				}
			}

			if (forbidden.size) {
				conventionsMaskApplied = true
				emissions = emissions.map((row) => row.map((v, idx) => (forbidden.has(idx) ? -1e9 : v)))
			}
		}

		tracePriors?.push({ kind: "conventionsMask", applied: conventionsMaskApplied })

		let labelIndices =
			this.decodeMode === "viterbi"
				? viterbi({
						emissions,
						transitions: this.transitions,
						startTransitions: this.startTransitions,
						endTransitions: this.endTransitions,
						// transition-beta: position-scoped entry bonuses from the placetype-pair prior
						// (undefined unless a pair hit fired on a transitionBeta-carrying index).
						// Viterbi-only by nature — the argmax path has no transitions to adjust.
						...(pairTransitionAdjustments ? { transitionAdjustments: pairTransitionAdjustments } : {}),
					}).path
				: emissions.map((row) => argmaxWithConfidence(row).idx)

		// The trace's `path` is the decoder's output — snapshot before the word-consistency healing
		// below reassigns labelIndices (the healing itself is visible as a `wordConsistency` repair).
		const decodedPath = trace ? [...labelIndices] : null

		// Per-word BIO consistency repair (#727 + the admin-token fragmentation class).
		// Opt-in — default off → byte-identical.
		// Heals words whose pieces disagree (e.g. `vermont`→VER[loc]+mont[region],
		// `Lozère`→Loz[loc]+ère[region]) via a confidence-weighted vote over the post-prior
		// emissions. a word whose pieces already agree is untouched.
		// See word-consistency.ts.
		let healedConfidence: Map<number, number> | null = null

		// The default is the shipped configuration, deliberately — `geocode-core.ts` resolves to
		// this same constant, so a bare classifier and the production pipeline decode identically.
		// Anything that defaults differently here is a decode no user is on, and probes written
		// against the classifier will report defects the shipped path cannot reach.
		//
		// The repair upholds an invariant no valid parse can violate: the pieces of one word carry one tag.
		// `false` opts out for callers who want the raw emissions.
		// The invariant is SentencePiece's: a "word" is a whitespace-delimited run of pieces.
		// On the char path every unit is one code point and a Japanese address has no whitespace,
		// so the whole string is one "word" and the repair would fold prefecture,
		// municipality, district and block into a single span (#2164).
		// The char path is never word-consistent by construction, so the repair does not run there.
		const wordConsistency = this.cfg.charEncoder
			? false
			: (opts?.enforceWordConsistency ?? this.cfg.enforceWordConsistency ?? WORD_CONSISTENCY_SHIP_DEFAULT)

		if (wordConsistency) {
			const beforeLabels = traceRepairs ? labelIndices.map((i) => (this.labels[i] ?? "O") as string) : []
			const wcOpts = typeof wordConsistency === "object" ? wordConsistency : undefined
			const wc = enforceWordConsistency(pieces, emissions, this.labels, labelIndices, wcOpts)
			labelIndices = wc.labelIndices
			healedConfidence = wc.healedConfidence

			if (traceRepairs) {
				recordRepair(
					"wordConsistency",
					beforeLabels,
					labelIndices.map((i) => (this.labels[i] ?? "O") as string)
				)
			}
		}

		let tokens: DecoderToken[] = pieces.map((p, i) => {
			const idx = labelIndices[i]!
			const probs = softmax(logits[i]!)

			return {
				piece: p.piece,
				start: p.start,
				end: p.end,
				label: (this.labels[idx] ?? "O") as DecoderToken["label"],
				// Healed words carry the vote's mean p(type) (length-invariant); unchanged
				// pieces keep the model's per-piece softmax confidence.
				confidence: healedConfidence?.get(i) ?? probs[idx]!,
			}
		})

		// Postcode repair runs when the caller asks for it or the detected system declares a postcode
		// shape (#511 Tier A): a span that is a sub-match of a shape-valid string is exactly the
		// snap-only truncation class the pass exists for ("47110" decoded as "4711" + a digit-split).
		if (opts?.postcodeRepair || conventions?.postcodePattern) {
			const before = traceRepairs ? labelsPerPiece(tokens) : []
			tokens = repairPostcodeLabels(text, tokens).tokens

			if (traceRepairs) {
				recordRepair("postcodeRepair", before, labelsPerPiece(tokens))
			}
		}

		if (opts?.unitRepair) {
			const before = traceRepairs ? labelsPerPiece(tokens) : []
			tokens = repairUnitLabels(text, tokens).tokens

			if (traceRepairs) {
				recordRepair("unitRepair", before, labelsPerPiece(tokens))
			}
		}

		// Punctuation-gap span bridging (v4.4.0 corrective — see span-bridge.ts): merge same-tag
		// fragments split at unlabeled punctuation ("P.O. Box" decoding as P + O + Box).
		// Opt-in, declared in the ship config like the conventions mask.
		// When the span proposer ran, its annotation/quoted boundaries become
		// merge-crossing constraints (M2's second half).
		// The char path only: the name registers close an administrative span the model
		// closed early — the six JP towns whose name carries 市 (`JP_INNER_SHI_TOWNS`)
		// and every Korean 시군구 (`KR_SIGUNGU`), both in `@mailwoman/codex`.
		// Exact register names, so no other row can move.
		if (this.cfg.charEncoder) {
			for (const [pass, repair] of [
				["jpMunicipality", repairJPMunicipalityLabels],
				["krSubregion", repairKRSubregionLabels],
			] as const) {
				const before = traceRepairs ? labelsPerPiece(tokens) : []
				tokens = repair(text, tokens).tokens

				if (traceRepairs) {
					recordRepair(pass, before, labelsPerPiece(tokens))
				}
			}
		}

		if (opts?.bridgePunctuationGaps ?? this.cfg.bridgePunctuationGaps) {
			const blockedSpans = spanProposals.filter((p) => p.kind === "ANNOTATION_SPAN" || p.kind === "QUOTED_SPAN")
			// The bridge merges tokens (later fragments are dropped), so both snapshots go through
			// the per-piece projection — a merged span's label lands on every piece it covers,
			// keeping before/after index-aligned with `pieces` per the TraceRepair interface.
			const before = traceRepairs ? labelsPerPiece(tokens) : []
			tokens = bridgePunctuationGaps(text, tokens, blockedSpans.length ? { blockedSpans } : undefined)

			if (traceRepairs) {
				recordRepair("spanBridge", before, labelsPerPiece(tokens))
			}
		}

		return {
			tokens,
			logits,
			pieces,
			localeCountry: confidentLocaleCountry(localeLogits),
			...(trace
				? {
						trace: {
							...(soft.anchor ? { anchor: soft.anchor } : {}),
							...(soft.gazetteer ? { gazetteer: soft.gazetteer } : {}),
							...(soft.country ? { country: soft.country } : {}),
							...(localeLogits ? { localeLogits } : {}),
							...(spanScores ? { spanScores } : {}),
							detectedSystem,
							systemSource,
							priors: tracePriors!,
							emissions,
							path: decodedPath!,
							repairs: traceRepairs!,
						},
					}
				: {}),
		}
	}

	async parseJSON(text: string, opts?: ParseOpts): Promise<Partial<Record<ComponentTag, string>>>
	async parseJSON(
		text: string,
		opts: ParseOpts & SerializeJSONOpts
	): Promise<Partial<Record<ComponentTag, string>> & { unknown?: UnknownSpan[] }>
	async parseJSON(
		text: string,
		opts: ParseOpts & SerializeJSONOpts = {}
	): Promise<Partial<Record<ComponentTag, string>> & { unknown?: UnknownSpan[] }> {
		return decodeAsJSON(await this.parse(text, opts), opts)
	}

	async parseTuples(text: string, opts?: ParseOpts): Promise<Array<[ComponentTag, string]>>
	async parseTuples(
		text: string,
		opts: ParseOpts & SerializeTuplesOpts
	): Promise<Array<[ComponentTag | "unknown", string]>>
	async parseTuples(
		text: string,
		opts: ParseOpts & SerializeTuplesOpts = {}
	): Promise<Array<[ComponentTag | "unknown", string]>> {
		return decodeAsTuples(await this.parse(text, opts), opts)
	}

	async parseXML(text: string, opts?: ParseOpts & { xml?: Parameters<typeof decodeAsXML>[1] }): Promise<string> {
		return decodeAsXML(await this.parse(text, opts), opts?.xml)
	}

	/**
	 * Guard against a silent label/emission shape overrun.
	 *
	 * When the model emits more logits per token than the configured label vocabulary
	 * (e.g. a Stage 3 bundle loaded with the default Stage 2 labels), viterbi indexes past the
	 * transition matrix and dies with an opaque `Cannot read properties of undefined (reading '0')`.
	 * Fail fast here with a message that names the interface the caller violated.
	 *
	 * The opposite shape (model narrower than labels) is intentionally permitted —
	 * STAGE2_BIO_LABELS prefix-extends STAGE1_BIO_LABELS so a Stage 1 model loaded with
	 * Stage 2 labels decodes correctly via the first 15 logits.
	 * See labels.ts for the interface.
	 */
	/**
	 * Turn the text into the units the model reads: SentencePiece pieces with vocabulary ids,
	 * or — on the char path — one piece per code point (id 0, unused by the graph)
	 * beside the `(S, W)` character ids the graph takes instead.
	 */
	private encode(text: string): {
		pieces: TokenizedPiece[]
		ids: number[]
		charIDs?: number[][]
		attentionMask?: number[]
	} {
		if (this.cfg.charEncoder) {
			const encoding = encodeCharUnits(text, this.cfg.charEncoder.vocabulary, this.cfg.charEncoder.interface)

			return {
				pieces: encoding.units.map((unit) => ({ piece: unit.text, id: 0, start: unit.start, end: unit.end })),
				ids: [],
				charIDs: encoding.charIDs,
				attentionMask: encoding.attentionMask,
			}
		}

		return this.cfg.tokenizer!.encode(text)
	}

	private assertEmissionWidth(logits: readonly number[][]): void {
		if (!logits.length) return
		const width = logits[0]!.length

		if (width > this.labels.length) {
			throw new Error(
				`Label/emission mismatch: model emits ${width} logits per token but the classifier was ` +
					`configured with only ${this.labels.length} labels. Did you load a Stage 3 bundle without ` +
					`passing its model-card labels? See loadFromWeights / loadNeuralClassifierFromURLs.`
			)
		}
	}
}

/**
 * Element-wise add two square matrices.
 *
 * Used to compose the structural mask + learned transitions.
 */
function addMatrices(a: number[][], b: number[][]): number[][] {
	const n = a.length
	const out: number[][] = []

	for (let i = 0; i < n; i++) {
		const row = new Array<number>(n)

		for (let j = 0; j < n; j++) {
			row[j] = a[i]![j]! + b[i]![j]!
		}

		out.push(row)
	}

	return out
}
