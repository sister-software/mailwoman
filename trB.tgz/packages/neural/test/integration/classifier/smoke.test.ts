/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   End-to-end smoke test for `NeuralAddressClassifier`.
 *
 *   Loads the v0.2.0 int8 model from the host-side weights dir (not committed to the repo because of
 *   size). Skips gracefully when the model isn't present so CI in non-host environments still
 *   passes. To run locally:
 *
 *   - Tokenizer.model is in `packages/neural/neural/test/fixtures/` (committed)
 *   - Model.onnx is read from $MAILWOMAN_TEST_ONNX_MODEL or the default path below
 */

import { dataRootPath } from "@mailwoman/core/data-root"
import { pathExists } from "@mailwoman/core/fs/readers"
import { workspacePath } from "@mailwoman/core/paths"
import { NeuralAddressClassifier } from "@mailwoman/neural/classifier"
import { $public } from "@mailwoman/neural/env"
import { ONNXRunner } from "@mailwoman/neural/onnx-runner"
import { MailwomanTokenizer } from "@mailwoman/neural/tokenizer"
import { describe, expect, test } from "vitest"

const TOKENIZER_PATH = workspacePath("neural", "test", "fixtures", "tokenizer-v0.1.0.model")

const MODEL_PATH =
	$public.MAILWOMAN_TEST_ONNX_MODEL ??
	String(dataRootPath("models", "quantized", "model-stage1-coarse-step-050000-int8.onnx"))

const haveModel = await pathExists(MODEL_PATH)

describe.skipIf(!haveModel)("NeuralAddressClassifier — smoke (v0.2.0 int8)", () => {
	test("parses the white-house address into a non-empty tree", async () => {
		const tokenizer = await MailwomanTokenizer.loadFromFile(TOKENIZER_PATH)
		const runner = await ONNXRunner.create(MODEL_PATH)
		const cls = new NeuralAddressClassifier({ tokenizer, runner })

		const tree = await cls.parse("1600 Pennsylvania Avenue NW, Washington, DC 20500")
		expect(tree.roots.length).toBeGreaterThan(0)
	})

	test("parseXML emits an <address> root with at least one component", async () => {
		const tokenizer = await MailwomanTokenizer.loadFromFile(TOKENIZER_PATH)
		const runner = await ONNXRunner.create(MODEL_PATH)
		const cls = new NeuralAddressClassifier({ tokenizer, runner })

		const xml = await cls.parseXML("75004 Paris")
		expect(xml).toMatch(/^<address /)
		expect(xml).toContain("</address>")
	})

	test("parseJSON returns at least one coarse component for a familiar address", async () => {
		const tokenizer = await MailwomanTokenizer.loadFromFile(TOKENIZER_PATH)
		const runner = await ONNXRunner.create(MODEL_PATH)
		const cls = new NeuralAddressClassifier({ tokenizer, runner })

		const json = await cls.parseJSON("Washington, DC 20500")
		const coarseHits = ["country", "region", "locality", "postcode"].filter((k) => k in json)
		expect(coarseHits.length).toBeGreaterThan(0)
	})

	test("empty input returns empty tree without error", async () => {
		const tokenizer = await MailwomanTokenizer.loadFromFile(TOKENIZER_PATH)
		const runner = await ONNXRunner.create(MODEL_PATH)
		const cls = new NeuralAddressClassifier({ tokenizer, runner })

		const tree = await cls.parse("")
		expect(tree.roots).toEqual([])
	})
})
