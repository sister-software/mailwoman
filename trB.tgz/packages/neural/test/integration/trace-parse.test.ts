/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Tests for `NeuralAddressClassifier.traceParse` (spec:
 *   docs/superpowers/specs/2026-07-03-parse-trace-model-visualizer-design.md).
 *
 *   The required assertion is parity: the trace's tokens must build the same AddressTree
 *   `parse()` returns under identical opts — proving trace retention never forked the decode
 *   path (#481). Uses a fake `NeuralRunner` so the suite runs in milliseconds.
 */

import { buildAddressTree } from "@mailwoman/core/decoder"
import { prettyJSON } from "@mailwoman/core/json"
import { workspacePath } from "@mailwoman/core/paths"
import type { AnchorLookup } from "@mailwoman/neural/anchor-inference"
import { NeuralAddressClassifier, type NeuralRunner } from "@mailwoman/neural/classifier"
import { STAGE2_BIO_LABELS } from "@mailwoman/neural/labels"
import type { InferResult } from "@mailwoman/neural/onnx-runner"
import type { QueryShapeLike } from "@mailwoman/neural/query-shape-prior"
import { MailwomanTokenizer } from "@mailwoman/neural/tokenizer"
import { TRACE_PRIOR_KINDS } from "@mailwoman/neural/trace"
import { describe, expect, it } from "vitest"

const TOKENIZER_PATH = workspacePath("neural", "test", "fixtures", "tokenizer-v0.1.0.model")

/**
 * Fake runner emitting a canned logits matrix (and optional locale head) regardless of input.
 */
class FakeRunner implements NeuralRunner {
	readonly #canned: number[][]
	readonly #localeLogits?: number[]

	constructor(canned: number[][], localeLogits?: number[]) {
		this.#canned = canned
		this.#localeLogits = localeLogits
	}
	async infer(_ids: number[]): Promise<InferResult> {
		return {
			logits: this.#canned,
			numLabels: this.#canned[0]?.length ?? 0,
			...(this.#localeLogits ? { localeLogits: this.#localeLogits } : {}),
		}
	}
}

/**
 * Uniform-noise logits with a boost on one label at one token index.
 */
function logitsWithBoost(numTokens: number, boostIdx: number, boostLabel: string, magnitude = 3): number[][] {
	const labelIdx = STAGE2_BIO_LABELS.indexOf(boostLabel as (typeof STAGE2_BIO_LABELS)[number])
	const matrix: number[][] = []

	for (let t = 0; t < numTokens; t++) {
		const row = Array.from<number>({ length: STAGE2_BIO_LABELS.length }).fill(0)

		if (t === boostIdx && labelIdx !== -1) {
			row[labelIdx] = magnitude
		}

		matrix.push(row)
	}

	return matrix
}

async function loadTokenizer(): Promise<MailwomanTokenizer> {
	return MailwomanTokenizer.loadFromFile(TOKENIZER_PATH)
}

describe("NeuralAddressClassifier.traceParse", () => {
	it("parity: trace tokens rebuild the exact tree parse() returns", async () => {
		const tokenizer = await loadTokenizer()
		const text = "350 5th Ave 10118"
		const { pieces } = tokenizer.encode(text)
		const logits = logitsWithBoost(pieces.length, 0, "B-house_number")
		const classifier = new NeuralAddressClassifier({ tokenizer, runner: new FakeRunner(logits) })

		const tree = await classifier.parse(text)
		const trace = await classifier.traceParse(text)

		expect(buildAddressTree(trace.text, trace.tokens)).toEqual(tree)
	})

	it("surfaces raw logits, pieces, labels, and viterbi path", async () => {
		const tokenizer = await loadTokenizer()
		const text = "350 5th Ave 10118"
		const { pieces } = tokenizer.encode(text)
		const logits = logitsWithBoost(pieces.length, 0, "B-house_number")
		const classifier = new NeuralAddressClassifier({ tokenizer, runner: new FakeRunner(logits) })

		const trace = await classifier.traceParse(text)

		expect(trace.logits).toEqual(logits)
		expect(trace.pieces).toHaveLength(pieces.length)

		expect(trace.pieces[0]).toEqual({
			piece: pieces[0]!.piece,
			id: pieces[0]!.id,
			start: pieces[0]!.start,
			end: pieces[0]!.end,
		})

		expect(trace.labels).toEqual([...STAGE2_BIO_LABELS])
		expect(trace.path).toHaveLength(pieces.length)
		expect(trace.decode).toBe("viterbi")
		expect(trace.tokens).toHaveLength(pieces.length)
	})

	it("records which priors fired", async () => {
		const tokenizer = await loadTokenizer()
		const text = "350 5th Ave 10118"
		const { pieces } = tokenizer.encode(text)
		const logits = logitsWithBoost(pieces.length, 0, "B-house_number")
		const classifier = new NeuralAddressClassifier({ tokenizer, runner: new FakeRunner(logits) })

		const bare = await classifier.traceParse(text)
		const queryShapePrior = bare.priors.find((p) => p.kind === "queryShape")

		expect(queryShapePrior).toEqual({ kind: "queryShape", applied: false })

		// The span proposer is default-on. whether it fires depends on the text.
		// The interface is every kind, in application order — asserted against the exported
		// constant, so a new prior added to #decode without its participation record fails here
		// instead of silently vanishing from traces.
		expect(bare.priors.map((p) => p.kind)).toEqual([...TRACE_PRIOR_KINDS])
	})

	it("placetypePair record carries probePath naming the probe-chain leg (segment vs anchored), absent when inert", async () => {
		const tokenizer = await loadTokenizer()

		// A minimal PairIndexLike double — one real GB pair, hit under any key form.
		const index = {
			delta: 6,
			probe: (child: string, parent: string) =>
				child === "moelfre" && parent === "abergele"
					? ({ tag: "dependent_locality", parentTag: "locality" } as const)
					: undefined,
		}

		const commaText = "Moelfre, Abergele"
		const { pieces: commaPieces } = tokenizer.encode(commaText)

		const commaClassifier = new NeuralAddressClassifier({
			tokenizer,
			runner: new FakeRunner(logitsWithBoost(commaPieces.length, 0, "B-street")),
		})

		const commaTrace = await commaClassifier.traceParse(commaText, {
			placetypePair: { index },
			spanProposer: false,
		})

		// Comma'd input → the chain's segment leg fires.
		expect(commaTrace.priors.find((p) => p.kind === "placetypePair")).toEqual({
			kind: "placetypePair",
			applied: true,
			probePath: "segment",
		})

		const bareText = "Moelfre Abergele"
		const { pieces: barePieces } = tokenizer.encode(bareText)

		const bareClassifier = new NeuralAddressClassifier({
			tokenizer,
			runner: new FakeRunner(logitsWithBoost(barePieces.length, 0, "B-street")),
		})

		const bareTrace = await bareClassifier.traceParse(bareText, {
			placetypePair: { index },
			spanProposer: false,
		})

		// Comma-free input → the anchored-adjacent leg.
		expect(bareTrace.priors.find((p) => p.kind === "placetypePair")).toEqual({
			kind: "placetypePair",
			applied: true,
			probePath: "anchored",
		})

		// No configured index → the record keeps its pre-chain shape: no probePath key at all.
		const inertTrace = await bareClassifier.traceParse(bareText, { spanProposer: false })

		expect(inertTrace.priors.find((p) => p.kind === "placetypePair")).toEqual({
			kind: "placetypePair",
			applied: false,
		})
	})

	it("emissions differ from logits when a prior applies, match when none do", async () => {
		const tokenizer = await loadTokenizer()
		const text = "12345"
		const { pieces } = tokenizer.encode(text)
		const logits = logitsWithBoost(pieces.length, 0, "B-locality", 0.1)
		const classifier = new NeuralAddressClassifier({ tokenizer, runner: new FakeRunner(logits) })

		const shape: QueryShapeLike = {
			knownFormats: [{ format: "us_zip", span: { start: 0, end: 5 }, confidence: 1 }],
		}

		const traced = await classifier.traceParse(text, { queryShape: shape, spanProposer: false })

		expect(traced.priors.find((p) => p.kind === "queryShape")).toEqual({ kind: "queryShape", applied: true })
		expect(traced.emissions).not.toEqual(traced.logits)
	})

	it("carries the locale head + detected system when conventions are on", async () => {
		const tokenizer = await loadTokenizer()
		const text = "350 5th Ave"
		const { pieces } = tokenizer.encode(text)
		const logits = logitsWithBoost(pieces.length, 0, "B-street")
		// LOCALE_COUNTRIES order: US first.
		// A huge US logit clears the 0.8 detection bar.
		const localeLogits = [10, 0, 0, 0, 0, 0, 0, 0, 0]
		const classifier = new NeuralAddressClassifier({ tokenizer, runner: new FakeRunner(logits, localeLogits) })

		const trace = await classifier.traceParse(text, { addressSystemConventions: "auto" })

		expect(trace.localeLogits).toEqual(localeLogits)
		expect(trace.systemSource).toBe("auto")
		expect(trace.detectedSystem).toBe("us")

		const off = await classifier.traceParse(text)

		expect(off.systemSource).toBe("off")
		expect(off.detectedSystem).toBeNull()
	})

	it("records repair passes as before/after label sequences", async () => {
		const tokenizer = await loadTokenizer()
		// A GB alphanumeric postcode: the repair pass's ADD path creates a span over all-O
		// labels (numeric shapes like a bare ZIP are snap-only and never fire from all-O —
		// see postcode-repair.ts precision guards).
		const text = "London SW1A 1AA"
		const { pieces } = tokenizer.encode(text)

		// Everything decodes O. the postcode-repair pass should add the "SW1A 1AA" postcode span.
		const logits = pieces.map(() => {
			const row = Array.from<number>({ length: STAGE2_BIO_LABELS.length }).fill(0)
			row[STAGE2_BIO_LABELS.indexOf("O")] = 2

			return row
		})

		const classifier = new NeuralAddressClassifier({ tokenizer, runner: new FakeRunner(logits) })

		const trace = await classifier.traceParse(text, { postcodeRepair: true, spanProposer: false })
		const repair = trace.repairs.find((r) => r.pass === "postcodeRepair")

		expect(repair).toBeDefined()
		expect(repair!.before).toHaveLength(pieces.length)
		expect(repair!.after).toHaveLength(pieces.length)
		expect(repair!.before).not.toEqual(repair!.after)
		expect(repair!.after.some((label) => label.endsWith("postcode"))).toBe(true)
		// Final tokens reflect the repaired labels.
		expect(trace.tokens.some((t) => t.label.endsWith("postcode"))).toBe(true)
	})

	it("GB conventions pin (#1275): a clipped GB postcode is snap-repaired with NO explicit postcodeRepair opt", async () => {
		// Characterizes the #1275 clip class: the en-gb overlay mis-tags the first piece of
		// the outward code as region ("SK11 9PD" → region "S" + postcode "K11 9PD").
		// The en-gb model-card pins `requires.conventions.mode` to "gb", which loadFromWeights
		// forwards as the classifier's `addressSystemConventions` config — reproduced here directly.
		// The codex gb row's `postcodePattern` must open the repair check so the snap path reunites the span.
		const tokenizer = await loadTokenizer()
		const text = "Macclesfield SK11 9PD"
		const { pieces } = tokenizer.encode(text)
		const postcodeStart = text.indexOf("SK11")
		// First piece carrying actual postcode characters (the fixture tokenizer emits a zero-width
		// "▁" piece at a word boundary — a zero-width span can never overlap the repair's raw-text match).
		const firstPostcodePiece = pieces.findIndex((p) => p.start >= postcodeStart && p.end > p.start)
		expect(firstPostcodePiece).toBeGreaterThan(0)

		// The diagnosed mislabel shape: locality run, then B-region on the outward code's
		// first piece, then the postcode labels on the remainder (the clip).
		const logits = pieces.map((_, i) => {
			const row = Array.from<number>({ length: STAGE2_BIO_LABELS.length }).fill(0)

			const label =
				i < firstPostcodePiece
					? i === 0
						? "B-locality"
						: "I-locality"
					: i === firstPostcodePiece
						? "B-region"
						: i === firstPostcodePiece + 1
							? "B-postcode"
							: "I-postcode"

			row[STAGE2_BIO_LABELS.indexOf(label as (typeof STAGE2_BIO_LABELS)[number])] = 6

			return row
		})

		// Without the pin (pre-#1275 en-gb reality): the eval never opens, the clip stands.
		const unpinned = new NeuralAddressClassifier({ tokenizer, runner: new FakeRunner(logits) })
		const clippedTrace = await unpinned.traceParse(text, { spanProposer: false })
		// The subject here is the postcode check: unpinned, the codex gb row is never consulted,
		// so the snap path never runs and the clip stands.
		// Assert that specifically rather than `repairs === []` — the blanket form silently
		// also pinned "word-consistency never fires", which was true only while that repair was
		// default-off on the classifier, and broke the moment the default matched the pipeline's.
		expect(clippedTrace.repairs.filter((r) => r.pass === "postcodeRepair")).toEqual([])
		const clipped = (await unpinned.parseJSON(text)) as { postcode?: string }
		expect(clipped.postcode).toBeDefined()
		expect(clipped.postcode).not.toBe("SK11 9PD")
		expect("SK11 9PD".endsWith(clipped.postcode!)).toBe(true)

		// With the pin (what the en-gb card now declares): pinned system → codex gb row → repair
		// check opens → the snap path relabels the whole raw-text match as one postcode span.
		const pinned = new NeuralAddressClassifier({
			tokenizer,
			runner: new FakeRunner(logits),
			addressSystemConventions: "gb",
		})

		const trace = await pinned.traceParse(text, { spanProposer: false })
		expect(trace.systemSource).toBe("pinned")
		expect(trace.detectedSystem).toBe("gb")
		const repair = trace.repairs.find((r) => r.pass === "postcodeRepair")
		expect(repair).toBeDefined()
		expect(repair!.before).not.toEqual(repair!.after)

		const repaired = (await pinned.parseJSON(text)) as { postcode?: string; region?: string }
		expect(repaired.postcode).toBe("SK11 9PD")
		expect(repaired.region).toBeUndefined()
	})

	it("no repairs requested → repairs empty", async () => {
		const tokenizer = await loadTokenizer()
		const text = "350 5th Ave"
		const { pieces } = tokenizer.encode(text)
		const logits = logitsWithBoost(pieces.length, 0, "B-street")
		const classifier = new NeuralAddressClassifier({ tokenizer, runner: new FakeRunner(logits) })

		const trace = await classifier.traceParse(text, { spanProposer: false })

		expect(trace.repairs).toEqual([])
	})

	it("empty input mirrors parse('') — empty trace, no throw", async () => {
		const tokenizer = await loadTokenizer()
		const classifier = new NeuralAddressClassifier({ tokenizer, runner: new FakeRunner([]) })

		const trace = await classifier.traceParse("")

		expect(trace.text).toBe("")
		expect(trace.pieces).toEqual([])
		expect(trace.logits).toEqual([])
		expect(trace.tokens).toEqual([])
		expect(trace.repairs).toEqual([])
		expect(trace.caseNormalized).toBe(false)
	})

	it("all-caps input is case-normalized and flagged", async () => {
		const tokenizer = await loadTokenizer()
		const upper = "214 JONES RD"
		// Piece count depends on the normalized text — encode what the model will actually see.
		const { pieces } = tokenizer.encode("214 Jones Rd")
		const logits = logitsWithBoost(pieces.length, 0, "B-house_number")
		const classifier = new NeuralAddressClassifier({ tokenizer, runner: new FakeRunner(logits) })

		const trace = await classifier.traceParse(upper)

		expect(trace.caseNormalized).toBe(true)
		expect(trace.text).not.toBe(upper)
	})

	it("spanBridge repair stays piece-aligned even though the bridge MERGES tokens", async () => {
		const tokenizer = await loadTokenizer()
		// "P.O.
		// Box" fragments: label the alphanumeric pieces street (a STAGE2 tag — the fake classifier
		// runs the 21-label set, and the bridge is tag-agnostic), leave the dot pieces O. The bridge
		// merges the fragments across the unlabeled intra-token punctuation, dropping tokens.
		// the trace interface still promises per-piece before/after (char-offset projection).
		const text = "P.O. Box 123"
		const { pieces } = tokenizer.encode(text)
		const oIdx = STAGE2_BIO_LABELS.indexOf("O")
		const bIdx = STAGE2_BIO_LABELS.indexOf("B-street")
		const iIdx = STAGE2_BIO_LABELS.indexOf("I-street")

		// Each fragment starts with B- (O → I- is an illegal BIO transition the viterbi mask forbids);
		// only a contiguous continuation piece gets I-.
		// The dots decode O — the gaps the bridge crosses.
		const logits = pieces.map((p, idx) => {
			const row = Array.from<number>({ length: STAGE2_BIO_LABELS.length }).fill(0)
			const alnum = /[\p{L}\p{N}]/u.test(p.piece)
			const prev = pieces[idx - 1]
			const continues = alnum && prev !== undefined && /[\p{L}\p{N}]/u.test(prev.piece) && prev.end === p.start

			row[alnum ? (continues ? iIdx : bIdx) : oIdx] = 4

			return row
		})

		const classifier = new NeuralAddressClassifier({ tokenizer, runner: new FakeRunner(logits) })

		const trace = await classifier.traceParse(text, { bridgePunctuationGaps: true, spanProposer: false })
		const bridge = trace.repairs.find((r) => r.pass === "spanBridge")

		// The bridge must have merged (fewer final tokens than pieces) — otherwise this
		// test's premise is dead and it should fail loudly rather than assert nothing.
		expect(trace.tokens.length).toBeLessThan(pieces.length)
		expect(bridge).toBeDefined()
		expect(bridge!.before).toHaveLength(pieces.length)
		expect(bridge!.after).toHaveLength(pieces.length)

		// The merged span's label covers the punctuation pieces it absorbed.
		expect(bridge!.after.filter((l) => l.endsWith("street")).length).toBeGreaterThan(
			bridge!.before.filter((l) => l.endsWith("street")).length
		)
	})

	it("anchor channel rides the trace exactly as fed, piece-aligned", async () => {
		const tokenizer = await loadTokenizer()
		const text = "350 5th Ave 10118"
		const { pieces } = tokenizer.encode(text)
		const logits = logitsWithBoost(pieces.length, 0, "B-house_number")
		const anchor: AnchorLookup = new Map([["10118", { posterior: { US: 1 }, lat: 40.75, lon: -73.99 }]])

		const classifier = new NeuralAddressClassifier({
			tokenizer,
			runner: new FakeRunner(logits),
			postcodeAnchorLookup: anchor,
		})

		const trace = await classifier.traceParse(text, { spanProposer: false })

		expect(trace.anchor).toBeDefined()
		expect(trace.anchor!.confidence).toHaveLength(pieces.length)
		expect(trace.anchor!.features).toHaveLength(pieces.length)
		// The ZIP's pieces carry the anchor hit. leading pieces don't.
		expect(Math.max(...trace.anchor!.confidence)).toBeGreaterThan(0)
		// Serializable by construction: a JSON round-trip preserves the channel byte-for-byte.
		expect(structuredClone(trace.anchor)).toEqual(trace.anchor)
	})

	it("schema snapshot — drift forces a conscious decision", async () => {
		const tokenizer = await loadTokenizer()
		const text = "350 5th Ave 10118"
		const { pieces } = tokenizer.encode(text)
		const logits = logitsWithBoost(pieces.length, 0, "B-house_number")
		const localeLogits = [10, 0, 0, 0, 0, 0, 0, 0, 0]
		const classifier = new NeuralAddressClassifier({ tokenizer, runner: new FakeRunner(logits, localeLogits) })

		const trace = await classifier.traceParse(text, { addressSystemConventions: "auto", spanProposer: false })

		// `false`: the committed fixture ends at the closing brace, and this test exists
		// so that drift is a conscious decision.
		// Letting the printer's default newline move the pin would make a lint migration into that decision.
		await expect(prettyJSON(trace, false)).toMatchFileSnapshot("../fixtures/trace-schema.snap.json")
	})
})
