/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Register enforcement fence (Decision A): `parse(text, { inputMode: "formatted" })` must run the
 *   evidence-bundle channels off (the curriculum-trained absence identity) while every other channel
 *   feeds unchanged; `"fragmented"` (and the bare-library default, unset) feeds them. Asserted at the
 *   runner boundary via a stub — the same interface the ONNX session sees.
 */

import { readLocalJSONFile } from "@mailwoman/core/fs/readers"
import { resolvePackagePath } from "@mailwoman/core/module/resolvers"
import { NeuralAddressClassifier, type NeuralRunner } from "@mailwoman/neural/classifier"
import { parseGazetteerLexicon } from "@mailwoman/neural/gazetteer-inference"
import { MailwomanTokenizer } from "@mailwoman/neural/tokenizer"
import { describe, expect, it } from "vitest"

interface Fixture {
	street_lexicon: Parameters<typeof parseGazetteerLexicon>[0]
	locality_lexicon: Parameters<typeof parseGazetteerLexicon>[0]
}

const fixture = await readLocalJSONFile<Fixture>(
	resolvePackagePath("@mailwoman/neural", "test", "fixtures", "evidence-parity-v2.json")
)

const LABELS = ["O", "B-street", "I-street", "B-locality", "I-locality"]

function stubRunner(seen: { evidence: unknown[] }): NeuralRunner {
	return {
		async infer(...args: Parameters<NeuralRunner["infer"]>) {
			const [ids] = args
			const evidence = args[4]
			seen.evidence.push(evidence)

			return { logits: ids.map(() => LABELS.map(() => 0)), numLabels: LABELS.length }
		},
	}
}

async function makeClassifier(seen: { evidence: unknown[] }) {
	const tokenizer = await MailwomanTokenizer.loadFromFile(
		resolvePackagePath("@mailwoman/neural", "test", "fixtures", "tokenizer-v0.1.0.model")
	)

	return new NeuralAddressClassifier({
		tokenizer,
		runner: stubRunner(seen),
		labels: LABELS,
		streetTypeLexicon: parseGazetteerLexicon(fixture.street_lexicon),
		localitySurfaceLexicon: parseGazetteerLexicon(fixture.locality_lexicon),
	})
}

describe("inputMode register enforcement (Decision A)", () => {
	it("formatted mode withholds the evidence channels", async () => {
		const seen = { evidence: [] as unknown[] }
		const classifier = await makeClassifier(seen)

		await classifier.parse("Boulevard des Capucines", { inputMode: "formatted" })
		expect(seen.evidence).toHaveLength(1)
		expect(seen.evidence[0]).toBeUndefined()
	})

	it("street-context check: a bare place name feeds NO locality evidence even in fragmented mode", async () => {
		// The 8.2.0 pre-ship gauntlet catch: homograph-flagged locality evidence on a bare
		// world-city lookup rotates the parse (locality → region/street).
		// No street context → locality channel withheld (the declared-ablation identity);
		// the street channel is inert on such input anyway.
		const seen = { evidence: [] as unknown[] }
		const classifier = await makeClassifier(seen)

		await classifier.parse("Springfield", { inputMode: "fragmented" })
		expect(seen.evidence).toHaveLength(1)
		// The street channel rides (all-zero confidence on a street-word-less input — inert by construction);
		// the locality channel is what the eval withholds.
		const evidence = seen.evidence[0] as { streetType?: unknown; localitySurface?: unknown }
		expect(evidence.localitySurface).toBeUndefined()
		expect(evidence.streetType).toBeDefined()
	})

	it("fragmented mode (and the bare-library default) feeds them", async () => {
		const seen = { evidence: [] as unknown[] }
		const classifier = await makeClassifier(seen)

		await classifier.parse("Boulevard des Capucines", { inputMode: "fragmented" })
		await classifier.parse("Boulevard des Capucines", {})
		expect(seen.evidence).toHaveLength(2)

		for (const e of seen.evidence) {
			expect(e).toBeDefined()
		}
	})
})
