/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   TS↔Python evidence-channel painter parity (Option-A Phase 2). The fixture
 *   (`test/fixtures/evidence-parity-v2.json`, regenerate via `generate-evidence-parity.py`) carries
 *   mini street-type + locality-surface lexicons and per-piece features painted by corpus-python's
 *   real painter. this test replays the same lexicons + piece offsets through the generic TS painter
 *   (`buildGazetteerFeatures`) and asserts byte equality. Train and inference must share one
 *   computation — this is the fence.
 *
 *   The probe set deliberately carries the classes that have bitten: hyphen/apostrophe folds (a
 *   Phase-1 defect made them unreachable keys), uppercase-conditional short codes, homograph bits,
 *   longest-first multi-token matches, the lowercase register (operator doctrine), negatives.
 */

import { readLocalJSONFile } from "@mailwoman/core/fs/readers"
import { stringifyJSON } from "@mailwoman/core/json"
import { resolvePackagePath } from "@mailwoman/core/module/resolvers"
import { buildGazetteerFeatures, parseGazetteerLexicon } from "@mailwoman/neural/gazetteer-inference"
import type { TokenizedPiece } from "@mailwoman/neural/tokenizer"
import { describe, expect, it } from "vitest"

interface FixtureCase {
	raw: string
	pieces: Array<{ piece: string; start: number; end: number }>
	street: { features: number[][]; confidence: number[] }
	locality: { features: number[][]; confidence: number[] }
}

interface Fixture {
	street_lexicon: Parameters<typeof parseGazetteerLexicon>[0]
	locality_lexicon: Parameters<typeof parseGazetteerLexicon>[0]
	cases: FixtureCase[]
}

const fixture = await readLocalJSONFile<Fixture>(
	resolvePackagePath("@mailwoman/neural", "test", "fixtures", "evidence-parity-v2.json")
)

const toPieces = (c: FixtureCase): TokenizedPiece[] =>
	c.pieces.map((p) => ({ piece: p.piece, id: 0, start: p.start, end: p.end }))

describe("evidence-channel painter parity (TS ↔ corpus-python)", () => {
	const street = parseGazetteerLexicon(fixture.street_lexicon)
	const locality = parseGazetteerLexicon(fixture.locality_lexicon)

	it("fixture is present and non-trivial", () => {
		expect(fixture.cases.length).toBeGreaterThanOrEqual(10)
	})

	for (const c of fixture.cases) {
		it(`paints ${stringifyJSON(c.raw)} identically on both channels`, () => {
			const pieces = toPieces(c)
			const s = buildGazetteerFeatures(c.raw, pieces, street)
			const l = buildGazetteerFeatures(c.raw, pieces, locality)

			expect(s.features).toEqual(c.street.features)
			expect(s.confidence).toEqual(c.street.confidence)
			expect(l.features).toEqual(c.locality.features)
			expect(l.confidence).toEqual(c.locality.confidence)
		})
	}
})
