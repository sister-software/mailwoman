/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 */

import { removePathIfPresent } from "@mailwoman/core/fs/writers"
import { workspacePath } from "@mailwoman/core/paths"
import { runAdapter } from "@mailwoman/corpus/runner"
import { readCanonicalRows, useScratchDir } from "@mailwoman/corpus/test-kit"
import {
	USGOV_HRSA_FQHC_ADAPTER_ID,
	USGOV_HRSA_FQHC_DEFAULT_LICENSE,
	createUSGovHRSAFQHCAdapter,
} from "@mailwoman/corpus/us/adapters/usgov/hrsa-fqhc/adapter"
import { alignRow } from "@mailwoman/corpus/utils"
import { join } from "path-ts"
import { describe, expect, it } from "vitest"

const scratch = useScratchDir("usgov-hrsa")

const loadRows = () => readCanonicalRows(scratch.path, USGOV_HRSA_FQHC_ADAPTER_ID)

const fixtureCSV = workspacePath("corpus", "fixtures", "usgov-hrsa-fqhc", "sample.csv")

describe("usgov-hrsa-fqhc adapter against fixture sample.csv", () => {
	it("emits one row per valid CSV record + drops invalid ones", async () => {
		const m = await runAdapter({
			adapter: createUSGovHRSAFQHCAdapter(),
			adapterOptions: { inputPath: fixtureCSV },
			outputDir: scratch.path,
			corpusVersion: "0.1.0",
		})

		// 10 fixture rows minus 2 (empty Site Name on row 9, invalid state "ZZ" on row 10).
		expect(m.yielded).toBe(8)
		const rows = await loadRows()
		expect(rows).toHaveLength(8)
		expect(rows.every((r) => r.country === "US")).toBe(true)
		expect(rows.every((r) => r.locale === "en-US")).toBe(true)
		expect(rows.every((r) => r.license === USGOV_HRSA_FQHC_DEFAULT_LICENSE)).toBe(true)
		expect(rows.every((r) => r.source === USGOV_HRSA_FQHC_ADAPTER_ID)).toBe(true)
	})

	it("source_id uses HRSA Site ID when present", async () => {
		await runAdapter({
			adapter: createUSGovHRSAFQHCAdapter(),
			adapterOptions: { inputPath: fixtureCSV },
			outputDir: scratch.path,
			corpusVersion: "0.1.0",
		})

		const rows = await loadRows()
		const row = rows.find((r) => r.source_id === "usgov-hrsa-fqhc-H80CS00001")
		expect(row).toBeDefined()

		expect(row!.components).toMatchObject({
			venue: "Buffalo Health Center Inc.",
			house_number: "123",
			street: "Main St",
			locality: "Buffalo",
			region: "NY",
			postcode: "14201",
		})
	})

	it("composes a venue-prefixed envelope-style raw line", async () => {
		await runAdapter({
			adapter: createUSGovHRSAFQHCAdapter(),
			adapterOptions: { inputPath: fixtureCSV },
			outputDir: scratch.path,
			corpusVersion: "0.1.0",
		})

		const rows = await loadRows()
		const row = rows.find((r) => r.source_id === "usgov-hrsa-fqhc-H80CS00001")!
		expect(row.raw).toBe("Buffalo Health Center Inc., 123 Main St, Buffalo, NY 14201")
	})

	it("kryptonite case: 'Buffalo Health Center' + 'Buffalo NY' aligns to disjoint spans (venue first)", async () => {
		await runAdapter({
			adapter: createUSGovHRSAFQHCAdapter(),
			adapterOptions: { inputPath: fixtureCSV },
			outputDir: scratch.path,
			corpusVersion: "0.1.0",
		})

		const rows = await loadRows()
		const row = rows.find((r) => r.source_id === "usgov-hrsa-fqhc-H80CS00001")!
		// Alignment downstream must place the venue's "Buffalo" under B-venue
		// and the locality's "Buffalo" under B-locality (not vice versa).
		const result = alignRow(row)
		expect(result.kind).toBe("labeled")

		if (result.kind !== "labeled") return
		const buffaloIndices = result.row.tokens.map((t, i) => (t === "Buffalo" ? i : -1)).filter((i) => i >= 0)
		expect(buffaloIndices).toHaveLength(2)
		expect(result.row.labels[buffaloIndices[0]!]).toBe("B-venue")
		expect(result.row.labels[buffaloIndices[1]!]).toBe("B-locality")
	})

	it("preserves Suite designators on the street component (no separate unit slot)", async () => {
		await runAdapter({
			adapter: createUSGovHRSAFQHCAdapter(),
			adapterOptions: { inputPath: fixtureCSV },
			outputDir: scratch.path,
			corpusVersion: "0.1.0",
		})

		const rows = await loadRows()
		const row = rows.find((r) => r.source_id === "usgov-hrsa-fqhc-H80CS00002")!
		expect(row.components.street).toBe("SE Hawthorne Blvd Suite 200")
	})

	it("PO Box surface form preserved verbatim in street (no false house-number split)", async () => {
		await runAdapter({
			adapter: createUSGovHRSAFQHCAdapter(),
			adapterOptions: { inputPath: fixtureCSV },
			outputDir: scratch.path,
			corpusVersion: "0.1.0",
		})

		const rows = await loadRows()
		const row = rows.find((r) => r.source_id === "usgov-hrsa-fqhc-H80CS00007")!
		expect(row.components.house_number).toBeUndefined()
		expect(row.components.street).toBe("PO Box 1234")
	})

	it("hyphenated NYC-style house number splits cleanly", async () => {
		await runAdapter({
			adapter: createUSGovHRSAFQHCAdapter(),
			adapterOptions: { inputPath: fixtureCSV },
			outputDir: scratch.path,
			corpusVersion: "0.1.0",
		})

		const rows = await loadRows()
		const row = rows.find((r) => r.source_id === "usgov-hrsa-fqhc-H80CS00008")!
		expect(row.components.house_number).toBe("40-12")
		expect(row.components.street).toBe("Bell Blvd")
	})

	it("drops rows whose state is not a recognized USPS abbreviation", async () => {
		await runAdapter({
			adapter: createUSGovHRSAFQHCAdapter(),
			adapterOptions: { inputPath: fixtureCSV },
			outputDir: scratch.path,
			corpusVersion: "0.1.0",
		})

		const rows = await loadRows()
		expect(rows.find((r) => r.source_id === "usgov-hrsa-fqhc-H80CS00010")).toBeUndefined()
	})

	it("drops rows missing a venue (empty Site Name)", async () => {
		await runAdapter({
			adapter: createUSGovHRSAFQHCAdapter(),
			adapterOptions: { inputPath: fixtureCSV },
			outputDir: scratch.path,
			corpusVersion: "0.1.0",
		})

		const rows = await loadRows()
		expect(rows.find((r) => r.source_id === "usgov-hrsa-fqhc-H80CS00009")).toBeUndefined()
	})

	it("rejects non-US --country", async () => {
		await expect(
			runAdapter({
				adapter: createUSGovHRSAFQHCAdapter(),
				adapterOptions: { inputPath: fixtureCSV, country: "FR" },
				outputDir: scratch.path,
				corpusVersion: "0.1.0",
			})
		).rejects.toThrow(/only US supported/)
	})

	it("honors --limit", async () => {
		const m = await runAdapter({
			adapter: createUSGovHRSAFQHCAdapter(),
			adapterOptions: { inputPath: fixtureCSV, limit: 3 },
			outputDir: scratch.path,
			corpusVersion: "0.1.0",
		})

		expect(m.yielded).toBe(3)
		expect(m.written).toBe(3)
	})

	it("two runs against the same fixture produce identical sha256", async () => {
		const a = await runAdapter({
			adapter: createUSGovHRSAFQHCAdapter(),
			adapterOptions: { inputPath: fixtureCSV },
			outputDir: scratch.path,
			corpusVersion: "0.1.0",
		})

		await removePathIfPresent(join(scratch.path, USGOV_HRSA_FQHC_ADAPTER_ID))

		const b = await runAdapter({
			adapter: createUSGovHRSAFQHCAdapter(),
			adapterOptions: { inputPath: fixtureCSV },
			outputDir: scratch.path,
			corpusVersion: "0.1.0",
		})

		expect(a.sha256).toBe(b.sha256)
	})
})
