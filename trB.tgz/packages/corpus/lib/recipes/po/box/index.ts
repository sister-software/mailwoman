/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   `po-box` recipe — synthetic PO box rows: tuples → {@link synthesizePoBoxRow} → aligned
 *   LabeledRow, plus optional self-contained US military/diplomatic rows (#517) at
 *   `--military-ratio`. Region is required except region-less locales (NZ). Ported from the root
 *   build script it replaced.
 */

import { makeLcg } from "@mailwoman/core/utils"

import {
	alignAndWrite,
	readTuples,
	recipeSourceID,
	SYNTHETIC_TUPLE_LICENSE as LICENSE,
	type CorpusRecipe,
} from "#recipes/scaffold"
import { synthesizeMilitaryPoBoxRow, synthesizePoBoxRow, type PoBoxBaseTuple } from "#synthesizers/po-box"

/**
 * Recipe registered with the corpus builder — see the file header for the parse behaviour
 * it exists to exercise, and `description` below for the surface form it generates.
 */
export const poBoxRecipe: CorpusRecipe = {
	name: "po-box",
	description: "PO box rows: tuples → synthesizePoBoxRow (+ optional US military/diplomatic rows)",
	mode: "tuples",
	options: [
		{ flag: "--pmb-ratio <p>", description: "P(private-mailbox layout). Default 0.15" },
		{ flag: "--military-ratio <p>", description: "P(emit one US military/diplomatic row per input, #517). Default 0" },
	],
	async run(opts, write) {
		if (!opts.input) throw new Error("po-box recipe requires --input <tuples.jsonl>")
		const random = makeLcg(opts.seed)
		const pmbRatio = opts.pmbRatio ?? 0.15
		const militaryRatio = opts.militaryRatio ?? 0
		// `--source-name` so an output built for one class carries its own source label
		// and its own reps per row.
		// A military-only output (`--variants 0 --military-ratio 1`) is otherwise indistinguishable from
		// the leader-template rows in the mixture, and the two are weighted for different reasons (#517).
		const source = opts.sourceName ?? "synth-po-box"
		let read = 0
		let emitted = 0
		let skipped = 0

		for await (const tuple of readTuples(opts.input)) {
			read++
			// Region required except region-less locales (NZ: "Private Bag 12, Auckland 1010", #517).
			const regionOptional = ["NZ", "NZL", "NEW ZEALAND"].includes(String(tuple.country || "").toUpperCase())

			if (!tuple.locality || !tuple.postcode || !tuple.country || (!tuple.region && !regionOptional)) {
				skipped++

				continue
			}

			for (let v = 0; v < opts.variants; v++) {
				const synth = synthesizePoBoxRow(tuple as PoBoxBaseTuple, { random, pmbRatio })

				if (!synth) continue

				const ok = alignAndWrite(
					write,
					{
						raw: synth.raw,
						components: synth.components,
						country: tuple.country,
						locale: synth.locale,
						source,
						source_id: recipeSourceID(source, {
							locality: tuple.locality,
							region: tuple.region,
							postcode: tuple.postcode,
							country: tuple.country,
							v: String(v),
						}),
						corpus_version: "0.4.0",
						license: LICENSE,
					},
					synth.template
				)

				if (ok) {
					emitted++
				} else {
					skipped++
				}
			}

			// US military/diplomatic rows (#517): self-contained, one per input line at --military-ratio.
			// Default 0 → byte-stable (random() not called when off).
			// US-only.
			if (militaryRatio > 0 && random() < militaryRatio) {
				const mil = synthesizeMilitaryPoBoxRow({ random })

				const ok = alignAndWrite(
					write,
					{
						raw: mil.raw,
						components: mil.components,
						country: "US",
						locale: mil.locale,
						source,
						source_id: recipeSourceID(source, {
							po_box: mil.components.po_box,
							locality: mil.components.locality,
							region: mil.components.region,
							postcode: mil.components.postcode,
							v: `mil${emitted}`,
						}),
						corpus_version: "0.4.0",
						license: LICENSE,
					},
					mil.template
				)

				if (ok) {
					emitted++
				} else {
					skipped++
				}
			}
		}

		return { read, emitted, skipped }
	},
}
