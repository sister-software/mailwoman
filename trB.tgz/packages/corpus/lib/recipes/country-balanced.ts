/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   `country-balanced` recipe — the balanced, model-first country-coverage recipe (#464). The
 *   shipped model is starved on `country` (P=R=F1=0 on the homograph eval), so this fills the void
 *   the way the `unit` recipe did, but built to avoid over-firing "trailing token ⇒ country". Three
 *   ingredients, ported faithfully from the root build script it replaced:
 *
 *   1. Breadth/recall — real OA skeletons (US/DE/FR/IT/NL) with a country token in a varied surface form
 *        from `@mailwoman/codex/country` (canonical / endonym / ISO code), + ~30% country-absent
 *        negatives (teach O-emission, the precision floor).
 *   2. Homograph contrast pairs — each true country-name homograph (Georgia, Jordan, Lebanon, Mexico,
 *        Peru, Turkey) rendered both ways: as `country` (foreign-city context) and as the US
 *        `region`/`locality` (US-ZIP context). Teaches that the label is contextual rather than
 *        positional.
 *   3. Code-as-region negatives — 2-letter codes that are both a US state abbrev and an ISO country code
 *        (CA/GA/IN/MA/PA/AL) in US-ZIP context → must read as `region`, never `country`.
 *
 *   `--golden` emits a held-out synthetic val over the VT (US) + Berlin (DE) holdouts. This is a
 *   `generate`-mode recipe that still reads real tuples off disk — `--count` bounds the output rather than
 *   the input. The passed `random` (the framework LCG) is consumed in the exact call order the
 *   legacy script used.
 */

import type { ComponentTag } from "@mailwoman/codex/component"
import { COUNTRY_SURFACE_FORMS, CountryNames } from "@mailwoman/codex/country"
import { dataRootPath } from "@mailwoman/core/data-root"
import { stringifyJSON } from "@mailwoman/core/json"
import { isPresent } from "@mailwoman/core/objects"
import { sample } from "@mailwoman/core/random"
import { mulberry32 as makeMulberry32 } from "@mailwoman/core/utils"
import type { PathBuilderLike } from "path-ts"

import { stableSourceID } from "#adapters/utils"
import { readOATuples, type CorpusRecipe } from "#recipes/scaffold"
import type { CanonicalRow } from "#types"
import { alignRow } from "#utils"

// v2: the country token is decoupled from the skeleton's locale and drawn from a broad pool —
// every ISO canonical name + every curated surface form (endonyms/abbrevs).
// Surface forms are over-weighted so endonyms/abbrevs ("Deutschland","USA","NL") get strong signal.

const COUNTRY_FORM_POOL = (() => {
	const surface = Object.values(COUNTRY_SURFACE_FORMS).flat() // endonyms + abbrevs + canonical (curated)
	const names = [...CountryNames]

	// all ~249 ISO canonical English names (breadth)
	return { surface, names }
})()

/**
 * Negatives: rows with no country token → teach golden precision.
 */
const COUNTRY_ABSENT_PROB = 0.3

/**
 * A cached OpenAddresses extract + the implied iso2/region/render-order.
 */
interface CountrySource {
	zip: PathBuilderLike
	csv: string
	iso2: string
	region: string
	order: string
}

/**
 * Multi-locale OA sources. region = implied admin where the extract is single-region
 * (US states, DE Saxony); countrywide extracts (FR/IT/NL) read region from the CSV when present.
 */
const SOURCES: readonly CountrySource[] = [
	{
		zip: dataRootPath("oa-cache", "us__ia__statewide.zip"),
		csv: "us/ia/statewide.csv",
		iso2: "US",
		region: "IA",
		order: "us",
	},
	{ zip: dataRootPath("oa-cache", "us__il__cook.zip"), csv: "us/il/cook.csv", iso2: "US", region: "IL", order: "us" },
	{
		zip: dataRootPath("oa-cache", "us__mt__statewide.zip"),
		csv: "us/mt/statewide.csv",
		iso2: "US",
		region: "MT",
		order: "us",
	},
	{
		zip: dataRootPath("oa-cache", "us__sd__statewide.zip"),
		csv: "us/sd/statewide.csv",
		iso2: "US",
		region: "SD",
		order: "us",
	},
	{
		zip: dataRootPath("oa-cache", "de__sn__statewide.zip"),
		csv: "de/sn/statewide.csv",
		iso2: "DE",
		region: "",
		order: "eu",
	},
	{
		zip: dataRootPath("oa-cache", "fr__countrywide.zip"),
		csv: "fr/countrywide.csv",
		iso2: "FR",
		region: "",
		order: "fr",
	},
	// ES uses the Spanish IGN schema rather than the OA standard columns — skipped here (codex still recognizes
	// "España"/"Spain"). A dedicated IGN adapter is a follow-up.
	{
		zip: dataRootPath("oa-cache", "it__countrywide.zip"),
		csv: "it/countrywide.csv",
		iso2: "IT",
		region: "",
		order: "eu",
	},
	{
		zip: dataRootPath("oa-cache", "nl__countrywide.zip"),
		csv: "nl/countrywide.csv",
		iso2: "NL",
		region: "",
		order: "eu",
	},
]

/**
 * Held-out for --golden: Vermont (US holdout) + Berlin (DE holdout) — geographic split, never trained.
 */
const EVAL_SOURCES: readonly CountrySource[] = [
	{
		zip: dataRootPath("oa-cache", "us__vt__statewide.zip"),
		csv: "us/vt/statewide.csv",
		iso2: "US",
		region: "VT",
		order: "us",
	},
	{ zip: dataRootPath("oa-cache", "de__berlin.zip"), csv: "de/berlin.csv", iso2: "DE", region: "", order: "eu" },
]

/**
 * A real tuple read out of a cached OA zip (+ the source's iso2/render-order).
 */
interface CountryTuple {
	house_number: string
	street: string
	locality: string
	region: string
	postcode: string
	iso2: string
	order: string
}

/**
 * The countrywide extracts (FR/IT/NL) are GB-scale, so this reads only as far as `limit` distinct tuples:
 * the `break` closes the reader, which releases the archive without inflating the rest of the member.
 */
async function readTuples(source: CountrySource, limit: number): Promise<CountryTuple[]> {
	return readOATuples(source, {
		limit,
		extra: (fields, row) => ({
			...fields,
			region: row.region || source.region,
			iso2: source.iso2,
			order: source.order,
		}),
	})
}

// After the absent draw: 60% curated surface forms (endonym/abbrev variety), 40% broad ISO canonical names.
const SURFACE_FORM_SHARE = 0.6

/**
 * Pick a country token from the broad pool, or null (a country-absent negative). v2.
 */
function pickCountry(random: () => number): string | null {
	if (random() < COUNTRY_ABSENT_PROB) return null // negative — teaches "trailing token != always country"
	const pool = random() < SURFACE_FORM_SHARE ? COUNTRY_FORM_POOL.surface : COUNTRY_FORM_POOL.names

	return sample(pool, random)
}

// country-containing rows: 80% full, 12% full-nl, 8% bare.
const FULL_CUTOFF = 0.8
const FULL_NEWLINE_CUTOFF = 0.92

/**
 * Render the address body in native-ish order.
 *
 * `country` null → a country-absent negative row.
 */
function renderCountry(
	random: () => number,
	t: CountryTuple,
	country: string | null
): { fmt: string; raw: string; components: Partial<Record<ComponentTag, string>> } {
	const { house_number: hn, street, locality: loc, region: reg, postcode: pc, order } = t
	const components: Partial<Record<ComponentTag, string>> = { house_number: hn, street, locality: loc }

	if (reg) {
		components.region = reg
	}

	if (pc) {
		components.postcode = pc
	}

	let body: string

	if (order === "us") {
		const regPc = [reg, pc].filter(isPresent).join(" ")
		body = `${hn} ${street}, ${loc}${regPc ? ", " + regPc : ""}`
	} else if (order === "fr") {
		// French is number-street, postcode-city: "84 Route de la Fontaine, 75008 Paris".
		body = `${hn} ${street}, ${[pc, loc].filter(isPresent).join(" ")}`
	} else {
		// DE/IT/NL: street-number, postcode-city: "Pariser Platz 1, 10117 Berlin".
		const pcCity = [pc, loc].filter(isPresent).join(" ")
		body = `${street} ${hn}, ${pcCity}`
	}

	if (!country) {
		// Negative: a normal address, no country token/component.
		// Teaches that a trailing region/city/ postcode is not a country (counters the v1 golden over-firing).
		return { fmt: "negative", raw: body, components }
	}

	const withC: Partial<Record<ComponentTag, string>> = { ...components, country }
	const r = random()

	if (r < FULL_CUTOFF) return { fmt: "full", raw: `${body}, ${country}`, components: withC }

	if (r < FULL_NEWLINE_CUTOFF) return { fmt: "full-nl", raw: `${body}\n${country}`, components: withC }
	const bareBody = order === "us" || order === "fr" ? `${hn} ${street}, ${loc}` : `${street} ${hn}, ${loc}`

	return {
		fmt: "bare",
		raw: `${bareBody}, ${country}`,
		components: { house_number: hn, street, locality: loc, country },
	}
}

// ── Homograph contrast (the model-first addition) ───────────────────────────────────────────────
// True country-name homographs: the surface form is both a country and a US state/locality.
// Rendering each both ways (foreign-city → country. US-ZIP → region/locality) is what
// teaches the contextual distinction. role: how the surface reads in US context.
interface Homograph {
	surface: string
	iso2: string
	cities: readonly string[]
	us: { role: "region" | "locality"; locality: string; region: string; postcodes: readonly string[] }
}

const HOMOGRAPHS: readonly Homograph[] = [
	{
		surface: "Georgia",
		iso2: "GE",
		cities: ["Tbilisi", "Batumi", "Kutaisi", "Rustavi"],
		us: { role: "region", locality: "Atlanta", region: "Georgia", postcodes: ["30309", "31401", "30601", "31201"] },
	},
	{
		surface: "Jordan",
		iso2: "JO",
		cities: ["Amman", "Irbid", "Zarqa", "Aqaba"],
		us: { role: "locality", locality: "Jordan", region: "MN", postcodes: ["55352"] },
	},
	{
		surface: "Lebanon",
		iso2: "LB",
		cities: ["Beirut", "Tripoli", "Sidon", "Byblos"],
		us: { role: "locality", locality: "Lebanon", region: "TN", postcodes: ["37087", "03766", "17042", "45036"] },
	},
	{
		surface: "Mexico",
		iso2: "MX",
		cities: ["Guadalajara", "Monterrey", "Puebla", "Oaxaca"],
		us: { role: "locality", locality: "Mexico", region: "MO", postcodes: ["65265"] },
	},
	{
		surface: "Peru",
		iso2: "PE",
		cities: ["Cusco", "Arequipa", "Trujillo", "Iquitos"],
		us: { role: "locality", locality: "Peru", region: "IL", postcodes: ["61354", "46970"] },
	},
	{
		surface: "Turkey",
		iso2: "TR",
		cities: ["Ankara", "Izmir", "Bursa", "Antalya"],
		us: { role: "locality", locality: "Turkey", region: "TX", postcodes: ["79261", "28393"] },
	},
]

// 2-letter codes that are both a US state abbrev and an ISO country code → must read as region in US ctx.
interface AbbrevRegion {
	code: string
	localities: readonly string[]
	postcodes: readonly string[]
}

const ABBREV_REGIONS: readonly AbbrevRegion[] = [
	{ code: "CA", localities: ["Los Angeles", "Sacramento", "San Diego"], postcodes: ["90012", "95814", "92101"] }, // California / Canada
	{ code: "GA", localities: ["Atlanta", "Savannah", "Macon"], postcodes: ["30309", "31401", "31201"] }, // Georgia(US) / Georgia
	{ code: "IN", localities: ["Indianapolis", "Fort Wayne"], postcodes: ["46204", "46802"] }, // Indiana / India
	{ code: "MA", localities: ["Boston", "Worcester"], postcodes: ["02108", "01608"] }, // Massachusetts / Morocco
	{ code: "PA", localities: ["Philadelphia", "Pittsburgh"], postcodes: ["19103", "15222"] }, // Pennsylvania / Panama
	{ code: "AL", localities: ["Birmingham", "Montgomery"], postcodes: ["35203", "36104"] }, // Alabama / Albania
]

const STREET_POOL: readonly string[] = [
	"Main Street",
	"Oak Avenue",
	"Park Road",
	"Elm Street",
	"Hill Road",
	"Market Street",
	"Church Street",
	"King Street",
	"2nd Avenue",
	"Maple Drive",
]

const houseNo = (random: () => number): string => String(1 + Math.floor(random() * 998))

// Country-surface homograph rows: 60% carry a street line, 40% are a bare `city, surface`.
const HOMOGRAPH_WITH_STREET_SHARE = 0.6

/**
 * A homograph contrast row: ~half render the surface as `country` (foreign city),
 * half as the US `region`/`locality` (US ZIP, no country).
 *
 * Returns iso2 for provenance.
 */
function renderHomograph(random: () => number): {
	fmt: string
	raw: string
	components: Partial<Record<ComponentTag, string>>
	iso2: string
} {
	const h = sample(HOMOGRAPHS, random)

	const hn = houseNo(random),
		street = sample(STREET_POOL, random)

	if (random() < 0.5) {
		const city = sample(h.cities, random)
		const withStreet = random() < HOMOGRAPH_WITH_STREET_SHARE
		const raw = withStreet ? `${hn} ${street}, ${city}, ${h.surface}` : `${city}, ${h.surface}`

		const components: Partial<Record<ComponentTag, string>> = withStreet
			? { house_number: hn, street, locality: city, country: h.surface }
			: { locality: city, country: h.surface }

		return { fmt: "homograph-country", raw, components, iso2: h.iso2 }
	}

	const pc = sample(h.us.postcodes, random)

	if (h.us.role === "region") {
		// surface is the US state: "123 Oak Ave, Atlanta, Georgia 30309" → region, no country
		return {
			fmt: "homograph-us-region",
			raw: `${hn} ${street}, ${h.us.locality}, ${h.surface} ${pc}`,
			components: { house_number: hn, street, locality: h.us.locality, region: h.surface, postcode: pc },
			iso2: "US",
		}
	}

	// surface is the US city: "123 Oak Ave, Lebanon, TN 37087" → locality, no country
	return {
		fmt: "homograph-us-locality",
		raw: `${hn} ${street}, ${h.surface}, ${h.us.region} ${pc}`,
		components: { house_number: hn, street, locality: h.surface, region: h.us.region, postcode: pc },
		iso2: "US",
	}
}

/**
 * An abbrev-as-region negative: "123 Main St, Los Angeles, CA 90012" → region CA, no country.
 */
function renderAbbrevRegion(random: () => number): {
	fmt: string
	raw: string
	components: Partial<Record<ComponentTag, string>>
	iso2: string
} {
	const a = sample(ABBREV_REGIONS, random)

	const hn = houseNo(random),
		street = sample(STREET_POOL, random),
		locality = sample(a.localities, random),
		postcode = sample(a.postcodes, random)

	return {
		fmt: "abbrev-region",
		raw: `${hn} ${street}, ${locality}, ${a.code} ${postcode}`,
		components: { house_number: hn, street, locality, region: a.code, postcode },
		iso2: "US",
	}
}

/**
 * Share of rows that are homograph contrast pairs.
 */
const HOMOGRAPH_FRAC = 0.22
/**
 * Share that are code-as-region negatives (cumulative with HOMOGRAPH_FRAC)
 */
const ABBREV_FRAC = 0.08

/**
 * Recipe registered with the corpus builder — see the file header for the parse behaviour
 * it exists to exercise, and `description` below for the surface form it generates.
 */
export const countryBalancedRecipe: CorpusRecipe = {
	name: "country-balanced",
	description: "Balanced model-first country rows (#464): OA skeletons + ISO surface forms + homograph contrast pairs",
	mode: "generate",
	options: [{ flag: "--golden", description: "Emit the held-out VT+Berlin eval set" }],
	async run(opts, write) {
		if (opts.count == null) throw new Error("country-balanced recipe requires --count <N>")
		const count = opts.count
		// The root build script this recipe replaced seeded mulberry32 with the raw
		// seed: `const random = mulberry32(opts.seed)`.
		const random = makeMulberry32(opts.seed)
		const source = opts.sourceName ?? "synth-country"
		const sources = opts.golden ? EVAL_SOURCES : SOURCES
		const perSource = Math.ceil((count * 3) / sources.length) // over-read. balance locales

		const pool: CountryTuple[] = []

		for (const s of sources) {
			const t = await readTuples(s, perSource)

			console.error(`  ${s.csv} (${s.iso2}): ${t.length} tuples`)

			for (const x of t) {
				pool.push(x)
			}
		}

		if (!pool.length) {
			throw new Error(`No tuples — are the cached OA zips present in ${dataRootPath("oa-cache")}?`)
		}

		let emitted = 0
		let skipped = 0
		let guard = 0
		const N = pool.length

		while (emitted < count && guard++ < count * 8) {
			// Mix three row types: homograph contrast (the distinction), code-as-region negatives,
			// and the breadth/recall main path (random ISO form on an OA skeleton, ~30% country-absent).
			const roll = random()
			let rendered: { fmt: string; raw: string; components: Partial<Record<ComponentTag, string>> }
			let rowISO2: string

			if (roll < HOMOGRAPH_FRAC) {
				const h = renderHomograph(random)
				rendered = h
				rowISO2 = h.iso2
			} else if (roll < HOMOGRAPH_FRAC + ABBREV_FRAC) {
				const a = renderAbbrevRegion(random)
				rendered = a
				rowISO2 = a.iso2
			} else {
				const t = pool[Math.floor(random() * N)]!
				const country = pickCountry(random) // may be null → a country-absent negative row
				rendered = renderCountry(random, t, country)
				rowISO2 = t.iso2

				if (country && !rendered.raw.includes(country)) {
					skipped++

					continue
				}
			}

			const { raw, components } = rendered
			const localeTag = rowISO2 === "US" ? "en-US" : `${rowISO2.toLowerCase()}-${rowISO2}`

			if (opts.golden) {
				write(stringifyJSON({ raw, components, country: rowISO2 }))

				emitted++

				continue
			}

			const canonical: CanonicalRow = {
				raw,
				components,
				country: rowISO2,
				locale: localeTag,
				source,
				source_id: stableSourceID(source, components),
				corpus_version: "0.4.0",
				license: "OpenAddresses multi-locale skeletons + injected ISO-3166 country surface forms (codex)",
			}

			const aligned = alignRow(canonical)

			if (aligned.kind !== "labeled" || !aligned.row) {
				skipped++

				continue
			}

			write(stringifyJSON({ ...aligned.row, synth_method: "country", synth_base_id: null }))

			emitted++
		}

		return { emitted, skipped }
	},
}
