/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 */

import { removePathIfPresent, writeLocalTextFile, writeLocalJSONLFile } from "@mailwoman/core/fs/writers"
import { stringifyJSON } from "@mailwoman/core/json"
import {
	OVERTURE_ADAPTER_ID,
	OVERTURE_DEFAULT_LICENSE,
	createOvertureAdapter,
	unitFieldIsDesignator,
} from "@mailwoman/corpus/adapters/overture/adapter"
import { runAdapter } from "@mailwoman/corpus/runner"
import { readCanonicalRows, useScratchDir } from "@mailwoman/corpus/test-kit"
import { join } from "path-ts"
import { describe, expect, it } from "vitest"

const scratch = useScratchDir("ov")

const loadRows = () => readCanonicalRows(scratch.path, OVERTURE_ADAPTER_ID)

/**
 * Write a per-country Overture corpus jsonl fixture
 * (the shape `ingest-overture-addresses.ts --corpus-jsonl` emits).
 */
async function writeFixture(rows: Record<string, unknown>[]): Promise<string> {
	const p = join(scratch.path, "overture-es.corpus.jsonl")
	await writeLocalJSONLFile(rows, p)

	return p
}

const ES = [
	{ street: "CALLE JULAN", number: "12", unit: null, postcode: "38914", locality: "El Pinar de El Hierro" },
	{ street: "CALLE HIBRONES", number: "S-N", unit: null, postcode: "38914", locality: "El Pinar de El Hierro" },
	{ street: "AVENIDA DE LA CONSTITUCION", number: "3", unit: "2A", postcode: "28013", locality: "Madrid" },
]

describe("unitFieldIsDesignator", () => {
	it("keeps a digit-containing or one-word unit and drops a name or NIL", () => {
		expect(unitFieldIsDesignator("2A")).toBe(true)
		expect(unitFieldIsDesignator("#05-67")).toBe(true)
		expect(unitFieldIsDesignator("EG")).toBe(true)
		expect(unitFieldIsDesignator("Penthouse")).toBe(true)
		expect(unitFieldIsDesignator("NIL")).toBe(false)
		expect(unitFieldIsDesignator("nil")).toBe(false)
		expect(unitFieldIsDesignator("SERANGOON GARDEN ESTATE")).toBe(false)
		expect(unitFieldIsDesignator("NATIONAL SHOOTING CENTRE")).toBe(false)
		expect(unitFieldIsDesignator("  ")).toBe(false)
	})
})

describe("overture adapter", () => {
	it("never emits an estate or building name, or NIL, as a unit — the Singapore register's shape", async () => {
		const input = await writeFixture([
			{
				street: "OLD CHOA CHU KANG ROAD",
				number: "990",
				unit: "NATIONAL SHOOTING CENTRE",
				postcode: "699814",
				locality: "Singapore",
			},
			{ street: "SERANGOON GARDEN WAY", number: "12", unit: "NIL", postcode: "555933", locality: "Singapore" },
			{ street: "ANG MO KIO AVENUE 3", number: "123", unit: "#05-67", postcode: "560123", locality: "Singapore" },
		])

		await runAdapter({
			adapter: createOvertureAdapter(),
			adapterOptions: { inputPath: input, country: "SG" },
			outputDir: scratch.path,
			corpusVersion: "0.1.0",
		})

		const rows = await loadRows()

		expect(rows).toHaveLength(3)
		expect(rows.map((r) => r.components.unit ?? null)).toEqual([null, null, "#05-67"])
	})

	it("emits a row per JSONL line, stamping country from --country and source=overture", async () => {
		const input = await writeFixture(ES)

		const manifest = await runAdapter({
			adapter: createOvertureAdapter(),
			adapterOptions: { inputPath: input, country: "ES" },
			outputDir: scratch.path,
			corpusVersion: "0.1.0",
		})

		expect(manifest.yielded).toBe(3)
		const rows = await loadRows()
		expect(rows).toHaveLength(3)
		expect(rows.every((r) => r.country === "ES")).toBe(true)
		expect(rows.every((r) => r.source === OVERTURE_ADAPTER_ID)).toBe(true)
		expect(rows.every((r) => r.license === OVERTURE_DEFAULT_LICENSE)).toBe(true)
	})

	it("keeps the street keyword WHOLE (affix-relabel splits the prefix downstream)", async () => {
		const input = await writeFixture(ES)

		await runAdapter({
			adapter: createOvertureAdapter(),
			adapterOptions: { inputPath: input, country: "ES" },
			outputDir: scratch.path,
			corpusVersion: "0.1.0",
		})

		const rows = await loadRows()
		const julan = rows.find((r) => r.raw.includes("CALLE JULAN"))

		expect(julan?.components).toMatchObject({
			house_number: "12",
			street: "CALLE JULAN",
			postcode: "38914",
			locality: "El Pinar de El Hierro",
		})

		expect(julan?.raw).toContain("38914")
		expect(julan?.raw).toContain("El Pinar de El Hierro")
		// street_prefix is not split here — that's the downstream affix-relabel's job.
		expect(julan?.components.street_prefix).toBeUndefined()
	})

	it("treats 'S-N' / 'S/N' (sin número) as no house number", async () => {
		const input = await writeFixture(ES)

		await runAdapter({
			adapter: createOvertureAdapter(),
			adapterOptions: { inputPath: input, country: "ES" },
			outputDir: scratch.path,
			corpusVersion: "0.1.0",
		})

		const sinNumero = (await loadRows()).find((r) => r.raw.includes("CALLE HIBRONES"))
		expect(sinNumero?.components.house_number).toBeUndefined()
		expect(sinNumero?.raw).not.toContain("S-N")
	})

	it("includes unit when present", async () => {
		const input = await writeFixture(ES)

		await runAdapter({
			adapter: createOvertureAdapter(),
			adapterOptions: { inputPath: input, country: "ES" },
			outputDir: scratch.path,
			corpusVersion: "0.1.0",
		})

		const madrid = (await loadRows()).find((r) => r.raw.includes("Madrid"))
		expect(madrid?.components.unit).toBe("2A")
	})

	it("rejects an invocation without --country", async () => {
		const input = await writeFixture(ES)

		await expect(
			runAdapter({
				adapter: createOvertureAdapter(),
				adapterOptions: { inputPath: input },
				outputDir: scratch.path,
				corpusVersion: "0.1.0",
			})
		).rejects.toThrow(/--country is required/)
	})

	it("honors --limit", async () => {
		const input = await writeFixture(ES)

		const manifest = await runAdapter({
			adapter: createOvertureAdapter(),
			adapterOptions: { inputPath: input, country: "ES", limit: 2 },
			outputDir: scratch.path,
			corpusVersion: "0.1.0",
		})

		expect(manifest.yielded).toBe(2)
	})

	it("skips blanks, comments, garbage, and street-less rows", async () => {
		const p = join(scratch.path, "messy.jsonl")

		await writeLocalTextFile(
			[
				"",
				"# comment",
				"{not json}",
				stringifyJSON({ postcode: "28013", locality: "Madrid" }), // no street → skip
				stringifyJSON({ street: "PLAZA MAYOR", number: "1", postcode: "28012", locality: "Madrid" }),
				"",
			],
			p
		)

		const manifest = await runAdapter({
			adapter: createOvertureAdapter(),
			adapterOptions: { inputPath: p, country: "ES" },
			outputDir: scratch.path,
			corpusVersion: "0.1.0",
		})

		expect(manifest.yielded).toBe(1)
		expect((await loadRows())[0]?.components.street).toBe("PLAZA MAYOR")
	})

	it("two runs over the same dump produce identical sha256", async () => {
		const input = await writeFixture(ES)

		const a = await runAdapter({
			adapter: createOvertureAdapter(),
			adapterOptions: { inputPath: input, country: "ES" },
			outputDir: scratch.path,
			corpusVersion: "0.1.0",
		})

		await removePathIfPresent(join(scratch.path, OVERTURE_ADAPTER_ID))

		const b = await runAdapter({
			adapter: createOvertureAdapter(),
			adapterOptions: { inputPath: input, country: "ES" },
			outputDir: scratch.path,
			corpusVersion: "0.1.0",
		})

		expect(a.sha256).toBe(b.sha256)
	})
})
