/**
 * @copyright Sister Software
 * @license AGPL-3.0
 * @author Teffen Ellis, et al.
 *
 *   Assemble a sampled, component-labeled Australian address set from G-NAF (the Geocoded National
 *   Address File — Geoscape Australia, Open G-NAF licence. any derived artifact must attribute
 *   "Geoscape Australia"). G-NAF is a relational PSV distribution (~16.9M addresses);
 *   reconstructing a street address joins three tables — ADDRESS_DETAIL (number, postcode, the
 *   PIDs) → STREET_LOCALITY (street name + type) → locality (suburb). State is the per-file prefix
 *   (ACT/NSW/…).
 *
 *   Streaming + in-memory join via the house {@link PSVSpliterator} (pipe-separated. header names key each row) — not
 *   raw `read_csv` SQL, which a flat-file join doesn't need and
 *   which the #183–190 cleanup retired. The two lookup tables (STREET_LOCALITY ~765k rows, locality
 *   ~16k) fit as Maps. ADDRESS_DETAIL is streamed once and reservoir-sampled, so memory stays
 *   bounded (the OOM lesson from the Overture ingest).
 *
 *   No coordinates: the output feeds the parser ({@link ../gnaf/adapter}, #208) — teaching the model
 *   AU's postcode-first / house-number-last word order, the gap `scripts/eval/au-order-probe.ts`
 *   pinned (65%→87% if the parse were order-robust). The parser needs the address string +
 *   component labels rather than lat/lon.
 *
 *   Output: component tuples as jsonl, consumed by the `gnaf` corpus adapter (which renders them in
 *   multiple orders + the corpus aligner BIO-labels them). An optional held-out eval set is
 *   excluded by (street, locality, postcode) so the training corpus never overlaps the benchmark.
 */

import { tryParsingJSON, stringifyJSON } from "@mailwoman/core/json"
import { join } from "path-ts"
import { createNewlineWriter, PSVSpliterator, TextSpliterator } from "spliterator"
import { Globerator } from "spliterator/node/fs"

export interface GNAFAssembleOptions {
	/**
	 * G-NAF `Standard` directory (holds the per-state `*_psv.psv` tables).
	 */
	standardDir: string
	/**
	 * Target sample size (uniform reservoir → population-proportional across states).
	 */
	sampleSize: number
	/**
	 * Output jsonl path.
	 */
	out: string
	/**
	 * Optional held-out eval jsonl (rows with a `components` field) —
	 * its (street,locality,postcode) are excluded.
	 */
	holdoutPath?: string
	/**
	 * Progress sink (the CLI passes a setter).
	 */
	onProgress?: (message: string) => void
}

export interface GNAFAssembleResult {
	written: number
	seen: number
	heldOut: number
	byState: Record<string, number>
}

/**
 * Uppercase → Title Case, preserving intra-word apostrophes/hyphens (O'Brien, Coff's Harbour).
 */
export function titlecase(s: string): string {
	return s
		.toLowerCase()
		.replaceAll(/(^|[\s'\-/])([a-z])/g, (_m, p: string, c: string) => p + c.toUpperCase())
		.trim()
}

/**
 * Holdout/dedup key: a street within a locality+postcode (house-number-agnostic — conservative).
 */
export function gnafHoldoutKey(street: string, locality: string, postcode: string): string {
	return `${street}|${locality}|${postcode}`.toLowerCase()
}

type Row = Record<string, string | number | undefined>

async function* psvObjects(path: string): AsyncIterable<Row> {
	yield* PSVSpliterator.fromAsync(path) as AsyncIterable<Row>
}

/**
 * Load a small lookup table fully into a Map keyed by `keyCol`.
 */
async function loadMap<V>(paths: string[], keyCol: string, pick: (r: Row) => V): Promise<Map<string, V>> {
	const m = new Map<string, V>()

	for (const p of paths) {
		for await (const r of psvObjects(p)) {
			const k = r[keyCol]

			if (k != null && k !== "") {
				m.set(String(k), pick(r))
			}
		}
	}

	return m
}

/**
 * Build the held-out key set from an eval jsonl whose rows carry a `components` object.
 */
async function loadHoldout(path: string): Promise<Set<string>> {
	const keys = new Set<string>()

	for await (const line of TextSpliterator.fromAsync(path)) {
		if (!line.trim()) continue

		const c = tryParsingJSON<{ components?: Record<string, string> }>(line)?.components

		if (c?.street && c?.locality && c?.postcode) {
			keys.add(gnafHoldoutKey(c.street, c.locality, c.postcode))
		}
	}

	return keys
}

export async function assembleGNAF(opts: GNAFAssembleOptions): Promise<GNAFAssembleResult> {
	const progress = opts.onProgress ?? (() => {})
	const files = await Globerator.from("*", { cwd: opts.standardDir, absolute: false }).toArray()

	const pick = (re: RegExp, exclude?: RegExp) =>
		files.filter((f) => re.test(f) && !(exclude && exclude.test(f))).map((f) => join(opts.standardDir, f))

	// `*_LOCALITY_psv.psv` also globs `*_STREET_LOCALITY_psv.psv` — exclude the latter explicitly.
	const streetPaths = pick(/_STREET_LOCALITY_psv\.psv$/)
	const localityPaths = pick(/_LOCALITY_psv\.psv$/, /_STREET_LOCALITY_psv\.psv$/)
	const addressPaths = pick(/_ADDRESS_DETAIL_psv\.psv$/)

	const holdout = opts.holdoutPath ? await loadHoldout(opts.holdoutPath) : new Set<string>()

	if (opts.holdoutPath) {
		progress(`held-out eval keys: ${holdout.size}`)
	}

	progress(`loading STREET_LOCALITY (${streetPaths.length} files) + LOCALITY (${localityPaths.length})…`)

	const streetMap = await loadMap(streetPaths, "street_locality_pid", (r) => ({
		name: String(r.street_name ?? ""),
		type: String(r.street_type_code ?? ""),
		suffix: String(r.street_suffix_code ?? ""),
	}))

	const localityMap = await loadMap(localityPaths, "locality_pid", (r) => String(r.locality_name ?? ""))
	progress(`streets=${streetMap.size.toLocaleString()} localities=${localityMap.size.toLocaleString()}`)

	const reservoir: Array<{ house_number: string; street: string; locality: string; region: string; postcode: string }> =
		[]

	let seen = 0
	let heldOut = 0

	for (const p of addressPaths) {
		const state = (p.match(/\/([A-Z]+)_ADDRESS_DETAIL/) ?? [])[1] ?? ""

		for await (const r of psvObjects(p)) {
			const numberFirst = String(r.number_first ?? "")

			if (!numberFirst || r.date_retired || !r.postcode) continue
			const st = streetMap.get(String(r.street_locality_pid ?? ""))
			const suburbRaw = localityMap.get(String(r.locality_pid ?? ""))

			if (!st?.name || !suburbRaw) continue
			const street = `${titlecase(st.name)} ${titlecase(st.type)}${st.suffix ? " " + titlecase(st.suffix) : ""}`.trim()
			const locality = titlecase(suburbRaw)
			const postcode = String(r.postcode)

			if (holdout.has(gnafHoldoutKey(street, locality, postcode))) {
				heldOut++

				continue
			}

			let house = numberFirst + (r.number_first_suffix ? String(r.number_first_suffix) : "")

			if (r.number_last) {
				house = `${house}-${String(r.number_last)}`
			}

			if (r.flat_number) {
				house = `${String(r.flat_number)}/${house}`
			}

			const tuple = { house_number: house, street, locality, region: state, postcode }

			seen++

			if (reservoir.length < opts.sampleSize) {
				reservoir.push(tuple)
			} else {
				const j = Math.floor(Math.random() * seen)

				if (j < opts.sampleSize) {
					reservoir[j] = tuple
				}
			}
		}

		progress(`${state}: ${seen.toLocaleString()} valid joinable seen`)
	}

	const byState: Record<string, number> = {}

	{
		await using out = createNewlineWriter(opts.out)

		for (const t of reservoir) {
			await out.write(stringifyJSON(t))
			byState[t.region] = (byState[t.region] ?? 0) + 1
		}
	}

	progress(`wrote ${reservoir.length.toLocaleString()} tuples → ${opts.out}`)

	return { written: reservoir.length, seen, heldOut, byState }
}
